import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { createCombatPolicy, exerciseCounterstroke, recordCounterstrokeCues as recordCues } from './native-counterstroke-flow.mts';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL, HZ } = await repoImport('src/shared/protocol.ts');
const { measuredRules: component } = await repoImport('src/shared/swordsman-measured.ts');
const { counterstrokeIds, counterstrokeRules: rules } = await repoImport('src/shared/swordsman-counterstroke.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { swordGuardContact, swordCircleContact } = await repoImport('src/shared/sword-geometry.ts');
const { default: swordRules } = await repoImport('src/shared/sword-rules.json');

const [transport, fitting, out, supplied, testAudience = 'public'] = process.argv.slice(2);
assert(PROTOCOL === 97 && ['worker','peer'].includes(transport) && ['entry','needle','back'].includes(fitting) && out);
const setup = {
  mode:fitting==='back'?'raid':'short',difficulty:'normal',arenaSelection:'route',openingArenaId:'sunken-chapel',
  freePlay:{ openingBossId:fitting==='back'?'matron':'constable',variant:'normal',seed:73 },
} as const;
const closeHealth = (view,id) => view?.players.find(player => player.id === id);
const spending = p => p.skills.reduce((sum,id) => sum+[...data.specializationSkills,...data.skills].find(row => row.id === id).cost,0);

async function wait(truth, detail, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(8);
  }
}
function pilotState() {
  return { events: [], observed: new Map(), cues: new Map() };
}
async function earnedFlow(adapter) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const p = closeHealth(view(),adapter.id); assert(p); return p; };
  const status = () => owner().kit.counterstroke;
  const policy = createCombatPolicy({ adapter, view, data, HZ, rules, component, runtimeArena, bulwarkTrialWorld,
    clearTrialWalk, segmentRect, segmentCircle, distance, restRaidInput, fitting, swordGuardContact, swordCircleContact, swordRules });
  const purchased = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind:'skill',item });
    assert(result.ok,JSON.stringify({ item,result }));
    purchased.push({ item,earned:owner().sp+spending(owner()),clears:owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(row => row.classId === 'swordsman').sort((a,b) => b.tier-a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind:'weapon',item:weapon.id })).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({ kind:'upgrade',item });
  }
  async function submit(input) {
    const aim = typeof input.aim === 'number' ? Math.atan2(Math.sin(input.aim), Math.cos(input.aim)) : undefined;
    const sequence = adapter.input(aim === undefined ? input : { ...input, aim });
    await wait(() => owner().ack >= sequence || view().phase !== 'combat','Ordinary control is acknowledged');
  }

  const earnedFitting = fitting === 'needle';
  assert.equal(owner().sp, fitting==='back'?12:3);
  await buy('swordsman-edgework-1');
  await buy(counterstrokeIds.entry);
  await wait(() => status() !== undefined, () => JSON.stringify({
    case:'own-state', transport, owned:owner().skills, classId:owner().classId,
    received:Object.keys(owner().kit), replicated:adapter.rawOwner?.(),
  }));
  if (earnedFitting) assert(!(await adapter.purchase({ kind:'skill',item:counterstrokeIds.needle })).ok);
  if (fitting==='back') {
    await buy(counterstrokeIds.back);
    assert.equal((await adapter.purchase({kind:'skill',item:counterstrokeIds.needle})).reason,'incompatibleItem');
  }
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat','The ordinary opening encounter begins');
  if (earnedFitting) {
    const shopLimit = Date.now()+135_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase),'Reach the first shop after an ordinary clear');
      if (view().phase === 'combat') {
        adapter.input(policy.ordinary(view(), owner()));
        adapter.allyPressure?.();
      } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(owner().sp+spending(owner()),9);
    await buy(counterstrokeIds.needle);
    const other = counterstrokeIds.back;
    assert.equal((await adapter.purchase({ kind:'skill',item:other })).reason,'incompatibleItem');
    await equip();
    await wait(() => view().phase === 'combat','The second ordinary encounter begins',95_000);
  }
  const next = { boss:view().boss.id,arena:view().arenaId,start:view().combatTick };
  const firstClear = owner().progress.clears;

  adapter.pause(true);
  await wait(() => adapter.paused(),'The authority acknowledges pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ technique2:true });
  await sleep(90);
  assert.equal(view().combatTick,pausedAt);
  assert(owner().ack < ignored && status()?.guardUntil === 0 && status()?.responseUntil === 0,
    JSON.stringify({ fitting,transport,pausedAt,ack:owner().ack,ignored,privateStatus:status() }));
  adapter.pause(false);
  await wait(() => !adapter.paused(),'The authority acknowledges resume');
  await adapter.stopAlly?.();

  console.log(JSON.stringify({milestone:'legal acquisition',fitting,boss:next.boss,firstClear,earned:owner().sp+spending(owner())}));
  const operation = await exerciseCounterstroke({ adapter, view, owner, submit, fitting, rules, HZ, equip, policy });
  const witnessed=await adapter.peerWitness?.(operation);
  return {passed:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,transport,fitting,bought:purchased,firstClear,next,setup,
    result:operation,witnessed,pausedCommandsDiscarded:true,noCheckpointImports:true};
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: setup.freePlay.seed, maxPlayers: 1 }, name: 'Dara', classId: 'swordsman' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'drawn-reply-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), blade = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], blade: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  blade.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, blade.id)?.kit.counterstroke !== undefined) leaks++;
  };
  blade.onEvents = batch => remember(state.events, state.observed, batch, blade.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  blade.onPurchase = entry => replies.blade.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await blade.connect({ ...setup, name: 'Dara', classId: 'swordsman', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => blade.view?.players.length === 2 && host.view?.players.length === 2, 'The Swordsman joins as the second player');
    assert.equal(blade.view.owner, host.id);
    assert.notEqual(blade.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: blade.id, view: () => blade.view,
      rawOwner: () => {
        const state = blade.room?.state.players.get(blade.id);
        return { private:state?.lineworkOwner, build:state ? JSON.parse(state.build).skills : undefined };
      },
      input: props => { blade.input(inputFrame(blade.view, ++sequence, props)); return sequence; },
      purchase: request => reply(blade, replies.blade, request), start: () => host.start(),
      vote: i => { host.vote(i); blade.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => blade.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'The host stops on the ordinary map');
      },
      allyCover: () => hostInput({ ...restRaidInput(host.view, readyHost(), [...peers.observed.values()]), q: false, e: false, ultimate: false, fire: false }),
      peerWitness: async operation => {
        const stage=operation.stage;
        await wait(()=>peers.cues.has(stage.first.id)&&peers.cues.has(operation.release.id),'The host sees the same held edge and actual cut');
        const shared=peers.cues.get(stage.first.id);
        assert.deepEqual(shared.first,stage.first);
        assert.deepEqual(peers.cues.get(operation.release.id).first,operation.release);
        assert.equal(leaks,0);
        return { nonHost:true, shared, sharedCut:operation.release.id, ownedStatePrivate:true };
      },
    });
    host.endMatch();
    await wait(() => [host, blade].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    blade.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, driverSha256: sha256(readFileSync(new URL(import.meta.url))), testedAudience: testAudience });
console.log(JSON.stringify({passed:true,transport,fitting,boss:result.result.boss,firstClear:result.firstClear,
  stage:result.result.stage.first.id,release:result.result.release.state,hits:result.result.hits}));
