import assert from 'node:assert/strict';

export function verifyNativeCase(report, expected) {
  const { transport, fitting, revision, driver, worker } = expected;
  assert(report.passed && report.protocol === 97 && report.contentRevision === revision && report.driverSha256 === driver);
  assert(report.transport === transport && report.fitting === fitting && report.pausedCommandsDiscarded && report.noCheckpointImports);
  const needle = fitting === 'needle', back = fitting === 'back';
  assert.equal(report.firstClear,needle ? 1 : 0);
  assert.equal(report.bought.at(-1).earned,needle ? 9 : back ? 12 : 3);
  const { stage, release, hits, paid, boss, sounds } = report.result;
  assert(typeof boss === 'string' && boss.length > 0);
  assert(hits.length && hits.every(hit => hit.after < hit.before));
  assert(sounds.includes('sword-drawn-reply-' + (needle ? 'needle' : back ? 'back' : 'cut')));
  assert(stage.first.state === 'guard' && stage.first.until - stage.first.at === 11 && paid.e > stage.first.at);
  assert(stage.phases.some(cue => cue.state === (fitting === 'entry' ? 'forward' : fitting)));
  assert.equal(release.state,needle ? 'return' : 'cut');
  assert.notEqual(release.id,stage.first.id);
  const angle = Math.abs(Math.atan2(Math.sin(release.aim - stage.first.aim),Math.cos(release.aim - stage.first.aim)));
  if (back) assert(angle >= Math.PI / 4 - 0.002);
  if (transport === 'worker') assert(report.wholeOptimizedWorker && !report.workerPatched && report.workerSha256 === worker);
  else assert(report.witnessed.nonHost && report.witnessed.ownedStatePrivate && report.witnessed.sharedCut === release.id);
  return { transport,fitting,boss,firstClear:report.firstClear,stage:stage.first.id,release:release.id,angle,hits };
}
