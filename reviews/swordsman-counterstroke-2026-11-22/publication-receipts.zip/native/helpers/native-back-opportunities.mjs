const bearing = (from, to) => Math.atan2(to.y - from.y, to.x - from.x);
const turn = (first, second) => Math.atan2(Math.sin(first - second), Math.cos(first - second));

export function installBackOpportunityPilot({ game, data, HZ, rules, observed, segmentRect,
  segmentCircle, swordGuardContact, swordCircleContact, swordRules }) {
  function targets(seen) {
    const boss = data.bosses.find(row => row.id === seen.boss.id);
    const parts = seen.bossCues.filter(row => ['raid-prop','service-prop','early-prop','stitch-pin'].includes(row.kind));
    return [...seen.minions, ...parts, { ...seen.boss, radius:boss?.radius ?? 42 }]
      .filter(row => row.health > 0 && row.radius > 0);
  }

  function flank(origin, opponents, guardAim, walls) {
    for (const target of opponents) {
      const away = turn(bearing(origin, target), guardAim);
      const offset = Math.max(rules.flankAngle + 0.06, Math.abs(away));
      const aim = guardAim + Math.sign(away || 1) * offset;
      if (swordCircleContact(origin, aim, rules.rear.reach, rules.rear.arc, target, target.radius, walls)) {
        return aim;
      }
    }
  }

  function projectedGuards(seen, body, opponents, walls) {
    const candidates = [];
    for (const shot of observed.values()) {
      const horizon = Math.min(rules.guardTicks - 2, shot.expires - seen.combatTick);
      if (shot.owner !== 'hostile' || horizon < 3) continue;
      const age = Math.max(0, seen.combatTick - shot.seenAt) / HZ;
      const from = { x:shot.x + shot.vx * age, y:shot.y + shot.vy * age };
      const to = { x:from.x + shot.vx * horizon / HZ, y:from.y + shot.vy * horizon / HZ };
      if (Math.hypot(body.x - from.x, body.y - from.y) > 210) continue;
      const toward = bearing(body, from);
      const bodyHit = segmentCircle(from, to, body, data.rules.playerRadius + shot.radius) ?? Infinity;
      for (const offset of [0, 0.24, -0.24, 0.49, -0.49, 0.72, -0.72]) {
        const aim = toward + offset;
        const hit = swordGuardContact(from, to, body, body, aim, shot.radius, swordRules.guardOffset,
          swordRules.guardHalfSpan, swordRules.guardHalfDepth);
        if (hit === null || hit * horizon < 2 || bodyHit <= hit ||
          walls.some(wall => (segmentRect(from, to, wall, shot.radius)?.t ?? Infinity) <= hit)) continue;
        const hasTarget = flank(body, opponents, aim, walls) !== undefined;
        if (hasTarget || bodyHit < 1) candidates.push({ aim, hasTarget, arrival:hit * horizon });
      }
    }
    return candidates.sort((a, b) => Number(b.hasTarget) - Number(a.hasTarget) || a.arrival - b.arrival)[0];
  }

  return (seen, body, original) => {
    const status = body.kit.counterstroke;
    if (!status || (original.supply ?? -1) >= 0) return original;
    const opponents = targets(seen), walls = game.obstacles;
    const reply = seen.classCues.find(row => row.kind === 'sword-drawn-reply' &&
      row.state === 'back' && row.owner === body.id);
    const ready = reply && status.responseUntil > seen.combatTick;
    const aim = ready ? flank(body, opponents, reply.aim - Math.PI, walls) :
      status.canGuard ? projectedGuards(seen, body, opponents, walls)?.aim : undefined;
    if (aim === undefined) return original;
    return { ...original, aim, moveX:0, moveY:0, fire:false, q:false, e:false, ultimate:false, dodge:false,
      sprint:false, reload:false, supply:-1, technique2:true };
  };
}
