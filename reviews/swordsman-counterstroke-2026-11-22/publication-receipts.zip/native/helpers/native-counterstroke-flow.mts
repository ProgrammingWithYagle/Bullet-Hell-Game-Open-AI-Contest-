import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { measuredPilot } from '../swordsman-measured/measured-pilot.mjs';
import { counterstrokePilot } from './counterstroke-targeted-pilot.mjs';
import { installBackOpportunityPilot } from './native-back-opportunities.mjs';

export function recordCounterstrokeCues(cues,view) {
  for(const cue of view.classCues){
    if(cue.kind!=='sword-drawn-reply')continue;
    let known=cues.get(cue.id);
    if(!known){known={first:cue,last:cue,phases:[]};cues.set(cue.id,known);}
    if(JSON.stringify(known.last)!==JSON.stringify(cue)||!known.phases.length)known.phases.push(cue);
    known.last=cue;
  }
}

export function createCombatPolicy({ adapter,view,data,HZ,rules,component,runtimeArena,bulwarkTrialWorld,clearTrialWalk,
  segmentRect,segmentCircle,distance,restRaidInput,fitting,swordGuardContact,swordCircleContact,swordRules }) {
  let worldTick=-1,world;
  const game={
    get arena(){return runtimeArena(view().arenaId,view().run.difficulty);},
    get obstacles(){
      const seen=view();
      if(worldTick!==seen.combatTick||world?.arenaId!==seen.arenaId){
        worldTick=seen.combatTick;world={...bulwarkTrialWorld(seen),arenaId:seen.arenaId};
      }
      return world.obstacles;
    },
    get combatTick(){return view().combatTick;},
    get encounter(){return view().encounter;},
    movementSpeed(body){return body.speed;},
  };
  function danger(seen,point,horizon){
    if(seen.minions.some(actor=>actor.health>0&&distance(actor,point)<22+horizon))return true;
    if(seen.fields.some(field=>field.kind==='zone'&&distance(field,point)<field.radius+8))return true;
    for(const shot of adapter.observed.values()){
      const time=Math.min(horizon,shot.expires-seen.combatTick);
      if(time<=0||shot.owner!=='hostile'||distance(shot,point)>435)continue;
      const elapsed=Math.max(0,seen.combatTick-shot.seenAt)/HZ;
      const from={x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed};
      const to={x:from.x+shot.vx*time/HZ,y:from.y+shot.vy*time/HZ};
      const hit=segmentCircle(from,to,point,shot.radius+data.rules.playerRadius+2);
      if(hit!==null&&!game.obstacles.some(wall=>(segmentRect(from,to,wall,shot.radius)?.t??Infinity)<=hit))return true;
    }
    return false;
  }
  const context={game,data,HZ,rules,component,distance,segmentRect,segmentCircle,clearTrialWalk,danger,observed:adapter.observed};
  const navigate=explicitNavigation(context);
  const ordinary=measuredPilot({...context,rules:component,policy:'unused'});
  const use=counterstrokePilot({...context,policy:fitting==='entry'?'reply':fitting});
  const flank = fitting==='back' ? installBackOpportunityPilot({ ...context, swordGuardContact, swordCircleContact, swordRules }) : undefined;
  const baseline=(seen,body)=>restRaidInput(seen,body,[...adapter.observed.values()]);
  return {ordinary:(seen,body)=>ordinary(seen,body,baseline(seen,body),navigate),
    invoke:(seen,body)=>{
      const original=use(seen,body,baseline(seen,body),navigate);
      return flank ? flank(seen,body,original) : original;
    }};
}

function healthMap(view) {
  return new Map([
    ['boss/'+view.boss.id,view.boss.health],
    ...view.minions.map(row=>['minion/'+row.id,row.health]),
    ...view.bossCues.filter(row=>['raid-prop','service-prop','early-prop','stitch-pin'].includes(row.kind)).map(row=>['part/'+row.id,row.health]),
  ]);
}
function damageBetween(before,after) {
  const now = healthMap(after);
  return [...before].flatMap(([id,health])=>{
    const lower = now.get(id);
    if (lower===undefined || lower>=health) return [];
    return [{ id,before:health,after:lower }];
  });
}
const angleDelta = (a,b) => Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)));

export async function exerciseCounterstroke({adapter,view,owner,submit,fitting,rules,HZ,equip,policy}) {
  const beginning=view().combatTick, deadline=Date.now()+195_000, eventStart=adapter.events.length;
  const payments=new Map(), traces=[];
  let lastTick=-1,lastShop=view().encounter;
  const records=()=>[...adapter.cues.values()].filter(row=>row.first.owner===adapter.id&&row.first.at>=beginning);
  const sounds=()=>adapter.events.slice(eventStart).filter(event=>event.type==='sound'&&event.owner===adapter.id&&
    event.id.startsWith('sword-drawn-reply-')).map(event=>event.id);
  for (;;) {
    const seen=view(), body=owner();
    if (Date.now()>=deadline||['victory','defeat'].includes(seen.phase)) {
      assert.fail(JSON.stringify({fitting,phase:seen.phase,boss:seen.boss.id,tick:seen.combatTick,
        health:body.health,traces:traces.slice(-10),sounds:sounds(),cues:records().slice(-4)}));
    }
    if(seen.phase!=='combat'){
      if(['mutationVote','contractVote','secretOffer'].includes(seen.phase))adapter.vote(0);
      if(seen.phase==='shop'&&seen.encounter!==lastShop){lastShop=seen.encounter;await equip();}
      await sleep(20);continue;
    }
    for (const row of records().filter(row=>row.first.state==='guard'&&!payments.has(row.first.id))) {
      payments.set(row.first.id,{e:body.eAt,q:body.qAt,ammo:body.ammo});
    }
    if(seen.combatTick===lastTick){await sleep(10);continue;}
    lastTick=seen.combatTick;
    const input=body.status==='active'?policy.invoke(seen,body):{interact:true};
    const cue=seen.classCues.find(row=>row.kind==='sword-drawn-reply'&&row.owner===adapter.id&&
      ['forward','needle','back'].includes(row.state));
    const answer=cue&&input.technique2;
    const before=answer?healthMap(seen):undefined;
    const sent=adapter.events.length;
    await submit(input);
    adapter.allyCover?.();
    if(!answer)continue;
    let after=view();
    const released=records().find(row=>['cut','return'].includes(row.first.state)&&row.first.at>seen.combatTick&&row.first.at<=after.combatTick);
    if(!released)continue;
    const row=records().find(sample=>sample.first.id===cue.id), paid=payments.get(cue.id);
    assert(row&&paid&&row.first.state==='guard'&&row.phases.some(sample=>sample.state===cue.state));
    const sign=fitting==='needle'?'sword-drawn-reply-needle':fitting==='back'?'sword-drawn-reply-back':'sword-drawn-reply-cut';
    if(fitting==='back'&&angleDelta(released.first.aim,row.first.aim)<rules.flankAngle-0.002)continue;
    if((fitting==='needle')!==(released.first.state==='return'))continue;
    if(fitting==='needle'){
      const until=released.first.at+Math.ceil(rules.needleReach/rules.needleSpeed*HZ)+2;
      while(view().combatTick<until&&view().phase==='combat'&&Date.now()<deadline){
        await submit({aim:released.first.aim});
        adapter.allyCover?.();
      }
      after=view();
      assert(adapter.events.slice(sent).some(event=>event.type==='shots'&&event.shots.some(shot=>shot.owner===adapter.id&&
        Math.abs(Math.hypot(shot.vx,shot.vy)-rules.needleSpeed)<0.01&&shot.pierce===0)));
    }
    const hits=damageBetween(before,after), heard=sounds();
    traces.push({stage:cue.id,release:released.first,hits});
    if(!hits.length)continue;
    assert(heard.includes(sign)&&heard.includes('sword-drawn-reply-guard')&&heard.includes('sword-drawn-reply-catch'));
    assert.equal(released.first.id!==row.first.id,true);
    assert.equal(row.first.until-row.first.at,rules.guardTicks);
    assert.equal(owner().eAt,paid.e);
    assert.equal(owner().qAt,paid.q);
    assert.equal(owner().ammo,paid.ammo);
    assert.equal(owner().kit.counterUntil??0,0);
    return {stage:row,release:released.first,hits,paid,sounds:heard,boss:after.boss.id,traces:traces.slice(-12)};
  }
}
