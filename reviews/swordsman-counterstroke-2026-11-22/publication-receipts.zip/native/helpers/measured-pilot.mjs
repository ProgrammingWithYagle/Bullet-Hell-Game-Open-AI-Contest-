const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const direction = angle => ({ x:Math.cos(angle),y:Math.sin(angle) });
const project = (origin,angle,range) => ({ x:origin.x+Math.cos(angle)*range,y:origin.y+Math.sin(angle)*range });
const heading = difference => Math.abs(Math.atan2(Math.sin(difference),Math.cos(difference)));
const radians = degrees => degrees * Math.PI / 180;

export function measuredPilot({ game,data,distance,segmentRect,clearTrialWalk,danger,rules,policy }) {
  function cutCouldReach(body,target,aim,shape) {
    if (distance(body,target)>shape.reach+target.radius-4) return false;
    if (heading(bearing(body,target)-aim)>shape.arc/2-0.04) return false;
    return !game.obstacles.some(wall=>segmentRect(body,target,wall,2));
  }
  return function decide(view,body,routine,navigate) {
    const now = view.combatTick;
    const state = body.kit.measuredStance;
    const bossDefinition = data.bosses.find(row=>row.id===view.boss.id);
    const boss = { ...view.boss, radius:bossDefinition?.radius??44 };
    const clear = (target,padding) => !game.obstacles.some(wall=>segmentRect(body,target,wall,padding));
    const parts = view.bossCues.filter(cue=>['raid-prop','early-prop','service-prop','stitch-pin'].includes(cue.kind) &&
      cue.health>0 && clear(cue,2));
    const near = view.minions.filter(target=>target.health>0 && distance(target,body)<95 && clear(target,2));
    const target = [...near,...parts.filter(part=>distance(part,body)<165)]
      .sort((a,b)=>distance(a,body)-distance(b,body))[0] ?? boss;
    const aim = bearing(body,target), range = distance(body,target);
    const weapon = data.weapons.find(item=>item.id===body.weapon);
    const primaryReach = weapon?.meleeReach ?? 108;
    const ideal = Math.max(59,primaryReach+target.radius-24);
    const threat = danger(view,body,6);
    let routineCut = {
      ...routine, aim, fire:range<=primaryReach+target.radius+9 && clear(target,2),
      q:body.qAt<=now && range>63 && range<200+target.radius && clear(target,5),
      e:body.eAt<=now && threat,
      ultimate:body.ultimateAt<=now && range<ideal+48 && clear(target,2),
    };
    if (!threat && !routine.dodge && !routineCut.q && Math.abs(range-ideal)>9) {
      const travel = aim + (range<ideal ? Math.PI : 0);
      const terrain = { ...game.arena, obstacles:game.obstacles, tick:now, playerRadius:data.rules.playerRadius };
      const choices = [0,.44,-.44,.88,-.88,1.31,-1.31];
      const path = choices.map(offset=>travel+offset)
        .find(angle=>clearTrialWalk(terrain,body,project(body,angle,30)) && !danger(view,project(body,angle,23),9));
      if (path!==undefined) {
        const move = direction(path);
        routineCut = { ...routineCut, moveX:move.x, moveY:move.y };
      } else {
        routineCut = navigate(view,body,routineCut);
      }
    }
    if (policy==='banked' || policy==='unused') return routineCut;

    const stand = {
      ...routineCut, moveX:0, moveY:0, q:false, e:false, ultimate:false,
      reload:false, sprint:false, supply:-1, dodge:false, fire:false,
    };
    const cue = view.classCues.find(row=>row.kind==='sword-measured-stance' && row.owner===body.id && row.state!=='cut');
    if (cue && state?.until>now) {
      if (threat || routine.dodge || (routine.supply??-1)>=0) return routineCut;
      if (state.readyAt>now) return stand;
      if (state.following) {
        const options = [aim,cue.aim+radians(31),cue.aim-radians(31)];
        const follow = options.find(angle => heading(angle-cue.aim)>rules.releaseAngle &&
          heading(angle-cue.aim)<=rules.maximumFollow && cutCouldReach(body,target,angle,rules.follow));
        return follow===undefined ? stand : { ...stand, aim:follow,technique1:true };
      }
      const turn = heading(aim-cue.aim);
      if (policy==='turn' && body.skills.includes('swordsman-measured-turn-edge-1') && !state.turned &&
        turn>rules.releaseAngle && turn<=rules.maximumTurn && now+rules.turnTicks+1<state.until &&
        !danger(view,body,rules.turnTicks+2) && cutCouldReach(body,target,aim,rules.first)) {
        return { ...stand, aim,technique1:true };
      }
      return cutCouldReach(body,target,cue.aim,rules.first)
        ? { ...stand,aim:cue.aim,technique1:true } : stand;
    }
    if (state?.canPlant && !routine.dodge && (routine.supply??-1)<0 &&
      cutCouldReach(body,target,aim,rules.first) && !danger(view,body,rules.prepareTicks+3)) {
      const deliberateTurn = policy==='turn' && body.skills.includes('swordsman-measured-turn-edge-1');
      return { ...stand,aim:aim+(deliberateTurn ? radians(48) : 0),technique1:true };
    }
    return routineCut;
  };
}
