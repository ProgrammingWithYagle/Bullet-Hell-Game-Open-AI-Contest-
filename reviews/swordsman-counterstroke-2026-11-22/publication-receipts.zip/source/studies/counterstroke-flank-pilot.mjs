import { measuredPilot } from '../swordsman-measured/measured-pilot.mjs';

const bearing=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
const turn=(a,b)=>Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)));
const point=(p,aim,length)=>({x:p.x+Math.cos(aim)*length,y:p.y+Math.sin(aim)*length});
const degrees=value=>value*Math.PI/180;

export function counterstrokePilot(options) {
  const {game,data,component,rules,HZ,distance,segmentRect,segmentCircle,clearTrialWalk,danger,observed,policy}=options;
  const ordinary=measuredPilot({...options,rules:component,policy:'unused'});
  const blocked=(from,to,padding)=>game.obstacles.some(wall=>segmentRect(from,to,wall,padding));
  function visibleTargets(body,view) {
    const definition=data.bosses.find(row=>row.id===view.boss.id);
    const boss={...view.boss,radius:definition?.radius??42};
    const weak=view.bossCues.filter(row=>['raid-prop','early-prop','service-prop','stitch-pin'].includes(row.kind)&&row.health>0);
    return [...view.minions.filter(row=>row.health>0),...weak,boss].sort((a,b)=>distance(a,body)-distance(b,body));
  }
  function answerAim(origin,targets,aim,fitting) {
    if (fitting==='needle') {
      const end=point(origin,aim,rules.needleReach);
      return targets.some(target=>segmentCircle(origin,end,target,target.radius+rules.needleRadius)!==null &&
        !blocked(origin,target,3)) ? aim : undefined;
    }
    const shape=fitting==='back'?rules.rear:rules.front;
    for (const target of targets) {
      if (distance(origin,target)>shape.reach+target.radius-6 || blocked(origin,target,3)) continue;
      const wanted=bearing(origin,target);
      if (fitting==='back') {
        const front=aim-Math.PI;
        const delta=turn(wanted,front);
        if (delta>=rules.flankAngle+0.03) return wanted;
        if (delta>=degrees(30)) {
          const side=Math.atan2(Math.sin(wanted-front),Math.cos(wanted-front));
          return front+Math.sign(side)*(rules.flankAngle+0.10);
        }
        continue;
      }
      if (turn(wanted,aim)<=rules.choiceAngle-0.025) return wanted;
      const near=turn(wanted,aim)-rules.choiceAngle;
      if (near>shape.arc/2-0.10) continue;
      const side=Math.atan2(Math.sin(wanted-aim),Math.cos(wanted-aim));
      return aim+Math.sign(side)*(rules.choiceAngle-0.035);
    }
  }
  function threatChoice(view,body,targets,fitting) {
    const choices=[];
    for(const shot of observed.values()){
      if(shot.owner!=='hostile'||shot.expires<=view.combatTick)continue;
      const age=Math.max(0,view.combatTick-shot.seenAt)/HZ;
      const before={x:shot.x+shot.vx*age,y:shot.y+shot.vy*age};
      const range=distance(before,body);
      if(range<40||range>184||blocked(before,body,3))continue;
      const high=Math.min(11,shot.expires-view.combatTick)/HZ;
      const after={x:before.x+shot.vx*high,y:before.y+shot.vy*high};
      const hit=segmentCircle(before,after,body,19+shot.radius);
      if(hit===null)continue;
      const aim=bearing(body,before), reversed=Math.atan2(-shot.vy,-shot.vx);
      const reply=fitting==='needle'?reversed:fitting==='back'?aim+Math.PI:aim;
      const likely=answerAim(body,targets,reply,fitting)!==undefined;
      if(!likely&&fitting==='back'&&!targets.some(target=>distance(target,body)<143))continue;
      if(!likely&&fitting!=='back')continue;
      choices.push({aim,likely,range});
    }
    return choices.sort((a,b)=>Number(b.likely)-Number(a.likely)||a.range-b.range)[0];
  }
  return function decide(view,body,routine,navigate) {
    const base=ordinary(view,body,routine,navigate);
    if(policy==='banked'||policy==='unused')return base;
    const now=view.combatTick, status=body.kit.counterstroke;
    const picked=policy==='needle'&&body.skills.includes('swordsman-counterstroke-needle-return-1')?'needle':
      policy==='back'&&body.skills.includes('swordsman-counterstroke-back-answer-1')?'back':'forward';
    const targets=visibleTargets(body,view);
    const stay={...base,moveX:0,moveY:0,fire:false,e:false,q:false,ultimate:false,dodge:false,sprint:false,reload:false,supply:-1};
    const cue=view.classCues.find(row=>row.kind==='sword-drawn-reply'&&row.owner===body.id&&row.state!=='cut'&&row.state!=='return');
    if(cue&&status?.responseUntil>now){
      if((base.supply??-1)>=0)return base;
      const aim=answerAim(body,targets,cue.aim,picked);
      if(aim!==undefined)return {...stay,aim,technique2:true};
      if(picked==='back'&&status.responseUntil-now<=7){
        const front=answerAim(body,targets,cue.aim-Math.PI,'forward');
        if(front!==undefined)return {...stay,aim:front,technique2:true};
      }
      const terrain={...game.arena,obstacles:game.obstacles,tick:now,playerRadius:data.rules.playerRadius};
      const candidates=targets.slice(0,4).flatMap(target=>(picked==='back'?[0,28,-28,62,-62,95,-95,122,-122]:[0,28,-28,50,-50]).map(side=>{
        const spot=point(target,cue.aim+Math.PI+degrees(side),picked==='needle'?103:63);
        return {spot,traverse:bearing(body,spot),range:distance(body,spot)};
      })).filter(choice=>choice.range>5&&choice.range<190&&answerAim(choice.spot,targets,cue.aim,picked)!==undefined)
        .sort((a,b)=>a.range-b.range);
      const choice=candidates.find(item=>clearTrialWalk(terrain,body,point(body,item.traverse,24))&&
        !danger(view,point(body,item.traverse,21),5));
      return choice?{...stay,aim:cue.aim,moveX:Math.cos(choice.traverse),moveY:Math.sin(choice.traverse)}:{...stay,aim:cue.aim};
    }
    if(cue&&status?.guardUntil>now)return stay;
    if(status?.canGuard&&(base.supply??-1)<0){
      const stop=threatChoice(view,body,targets,picked);
      if(stop)return {...stay,aim:stop.aim,technique2:true};
    }
    return base;
  };
}
