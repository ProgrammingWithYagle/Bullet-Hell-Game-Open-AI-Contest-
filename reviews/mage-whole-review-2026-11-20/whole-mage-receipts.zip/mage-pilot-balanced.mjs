export function magePilot({ game, mage, data, distance, danger, visible, movement, clearTrialWalk, pivot, spatial, fuse, portfolio, bindingIds, fuseIds }){
  let current=-1, nextPath=0, pivotAim, returnPlan, fusePlan, reservedClock, reserveUntil;
  const point=({x,y})=>({x,y});
  const heading=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
  const normalized=angle=>Math.atan2(Math.sin(angle),Math.cos(angle));
  const forward=(p,angle,reach)=>({x:p.x+Math.cos(angle)*reach,y:p.y+Math.sin(angle)*reach});
  const rotation=['binding','spatial','volatile'];
  while(rotation[0]!==portfolio.opening)rotation.push(rotation.shift());
  const terrain=()=>({...game.arena,obstacles:game.obstacles,tick:game.combatTick});

  function floor(p,pad){
    const rect=game.arena.bounds;
    return p.x>=rect.x+pad&&p.y>=rect.y+pad&&p.x<=rect.x+rect.width-pad&&p.y<=rect.y+rect.height-pad&&
      visible(p,p,pad)&&!game.arena.lavaPits.some(pit=>distance(pit,p)<=pit.radius+pad);
  }
  function ready(p,view,base,horizon){
    return p.health>p.maxHealth*.39&&!base.dodge&&mage.reloadAt<=view.combatTick&&mage.dashUntil<=view.combatTick&&
      !danger(view,p,horizon);
  }
  function targets(view){
    const radius=data.bosses.find(row=>row.id===view.boss.id)?.radius??24;
    const minions=view.minions.filter(row=>row.health>0).map(row=>({...row,key:'minion-'+row.id}));
    return [...minions,{...view.boss,key:'boss',radius}];
  }
  function pivotRay(mark,aim){
    const edge=forward(mark,aim,pivot.shortestStroke+2);
    return floor(edge,pivot.halfWidth)&&visible(mark,edge,pivot.halfWidth);
  }
  function pivotTarget(view,mark){
    return targets(view).filter(row=>distance(mark,row)<pivot.reach+(row.radius??10)-5&&visible(mark,row,1))
      .sort((a,b)=>Number(a.key==='boss')-Number(b.key==='boss')||distance(a,mark)-distance(b,mark))[0];
  }
  function binding(view,p,base,canStart){
    const state=p.kit.pivotSigil;
    if(!state||state.phase==='fixed')return;
    const mark=view.classCues.find(c=>c.owner===mage.id&&c.kind.startsWith('mage-pivot-'));
    const aimBoss=heading(p,view.boss), canStand=ready(p,view,base,5);
    if(state.phase==='sweeping'&&mark){
      const actual=heading(mark,{x:mark.toX,y:mark.toY});
      const close=pivotTarget(view,mark);
      if(!canStand)return close?{...base,q:false,aim:heading(mark,close)}:undefined;
      if(portfolio.binding==='fixed'&&state.canFix)return {technique1:true,aim:actual};
      if(portfolio.binding==='reverse'&&state.reverseArmed&&!mark.reversed&&pivotRay(mark,actual+Math.PI))
        return {technique1:true,aim:actual+Math.PI};
      if(pivotAim!==undefined&&!mark.reversed)return {aim:pivotAim};
      return {aim:close?heading(mark,close):actual};
    }
    if(state.phase==='marked'&&mark&&canStand){
      const target=pivotTarget(view,mark);
      if(!target)return view.combatTick+8<state.until?{...base,q:false}:undefined;
      const line=heading(mark,target), reverse=portfolio.binding==='reverse'&&p.skills.includes(bindingIds.reverse);
      if(!reverse&&!p.skills.includes(bindingIds.fixed))return {technique1:true,aim:line};
      const full=reverse?line+Math.PI:line, offset=reverse?.75:.50;
      const start=[full-offset,full+offset].find(angle=>pivotRay(mark,angle)&&pivotRay(mark,full)&&(!reverse||pivotRay(mark,line)));
      pivotAim=start===undefined?undefined:full;
      return {technique1:true,aim:start??line};
    }
    if(!canStart||!canStand||state.phase!=='idle'||mage.qAt>view.combatTick||(state.until??0)>view.combatTick)return;
    const target=targets(view).filter(x=>distance(x,p)>=91&&distance(x,p)<253&&visible(p,x,2))
      .sort((a,b)=>distance(a,p)-distance(b,p))[0];
    if(!target)return;
    const aim=heading(p,target), markPoint=forward(p,aim,pivot.markReach);
    if(floor(markPoint,pivot.markRadius)&&visible(p,markPoint,2)&&pivotRay(markPoint,aim))return {technique1:true,aim};
    if(!base.q&&visible(p,view.boss,2))return { ...base,aim:aimBoss };
  }

  function returnLane(view,p){
    const line=heading(p,view.boss), initial=distance(p,view.boss), world=terrain();
    if(initial<167||initial>402)return;
    const candidates=[120,144].flatMap(reach=>[.58,-.58,.88,-.88,1.22,-1.22].map(off=>forward(p,line+off,reach)));
    return candidates.find(goal=>distance(goal,view.boss)>116&&distance(goal,view.boss)<323&&
      clearTrialWalk(world,p,goal)&&visible(goal,view.boss,3)&&!danger(view,goal,12));
  }
  function returnControl(view,p,base,canStart){
    const state=p.kit.waymark, now=view.combatTick, aim=heading(p,view.boss);
    if(!state)return;
    const mark=view.classCues.find(c=>c.kind==='mage-waymark'&&c.owner===mage.id);
    if(state.phase==='resting'&&mark){
      if(returnPlan&&!returnPlan.rested&&!danger(view,p,4)&&now+3<state.until){
        returnPlan.rested=true;
        return {aim,fire:visible(p,view.boss,2)};
      }
      return {technique2:true,aim:heading(p,mark)};
    }
    if(state.phase==='returning'&&mark){
      if(portfolio.spatial==='hold'&&state.canHold&&!danger(view,p,5))return {technique2:true,aim};
      if(portfolio.spatial==='side'&&state.sideWindow){
        const toward=heading(p,mark), reach=Math.min(spatial.sideMaximum,distance(p,mark)), world=terrain();
        if(reach>0){
          const turn=[toward+Math.PI/2,toward-Math.PI/2].find(angle=>{
            const site=forward(p,angle,reach);
            return clearTrialWalk(world,p,site)&&!danger(view,site,6);
          });
          if(turn!==undefined)return {technique2:true,aim:turn};
        }
      }
      return {aim};
    }
    if(state.phase==='marked'&&returnPlan&&mark){
      const current=returnPlan.goal;
      const traveled=(state.walked??0)>=spatial.minimumWalk;
      if(!traveled&&danger(view,p,3))return {...base,e:false};
      if(traveled&&(distance(p,current)<8||now+9>=state.until||danger(view,p,4))){
        if(p.kit.fuseSeal?.phase==='idle'&&mage.ultimateAt<=now&&state.until>now+9&&floor(p,fuse.radius)&&
           distance(mark,p)<=fuse.leash-8&&ready(p,view,base,8)&&ventTarget(view,mark,'ward')){
          fusePlan={useWaymark:true};
          return {technique3:true,aim};
        }
        return {technique2:true,aim:heading(p,mark)};
      }
      const move=movement(view,p,heading(p,current));
      return move?{...move,aim,fire:visible(p,view.boss,2)}:{...base,e:false};
    }
    if(!canStart||state.phase!=='idle'||mage.eAt>now||(state.until??0)>now||!ready(p,view,base,10))return;
    const goal=returnLane(view,p);
    if(goal){
      returnPlan={goal};
      return {technique2:true,aim:heading(p,goal)};
    }
  }

  function ventTarget(view,p,shape,excluded){
    const selected=targets(view).filter(row=>row.key!==excluded&&distance(p,row)>49)
      .sort((a,b)=>Number(b.key==='boss')-Number(a.key==='boss')||distance(p,a)-distance(p,b));
    for(const actor of selected){
      const aim=heading(p,actor), range=distance(p,actor), radius=actor.radius??10;
      if(shape==='binding'&&range<fuse.forwardReach+radius-5&&visible(p,actor,fuse.width))return {angle:aim,key:actor.key};
      if(shape==='binding')continue;
      for(const offset of [0,.18,-.18,.31,-.31,.44,-.44]){
        const angle=aim+offset, center=forward(p,angle,fuse.wardOffset), dx=actor.x-center.x, dy=actor.y-center.y;
        const lateral=Math.abs(dx*Math.sin(angle)-dy*Math.cos(angle)), depth=Math.abs(dx*Math.cos(angle)+dy*Math.sin(angle));
        if(lateral>=fuse.wardSpan-4||depth>=radius+fuse.width-5||!floor(center,fuse.width)||
           !visible(p,center,fuse.width)||!visible(center,actor,2))continue;
        return {angle,key:actor.key};
      }
    }
  }
  function shuntLane(view,p){
    const toward=heading(p,view.boss), world=terrain();
    for(const off of [.83,-.83,1.24,-1.24,.53,-.53]){
      const goal=forward(p,toward+off,81);
      if(clearTrialWalk(world,p,goal)&&ventTarget(view,goal,'binding')&&!danger(view,goal,11))return goal;
    }
  }
  function volatile(view,p,base,canStart){
    const state=p.kit.fuseSeal, now=view.combatTick;
    if(!state||!ready(p,view,base,5))return;
    const q=mage.qAt<=now,e=mage.eAt<=now, twin=p.skills.includes(fuseIds.twin), shunt=p.skills.includes(fuseIds.shunt);
    if(state.phase==='prepared'){
      if(fusePlan?.useWaymark&&p.kit.waymark?.phase==='marked')return;
      if(fusePlan?.usePivot&&q&&now+8<state.until){
        const command=binding(view,p,{...base,q:false,e:false,ultimate:false},true);
        if(command?.technique1)return command;
      }
      if(twin&&q&&e)return { ...base,q:true,e:false,ultimate:false };
      if(q&&ventTarget(view,p,'binding'))return { ...base,q:true,e:false,ultimate:false };
      if(e&&ventTarget(view,p,'ward'))return { ...base,q:false,e:true,ultimate:false };
      return { ...base,ultimate:false,q:false,e:false };
    }
    if(state.phase==='binding'||state.phase==='ward'||state.phase==='crossed'){
      if(shunt&&state.phase==='binding'&&!fusePlan?.shifted&&fusePlan?.route&&now+13<state.until){
        const stride=movement(view,p,heading(p,fusePlan.route));
        if(stride&&distance(p,fusePlan.route)>9){
          if(state.canShunt){ fusePlan.shifted=true; return {...stride,technique3:true,aim:base.aim}; }
          return {...stride,aim:base.aim,fire:base.fire};
        }
      }
      if(twin&&!state.echo&&state.phase==='binding'&&e&&ventTarget(view,p,'ward')&&now+3<state.until)
        return {...base,q:false,e:true,ultimate:false};
      const shape=state.split?'binding':state.phase;
      const target=(state.echo&&ventTarget(view,p,shape,fusePlan?.firstTarget))||ventTarget(view,p,shape);
      if(target){
        if(state.split&&fusePlan)fusePlan.firstTarget=target.key;
        return {technique3:true,aim:target.angle};
      }
      return {...base,q:false,e:false,ultimate:false};
    }
    if(!canStart||state.phase!=='idle'||mage.ultimateAt>now||(state.until??0)>now||!floor(p,fuse.radius)||!ready(p,view,base,8))return;
    const best=twin&&q&&e&&ventTarget(view,p,'ward')
      ?ventTarget(view,p,'binding'):q&&ventTarget(view,p,'binding')||e&&ventTarget(view,p,'ward');
    if(best){
      const pivotAvailable=p.kit.pivotSigil&&['idle','marked'].includes(p.kit.pivotSigil.phase);
      const pivotOpening=portfolio.opening==='binding'||p.kit.pivotSigil?.phase==='marked';
      fusePlan={route:shunt?shuntLane(view,p):undefined,usePivot:q&&pivotAvailable&&pivotOpening};
      return {technique3:true,aim:best.angle};
    }
  }

  return (view,p,base)=>{
    if(current!==game.encounter){ current=game.encounter; pivotAim=undefined; returnPlan=undefined; fusePlan=undefined; }
    const now=view.combatTick, fuseState=p.kit.fuseSeal;
    if(reservedClock!==mage.ultimateAt){
      reservedClock=mage.ultimateAt;
      reserveUntil=undefined;
    }
    const canReserve=fuseState?.phase==='idle'&&mage.ultimateAt<=now&&p.health>=p.maxHealth*.43;
    if(canReserve&&reserveUntil===undefined)reserveUntil=now+210;
    const stock=canReserve&&now<reserveUntil;
    const original=base;
    if(stock)base={...base,q:false,e:false,ultimate:false};
    const underWay=p.kit.waymark?.phase&&p.kit.waymark.phase!=='idle';
    if(underWay){
      const route=returnControl(view,p,base,false);
      if(route)return route;
    }
    const prime=stock&&volatile(view,p,base,true);
    if(prime)return prime;
    const charged=volatile(view,p,base,false);
    if(charged)return charged;
    const occupied=binding(view,p,base,false);
    if(occupied)return occupied;
    if(stock)return base;
    for(let i=0;i<rotation.length;i++){
      const index=(nextPath+i)%rotation.length,path=rotation[index];
      const attempt=path==='binding'?binding(view,p,base,true):path==='spatial'?returnControl(view,p,base,true):volatile(view,p,base,true);
      if(attempt){ nextPath=(index+1)%rotation.length; return attempt; }
    }
    return stock?base:original;
  };
}
