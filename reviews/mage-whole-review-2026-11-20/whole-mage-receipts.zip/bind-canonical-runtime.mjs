import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFileSync,readdirSync } from 'node:fs';
import { join } from 'node:path';
import { checkout,readJson,receipt,sha256 } from '../bastion/study-paths.mjs';

const [output]=process.argv.slice(2);
assert(output);
const here=file=>new URL('./'+file,import.meta.url);
const stage='../mage-volatile-spellwork/';
const read=file=>readFileSync(here(stage+file),'utf8');
const stageBundle=readJson(here(stage+'censusgame01.json'));
const exact=readJson(here(stage+'source-commit01.json'));
const review=readJson(here('whole-summary02.json'));
assert(exact.passed&&exact.protocol===89&&review.passed&&review.revision===exact.contentRevision);
assert.equal(review.gameBundle,stageBundle.bundle);
assert.equal(review.cases,96);
assert.equal(review.sameUnusedInInitialAndRevised,48);
for(const [file,digest] of Object.entries(stageBundle.inputs))assert.equal(sha256(readFileSync(join(checkout,file))),digest,file);
const template=read('bundle-ui-proof.mjs');
const start=template.indexOf('contents: gameEntry ? '+String.fromCharCode(96))+23;
assert(template.slice(start,start+8)==='export {');
const end=template.indexOf(String.fromCharCode(96)+' :',start);
assert(end>start);
const gameEntry=template.slice(start,end);
const { build }=createRequire(join(checkout,'package.json'))('esbuild');
const built=await build({absWorkingDir:checkout,stdin:{contents:gameEntry,resolveDir:checkout},write:false,bundle:true,
  platform:'node',format:'esm',target:'node24',packages:'external',logLevel:'silent'});
assert.equal(sha256(built.outputFiles[0].contents),stageBundle.bundle);
function walk(scope){
  return readdirSync(join(checkout,scope),{withFileTypes:true}).flatMap(item=>{
    assert(!item.isSymbolicLink());
    const path=scope+'/'+item.name;
    return item.isDirectory()?walk(path):[path];
  });
}
const hash=createHash('sha256');
for(const file of walk('src').sort())hash.update(file+'\0').update(readFileSync(join(checkout,file)));
assert.equal(hash.digest('hex'),exact.runtimeSourceSha256);
const result={passed:true,protocol:89,sourceCommit:exact.sourceCommit,runtimeSourceSha256:exact.runtimeSourceSha256,
  sourceSnapshotSha256:exact.sourceSnapshotSha256,contentRevision:exact.contentRevision,stageBundleSha256:stageBundle.bundle,
  rebuiltBundleSha256:sha256(built.outputFiles[0].contents),canonicalOverlayPaths:Object.keys(stageBundle.inputs),reviewCases:review.cases};
receipt(output,result);
console.log(JSON.stringify(result));
