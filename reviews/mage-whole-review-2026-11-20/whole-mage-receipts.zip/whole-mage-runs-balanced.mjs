import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson,receipt,verifiedBundle } from '../bastion/study-paths.mjs';
import { magePilot } from './mage-pilot-balanced.mjs';

const [destination,cohort,filter,requestedBundle='../mage-volatile-spellwork/censusgame01'] = process.argv.slice(2);
assert(destination&&['solo','party'].includes(cohort));
const here=file=>new URL('./'+file,import.meta.url);
const binding=readJson(here(requestedBundle+'.json'));
const { Game,data,viewOf,HZ,idleInput,PROTOCOL,CONTENT_REVISION,
  mageBindingIds,pivotSigilRules,mageSpatialIds,waymarkRules,mageVolatileIds,fuseSealRules,
  distance,segmentRect,segmentCircle,restRaidInput,clearTrialWalk }=
  await verifiedBundle(fileURLToPath(here(requestedBundle+'.mjs')),binding.bundle);
assert.equal(PROTOCOL,89);
const scenarios=[['gatehouse','baby',41],['sunken-chapel','normal',73],['ossuary-works','normal',109]];
const families=['binding','spatial','volatile'];
const portfolios=['fixed','reverse'].flatMap(b=>['hold','side'].flatMap(s=>['shunt','twin'].map(v=>
  ({binding:b,spatial:s,volatile:v}))))
  .map((kit,i)=>({...kit,opening:families[i%3],id:[kit.binding,kit.spatial,kit.volatile].join('-')}));
const picked=filter?.split('/');
if(picked)assert(picked.length===3&&scenarios.some(row=>row[0]===picked[0])&&portfolios.some(row=>row.id===picked[1])&&['active','unused'].includes(picked[2]));
const point=({x,y})=>({x,y});
const bearing=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
const forward=(p,a,d)=>({x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d});
const around=angle=>Math.atan2(Math.sin(angle),Math.cos(angle));

function run(arena,difficulty,seed,portfolio,active){
  const game=new Game({mode:'standard',difficulty,seed,arenaSelection:'route',openingArenaId:arena,maxPlayers:cohort==='solo'?1:2});
  const mage=game.addPlayer('solo','Sable','mage');
  const ally=cohort==='party'?game.addPlayer('ally','Lane','soldier'):undefined;
  const actors=ally?[mage,ally]:[mage];
  const shots=new Map(), events=[], fights=[], purchases=[], crossovers=[];
  const trace=createHash('sha256');
  let serial=0,steps=0,lastShop=-1,lastEncounter=-1,fullKitAt;
  const buy=(p,kind,item)=>game.transact(p.id,{kind,item,id:'mage-review-'+(++serial)});
  const kits={
    binding:['mage-control-1',mageBindingIds.entry,mageBindingIds[portfolio.binding]],
    spatial:['mage-warding-1',mageSpatialIds.entry,mageSpatialIds[portfolio.spatial]],
    volatile:['mage-hexcraft-1',mageVolatileIds.entry,mageVolatileIds[portfolio.volatile]],
  };
  const order=[...families];
  while(order[0]!==portfolio.opening)order.push(order.shift());
  const remaining=()=>mage.totalSp-mage.skills.reduce((sum,id)=>sum+game.skillCost(id),0);
  function pick(id){
    if(mage.skills.includes(id))return;
    const result=buy(mage,'skill',id);
    assert(result.ok,JSON.stringify({id,portfolio,result,earned:mage.totalSp,remaining:remaining()}));
    purchases.push({item:id,earned:mage.totalSp,clears:mage.progress.clears,at:game.combatTick,remaining:remaining()});
  }
  function acquire(path,gate){
    const needed=kits[path].slice(0,2).filter(id=>!mage.skills.includes(id));
    if(mage.totalSp>=gate&&remaining()>=needed.reduce((sum,id)=>sum+game.skillCost(id),0))needed.forEach(pick);
  }
  function fitting(path,at){
    const [,entry,id]=kits[path];
    if(mage.totalSp>=at&&mage.skills.includes(entry)&&remaining()>=game.skillCost(id))pick(id);
  }
  function invest(){
    fitting(order[0],5);
    acquire(order[1],8);
    acquire(order[2],11);
    fitting(order[1],14);
    fitting(order[2],16);
    if(!fullKitAt&&Object.values(kits).every(([,id])=>mage.skills.includes(id)))
      fullKitAt={earned:mage.totalSp,clears:mage.progress.clears,tick:game.combatTick};
    if(mage.totalSp>=19){
      for(const id of ['general-sprint','general-brake-step','general-course-correction'])
        if(remaining()>=game.skillCost(id))pick(id);
    }
  }
  assert.equal(mage.totalSp,3);
  acquire(order[0],3);
  assert.equal(remaining(),0);
  function equipment(p) {
    for(const weapon of data.weapons.filter(w=>w.classId===p.classId).sort((a,b)=>b.tier-a.tier))
      if(p.weapon===weapon.id || buy(p,'weapon',weapon.id).ok)break;
    for(const item of ['damage','health','fire-rate','reload','magazine']) buy(p,'upgrade',item);
    buy(p,'supply','medkit');
  }
  for(const p of actors) equipment(p);
  assert(game.start());

  function danger(view,p,horizon) {
    if(view.minions.some(actor=>actor.health>0 && distance(actor,p)<28+Math.min(28,horizon*2.8)))return true;
    if(view.fields.some(field=>field.kind==='zone' && distance(field,p)<field.radius+12))return true;
    for(const shot of shots.values()) {
      const lifetime=Math.min(horizon,shot.expires-view.combatTick);
      if(lifetime<=0 || distance(shot,p)>500)continue;
      const elapsed=(view.combatTick-shot.seenAt)/HZ;
      const origin={ x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed };
      const end={ x:origin.x+shot.vx*lifetime/HZ,y:origin.y+shot.vy*lifetime/HZ };
      const entry=segmentCircle(origin,end,p,shot.radius+data.rules.playerRadius+2);
      if(entry!==null && !game.obstacles.some(wall=>(segmentRect(origin,end,wall,shot.radius)?.t??Infinity)<=entry))return true;
    }
    return false;
  }
  const visible=(a,b,r=1)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,r));
  function movement(view,p,aim) {
    const target=forward(p,aim,23), world={ ...game.arena,obstacles:game.obstacles,tick:view.combatTick };
    return clearTrialWalk(world,p,target) && !danger(view,target,5) ? { moveX:Math.cos(aim),moveY:Math.sin(aim) } : undefined;
  }
  const navigation = new Map();
  const navigationPlans = [];
  const radius = data.rules.playerRadius;
  const aimVector = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  function firingLane(player, target, input) {
    const boss = point(target);
    const walls = game.obstacles;
    const occluded = (from) => walls.some(wall => segmentRect(from, boss, wall, 4));
    if (!occluded(player)) {
      navigation.delete(player.id);
      return;
    }
    if (player.health < player.maxHealth * .28 || danger(viewOf(game, player.id), player, 10)) return;
    const now = game.combatTick;
    const world = { ...game.arena, obstacles: walls, tick: now, playerRadius: radius };
    const clear = (a, b) => clearTrialWalk(world, a, b);
    let chase = navigation.get(player.id);
    if (!chase || chase.encounter !== game.encounter || now >= chase.at + 55 || chase.target !== target.id) {
      const margin = radius + 14;
      const bends = walls.flatMap(wall => [
        { x: wall.x - margin, y: wall.y - margin }, { x: wall.x + wall.width + margin, y: wall.y - margin },
        { x: wall.x - margin, y: wall.y + wall.height + margin }, { x: wall.x + wall.width + margin, y: wall.y + wall.height + margin },
      ]).filter(p => clear(p, p));
      const goals = [142, 200, 275, 360].flatMap(range => Array.from({ length: 20 }, (_, i) => {
        const aim = aimVector(i * Math.PI / 10);
        return { x: boss.x + aim.x * range, y: boss.y + aim.y * range };
      })).filter(p => clear(p, p) && !occluded(p));
      const points = [point(player), ...bends, ...goals];
      const cheapest = points.map((_, i) => i === 0 ? 0 : Infinity);
      const parent = points.map(() => -1), visited = new Set();
      let path = [];
      for (let pass = 0; pass < points.length; pass++) {
        let index = -1, shortest = Infinity;
        for (let i = 0; i < points.length; i++) if (!visited.has(i) && cheapest[i] < shortest) {
          index = i;
          shortest = cheapest[i];
        }
        if (index < 0) break;
        if (index > bends.length) {
          for (let start = index; start > 0; start = parent[start]) path.unshift(points[start]);
          break;
        }
        visited.add(index);
        for (let next = 1; next < points.length; next++) {
          const step = distance(points[index], points[next]);
          if (visited.has(next) || shortest + step >= cheapest[next] || !clear(points[index], points[next])) continue;
          cheapest[next] = shortest + step;
          parent[next] = index;
        }
      }
      chase = { at: now, encounter: game.encounter, path, target: target.id };
      navigation.set(player.id, chase);
      if (path.length) navigationPlans.push({ player: player.id, encounter: game.encounter, tick: now, from: point(player), route: [...path] });
    }
    while (chase.path.length && distance(player, chase.path[0]) < 2) chase.path.shift();
    const next = chase.path[0];
    if (!next || !clear(player, next)) return;
    const scale = Math.max(distance(player, next), game.movementSpeed(player) / HZ);
    return { ...input, moveX: (next.x - player.x) / scale, moveY: (next.y - player.y) / scale, dodge: false };
  }


  function ordinary(view,p,current) {
    const targets=view.bossCues.filter(c=>c.health>0 && ['service-prop','stitch-pin','raid-prop','early-prop'].includes(c.kind) &&
      distance(p,c)<530 && visible(p,c,2)).sort((a,b)=>distance(p,a)-distance(p,b));
    const immediate=view.minions.filter(c=>c.health>0 && distance(p,c)<82 && visible(p,c,2));
    const target=immediate.sort((a,b)=>distance(p,a)-distance(p,b))[0]??targets[0]??view.boss;
    const aim=bearing(p,target);
    if(immediate.length) {
      const retreat=[aim+Math.PI,aim+1.6,aim-1.6].map(h=>movement(view,p,h)).find(Boolean);
      return { ...current,...retreat,aim,fire:true };
    }
    if(visible(p,target,2))
      return { ...current,aim,fire:current.fire || distance(p,target)<320 };
    if(current.dodge || danger(view,p,6))return current;
    return firingLane(p,target,{ ...current,aim }) ?? current;
  }

  const pilot=magePilot({game,mage,data,distance,danger,visible,movement,clearTrialWalk,
    pivot:pivotSigilRules,spatial:waymarkRules,fuse:fuseSealRules,portfolio,bindingIds:mageBindingIds,fuseIds:mageVolatileIds});
  while(!['victory','defeat'].includes(game.phase)&&steps++<90000){
    if(game.phase!=='combat'){
      shots.clear();
      if(['mutationVote','contractVote','secretOffer'].includes(game.phase))for(const actor of actors)game.vote(actor.id,0);
      if(game.phase==='shop'&&game.encounter!==lastShop){
        lastShop=game.encounter;
        invest();
        for(const actor of actors)equipment(actor);
      }
      game.step();game.drainEvents();continue;
    }
    if(game.encounter!==lastEncounter){
      lastEncounter=game.encounter;
      fights.push({boss:game.boss.id,arena:game.arena.id,earned:mage.totalSp,at:game.combatTick});
    }
    const view=viewOf(game,mage.id), before={q:mage.qAt,e:mage.eAt,u:mage.ultimateAt,damage:mage.damageDealt,position:point(mage)};
    for(const actor of actors){
      const p=view.players.find(row=>row.id===actor.id);
      const base=actor.status==='active'?ordinary(view,p,restRaidInput(view,p,[...shots.values()])):actor.status==='downed'?{interact:true}:{};
      const next=actor===mage&&actor.status==='active'&&active?pilot(view,p,base):base;
      const frame={...idleInput(),...next,aim:around(next.aim??0),sequence:actor.ack+1,clientTick:view.combatTick};
      trace.update(JSON.stringify(frame));
      assert(game.submitInput(actor.id,frame));
    }
    game.step();
    const batch=game.drainEvents(), notes=[];
    for(const event of batch){
      if(event.type==='shots')for(const shot of event.shots)if(shot.owner==='hostile')shots.set(shot.id,{...shot,seenAt:game.combatTick});
      if(event.type==='remove')for(const id of event.ids)shots.delete(id);
      if(event.type==='sound'&&event.owner===mage.id&&/^mage-(pivot|waymark|fuse)-/.test(event.id))notes.push(event);
    }
    const during={q:mage.qAt,e:mage.eAt,u:mage.ultimateAt,damage:mage.damageDealt,position:point(mage)};
    for(const event of notes){
      events.push({id:event.id,boss:game.boss.id,at:game.combatTick,x:event.x,y:event.y,before,during});
      if(event.id==='mage-pivot-stroke')assert(during.q>before.q);
      if(event.id==='mage-waymark-return')assert(during.e>before.e);
      if(event.id==='mage-fuse-binding'||event.id==='mage-fuse-ward')assert(during.u>before.u);
      if(event.id==='mage-fuse-echo'||event.id==='mage-fuse-vent'||event.id==='mage-fuse-shunt')assert(during.u===before.u);
    }
    const codes=notes.map(note=>note.id);
    if(codes.includes('mage-pivot-stroke')&&codes.includes('mage-fuse-binding'))crossovers.push({from:'pivot',at:game.combatTick,boss:game.boss.id});
    if(codes.includes('mage-waymark-return')&&codes.includes('mage-fuse-ward'))crossovers.push({from:'waymark',at:game.combatTick,boss:game.boss.id});
    if(codes.includes('mage-fuse-crossed')&&(codes.includes('mage-pivot-stroke')||codes.includes('mage-waymark-return')))
      crossovers.push({from:codes.includes('mage-pivot-stroke')?'pivot crossed':'waymark crossed',at:game.combatTick,boss:game.boss.id});
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(a=>[a.x,a.y,a.health,a.ammo,a.qAt,a.eAt,a.ultimateAt,a.damageDealt,a.damageTaken])]));
  }
  assert(['defeat','victory'].includes(game.phase));
  assert(remaining()>=0);
  if(!active)assert.equal(events.length,0);
  return {arena,difficulty,seed,portfolio,active,won:game.phase==='victory',clears:mage.progress.clears,earned:mage.totalSp,
    damage:mage.damageDealt,received:mage.damageTaken,fullKitAt,skills:mage.skills,purchases,fights,events,crossovers,trace:trace.digest('hex')};
}

const rows=[];
for(const args of scenarios){
  for(const kit of portfolios){
    for(const active of [false,true]){
      if(picked&&(args[0]!==picked[0]||kit.id!==picked[1]||(active?'active':'unused')!==picked[2]))continue;
      const r=run(...args,kit,active);
      rows.push(r);
      console.log(JSON.stringify({arena:r.arena,kit:kit.id,active,won:r.won,clears:r.clears,earned:r.earned,
        events:r.events.length,crossovers:r.crossovers.length}));
    }
  }
}
assert.equal(rows.length,picked?1:48);
receipt(destination,{passed:true,mode:'standard',cohort,protocol:PROTOCOL,revision:CONTENT_REVISION,
  gameBundle:binding.bundle,rows});
