import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdirSync,readFileSync } from 'node:fs';
import { promisify } from 'node:util';
import { fileURLToPath } from 'node:url';
import { readJson,receipt,sha256 } from '../bastion/study-paths.mjs';

const [output,policyMode]=process.argv.slice(2);
assert(output);
const here=file=>new URL('./'+file,import.meta.url);
const edition=readJson(here('../mage-volatile-spellwork/content01.json'));
const exact=readJson(here('../mage-volatile-spellwork/censusgame01.json'));
const balanced=policyMode==='balanced';
const editionSuffix=balanced?'02':'01';
const driver=balanced?'whole-mage-runs-balanced.mjs':'whole-mage-runs.mjs';
const policy=balanced?'mage-pilot-balanced.mjs':'mage-pilot.mjs';
const replayFolder='replays'+editionSuffix;
const controlled=readJson(here('controlled01.json'));
assert(controlled.passed&&controlled.protocol===89&&controlled.revision===edition.revision&&controlled.gameBundle===exact.bundle);
const counts=(rows,keys)=>rows.reduce((n,row)=>n+row.events.filter(e=>keys.includes(e.id)).length,0);
const digest=file=>sha256(readFileSync(here(file)));
const groupNames=['solo','party'];
const selected=[], summaries=[], paired=[], raw=[];
for(const cohort of groupNames){
  const path='whole-standard-'+cohort+editionSuffix+'.json', receiptData=readJson(here(path));
  assert(receiptData.passed&&receiptData.mode==='standard'&&receiptData.rows.length===48);
  assert(receiptData.revision===edition.revision&&receiptData.gameBundle===exact.bundle);
  const rows=receiptData.rows;
  if(balanced){
    const earlier=readJson(here('whole-standard-'+cohort+'01.json'));
    assert.deepEqual(rows.filter(row=>!row.active),earlier.rows.filter(row=>!row.active));
    assert(earlier.rows.every(row=>row.events.every(event=>!event.id.startsWith('mage-fuse-'))));
  }
  for(const inactive of rows.filter(row=>!row.active)){
    const active=rows.find(row=>row.active&&row.arena===inactive.arena&&row.portfolio.id===inactive.portfolio.id);
    assert(active);
    const common=active.purchases.filter(a=>inactive.purchases.some(b=>a.item===b.item));
    for(const item of common)assert.equal(item.earned,inactive.purchases.find(other=>other.item===item.item).earned);
    paired.push({cohort,arena:active.arena,id:active.portfolio.id,activeClears:active.clears,inactiveClears:inactive.clears,
      activeWon:active.won,inactiveWon:inactive.won,samePurchasedPrefix:common.length,inactivePrefix:inactive.purchases.length});
  }
  for(const active of [false,true]){
    const group=rows.filter(row=>row.active===active);
    summaries.push({
      cohort,active,runs:group.length,wins:group.filter(r=>r.won).length,at27:group.filter(r=>r.earned===27).length,
      fullyOwned:group.filter(r=>r.fullKitAt).length,
      pivotSpent:counts(group,['mage-pivot-stroke']),pivotContacts:counts(group,['mage-pivot-contact']),
      fixed:counts(group,['mage-pivot-fixed']),reverse:counts(group,['mage-pivot-reverse']),
      returns:counts(group,['mage-waymark-return']),arrivals:counts(group,['mage-waymark-arrive']),
      holds:counts(group,['mage-waymark-hold']),side:counts(group,['mage-waymark-side']),
      paidSeals:counts(group,['mage-fuse-binding','mage-fuse-ward']),
      vents:counts(group,['mage-fuse-vent','mage-fuse-split','mage-fuse-echo']),
      shifted:counts(group,['mage-fuse-shunt']),echo:counts(group,['mage-fuse-echo']),
      mixed:group.reduce((n,row)=>n+row.crossovers.length,0),
      damage:group.reduce((n,row)=>n+row.damage,0),taken:group.reduce((n,row)=>n+row.received,0),
    });
  }
  for(const arena of [...new Set(rows.map(row=>row.arena))]){
    const rank=row=>
      new Set(row.events.filter(e=>/stroke|arrive|vent|echo|shunt|resume|side/.test(e.id)).map(e=>e.id)).size*100+
      row.events.length;
    const choose=rows.filter(row=>row.active&&row.arena===arena).sort((a,b)=>rank(b)-rank(a))[0];
    assert(choose&&choose.events.length>0);
    const comparison=rows.find(row=>!row.active&&row.arena===arena&&row.portfolio.id===choose.portfolio.id);
    assert(comparison);
    selected.push({cohort,expected:choose},{cohort,expected:comparison});
  }
  raw.push({path,sha256:digest(path),cohort});
}
assert.equal(selected.length,12);
mkdirSync(here(replayFolder+'/'));
const call=promisify(execFile), comparisons=[];
await Promise.all([0,1].map(async start=>{
  for(let index=start;index<selected.length;index+=2){
    const {cohort,expected}=selected[index];
    const filename=replayFolder+'/'+String(index+1).padStart(2,'0')+'-'+cohort+'-'+expected.arena+'-'+(expected.active?'active':'unused')+'.json';
    await call(process.execPath,[fileURLToPath(here(driver)),fileURLToPath(here(filename)),cohort,
      [expected.arena,expected.portfolio.id,expected.active?'active':'unused'].join('/')],
    {cwd:fileURLToPath(here('.')),windowsHide:true,timeout:180_000});
    const found=readJson(here(filename));
    assert(found.passed&&found.rows.length===1&&found.gameBundle===exact.bundle);
    assert.deepEqual(found.rows[0],expected);
    comparisons[index]={path:filename,sha256:digest(filename),cohort,arena:expected.arena,kit:expected.portfolio.id,
      active:expected.active,trace:expected.trace,purchases:expected.purchases.length,operations:expected.events.length};
  }
}));
const result={passed:true,protocol:89,revision:edition.revision,gameBundle:exact.bundle,cases:96,controlledCases:2,
  exactReplays:comparisons.length,focusedSource:digest('controlled-hybrids.mjs'),controlled:digest('controlled01.json'),
  driver:digest(driver),policy:digest(policy),driverFile:driver,policyFile:policy,
  sameUnusedInInitialAndRevised:balanced?48:0,summaries,paired,raw,comparisons};
receipt(fileURLToPath(here(output)),result);
console.log(JSON.stringify({passed:true,tests:result.cases,exactReplays:result.exactReplays,summaries}));
