import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
const here=name=>new URL('./'+name,import.meta.url);
let pilot=readFileSync(here('mage-pilot.mjs'),'utf8').replaceAll('\r\n','\n');
function edit(from,to){
  assert.equal(pilot.split(from).length,2,from);
  pilot=pilot.replace(from,()=>to);
}
edit('let current=-1, nextPath=0, pivotAim, returnPlan, fusePlan;',
  'let current=-1, nextPath=0, pivotAim, returnPlan, fusePlan, reservedClock, reserveUntil;');
edit("      if(fusePlan?.useWaymark&&p.kit.waymark?.phase==='marked')return;",
  [
    "      if(fusePlan?.useWaymark&&p.kit.waymark?.phase==='marked')return;",
    '      if(fusePlan?.usePivot&&q&&now+8<state.until){',
    '        const command=binding(view,p,{...base,q:false,e:false,ultimate:false},true);',
    '        if(command?.technique1)return command;',
    '      }',
  ].join('\n'));
edit('      fusePlan={route:shunt?shuntLane(view,p):undefined};',[
  "      const pivotAvailable=p.kit.pivotSigil&&['idle','marked'].includes(p.kit.pivotSigil.phase);",
  "      const pivotOpening=portfolio.opening==='binding'||p.kit.pivotSigil?.phase==='marked';",
  '      fusePlan={route:shunt?shuntLane(view,p):undefined,usePivot:q&&pivotAvailable&&pivotOpening};',
].join('\n'));
edit("    const underWay=p.kit.waymark?.phase&&p.kit.waymark.phase!=='idle';",[
  '    const now=view.combatTick, fuseState=p.kit.fuseSeal;',
  '    if(reservedClock!==mage.ultimateAt){',
  '      reservedClock=mage.ultimateAt;',
  '      reserveUntil=undefined;',
  '    }',
  "    const canReserve=fuseState?.phase==='idle'&&mage.ultimateAt<=now&&p.health>=p.maxHealth*.43;",
  '    if(canReserve&&reserveUntil===undefined)reserveUntil=now+210;',
  '    const stock=canReserve&&now<reserveUntil;',
  '    const original=base;',
  '    if(stock)base={...base,q:false,e:false,ultimate:false};',
  "    const underWay=p.kit.waymark?.phase&&p.kit.waymark.phase!=='idle';",
].join('\n'));
edit("    const charged=volatile(view,p,base,false);",[
  '    const prime=stock&&volatile(view,p,base,true);',
  '    if(prime)return prime;',
  '    const charged=volatile(view,p,base,false);',
].join('\n'));
edit('    if(occupied)return occupied;','    if(occupied)return occupied;\n    if(stock)return base;');
edit('    return base;\n  };','    return stock?base:original;\n  };');
writeFileSync(here('mage-pilot-balanced.mjs'),pilot,{flag:'wx'});
const tested=readFileSync(here('whole-mage-runs.mjs'),'utf8').replaceAll('\r\n','\n')
  .replace("from './mage-pilot.mjs';","from './mage-pilot-balanced.mjs';");
writeFileSync(here('whole-mage-runs-balanced.mjs'),tested,{flag:'wx'});
