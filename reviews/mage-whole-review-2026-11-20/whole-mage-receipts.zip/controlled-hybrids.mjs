import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readJson,receipt,verifiedBundle } from '../bastion/study-paths.mjs';

const [output,origin='../mage-volatile-spellwork/censusgame01']=process.argv.slice(2);
assert(output);
const here=path=>new URL('./'+path,import.meta.url);
const bundle=readJson(here(origin+'.json'));
const {Game,viewOf,PROTOCOL,CONTENT_REVISION,idleInput,waymarkRules,mageSpatialIds,mageBindingIds,mageVolatileIds,fuseSealRules,distance}=
  await verifiedBundle(fileURLToPath(here(origin+'.mjs')),bundle.bundle);
assert.equal(PROTOCOL,89);
const point=({x,y})=>({x,y});
function fixture(waymark,volatile){
  const game=new Game({mode:'standard',seed:41,arenaSelection:'fixed',openingArenaId:'gatehouse',maxPlayers:2});
  game.encounter=5;
  const p=game.addPlayer('solo','Sable','mage'),ally=game.addPlayer('ally','Lane','soldier');
  const purchases=['mage-control-1',mageBindingIds.entry,'mage-warding-1',mageSpatialIds.entry,
    'mage-hexcraft-1',mageVolatileIds.entry,waymark,volatile];
  for(const item of purchases)assert(game.transact(p.id,{id:'review-'+item,kind:'skill',item}).ok,item);
  const spent=p.skills.reduce((sum,item)=>sum+game.skillCost(item),0);
  assert(spent===13&&p.totalSp>=spent);
  assert(game.start());
  const arena=structuredClone(game.arena);
  arena.obstacles=[];
  arena.lavaPits=[];
  Object.defineProperty(game,'arena',{get:()=>arena});
  Object.assign(p,{x:500,y:500});Object.assign(ally,{x:480,y:748});
  Object.assign(game.boss,{x:1280,y:760,staggerUntil:6000,deadline:6000});
  const timeline=[];
  function tick(input={}){
    assert(game.submitInput(p.id,{...idleInput(),aim:p.aim,sequence:p.ack+1,clientTick:game.combatTick,...input}));
    assert(game.submitInput(ally.id,{...idleInput(),sequence:ally.ack+1,clientTick:game.combatTick}));
    game.step();
    const sounds=game.drainEvents().filter(event=>event.type==='sound').map(event=>event.id);
    const row={tick:game.combatTick,position:point(p),input,sounds,health:p.health,damage:p.damageDealt,
      q:p.qAt,e:p.eAt,u:p.ultimateAt,kit:game.kitStatus(p.id)};
    timeline.push(row);
    return row;
  }
  const paid=()=>({q:p.qAt,e:p.eAt,u:p.ultimateAt});
  const body=()=>game.classCues().filter(cue=>cue.owner===p.id);
  while(game.combatTick<p.invulnerableUntil)tick();
  return {game,p,ally,tick,body,paid,timeline,spent,purchases};
}
function walkAway(f,origin,minimum,axis='x'){
  let ticks=0;
  while(distance(f.p,origin)<minimum&&ticks++<25)f.tick(axis==='x'?{moveX:1}:{moveY:1});
  assert(distance(f.p,origin)>=minimum);
}

const twin=fixture(mageSpatialIds.hold,mageVolatileIds.twin);
const anchor=point(twin.p);
twin.tick({technique2:true});walkAway(twin,anchor,118);
twin.tick({technique3:true});
twin.tick({technique1:true,aim:Math.PI});const pivot=twin.tick({technique1:true,aim:Math.PI});
assert(pivot.sounds.includes('mage-pivot-stroke')&&pivot.sounds.includes('mage-fuse-binding'));
const cross=twin.tick({technique2:true,aim:Math.PI});
assert(cross.sounds.includes('mage-waymark-return')&&cross.sounds.includes('mage-fuse-crossed'));
const clocks=twin.paid();
while(!twin.game.kitStatus(twin.p.id).waymark.canHold) {
  assert(twin.game.combatTick-cross.tick<12);
  twin.tick();
}
const hold=twin.tick({technique2:true});
assert(hold.kit.waymark.phase==='resting');
const holdUntil=hold.kit.waymark.until, fuseUntil=hold.kit.fuseSeal.until, parked=point(twin.p);
assert(hold.kit.waymark.traveled>=waymarkRules.fittingTravel);
const firstTarget=twin.game.minions.spawn(900001,{kind:'ordinary',x:parked.x+260,y:parked.y,health:1200,speed:0,radius:10,damage:0},twin.game.combatTick);
const nextTarget=twin.game.minions.spawn(900002,{kind:'ordinary',x:parked.x+65,y:parked.y-210,health:1200,speed:0,radius:10,damage:0},twin.game.combatTick);
assert(firstTarget&&nextTarget);
const first=twin.tick({technique3:true,aim:0});const firstLoss=1200-firstTarget.health;
assert(first.sounds.includes('mage-fuse-split')&&firstLoss>0&&nextTarget.health===1200);
assert.deepEqual(point(twin.p),parked);
assert(twin.game['emitShot']('hostile',parked.x-4,parked.y,0,30,14,4,0,1));
const wound=twin.tick();
assert(wound.health<first.health&&wound.sounds.includes('mage-fuse-wound'));
assert.equal(wound.kit.fuseSeal.until,fuseUntil-fuseSealRules.woundCost);
const echo=twin.tick({technique3:true,aim:-Math.PI/2}), echoLoss=1200-nextTarget.health;
assert(echo.sounds.includes('mage-fuse-echo')&&echoLoss>0&&echo.tick<holdUntil);
assert.equal(1200-firstTarget.health,firstLoss);
assert.deepEqual(point(twin.p),parked);
const owned=viewOf(twin.game,twin.p.id), observed=viewOf(twin.game,twin.ally.id);
assert.deepEqual(owned.classCues,observed.classCues);
assert.equal(observed.players.find(row=>row.id===twin.p.id).kit.fuseSeal,undefined);
const resume=twin.tick({technique2:true,aim:Math.PI});
assert(resume.sounds.includes('mage-waymark-resume'));
while(twin.game.kitStatus(twin.p.id).waymark.phase==='returning')twin.tick();
assert(distance(twin.p,anchor)<.01);
assert.deepEqual(twin.paid(),clocks);

const shunt=fixture(mageSpatialIds.side,mageVolatileIds.shunt);
const foot=point(shunt.p);
shunt.tick({technique1:true,aim:0});
const originalQ=shunt.tick({technique1:true,q:true,aim:0});
assert(originalQ.q>originalQ.tick&&!originalQ.sounds.includes('mage-pivot-stroke'));
assert.equal(originalQ.kit.pivotSigil.phase,'idle');
shunt.tick({technique2:true});walkAway(shunt,foot,114);
shunt.tick({technique3:true});
const beforeWard=shunt.body().find(row=>row.kind==='mage-fuse-point');
const originalE=shunt.tick({technique2:true,e:true,aim:0});
assert(originalE.e>originalE.tick&&originalE.sounds.includes('mage-fuse-ward'));
assert(!originalE.sounds.includes('mage-waymark-return'));
assert.equal(originalE.kit.waymark.phase,'idle');
assert.equal(originalE.kit.fuseSeal.phase,'ward');
assert.equal(originalE.q,originalQ.q);
const originalSpent=shunt.paid();
walkAway(shunt,beforeWard,fuseSealRules.shuntMinimum,'y');
const carried=shunt.tick({technique3:true,moveY:1,aim:0});
assert(carried.sounds.includes('mage-fuse-shunt'));
assert.deepEqual(shunt.paid(),originalSpent);
assert.equal(carried.kit.fuseSeal.until,originalE.kit.fuseSeal.until-fuseSealRules.shuntCost);
const out=shunt.tick({technique3:true,aim:0});
assert(out.sounds.includes('mage-fuse-vent'));
assert.equal(shunt.body().find(cue=>cue.kind==='mage-fuse-vent').phase,'ward');
assert.deepEqual(shunt.paid(),originalSpent);

receipt(output,{
  passed:true,controlled:true,protocol:PROTOCOL,revision:CONTENT_REVISION,gameBundle:bundle.bundle,
  twin:{earned:twin.p.totalSp,spent:twin.spent,owned:twin.purchases,clocks,holdUntil,fuseUntil,parked,
    firstDamage:firstLoss,echoDamage:echoLoss,realProjectileDamage:first.health-wound.health,arrived:point(twin.p),timeline:twin.timeline},
  shunt:{earned:shunt.p.totalSp,spent:shunt.spent,owned:shunt.purchases,originalSpent,originalQ:originalQ.tick,
    normalWard:originalE.tick,carriedAt:carried.tick,releasedAt:out.tick,timeline:shunt.timeline},
});
console.log(JSON.stringify({passed:true,twin:{earned:twin.p.totalSp,firstDamage:firstLoss,echoDamage:echoLoss,
  actualProjectileWound:first.health-wound.health},shunt:{earned:shunt.p.totalSp,wardReleased:true}}));
