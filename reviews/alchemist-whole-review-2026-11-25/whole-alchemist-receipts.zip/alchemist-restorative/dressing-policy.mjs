const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);
const heading = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const edge = (p,angle,reach) => ({x:p.x + Math.cos(angle)*reach,y:p.y + Math.sin(angle)*reach});

export function dressingPolicy({ownerRoute,partnerRoute,arenaFor,segmentRect,segmentCircle,reach}) {
  const clear = (world,a,b,pad) => !world.obstacles.some(wall => segmentRect(a,b,wall,pad) !== null);
  const walkable = (world,a,b) => clear(world,a,b,13) && world.lavaPits.every(pit => segmentCircle(a,b,pit,pit.radius+13) === null);
  const wounded = player => player.connected && player.status === 'active' && player.maxHealth - player.health >= 8;
  function fieldRoute(view,player,owner,world,base) {
    if (!wounded(player)) return;
    const field = view.classCues.find(cue => cue.kind === 'alchemy-dressing' && cue.owner === owner.id &&
      view.combatTick < cue.until - 22 && distance(player,cue) < 230 && walkable(world,player,cue));
    if (!field || base.dodge) return;
    const angle = heading(player,field), moving = distance(player,field) > field.radius * .56;
    return { ...base,supply:-1,moveX:moving ? Math.cos(angle) : 0,moveY:moving ? Math.sin(angle) : 0 };
  }
  const aimSite = (world,chemist,patient,boss) => {
    const angle = distance(chemist,patient) > 100 ? heading(chemist,patient) : heading(boss,chemist);
    const candidates = [angle,angle+.55,angle-.55,angle+1.1,angle-1.1,angle+2.2,angle-2.2];
    return candidates.find(aim => {
      const site = edge(chemist,aim,reach), {x,y,width,height} = world.bounds;
      return site.x > x+12 && site.x < x+width-12 && site.y > y+12 && site.y < y+height-12 &&
        distance(site,patient) < 195 && distance(site,boss) > 94 && clear(world,chemist,site,8) && walkable(world,patient,site);
    });
  };

  return (view,player,owner,hostile,chemistry,active,fitting) => {
    const isOwner = player.id === owner.id, now = view.combatTick;
    const base = (isOwner ? ownerRoute : partnerRoute)(view,player,hostile);
    const map = arenaFor(view.arenaId,view.run.difficulty);
    const route = active && (isOwner || fitting !== 'quick') ? fieldRoute(view,player,owner,map,base) : undefined;
    if (!isOwner) return route ?? base;
    const input = { ...(route ?? base),q:false,e:false };
    const { kit } = player;
    if (route || input.dodge || input.supply >= 0 || (kit.alchemyBrewUntil ?? 0) > now) return input;
    const ready = now >= player.eAt && now >= player.dashUntil;
    const patients = fitting === 'quick' && active ? [player] : view.players;
    const patient = patients.filter(row => wounded(row) && distance(player,row) < 255)
      .sort((a,b) => (b.maxHealth - b.health) - (a.maxHealth-a.health))[0];
    const queue = kit.alchemyPrepared ?? [], first = queue[0];
    if (first === 'mending' && ready) {
      if (!active && patient) chemistry.throw(patient);
      if (active && patient && kit.alchemyDressing?.stage !== 'placed') {
        const aim = aimSite(map,player,patient,view.boss);
        if (aim !== undefined) return { ...input,aim:Math.atan2(Math.sin(aim),Math.cos(aim)),technique3:true,fire:false,ultimate:false };
      }
      return input;
    }
    if (first === 'flare' && ready && distance(player,view.boss) < 260 && clear(map,player,view.boss,8)) {
      chemistry.throw(view.boss);
      return input;
    }
    if (!first) {
      const needed = patient ? 'mending' : 'flare';
      if (kit.alchemyRecipe !== needed) chemistry.select(needed);
      else if(now >= player.qAt) return { ...input,q:true };
    }
    return input;
  };
}
