import { dressingPolicy } from '../alchemist-restorative/dressing-policy.mjs';

const distance = (a,b) => Math.hypot(a.x - b.x,a.y - b.y);
const heading = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const toward = angle => ({moveX:Math.cos(angle),moveY:Math.sin(angle)});

export function wholeAlchemistPolicy({ownerRoute,partnerRoute,arenaFor,segmentRect,segmentCircle,flaskRange,shortRange,dressingRange}) {
  const care = dressingPolicy({ownerRoute,partnerRoute,arenaFor,segmentRect,segmentCircle,reach:dressingRange});
  const open = (map,a,b,pad) => !map.obstacles.some(wall => segmentRect(a,b,wall,pad) !== null);
  function selectedRecipe(view,owner,chemistry,base,wanted) {
    if (owner.kit.alchemyRecipe !== wanted) chemistry.select(wanted);
    else if(view.combatTick >= owner.qAt) return {...base,q:true};
    return base;
  }

  return (view,player,owner,shots,chemistry,active) => {
    const { kit } = owner, now = view.combatTick, boss = view.boss;
    const fitting = kit.alchemyDressing?.fitting;
    const dressing = active && kit.alchemyDressing;
    const hasDressing = view.classCues.some(cue => cue.kind === 'alchemy-dressing' && cue.owner === owner.id);
    const firstAid = view.players.some(row =>
      (!dressing || fitting !== 'quick' || row.id === owner.id) && row.connected && row.status === 'active' &&
      row.maxHealth-row.health >= 18 && distance(owner,row) <= 245);
    if (player.id !== owner.id || hasDressing) return care(view,player,owner,shots,chemistry,!!dressing,fitting);
    const queued = kit.alchemyPrepared ?? [];
    if ((queued[0] === 'mending' || !queued.length && firstAid) && kit.alchemyReserve?.stage !== 'brew') {
      if (!queued.length || firstAid) return care(view,player,owner,shots,chemistry,!!dressing,fitting);
      // Clear an old Mending vial if another source has already filled the wound.
      if (now >= player.eAt) chemistry.throw(player);
    }
    const base = {...ownerRoute(view,player,shots),q:false,e:false};
    if (base.dodge || base.supply >= 0 || (kit.alchemyBrewUntil??0)>now) return base;
    const arena = arenaFor(view.arenaId,view.run.difficulty), range = distance(player,boss);
    const clear = open(arena,player,boss,8), ready = now >= player.eAt && now >= player.dashUntil;
    const flash = active && kit.alchemyReaction, sleeve = active && kit.alchemyReserve;
    const reach = flash?.fitting === 'wick' ? shortRange : flaskRange;
    const ownedBinding = view.classCues.filter(cue => cue.kind === 'alchemy-pool' && cue.recipe === 'binding' && cue.owner === player.id);
    const target = ownedBinding.find(pool => pool.until > now + 16 && distance(pool,boss) < pool.radius * .69 &&
      distance(pool,player) <= reach - 4 && open(arena,player,pool,8));
    const hasFlare = queued[0] === 'flare', targetInReach = clear && range < flaskRange-15;
    const setBinding = clear && range < reach-14;
    function approach() {
      const angle = heading(player,boss), ahead = {x:player.x+Math.cos(angle)*26,y:player.y+Math.sin(angle)*26};
      return clear && open(arena,player,ahead,15) && arena.lavaPits.every(pit => segmentCircle(player,ahead,pit,pit.radius+15)===null)
        ? {...base,...toward(angle)} : base;
    }

    if (sleeve?.held) {
      if (queued[0] === 'binding' && ready && setBinding && chemistry.throw(boss)) return base;
      if (queued[0] === 'binding' && ready && range >= reach-14) return approach();
      if (sleeve.stage === 'return') return {...base,technique2:true,fire:false,ultimate:false};
      if (sleeve.stage === 'brew' && !queued.length) return selectedRecipe(view,player,chemistry,base,'mending');
      if (queued[0] !== 'binding') return base;
    }
    if (flash && hasFlare && target && !firstAid && ['aim','ready'].includes(flash.stage) && now + 3 < player.eAt) {
      return {...base,aim:heading(player,target),technique1:true,fire:false,ultimate:false};
    }
    if (sleeve?.stage === 'stow' && hasFlare && queued[1] === 'binding' && ready && !firstAid) {
      if (setBinding) return {...base,technique2:true,fire:false,ultimate:false};
      if (range >= reach-14) return approach();
    }
    if (flash && !sleeve?.held && !ownedBinding.length && !firstAid) {
      if (queued[0] === 'binding' && queued[1] === 'flare' && ready) {
        if (setBinding && chemistry.throw(boss)) return base;
        if (range >= reach-14) return approach();
        return base;
      }
      if (!queued.length) return selectedRecipe(view,player,chemistry,base,sleeve ? 'flare' : 'binding');
      if (queued.length === 1 && queued[0] === 'binding') return selectedRecipe(view,player,chemistry,base,'flare');
      if (sleeve && queued.length === 1 && hasFlare) return selectedRecipe(view,player,chemistry,base,'binding');
    }
    if (queued[0] && ready && targetInReach) chemistry.throw(boss);
    if (!queued.length) return selectedRecipe(view,player,chemistry,base,'flare');
    return base;
  };
}
