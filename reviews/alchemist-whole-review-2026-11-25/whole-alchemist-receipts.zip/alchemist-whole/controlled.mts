import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { reactiveIds, reactiveRules } = await repoImport('src/shared/alchemist-reactive.ts');
const { preparedIds } = await repoImport('src/shared/alchemist-prepared.ts');
const { restorativeIds } = await repoImport('src/shared/alchemist-restorative.ts');

const [out, edition] = process.argv.slice(2);
assert(out && ['pilot', 'source'].includes(edition));
assert.equal(PROTOCOL,107);
const formulas = [...data.skills, ...data.specializationSkills];
const cards = new Map(formulas.map(card => [card.id, card]));
type Recipe = 'flare' | 'binding' | 'mending';
type Player = ReturnType<Game['addPlayer']>;
type Control = Partial<ReturnType<typeof idleInput>>;

function fixture() {
  const game = new Game({mode:'endless',difficulty:'normal',seed:41,maxPlayers:3});
  game.encounter = 9;
  const first = game.addPlayer('owner','Perrin','alchemist');
  const other = game.addPlayer('other','Heda','alchemist');
  const ally = game.addPlayer('ally','Mara','soldier');
  let serial = 0;
  function learn(actor: Player,id: string) {
    if (actor.skills.includes(id)) return;
    const card = cards.get(id);
    assert(card,id);
    if (card.prerequisite) learn(actor,card.prerequisite);
    assert(game.transact(actor.id,{id:'chemistry-combined-' + ++serial,kind:'skill',item:id}).ok,id);
  }
  const place = (actor: Player,x: number,y: number) => Object.assign(actor,{x,y,oldX:x,oldY:y});
  function start() {
    assert(game.start());
    const cleared = {...game.arena,obstacles:[],lavaPits:[]};
    Object.defineProperty(game,'arena',{get:() => cleared});
    Object.defineProperty(game,'obstacles',{get:() => cleared.obstacles});
    Object.assign(game.boss,{x:1340,y:792,health:100000,maxHealth:100000,staggerUntil:9999,deadline:12000});
    place(first,800,700);
    place(other,800,460);
    place(ally,600,520);
  }
  function step(actor: Player, changes: Control = {}) {
    for (const person of [first,other,ally].filter(person => person.connected)) {
      assert(game.submitInput(person.id,{...idleInput(),...(actor === person ? changes : {}),
        sequence:person.ack+1,clientTick:game.combatTick}));
    }
    game.step();
  }
  function wait(until: () => boolean, actor = first) {
    for (let i=0;i<590 && !until();i++) step(actor);
    assert(until());
  }
  const kit = (actor: Player) => game.kitStatus(actor.id);
  function brew(actor: Player,recipe: Recipe) {
    wait(() => game.combatTick >= actor.qAt,actor);
    if (kit(actor).alchemyRecipe !== recipe) assert(game.selectAlchemy(actor.id,recipe));
    step(actor,{q:true});
    assert(kit(actor).alchemyBrewUntil);
    wait(() => !kit(actor).alchemyBrewUntil,actor);
    assert.equal(kit(actor).alchemyPrepared!.at(-1),recipe);
  }
  const cues = (actor: Player,kind: string) => game.classCues().filter(cue => cue.owner === actor.id && cue.kind === kind);
  function dress(actor: Player) {
    wait(() => game.combatTick >= actor.eAt,actor);
    const status = kit(actor).alchemyDressing;
    assert(status?.stage === 'ready' && status.targets?.length);
    step(actor,{technique3:true});
    const flights = cues(actor,'alchemy-flask');
    assert(flights.length && flights.every(flight => flight.recipe === 'mending'));
    wait(() => game.combatTick >= flights[0].until, actor);
    const ground = cues(actor,'alchemy-dressing');
    assert.equal(ground.length,flights.length);
    return ground;
  }
  return {game,first,other,ally,start,learn,place,step,wait,brew,kit,cues,dress};
}

function useWholeKit(transform: string) {
  const f = fixture(), actor = f.first;
  for (const id of [reactiveIds.vent,preparedIds.toss,restorativeIds.shared]) f.learn(actor,id);
  const form = formulas.find(card => card.classId === 'alchemist' && card.transform === transform);
  assert(form);
  f.learn(actor,form.id);
  const points = actor.skills.reduce((n,id) => n + cards.get(id).cost,0);
  assert(points <= actor.totalSp && actor.totalSp === 27);
  f.start();
  f.brew(actor,'flare');
  f.brew(actor,'binding');
  f.step(actor,{technique2:true});
  const seal = f.kit(actor).alchemyReserve?.held;
  assert(seal?.recipe === 'flare');
  assert.deepEqual(f.kit(actor).alchemyPrepared,['binding']);
  assert(f.game.throwAlchemy(actor.id,{x:930,y:700}));
  assert(!f.kit(actor).alchemyReserve?.held);
  assert.deepEqual(f.kit(actor).alchemyPrepared,['flare']);
  f.wait(() => f.cues(actor,'alchemy-pool').length > 0);
  const pool = f.cues(actor,'alchemy-pool')[0];
  const aim = Math.atan2(pool.y-actor.y,pool.x-actor.x);
  f.step(actor,{aim});
  assert.equal(f.kit(actor).alchemyReaction?.stage,'ready');
  const enemy = f.game.minions.spawn(99101,{kind:'ordinary',x:pool.x,y:pool.y,health:1000,speed:0,radius:10,damage:0},f.game.combatTick);
  assert(enemy);
  const chalk = f.kit(actor).alchemyChalk!;
  const damage = actor.damageDealt;
  f.step(actor,{technique1:true,aim});
  assert.equal(f.kit(actor).alchemyChalk,chalk-reactiveRules.chalk);
  assert.deepEqual(f.kit(actor).alchemyPrepared,[]);
  const returned = f.cues(actor,'alchemy-flask');
  assert(returned.length && returned.every(flight => flight.recipe === seal.recipe));
  f.wait(() => f.game.combatTick >= returned[0].until);
  assert(enemy.health < 1000 && actor.damageDealt > damage);
  const positiveDamage = actor.damageDealt-damage;
  assert(f.cues(actor,'alchemy-pool').some(cue => cue.id === pool.id && cue.until === pool.until));

  f.brew(actor,'mending');
  f.wait(() => f.game.combatTick >= actor.eAt);
  f.step(actor,{ultimate:true});
  const batch = f.kit(actor).alchemyBatchCharges!;
  const cinder = f.kit(actor).alchemyCinder!;
  const nowHealing = actor.healing;
  const fields = f.dress(actor);
  assert.equal(fields.length,transform === 'split-pour' ? 2 : 1);
  assert(fields.every(field => field.empowered && field.uses === 2));
  assert.equal(f.kit(actor).alchemyBatchCharges,batch-1);
  assert.equal(f.kit(actor).alchemyCinder,cinder);
  const [field, second = field] = fields;
  const gap = Math.hypot(field.x-second.x,field.y-second.y);
  const position = (patient,own,sibling) => {
    const offset = gap ? own.radius * .9 / gap : 0;
    f.place(patient,own.x+(own.x-sibling.x)*offset,own.y+(own.y-sibling.y)*offset);
    assert(!gap || Math.hypot(patient.x-sibling.x,patient.y-sibling.y) > sibling.radius);
  };
  position(f.ally,field,second);
  position(f.other,second,field);
  f.ally.health -= 40;
  f.other.health -= 40;
  const before = [f.ally.health,f.other.health];
  f.wait(() => f.ally.health > before[0] && f.other.health > before[1]);
  const healing = [f.ally.health-before[0], f.other.health-before[1]];
  const details = f.game.stats(actor);
  const potency = details.ability * (transform === 'settled-batch' ? 1.25 : 1);
  const rules = data.rules.alchemy;
  const expectedPortion = rules.recipes.mending.healing * potency * rules.ultimateDamageMultiplier *
    (1+(details.effects.ultimatePotency??0)) * (transform === 'split-pour' ? rules.splitMultiplier : 1) / 2;
  assert(healing.every(amount => Math.abs(amount-expectedPortion) < .001),JSON.stringify({transform,healing,expectedPortion}));
  const naturalRefund = transform === 'second-extraction' ? 1 : 0;
  assert.equal(f.kit(actor).alchemyCinder,cinder+naturalRefund);
  assert(Math.abs(actor.healing-nowHealing-healing.reduce((sum,amount) => sum+amount,0)) < .001);
  assert.equal(f.kit(actor).alchemyReaction?.stage,'spent');
  return {transform,points,owned:[...actor.skills],reserveRecipe:seal.recipe,returnedFlights:returned.length,
    preservedBinding:pool.id,positiveDamage,landedDressings:fields.length,actualPaidPortions:healing,
    brewPotency:potency,expectedPortion,batchSpent:1,reagentsReturned:naturalRefund};
}

function verifyOwnerIsolation() {
  const f = fixture();
  for (const actor of [f.first,f.other]) for (const id of [reactiveIds.entry,preparedIds.entry,restorativeIds.entry]) f.learn(actor,id);
  f.start();
  for (const actor of [f.first,f.other]) f.brew(actor,'mending');
  const [departing] = f.dress(f.first);
  const [remaining] = f.dress(f.other);
  f.brew(f.first,'flare');
  f.step(f.first,{technique2:true});
  assert.equal(f.kit(f.first).alchemyReserve?.held?.recipe,'flare');
  const before = viewOf(f.game,f.ally.id);
  assert(before.classCues.some(cue => cue.id === departing.id) && before.classCues.some(cue => cue.id === remaining.id));
  for (const player of before.players.filter(row => row.id !== f.ally.id)) {
    assert(!player.kit.alchemyDressing && !player.kit.alchemyReserve && !player.kit.alchemyReaction);
  }
  f.place(f.ally,remaining.x,remaining.y);
  f.ally.health -= 40;
  const health = f.ally.health;
  const partnerStock = f.kit(f.other).alchemyPrepared;
  f.game.setConnected(f.first.id,false);
  assert(!f.kit(f.first).alchemyReserve?.held);
  assert.deepEqual(f.kit(f.other).alchemyPrepared,partnerStock);
  const after = viewOf(f.game,f.ally.id);
  assert(!after.classCues.some(cue => cue.id === departing.id));
  const retained = after.classCues.find(cue => cue.id === remaining.id);
  assert.deepEqual(retained,before.classCues.find(cue => cue.id === remaining.id));
  f.wait(() => f.ally.health > health,f.other);
  const expected = data.rules.alchemy.recipes.mending.healing * f.game.stats(f.other).ability;
  assert(Math.abs(f.ally.health-health-expected) < .001);
  assert(Math.abs(f.other.healing-expected) < .001);
  assert.equal(f.first.healing,0);
  return {removedField:departing.id,retainedField:remaining.id,retainedExpiry:remaining.until,returnedToPartnerStock:false,
    departedCredit:f.first.healing,partnerCredit:f.other.healing,recipient:f.ally.id};
}

const combinations = ['split-pour','settled-batch','second-extraction'].map(useWholeKit);
const ownerIsolation = verifyOwnerIsolation();
const checkoutFiles = ['src/shared/game.ts','src/shared/alchemist-kit.ts','src/shared/alchemist-reactive.ts',
  'src/shared/alchemist-prepared.ts','src/shared/alchemist-restorative.ts'];
const scratchOnly = edition === 'pilot';
const sourceFiles = scratchOnly ? null : Object.fromEntries(checkoutFiles.map(file => [file,sha256(readFileSync(join(checkout,file)))]));
receipt(out,{passed:true,scratchOnly,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,sourceFiles,
  driverSha256:sha256(readFileSync(new URL(import.meta.url))),combinations,ownerIsolation});
console.log(JSON.stringify({combinations,ownerIsolation}));
