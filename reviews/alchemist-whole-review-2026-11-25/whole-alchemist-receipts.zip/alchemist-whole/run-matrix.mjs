import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

const [folder,profile,edition] = process.argv.slice(2);
assert(folder && ['standard','tactical'].includes(profile) && ['pilot','source'].includes(edition));
const pilot = edition === 'pilot';
const source = pilot ? null : readJson(new URL('../alchemist-restorative/source-commit01.json',import.meta.url));
if (source) assert(source.passed && source.protocol === 107);
const loader = pilot ? ['--import',new URL('../alchemist-restorative/overlay-loader.mjs',import.meta.url).href] : [];
if (pilot) assert.equal(process.env.GA_RESTORATIVE_MIGRATION_REHEARSAL,'yes');
const driver = fileURLToPath(new URL('run-observed.mts',import.meta.url));
const driverSha256 = digest(driver);
const worlds = ['gatehouse','sunken-chapel','ossuary-works'];
mkdirSync(folder);
const files = [];
let baseline;

async function run(name,party,...args) {
  const raw = join(folder,name+'.json'), log = join(folder,name+'.log');
  assert.equal(await runChild([...loader,driver,raw,party,profile,edition,...args],log,1200000),0,log);
  const result = readJson(raw);
  assert(result.scratchOnly === pilot && result.routed && result.effectsObserved && result.protocol === 107);
  assert(result.profile === profile && result.party === party && result.driverSha256 === driverSha256);
  for (const row of result.policyFiles) assert.equal(digest(new URL(row.path,import.meta.url)),row.sha256);
  const measured = {runtime:result.runtimeSourceSha256,content:result.contentRevision,catalogue:result.catalogueSha256,policies:result.policyFiles};
  baseline ??= measured;
  assert.deepEqual(measured,baseline);
  if (source) assert(source.contentRevision === measured.content && source.runtimeSourceSha256 === measured.runtime);
  files.push({name,raw:name+'.json',rawSha256:digest(raw),log:name+'.log',logSha256:digest(log)});
  return result.rows;
}

async function lane(party) {
  const rows = await run(party+'-all',party);
  const keyed = new Map(rows.map(row => [row.key,row]));
  assert.equal(rows.length,48);
  assert.equal(keyed.size,48);
  const equipment = [];
  for (const idle of rows.filter(row => !row.active)) {
    assert.equal(idle.effects.length,0);
    const active = keyed.get(idle.key.replace(/unused$/,'active'));
    assert(active);
    const common = Math.min(idle.purchases.length,active.purchases.length);
    assert.deepEqual(idle.purchases.slice(0,common),active.purchases.slice(0,common));
    const sharedClears = Math.min(idle.clears,active.clears);
    const a = active.loadout.filter(row => row.clears <= sharedClears);
    const b = idle.loadout.filter(row => row.clears <= sharedClears);
    if (JSON.stringify(a) !== JSON.stringify(b)) equipment.push({key:active.key,sharedClears,active:a,unused:b});
  }
  const replays = [], practices = [];
  for (const [index,arena] of worlds.entries()) for (const active of [false,true]) {
    const row = rows.filter(candidate => candidate.active === active && candidate.arena === arena)[index*2];
    const [actual] = await run(party+'-replay-'+replays.length,party,row.key);
    assert.deepEqual(actual,row);
    replays.push(row.key);
  }
  if (party === 'solo') for (const row of rows.filter(row => row.active && row.boundary)) {
    const [actual] = await run('solo-practice-'+practices.length,party,row.key,'restore');
    assert.deepEqual(actual,row);
    practices.push({key:actual.key,boundary:actual.boundary,continuation:actual.continuation,clears:actual.clears,won:actual.won});
  }
  const summaries = [];
  for (const arena of worlds) for (const active of [false,true]) {
    const cases = rows.filter(row => row.active === active && row.arena === arena);
    const effects = cases.flatMap(c => c.effects);
    const counter = key => effects.filter(effect => effect.path === key).length;
    const summary = {party,arena,active,runs:cases.length,wins:cases.filter(row => row.won).length,clears:cases.map(row => row.clears),
      fitted:cases.filter(row => row.fullyFitted).length,usedAll:cases.filter(row => row.pathsUsed.length === 3).length,
      usedAllFitted:cases.filter(row => row.fittedUsed.length === 3).length,positiveReactions:counter('reactive mixtures'),
      stowedVialsThrown:counter('prepared compounds'),treatments:counter('restorative practice'),
      partnerTreatments:effects.filter(effect => effect.recipient && effect.recipient !== 'solo').length,
      positiveDamage:effects.reduce((n,row) => n + (row.damage ?? 0),0),treatmentHealing:effects.reduce((n,row) => n + (row.healing ?? 0),0)};
    summaries.push(summary);
    console.log(JSON.stringify(summary));
  }
  return {party,replays,practices,equipment,summaries};
}

const outcomes = await Promise.allSettled(['solo','pair'].map(lane));
const passed = outcomes.every(row => row.status === 'fulfilled');
for(const result of outcomes)if(result.status === 'rejected')console.error(result.reason);
receipt(join(folder,'whole-summary.json'),{passed,scratchOnly:pilot,routed:true,effectsObserved:true,profile,source:source?.sourceCommit??null,
  matches:96,pairedComparisons:48,exactReplays:passed?12:null,sourceBytes:baseline,
  outcomes:outcomes.map(row => row.status === 'fulfilled' ? row.value : {error:String(row.reason)}),files});
if(!passed)process.exitCode = 1;
