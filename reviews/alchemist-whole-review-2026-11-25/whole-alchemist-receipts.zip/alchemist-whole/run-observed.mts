import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { situationalInput } from '../summoner-whole/situational-input.mjs';
import { navigationPolicy } from '../ranger-whole/navigation-policy.mjs';
import { wholeAlchemistPolicy } from './whole-policy.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { reactiveIds, reactiveRules } = await repoImport('src/shared/alchemist-reactive.ts');
const { preparedIds } = await repoImport('src/shared/alchemist-prepared.ts');
const { restorativeIds, dressingRules } = await repoImport('src/shared/alchemist-restorative.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle, moveBody } = await repoImport('src/shared/geometry.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');

const [output,party,profile,edition,selected,reentry] = process.argv.slice(2);
assert(output && ['solo','pair'].includes(party) && ['standard','tactical'].includes(profile) && ['source','pilot'].includes(edition));
assert(!reentry || reentry === 'restore' && party === 'solo' && selected);
assert.equal(PROTOCOL,107);
const tactical = profile === 'tactical', pilot = edition === 'pilot';
const catalogueSha256 = sha256(JSON.stringify(data));
assert.equal(catalogueSha256,CONTENT_REVISION);
const worlds = [['gatehouse',73],['sunken-chapel',67],['ossuary-works',103]] as const;
const configurations = ['wick','vent'].flatMap(reaction => ['brew','toss'].flatMap(reserve => ['shared','quick'].map(dressing => ({reaction,reserve,dressing}))));
const forms = ['split-pour','settled-batch','second-extraction'];
const skills = new Map(data.skills.map(node => [node.id,node]));
const key = (arena,fits,active) => [arena,fits.reaction,fits.reserve,fits.dressing,active ? 'active' : 'unused'].join(',');
const ordinary = tactical ? situationalInput({restRaidInput,runtimeArena,segmentRect,segmentCircle,moveBody}) : restRaidInput;
const navigation = {ordinary,arenaFor:runtimeArena,segmentRect,segmentCircle,playerRadius:data.rules.playerRadius};
const policy = () => wholeAlchemistPolicy({ownerRoute:navigationPolicy(navigation),partnerRoute:navigationPolicy(navigation),
  arenaFor:runtimeArena,segmentRect,segmentCircle,flaskRange:data.rules.alchemy.flaskRange,shortRange:reactiveRules.wickRange,dressingRange:dressingRules.range});

function play(arena,seed,fits,active,restore) {
  let game = new Game({mode:tactical ? 'long' : 'standard',difficulty:tactical ? 'baby' : 'normal',seed,openingArenaId:arena,
    arenaSelection:'fixed',maxPlayers:party === 'solo' ? 1 : 2});
  let owner = game.addPlayer('solo','Perrin Moss','alchemist');
  const members = party === 'solo' ? [owner] : [owner,game.addPlayer('ally','Mara','soldier')];
  const paths = [ ['alchemist-mixtures-1',reactiveIds.entry,reactiveIds[fits.reaction]],
    ['alchemist-reagents-1',preparedIds.entry,preparedIds[fits.reserve]], ['alchemist-dyehouse-1',restorativeIds.entry,restorativeIds[fits.dressing]] ];
  const rotation = (worlds.findIndex(row => row[0] === arena) + configurations.indexOf(fits)) % paths.length;
  const ordered = [...paths.slice(rotation),...paths.slice(0,rotation)];
  const chosenForm = forms[(rotation + configurations.indexOf(fits)) % forms.length];
  const formNode = data.skills.find(node => node.classId === 'alchemist' && node.transform === chosenForm);
  assert(formNode);
  const purchases = [], loadout = [], effects = [], encounters = [];
  const hostile = new Map(), trace = createHash('sha256'), continuation = createHash('sha256');
  const owns = id => owner.skills.includes(id);
  const totalLeft = () => owner.totalSp - owner.skills.reduce((n,id) => n + game.skillCost(id),0);
  const isFitted = () => paths.every(([, , fitting]) => owns(fitting));
  let serial = 0, lastShop = -1, frames = 0, boundary, choose = policy(), fittedInFight = false;
  const mark = (path,details) => {
    assert(active);
    effects.push({path,boss:game.boss.id,at:game.combatTick,fitted:fittedInFight,...details});
  };

  function observe(subject) {
    const restoredVials = new Set();
    const actualArea = subject.alchemyArea.bind(subject);
    subject.alchemyArea = area => {
      const result = actualArea(area);
      if (area.owner === owner.id && area.recipient && result.healing > 0) mark('restorative practice',{recipient:area.recipient,healing:result.healing});
      return result;
    };
    const land = subject.alchemy.land.bind(subject.alchemy);
    subject.alchemy.land = (player,flask,context) => {
      const before = owner.damageDealt;
      const result = land(player,flask,context);
      if (flask.owner === owner.id && flask.reaction && owner.damageDealt > before) {
        mark('reactive mixtures',{flight:flask.id,damage:owner.damageDealt-before,group:flask.refundGroup});
      }
      return result;
    };
    const release = subject.alchemy.release.bind(subject.alchemy);
    subject.alchemy.release = (stock,reserve) => {
      const result = release(stock,reserve);
      assert.equal(stock.vials[0],reserve.vial);
      restoredVials.add(reserve.vial);
      return result;
    };
    const launch = subject.alchemy.launchFlask.bind(subject.alchemy);
    subject.alchemy.launchFlask = (player,stock,...args) => {
      const vial = stock.vials[0];
      const result = launch(player,stock,...args);
      if (player.id === owner.id && restoredVials.delete(vial)) mark('prepared compounds',{recipe:vial.recipe});
      return result;
    };
  }
  observe(game);
  const updateTrace = value => {
    const text = JSON.stringify(value);
    trace.update(text);
    if (boundary) continuation.update(text);
  };
  const chemistry = {
    select(recipe) { const result = game.selectAlchemy(owner.id,recipe); if(result)updateTrace(['select',game.combatTick,recipe]); return result; },
    throw(point) { const result = game.throwAlchemy(owner.id,point); if(result)updateTrace(['throw',game.combatTick,point.x,point.y]); return result; },
  };
  const buy = (actor,kind,item) => game.transact(actor.id,{kind,item,id:'alchemist-whole-' + ++serial}).ok;
  function learn(id) {
    assert(buy(owner,'skill',id),id);
    purchases.push({id,earned:owner.totalSp,clears:owner.progress.clears,left:totalLeft()});
  }
  function advance() {
    for (const [root,entry] of ordered) if (!owns(entry) && totalLeft() >= 2 + Number(!owns(root))) {
      if (!owns(root)) learn(root);
      learn(entry);
    }
    if (paths.every(([,entry]) => owns(entry))) for (const [,,fitting] of ordered) if (!owns(fitting) && totalLeft() >= 2) learn(fitting);
    if (!isFitted()) return;
    const queue = [];
    for(let node=formNode;node && !owns(node.id);node=skills.get(node.prerequisite)) queue.unshift(node);
    if (queue.reduce((n,node) => n+node.cost,0) <= totalLeft()) for (const node of queue) learn(node.id);
  }
  function outfit(actor) {
    const equipment = (kind,item) => {
      const ok = buy(actor,kind,item);
      if(ok)loadout.push({owner:actor.id,kind,item,clears:actor.progress.clears});
      return ok;
    };
    for (const weapon of data.weapons.filter(row => row.classId === actor.classId).sort((a,b) => b.tier-a.tier)) {
      if (actor.weapon === weapon.id || equipment('weapon',weapon.id)) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) equipment('upgrade',item);
    equipment('supply','medkit');
  }
  function practiceBoundary() {
    const local = game.offlineCheckpoint();
    assert(local?.phase === 'shop' && local.practiceOnly && local.contentRevision === CONTENT_REVISION);
    assert.deepEqual(local.player.skills,owner.skills);
    const raw = JSON.stringify(local);
    boundary = {digest:sha256(raw),skills:[...owner.skills],earned:owner.totalSp,clears:owner.progress.clears,ammo:owner.ammo};
    if (!restore) return;
    game = Game.restoreOffline(JSON.parse(raw));
    owner = game.players.get('solo');
    members[0] = owner;
    observe(game);
    assert.deepEqual(owner.skills,boundary.skills);
    assert.equal(owner.ammo,boundary.ammo);
    const kit = game.kitStatus(owner.id);
    assert(!kit.alchemyReserve?.held && !kit.alchemyReaction?.target && !kit.alchemyDressing?.targets?.length);
    assert.deepEqual(kit.alchemyPrepared,[]);
    assert.equal(game.phase,'shop');
  }
  advance();
  assert.equal(purchases.length,2);
  members.forEach(outfit);
  assert(game.start());
  while (!['defeat','victory'].includes(game.phase) && frames++ < 125000) {
    if (game.phase !== 'combat') {
      hostile.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of members) game.vote(actor.id,game.phase === 'contractVote' ? 1 : 0);
      if (game.phase === 'shop' && lastShop !== game.encounter) {
        lastShop = game.encounter;
        advance();
        members.forEach(outfit);
        if (party === 'solo' && !boundary && isFitted()) practiceBoundary();
      }
      game.step(); game.drainEvents(); continue;
    }
    const view = viewOf(game,owner.id), shots = [...hostile.values()];
    const encounter = {index:view.encounter,arena:view.arenaId,boss:view.boss.id};
    if (encounters.at(-1)?.index !== encounter.index) { encounters.push(encounter); choose = policy(); }
    const alchemist = view.players.find(row => row.id === owner.id);
    assert(alchemist);
    fittedInFight = isFitted();
    for (const actor of members) {
      const player = view.players.find(row => row.id === actor.id);
      const control = actor.status === 'active' ? choose(view,player,alchemist,shots,chemistry,active) : {interact:true};
      const input = {...idleInput(),...control,clientTick:game.combatTick};
      input.aim = Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      updateTrace(input);
      assert(game.submitInput(actor.id,{...input,sequence:actor.ack+1}));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') hostile.set(shot.id,{...shot,seenAt:game.combatTick});
      if (event.type === 'remove') for (const id of event.ids) hostile.delete(id);
    }
    updateTrace([game.combatTick,game.boss.health,owner.x,owner.y,owner.health,owner.ammo,owner.healing,owner.damageDealt,owner.qAt,owner.eAt]);
  }
  assert(['defeat','victory'].includes(game.phase));
  if (restore) assert(boundary);
  const exercised = rows => [...new Set(rows.map(row => row.path))].sort();
  return {key:key(arena,fits,active),arena,seed,fitting:fits,active,won:game.phase === 'victory',clears:owner.progress.clears,
    unlocked:paths.filter(([,entry]) => owns(entry)).length,fullyFitted:isFitted(),form:owns(formNode.id) ? chosenForm : null,
    pathsUsed:exercised(effects),fittedUsed:exercised(effects.filter(row => row.fitted)),purchases,loadout,effects,encounters,boundary:boundary??null,
    trace:trace.digest('hex'),continuation:boundary ? continuation.digest('hex') : null,
    finish:{health:owner.health,bossHealth:game.boss.health,damageDealt:owner.damageDealt,healing:owner.healing,tick:game.combatTick}};
}

const rows = [];
for (const [arena,seed] of worlds) for (const fit of configurations) for (const active of [false,true]) {
  if (selected && key(arena,fit,active) !== selected) continue;
  const row = play(arena,seed,fit,active,reentry === 'restore');
  rows.push(row);
  console.log(JSON.stringify({key:row.key,won:row.won,clears:row.clears,paths:row.pathsUsed,fitted:row.fullyFitted,observed:row.effects.length}));
}
assert.equal(rows.length,selected?1:48);
const roots = pilot ? [ '../alchemist-restorative/content-pilot/', '../alchemist-restorative/stage/', '../alchemist-prepared/content-pilot/',
  '../alchemist-prepared/stage/', '../alchemist-reactive/stage/' ].map(path => fileURLToPath(new URL(path,import.meta.url))) : [];
roots.push(checkout);
function files(root,dir) {
  if (!existsSync(join(root,dir))) return [];
  return readdirSync(join(root,dir),{withFileTypes:true}).flatMap(row => row.isDirectory() ? files(root,dir + '/' + row.name) : [dir + '/' + row.name]);
}
const fingerprint = createHash('sha256');
for(const path of [...new Set(roots.flatMap(root => files(root,'src')))].sort()) {
  fingerprint.update(path + '\0').update(readFileSync(roots.map(root => join(root,path)).find(existsSync)));
}
const policyFiles = ['./whole-policy.mjs','../ranger-whole/navigation-policy.mjs','../alchemist-restorative/dressing-policy.mjs','../summoner-whole/situational-input.mjs']
  .map(path => ({path,sha256:sha256(readFileSync(new URL(path,import.meta.url)))}));
receipt(output,{scratchOnly:pilot,routed:true,effectsObserved:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,catalogueSha256,
  runtimeSourceSha256:fingerprint.digest('hex'), profile,party,driverSha256:sha256(readFileSync(new URL(import.meta.url))),policyFiles,rows});
