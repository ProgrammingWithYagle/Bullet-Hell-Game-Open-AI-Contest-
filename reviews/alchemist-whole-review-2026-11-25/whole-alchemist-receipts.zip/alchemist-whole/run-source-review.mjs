import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

const root = fileURLToPath(new URL('./',import.meta.url));
const here = path => join(root,path);
const source = readJson(new URL('../alchemist-restorative/source-commit01.json',import.meta.url));
const gate = readJson(join(checkout,'reviews/alchemist-restorative-2026-11-24/source-verification.json'));
assert(source.passed && source.protocol === 107 && gate.passed);
assert.equal(gate.runtimeSourceSha256,source.runtimeSourceSha256);
assert.equal(gate.sourceSnapshotSha256,source.sourceSnapshotSha256);

const jobs = [
  {name:'Standard Normal',driver:'run-matrix.mjs',args:[here('standard01'),'standard','source'],log:'standard01.log',timeout:2_100_000},
  {name:'Tactical Long',driver:'run-matrix.mjs',args:[here('tactical01'),'tactical','source'],log:'tactical01.log',timeout:2_100_000},
  {name:'Combined kits and owner isolation',driver:'controlled.mts',args:[here('controlled-source01.json'),'source'],log:'controlled-source01.log',timeout:120_000},
];
assert(jobs.every(job => !existsSync(here(job.log))));
const outcomes = await Promise.all(jobs.map(async job => {
  const driver = here(job.driver), log = here(job.log);
  const status = await runChild([driver,...job.args],log,job.timeout);
  const result = {name:job.name,driver:job.driver,driverSha256:digest(driver),log:job.log,logSha256:digest(log),passed:status === 0,status};
  console.log(JSON.stringify(result));
  return result;
}));
const passed = outcomes.every(job => job.passed);
receipt(here('source-review01.json'),{passed,protocol:107,source:source.sourceCommit,
  contentRevision:source.contentRevision,runtimeSourceSha256:source.runtimeSourceSha256,outcomes});
if (!passed) process.exitCode = 1;
