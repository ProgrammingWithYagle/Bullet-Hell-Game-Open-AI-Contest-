import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { closeSync, existsSync, mkdirSync, openSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const [commit, output] = process.argv.slice(2);
assert(/^[0-9a-f]{40}$/.test(commit) && output && !existsSync(output));
mkdirSync(output);
const scope = 'reviews/medic-rapid-response-2026-11-19';
const artRoot = join(checkout, 'assets/production/ui');
const existingArt = join(artRoot, 'medic-field-surgery-2026-11-19');
const newArt = join(artRoot, 'medic-rapid-response-2026-11-19');
const nativeDriver = fileURLToPath(new URL('./native-study.mts', import.meta.url));
const revision = '5c38a80c4d8992fc97b7d81f86b9e236c1d1f2f61d4a7282616b2f7289763ed6';
const digest = path => sha256(readFileSync(path));
const source = readJson(new URL('./source-commit01.json', import.meta.url));
assert(source.passed && source.sourceCommit === commit && source.contentRevision === revision);
const icons = ['medic-field-dressing-1', 'medic-surgery-steady-step-1', 'medic-surgery-set-aside-1'];
const sounds = ['launch', 'arrive', 'switch', 'handoff', 'dose'];
const fittings = ['entry', 'switchback', 'handoff'] as const;

async function reply(url: string) {
  const result = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  assert.equal(result.status, 200, url);
  return result;
}
async function health(preview) {
  const result = await (await reply(preview.endpoint + '/api/health')).json();
  assert(result.status === 'ok' && result.audience === preview.audience && result.sourceCommit === commit);
  assert(result.protocolVersion === 85 && result.contentRevision === revision);
  return result;
}
async function served(preview, member) {
  const bytes = Buffer.from(await (await reply(new URL(member.path, preview.url).href)).arrayBuffer());
  assert.equal(bytes.length, member.bytes);
  assert.equal(sha256(bytes), member.sha256);
}
function child(args: string[], log: string, limit: number) {
  const fd = openSync(log, 'wx');
  return new Promise<number | null>((resolve, reject) => {
    const processChild = spawn(process.execPath, ['--import', 'tsx', ...args],
      { cwd: checkout, stdio: ['ignore', fd, fd], windowsHide: true });
    const timeout = setTimeout(() => processChild.kill(), limit);
    processChild.once('error', error => { clearTimeout(timeout); closeSync(fd); reject(error); });
    processChild.once('exit', code => { clearTimeout(timeout); closeSync(fd); resolve(code); });
  });
}

async function review(audience: 'testing' | 'public') {
  const previewPath = join(checkout, scope, 'preview-' + audience + '.json');
  const preview = readJson(previewPath);
  assert(preview.passed && preview.sourceCommit === commit && preview.protocol === 85 && preview.contentRevision === revision);
  assert.equal(preview.runtimeSourceSha256, source.runtimeSourceSha256);
  assert.equal(preview.sourceSnapshotSha256, source.sourceSnapshotSha256);
  assert.equal(digest(preview.manifestPath), preview.manifestSha256);
  assert.equal(digest(preview.backend.path), preview.backend.sha256);
  const manifest = readJson(preview.manifestPath);
  assert(manifest.passed && manifest.members.length === preview.files && manifest.audience === audience);
  const startup = await health(preview);
  const worker = manifest.members.find(member => /offline\.worker-.*\.js$/.test(member.path));
  assert(worker);
  const workerPath = join(preview.root, worker.path);
  assert.equal(digest(workerPath), worker.sha256);
  await served(preview, worker);
  const assets = [
    ...icons.map(id => [id, '.png', join(existingArt, id + '.png')]),
    ...['medic-rescue-run-1', 'medic-response-switchback-1', 'medic-response-moving-handoff-1'].map(id => [id, '.png', join(newArt, id + '.png')]),
    ...sounds.map(code => ['medic-response-' + code, '.wav', join(checkout, 'assets/audio/sfx/medic-response-' + code + '.wav')]),
  ];
  for (const [id, suffix, original] of assets) {
    const member = manifest.members.find(member => member.path.startsWith('assets/' + id + '-') && member.path.endsWith(suffix));
    assert(member, id);
    assert.equal(digest(original), member.sha256);
    await served(preview, member);
  }

  const smoke = join(output, audience + '-http.log');
  const smokePath = join(checkout, scope, 'smoke-' + audience + '.json');
  assert(!existsSync(smokePath), 'Preserve earlier smoke receipts');
  const smokeExit = await child(['tools/smoke-client-review.mts', audience, scope], smoke, 95_000);
  assert.equal(smokeExit, 0, 'Inspect ' + smoke);
  const http = readJson(smokePath);
  assert(http.passed && http.probeRoomsClosed && http.health.startedAt === startup.startedAt);
  assert.equal(http.sourceCommit, commit);

  async function operation(transport: 'worker' | 'peer', fitting: typeof fittings[number]) {
    const stem = audience + '-' + transport + '-' + fitting;
    const raw = join(output, stem + '.json'), log = join(output, stem + '.log');
    const before = await health(preview);
    assert.equal(before.startedAt, startup.startedAt);
    const endpoint = transport === 'worker' ? workerPath : preview.endpoint;
    const status = await child([nativeDriver, transport, fitting, raw, endpoint, audience], log, 300_000);
    const after = await health(preview);
    assert.equal(after.startedAt, before.startedAt);
    const response = existsSync(raw) ? readJson(raw) : undefined;
    const passed = status === 0 && response?.passed === true;
    if (passed) {
      assert(response.testedAudience === audience && response.contentRevision === revision && response.protocol === 85);
      assert(response.transport === transport && response.fitting === fitting && response.amount > 0 && response.firstClear === 1);
      assert(response.pausedCommandsDiscarded && response.noCheckpointImports && response.physical.length === 1);
      assert.deepEqual(response.bought.map(row => row.earned), fitting === 'entry' ? [3, 3] : [3, 3, 9]);
      assert(response.paid > response.before.eAt);
      if (fitting === 'switchback') assert.equal(response.turnReceipt.extended - response.turnReceipt.start, 7);
      if (transport === 'worker') assert(response.wholeOptimizedWorker && !response.workerPatched && response.workerSha256 === worker.sha256);
      else assert(response.witnessed.ownedStatePrivate && response.witnessed.ownedSoundsPrivate && response.witnessed.nonHost);
    }
    console.log(JSON.stringify({ audience, fitting, transport, passed, status }));
    return { fitting, transport, passed, status, log: stem + '.log', logSha256: digest(log),
      raw: response && stem + '.json', resultSha256: response && digest(raw), backendStartedAt: after.startedAt };
  }

  const lanes = await Promise.all((['worker', 'peer'] as const).map(async transport => {
    const rows = [];
    for (const fitting of fittings) rows.push(await operation(transport, fitting));
    return rows;
  }));
  const cases = lanes.flat();
  const limit = Date.now() + 12_000;
  let metrics;
  do {
    metrics = await (await reply(preview.endpoint + '/api/metrics')).json();
    if (metrics.rooms === 0 && metrics.connections === 0) break;
    await sleep(100);
  } while (Date.now() < limit);
  assert.equal((await health(preview)).startedAt, startup.startedAt);
  assert.equal(digest(preview.backend.path), preview.backend.sha256);
  const passed = cases.length === 6 && cases.every(row => row.passed) && metrics.rooms === 0 && metrics.connections === 0;
  const report = { passed, audience, sourceCommit: commit, contentRevision: revision, protocol: 85,
    url: preview.url, endpoint: preview.endpoint, files: preview.files, manifestSha256: preview.manifestSha256,
    backendSha256: preview.backend.sha256, backendStartedAt: startup.startedAt, worker, sampledNewAssets: assets.length,
    httpSha256: digest(smokePath), httpLogSha256: digest(smoke), cases, caseCount: cases.length + 1,
    remainingProbeRooms: metrics.rooms, remainingProbeConnections: metrics.connections };
  receipt(join(output, 'result-' + audience + '.json'), report);
  return report;
}

const audiences = await Promise.allSettled((['testing', 'public'] as const).map(review));
const passed = audiences.every(row => row.status === 'fulfilled' && row.value.passed);
const result = { passed, sourceCommit: commit, contentRevision: revision, protocol: 85,
  checkedAt: new Date().toISOString(), nativeDriverSha256: digest(nativeDriver),
  audiences: audiences.map(row => row.status === 'fulfilled' ? row.value : { passed: false, error: String(row.reason) }) };
receipt(join(output, 'frozen-verification.json'), result);
console.log(JSON.stringify({ passed, audiences: result.audiences.map(row => row.passed ? 'passed' : row.error ?? 'failed') }));
if (!passed) process.exitCode = 1;
