import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL, idleInput, HZ } = await repoImport('src/shared/protocol.ts');
const { rapidResponseIds, rapidResponseRules } = await repoImport('src/shared/medic-rapid-response.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect } = await repoImport('src/shared/geometry.ts');
const args = process.argv.slice(2);
const [transport, fitting, out, supplied, testAudience = 'public'] = args;
assert(PROTOCOL === 85 && ['worker', 'peer'].includes(transport) && ['entry', 'switchback', 'handoff'].includes(fitting) && out);
const setup = { mode: 'short', difficulty: 'baby', arenaSelection: 'fixed', openingArenaId: 'gatehouse' } as const;
const spending = p => p.skills.reduce((sum, id) => sum + [...data.specializationSkills, ...data.skills].find(node => node.id === id).cost, 0);
const point = p => ({ x: p.x, y: p.y });
const angle = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
const closeHealth = (view, id) => view?.players.find(player => player.id === id);

async function wait(truth, why, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, why);
    await sleep(8);
  }
}
function pilotState() {
  const events = [], observed = new Map(), cues = new Map();
  return { events, observed, cues };
}
function recordCues(cues, view) {
  for (const cue of view.classCues) if (cue.kind === 'medic-response-dose') cues.set(cue.id, cue);
}
function heading(view, from, goal, reach = 0) {
  if (distance(from, goal) <= reach) return {};
  const world = bulwarkTrialWorld(view), toward = angle(from, goal);
  const options = [0, 30, -30, 60, -60, 90, -90, 120, -120].map(value => toward + value * Math.PI / 180)
    .map(aim => {
      const x = Math.cos(aim), y = Math.sin(aim);
      const end = { x: from.x + x * 28, y: from.y + y * 28 };
      return { x, y, end, score: distance(end, goal) };
    }).filter(v => clearTrialWalk(world, from, v.end)).sort((a, b) => a.score - b.score);
  const best = options[0];
  return best ? { moveX: best.x, moveY: best.y } : {};
}

function ordinaryWoundDirection(view, patient, reach, observed) {
  const world = bulwarkTrialWorld(view);
  const opportunities = view.bossCues.filter(cue => cue.kind === 'stitch-seam' && !cue.disabled && cue.until > view.combatTick + 4)
    .flatMap(cue => {
      const dx = cue.x2 - cue.x1, dy = cue.y2 - cue.y1;
      const projection = Math.max(.08, Math.min(.92,
        ((patient.x - cue.x1) * dx + (patient.y - cue.y1) * dy) / (dx * dx + dy * dy)));
      if (!Number.isFinite(projection)) return [];
      return [projection, .25, .5, .75].map(u => ({ x: cue.x1 + dx * u, y: cue.y1 + dy * u }));
    }).filter(goal => clearTrialWalk(world, patient, goal)).sort((a, b) => distance(patient, a) - distance(patient, b));
  if (opportunities[0]) return heading(view, patient, opportunities[0], 4);
  for (const offset of [3, 6, 10, 14]) {
    const path = [...observed.values()].filter(shot => shot.owner === 'hostile' && shot.expires > view.combatTick + offset)
      .map(shot => {
        const seconds = (view.combatTick - shot.seenAt + offset) / HZ;
        return { x: shot.x + shot.vx * seconds, y: shot.y + shot.vy * seconds };
      }).filter(point => distance(patient, point) <= 8 + 4.5 * offset && clearTrialWalk(world, patient, point))
      .sort((a, b) => distance(patient, a) - distance(patient, b));
    if (path[0]) return heading(view, patient, path[0], 3);
  }
  return heading(view, patient, view.boss, reach);
}

async function earnedFlow(adapter) {
  const view = () => {
    const now = adapter.view();
    assert(now);
    return now;
  };
  const owner = () => closeHealth(view(), adapter.id);
  const patient = () => closeHealth(view(), adapter.patientId ?? adapter.id);
  const ally = !!adapter.patientId;
  const sounds = (event, offset = 0) => adapter.events.slice(offset).filter(e =>
    e.type === 'sound' && e.id === 'medic-response-' + event && e.owner === adapter.id);
  const aimAtPatient = () => ally ? angle(owner(), patient()) : angle(owner(), view().boss);
  const walk = heading => ({ moveX: Math.cos(heading), moveY: Math.sin(heading), aim: aimAtPatient() });
  const purchase = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind: 'skill', item });
    assert(result.ok, JSON.stringify({ item, result }));
    purchase.push({ item, earned: owner().sp + spending(owner()), clears: owner().progress.clears });
  }
  async function equip() {
    for (const w of data.weapons.filter(w => w.classId === 'medic').sort((a, b) => b.tier - a.tier)) {
      if (owner().weapon === w.id || (await adapter.purchase({ kind: 'weapon', item: w.id })).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) await adapter.purchase({ kind: 'upgrade', item });
  }
  const fitted = fitting !== 'entry';
  assert.equal(owner().sp, 3);
  await buy('medic-recovery-1');
  await buy(rapidResponseIds.entry);
  if (fitted) assert(!(await adapter.purchase({ kind: 'skill', item: rapidResponseIds[fitting] })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat', 'The ordinary opening encounter begins');
  const shopLimit = Date.now() + 125_000;
  while (view().phase !== 'shop') {
    assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase), 'Reach the shop with an actual first clear');
    if (view().phase === 'combat') {
      const p = owner();
      const a = restRaidInput(view(), p, [...adapter.observed.values()]);
      adapter.input({ ...a, q: p.health <= p.maxHealth - 18 && !!a.q, e: p.health <= p.maxHealth - 14 && !!a.e });
      adapter.allyPressure?.();
    } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
    await sleep(25);
  }
  assert.equal(owner().progress.clears, 1);
  assert.equal(owner().sp + spending(owner()), 9);
  if (fitted) {
    await buy(rapidResponseIds[fitting]);
    const other = fitting === 'handoff' ? 'switchback' : 'handoff';
    const denied = await adapter.purchase({ kind: 'skill', item: rapidResponseIds[other] });
    assert.equal(denied.reason, 'incompatibleItem');
  }
  await equip();
  await wait(() => view().phase === 'combat', 'The second ordinary encounter begins', 95_000);
  const next = { boss: view().boss.id, start: view().combatTick };

  const missing = () => patient().maxHealth - patient().health;
  const world = () => bulwarkTrialWorld(view());
  const pointHeading = (origin, bearing, length) => ({ x: origin.x + Math.cos(bearing) * length, y: origin.y + Math.sin(bearing) * length });
  const clearLine = (a, b) => !world().obstacles.some(wall => segmentRect(a, b, wall, 1));
  const offsets = [0, .28, -.28, .6, -.6, .95, -.95, 1.38, -1.38, 1.9, -1.9, Math.PI];
  function path() {
    const p = owner(), t = patient(), landscape = world();
    const toward = ally ? angle(p, t) : angle(view().boss, p);
    for (const h of offsets.map(add => toward + add)) {
      const forward = pointHeading(p, h, 54);
      if (!clearTrialWalk(landscape, p, forward)) continue;
      if (ally && (distance(forward, t) > 58 || !clearLine(forward, t))) continue;
      if (fitting !== 'switchback') return { h };
      const firstLeg = pointHeading(p, h, 45);
      for (const turn of [h + Math.PI / 2, h - Math.PI / 2, h + 2, h - 2]) {
        const branch = pointHeading(firstLeg, turn, 38);
        if (clearTrialWalk(landscape, firstLeg, branch) && (!ally || distance(branch, t) < 58 && clearLine(branch, t)))
          return { h, turn };
      }
    }
  }

  async function pauseProbe() {
    adapter.pause(true);
    await wait(() => adapter.paused(), 'The authority acknowledges pause');
    const tick = view().combatTick, deadline = owner().kit.rapidResponse?.until;
    const ignored = adapter.input({ moveX: 1, technique2: true });
    await sleep(75);
    assert.equal(view().combatTick, tick);
    assert.equal(owner().kit.rapidResponse?.until, deadline);
    assert(owner().ack < ignored);
    adapter.pause(false);
    await wait(() => !adapter.paused(), 'The authority acknowledges resume');
  }
  const findLimit = Date.now() + 64_000;
  let launch, before, originalDeadline, turnReceipt;
  const wanted = fitting === 'handoff' ? 18 : 21;
  const past = adapter.events.length;
  if (fitting === 'handoff') await pauseProbe();
  while (!launch) {
    const p = owner(), t = patient();
    assert(Date.now() < findLimit && view().phase === 'combat', JSON.stringify({ why: 'Find an ordinary wound and clear legal approach',
      health: t.health, owner: p.health, p: point(p), t: point(t), eAt: p.eAt, tick: view().combatTick,
      boss: view().boss.id, current: p.kit.rapidResponse, launch: sounds('launch', past).length }));
    const suitable = missing() >= wanted && [p,t].every(p => p.status === 'active') && p.kit.rapidResponse?.ready;
    const sheltered = distance(p, view().boss) >= 170 && distance(t, view().boss) >= 150;
    const plan = suitable && sheltered && path();
    if (plan) {
      await adapter.stopAlly?.();
      const select = path();
      if (!select) continue;
      const seq = adapter.input({ ...walk(select.h), technique2: true });
      await wait(() => owner().ack >= seq, 'Admit the actual launch command');
      const status = owner().kit.rapidResponse;
      if (status?.phase !== 'running') continue;
      launch = select;
      before = { health: t.health, eAt: p.eAt, at: view().combatTick, location: point(p), patient: point(t) };
      originalDeadline = status.until;
      break;
    }
    if (ally) {
      const rally = world().playerSpawn;
      const allyWalk = missing() < wanted ? ordinaryWoundDirection(view(), t, 80, adapter.allyObserved ?? adapter.observed) :
        sheltered && distance(t, rally) < 65 ? {} : heading(view(), t, rally, 47);
      adapter.allyHunt?.(allyWalk);
      const direction = suitable && !sheltered ? heading(view(), p, rally, 55) : heading(view(), p, t, 34);
      adapter.input({ ...direction, aim: aimAtPatient() });
    } else {
      const direction = missing() < wanted ? ordinaryWoundDirection(view(), p, 78, adapter.observed) :
        heading(view(), p, world().playerSpawn, 70);
      adapter.input({ ...direction, aim: aimAtPatient() });
    }
    await sleep(31);
  }
  assert(launch && before && originalDeadline > view().combatTick);
  await wait(() => sounds('launch', past).length > 0, 'Owner receives the launch sound');
  const paid = owner().eAt;
  assert(paid > before.eAt && originalDeadline > view().combatTick);
  const active = () => owner().kit.rapidResponse;
  const minimum = fitting === 'switchback' ? rapidResponseRules.switchWalk : rapidResponseRules.requiredWalk;
  await wait(() => active()?.phase !== 'running' || active().walked >= minimum, 'Observe voluntary progress on full terrain');
  assert.equal(active()?.phase, 'running', JSON.stringify({ reason: 'Actual response remains active after walking', active: active(),
    owner: point(owner()), boss: view().boss.id, at: view().combatTick, originalDeadline }));
  if (fitting === 'switchback') {
    const seq = adapter.input({ ...walk(launch.turn), technique2: true });
    await wait(() => owner().ack >= seq, 'The sharp turn command is acknowledged');
    await wait(() => active()?.switched && sounds('switch', past).length > 0, 'An actual turned step earns the extra leg');
    assert.equal(active().until, originalDeadline + rapidResponseRules.switchTicks);
    turnReceipt = { start: originalDeadline, extended: active().until, at: view().combatTick, location: point(owner()) };
    await wait(() => active()?.phase !== 'running' || active().walked >= rapidResponseRules.requiredWalk, 'Cover the full minimum after the turn');
    assert.equal(active()?.phase, 'running');
  }
  const signal = fitting === 'handoff' ? 'handoff' : 'dose';
  let handoffReceipt;
  if (signal === 'handoff') {
    if (ally) {
      const p = owner(), t = patient(), toward = angle(p, t), landscape = world();
      const option = [toward, toward + Math.PI / 2, toward - Math.PI / 2, toward + .7, toward - .7, toward + Math.PI]
        .map(h => ({ h, near: pointHeading(p, h, 5), center: pointHeading(p, h, 11), far: pointHeading(p, h, 17) }))
        .filter(row => clearTrialWalk(landscape, p, row.far) && [row.near,row.center,row.far].every(end =>
          distance(end,t) >= 15 && distance(end,t) < rapidResponseRules.range - 4 && clearLine(end,t)))
        .map(row => ({ ...row, aim: angle(row.center, t) }))
        .find(row => [row.near,row.far].every(end => Math.cos(angle(end,t) - row.aim) >= rapidResponseRules.facingDot));
      assert(option, JSON.stringify({ reason: 'A moving handoff needs a clear step and patient line at contact', owner: point(p), patient: point(t), active: active() }));
      handoffReceipt = { from: point(p), patient: point(t), heading: option.h, aim: option.aim };
      adapter.input({ ...walk(option.h), aim: option.aim, technique2: true });
    } else adapter.input({ ...walk(launch.h), technique2: true });
  } else {
    adapter.input({ aim: aimAtPatient() });
    await wait(() => active()?.phase === 'arrived', 'The player stops on the real map before opening the dose');
    assert.equal(active().patient, patient().id);
    await pauseProbe();
    adapter.input({ aim: aimAtPatient(), technique2: true });
  }
  try {
    await wait(() => sounds(signal, past).length > 0 && [...adapter.cues.values()].some(cue => cue.patient === patient().id),
      'Observe positive healing and its public physical cue');
  } catch (error) {
    throw Error(JSON.stringify({ reason: String(error), owner: point(owner()), patient: point(patient()),
      active: active(), handoffReceipt, eAt: owner().eAt, cues: [...adapter.cues.values()],
      sounds: sounds(signal, past).length }), { cause: error });
  }
  const physical = [...adapter.cues.values()].filter(cue => cue.patient === patient().id);
  const amount = patient().health - before.health;
  assert(amount > 0 && physical.length === 1 && owner().eAt === paid);
  const witnessed = await adapter.peerWitness?.(physical.map(cue => cue.id));
  return { passed: true, protocol: PROTOCOL, contentRevision: CONTENT_REVISION, transport, fitting, bought: purchase,
    patient: ally ? 'actual-teammate' : 'self', firstClear: 1, next, before, paid, amount, path: launch, turnReceipt, handoffReceipt,
    physical, witnessed, pausedCommandsDiscarded: true, noCheckpointImports: true };
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Iona', classId: 'medic' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'response-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), medic = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], medic: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  medic.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, medic.id)?.kit.rapidResponse !== undefined) leaks++;
  };
  medic.onEvents = batch => remember(state.events, state.observed, batch, medic.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  medic.onPurchase = entry => replies.medic.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await medic.connect({ ...setup, name: 'Iona', classId: 'medic', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => medic.view?.players.length === 2 && host.view?.players.length === 2, 'Actual non-host Medic lobby');
    assert.equal(medic.view.owner, host.id);
    assert.notEqual(medic.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: medic.id, patientId: host.id, view: () => medic.view,
      input: props => { medic.input(inputFrame(medic.view, ++sequence, props)); return sequence; },
      purchase: request => reply(medic, replies.medic, request), start: () => host.start(),
      vote: i => { host.vote(i); medic.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => medic.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      allyObserved: peers.observed, allyHunt: i => hostInput(i), stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'Patient stops on the ordinary map');
      },
      peerWitness: async ids => {
        await wait(() => ids.some(id => peers.cues.has(id)), 'Host sees the same physical admitted dose');
        assert.equal(leaks, 0);
        assert(!peers.events.some(e => e.type === 'sound' && e.owner === medic.id && e.id.startsWith('medic-response-')));
        assert(!host.room.state.players.get(medic.id).lineworkOwner);
        return { nonHost: true, sharedCue: ids.find(id => peers.cues.has(id)), ownedStatePrivate: true, ownedSoundsPrivate: true };
      },
    });
    host.endMatch();
    await wait(() => [host, medic].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    medic.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, testedAudience: testAudience });
console.log(JSON.stringify({ ...result, physical: result.physical.map(cue => cue.id) }));
