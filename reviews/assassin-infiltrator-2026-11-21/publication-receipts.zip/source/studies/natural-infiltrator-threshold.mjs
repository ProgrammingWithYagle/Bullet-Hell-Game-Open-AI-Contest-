import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { fittingRoutePilot } from './fitting-route-pilot-threshold.mjs';
import { readJson,receipt,verifiedBundle } from '../bastion/study-paths.mjs';

const [destination,cohort,bundle='game03',mode='short',sample] = process.argv.slice(2);
assert(destination && ['solo','party'].includes(cohort) && ['short','standard'].includes(mode)&&/^game[0-9]{2}$/.test(bundle));
const here = file => new URL('./'+file,import.meta.url);
const verified = readJson(here(bundle+'.json'));
const { Game,data,viewOf,HZ,idleInput,CONTENT_REVISION,slipRouteId,slipRouteRules:rules,infiltratorIds,distance,
  segmentRect,segmentCircle,restRaidInput,clearTrialWalk } = await verifiedBundle(fileURLToPath(here(bundle+'.mjs')),verified.bundle);
const scenarios = [['gatehouse','baby',41],['sunken-chapel','normal',73],['ossuary-works','normal',109],['crown-crypt','baby',61]];
const policies = ['banked', 'unused', 'slip', 'relay', 'threshold'];
const point = ({x,y}) => ({x,y});
const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const forward = (p,a,d) => ({ x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d });
const around = angle => Math.atan2(Math.sin(angle),Math.cos(angle));

function run(arena,difficulty,seed,policy) {
  const game = new Game({ mode,difficulty,seed,arenaSelection:'route',openingArenaId:arena,maxPlayers:cohort==='solo'?1:2 });
  const infiltrator = game.addPlayer('solo','Nyx','assassin');
  const ally = cohort==='party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [infiltrator,ally] : [infiltrator];
  const shots = new Map(), events = [], fights = [];
  const trace = createHash('sha256');
  const plans = [], purchases = [];
  let serial = 0, steps = 0, lastShop = -1, lastEncounter = -1, fitting;
  const buy = (actor,kind,item) => game.transact(actor.id,{ kind,item,id:'slip-study-'+(++serial) });
  assert.equal(infiltrator.totalSp,3);
  assert(buy(infiltrator,'skill','assassin-ambush-1').ok);
  if(policy!=='banked') assert(buy(infiltrator,'skill',slipRouteId).ok);
  function equipment(p) {
    for(const weapon of data.weapons.filter(w=>w.classId===p.classId).sort((a,b)=>b.tier-a.tier))
      if(p.weapon===weapon.id || buy(p,'weapon',weapon.id).ok)break;
    for(const item of ['damage','health','fire-rate','reload','magazine']) buy(p,'upgrade',item);
    buy(p,'supply','medkit');
  }
  for(const p of actors) equipment(p);
  assert(game.start());

  function danger(view,p,horizon) {
    if(view.minions.some(actor=>actor.health>0 && distance(actor,p)<28+Math.min(28,horizon*2.8)))return true;
    if(view.fields.some(field=>field.kind==='zone' && distance(field,p)<field.radius+12))return true;
    for(const shot of shots.values()) {
      const lifetime=Math.min(horizon,shot.expires-view.combatTick);
      if(lifetime<=0 || distance(shot,p)>500)continue;
      const elapsed=(view.combatTick-shot.seenAt)/HZ;
      const origin={ x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed };
      const end={ x:origin.x+shot.vx*lifetime/HZ,y:origin.y+shot.vy*lifetime/HZ };
      const entry=segmentCircle(origin,end,p,shot.radius+data.rules.playerRadius+2);
      if(entry!==null && !game.obstacles.some(wall=>(segmentRect(origin,end,wall,shot.radius)?.t??Infinity)<=entry))return true;
    }
    return false;
  }
  const visible=(a,b,r=1)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,r));
  function movement(view,p,aim) {
    const target=forward(p,aim,23), world={ ...game.arena,obstacles:game.obstacles,tick:view.combatTick };
    return clearTrialWalk(world,p,target) && !danger(view,target,5) ? { moveX:Math.cos(aim),moveY:Math.sin(aim) } : undefined;
  }
  const navigation = new Map();
  const navigationPlans = [];
  const radius = data.rules.playerRadius;
  const aimVector = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  function firingLane(player, target, input) {
    const boss = point(target);
    const walls = game.obstacles;
    const occluded = (from) => walls.some(wall => segmentRect(from, boss, wall, 4));
    if (!occluded(player)) {
      navigation.delete(player.id);
      return;
    }
    if (player.health < player.maxHealth * .28 || danger(viewOf(game, player.id), player, 10)) return;
    const now = game.combatTick;
    const world = { ...game.arena, obstacles: walls, tick: now, playerRadius: radius };
    const clear = (a, b) => clearTrialWalk(world, a, b);
    let chase = navigation.get(player.id);
    if (!chase || chase.encounter !== game.encounter || now >= chase.at + 55 || chase.target !== target.id) {
      const margin = radius + 14;
      const bends = walls.flatMap(wall => [
        { x: wall.x - margin, y: wall.y - margin }, { x: wall.x + wall.width + margin, y: wall.y - margin },
        { x: wall.x - margin, y: wall.y + wall.height + margin }, { x: wall.x + wall.width + margin, y: wall.y + wall.height + margin },
      ]).filter(p => clear(p, p));
      const goals = [142, 200, 275, 360].flatMap(range => Array.from({ length: 20 }, (_, i) => {
        const aim = aimVector(i * Math.PI / 10);
        return { x: boss.x + aim.x * range, y: boss.y + aim.y * range };
      })).filter(p => clear(p, p) && !occluded(p));
      const points = [point(player), ...bends, ...goals];
      const cheapest = points.map((_, i) => i === 0 ? 0 : Infinity);
      const parent = points.map(() => -1), visited = new Set();
      let path = [];
      for (let pass = 0; pass < points.length; pass++) {
        let index = -1, shortest = Infinity;
        for (let i = 0; i < points.length; i++) if (!visited.has(i) && cheapest[i] < shortest) {
          index = i;
          shortest = cheapest[i];
        }
        if (index < 0) break;
        if (index > bends.length) {
          for (let start = index; start > 0; start = parent[start]) path.unshift(points[start]);
          break;
        }
        visited.add(index);
        for (let next = 1; next < points.length; next++) {
          const step = distance(points[index], points[next]);
          if (visited.has(next) || shortest + step >= cheapest[next] || !clear(points[index], points[next])) continue;
          cheapest[next] = shortest + step;
          parent[next] = index;
        }
      }
      chase = { at: now, encounter: game.encounter, path, target: target.id };
      navigation.set(player.id, chase);
      if (path.length) navigationPlans.push({ player: player.id, encounter: game.encounter, tick: now, from: point(player), route: [...path] });
    }
    while (chase.path.length && distance(player, chase.path[0]) < 2) chase.path.shift();
    const next = chase.path[0];
    if (!next || !clear(player, next)) return;
    const scale = Math.max(distance(player, next), game.movementSpeed(player) / HZ);
    return { ...input, moveX: (next.x - player.x) / scale, moveY: (next.y - player.y) / scale, dodge: false };
  }


  function ordinary(view,p,current) {
    const targets=view.bossCues.filter(c=>c.health>0 && ['service-prop','stitch-pin','raid-prop','early-prop'].includes(c.kind) &&
      distance(p,c)<530 && visible(p,c,2)).sort((a,b)=>distance(p,a)-distance(p,b));
    const immediate=view.minions.filter(c=>c.health>0 && distance(p,c)<82 && visible(p,c,2));
    const target=immediate.sort((a,b)=>distance(p,a)-distance(p,b))[0]??targets[0]??view.boss;
    const aim=bearing(p,target);
    if(immediate.length) {
      const retreat=[aim+Math.PI,aim+1.6,aim-1.6].map(h=>movement(view,p,h)).find(Boolean);
      return { ...current,...retreat,aim,fire:true };
    }
    if(visible(p,target,2))
      return { ...current,aim,fire:current.fire || distance(p,target)<320 };
    if(current.dodge || danger(view,p,6))return current;
    return firingLane(p,target,{ ...current,aim }) ?? current;
  }

  const choose = fittingRoutePilot({ game, rules, distance, segmentRect, clearTrialWalk, danger, HZ }, row => plans.push(row));
  function guideEnemy(view, p, input, actor) {
    const route = view.players.find(row => row.id === infiltrator.id).kit.slipRoute;
    if (!route?.ground || !['walk','exit','watch'].includes(route.phase) || actor.health < actor.maxHealth * .36 || danger(view, p, 4)) return input;
    const threats = [...view.minions.filter(row => row.health > 0), view.boss].filter(row => row.health > 0 && visible(route.ground, row));
    const near = threats.sort((a,b) => distance(a, route.ground) - distance(b, route.ground))[0];
    if (!near) return input;
    const lead = forward(route.ground, bearing(route.ground, near) + Math.PI, 38);
    const world = { ...game.arena, obstacles: game.obstacles, tick: view.combatTick };
    const goal = clearTrialWalk(world, p, lead) ? lead : route.ground;
    if (distance(p, goal) > 210 || !clearTrialWalk(world, p, goal)) return input;
    const scale = Math.max(distance(p, goal), game.movementSpeed(actor) / HZ);
    return { moveX: (goal.x - p.x) / scale, moveY: (goal.y - p.y) / scale, aim: bearing(p, near), fire: false };
  }
  while (!['victory','defeat'].includes(game.phase) && steps++ < 90000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of actors) game.vote(actor.id, 0);
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        for (const actor of actors) equipment(actor);
        if (!fitting && ['relay','threshold'].includes(policy)) {
          fitting = policy;
          assert.equal(infiltrator.totalSp, mode === 'short' ? 9 : 5);
          assert(buy(infiltrator, 'skill', infiltratorIds[fitting]).ok);
          const other = fitting === 'relay' ? 'threshold' : 'relay';
          assert.equal(buy(infiltrator, 'skill', infiltratorIds[other]).reason, 'incompatibleItem');
          purchases.push({ id: infiltratorIds[fitting], earned: infiltrator.totalSp, at: game.combatTick });
        }
      }
      game.step();
      game.drainEvents();
      continue;
    }
    if (game.encounter !== lastEncounter) {
      lastEncounter = game.encounter;
      fights.push({ boss: game.boss.id, arena: game.arena.id, earned: infiltrator.totalSp, tick: game.combatTick });
    }
    const view = viewOf(game, infiltrator.id);
    const before = { q: infiltrator.qAt, pos: point(infiltrator), hp: infiltrator.health, veil: game.kitStatus(infiltrator.id).veilUntil };
    let ownFrame;
    for (const actor of actors) {
      const p = view.players.find(row => row.id === actor.id);
      const base = actor.status === 'active' ? ordinary(view, p, restRaidInput(view, p, [...shots.values()])) :
        actor.status === 'downed' ? { interact: true } : {};
      const input = actor === infiltrator && actor.status === 'active' ? choose(view, p, base, actor) :
        actor === ally && actor.status === 'active' ? guideEnemy(view, p, base, actor) : base;
      const frame = { ...idleInput(), ...input, sequence: actor.ack + 1, clientTick: game.combatTick };
      frame.aim = around(frame.aim);
      if (actor === infiltrator) ownFrame = frame;
      trace.update(JSON.stringify(frame));
      assert(game.submitInput(actor.id, frame), JSON.stringify(frame));
    }
    game.step();
    const privateView = game.kitStatus(infiltrator.id);
    const echoes = game.classKits.constructs().filter(cue => cue.owner === infiltrator.id && cue.kind === 'decoy' && cue.slipRouteEcho)
      .map(({ id, x, y, health, until }) => ({ id, x, y, health, until }));
    const batch = game.drainEvents();
    const triggered = batch.some(event => event.type === 'sound' && event.owner === infiltrator.id && event.id === 'assassin-slip-threshold');
    for (const event of batch) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id, { ...shot, seenAt: game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== infiltrator.id || !event.id.startsWith('assassin-slip-')) continue;
      const action = event.id.slice('assassin-slip-'.length);
      if (action === 'mark') assert(ownFrame.technique2 && infiltrator.qAt > before.q);
      if (action === 'break') assert(Math.hypot(ownFrame.moveX, ownFrame.moveY) > 0);
      if (action === 'relay' || action === 'arm') assert(ownFrame.technique2 && infiltrator.qAt === before.q);
      if (action === 'arrive') assert(fitting === 'relay');
      if (action === 'exchange') {
        assert((triggered || ownFrame.technique2 && Math.hypot(ownFrame.moveX, ownFrame.moveY) < .001) && infiltrator.qAt === before.q);
        if (triggered) assert(fitting === 'threshold');
        if (game.phase === 'combat' && infiltrator.status === 'active') {
          assert(privateView.veilUntil < before.veil);
          if (echoes.length) assert.equal(echoes.length, 1);
        }
      }
      events.push({ action, boss: game.boss.id, at: game.combatTick, before, qAt: infiltrator.qAt, veil: privateView.veilUntil,
        state: privateView.slipRoute, point: { x: event.x, y: event.y }, echoes });
    }
    trace.update(JSON.stringify([game.phase, game.combatTick, game.boss.health, ...actors.map(a => [a.x,a.y,a.health,a.ammo,a.qAt,a.eAt,a.damageDealt,a.damageTaken])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  return { arena, difficulty, seed, policy, won: game.phase === 'victory', clears: infiltrator.progress.clears,
    events, plans, purchases, fights, navigationPlans, trace: trace.digest('hex') };
}

assert(cohort === 'party' && sample?.endsWith('/threshold'));
const chosen = sample.split('/');
if (chosen) assert(chosen.length === 2 && scenarios.some(row => row[0] === chosen[0]) && policies.includes(chosen[1]));
const rows = [], controls = [];
for (const inputs of scenarios) {
  if (chosen && inputs[0] !== chosen[0]) continue;
  const sampleRows = (chosen ? [chosen[1]] : policies).map(policy => run(...inputs, policy));
  if (!chosen) {
    assert.equal(sampleRows[0].trace, sampleRows[1].trace, inputs[0]);
    controls.push({ arena: inputs[0], sameTrace: true });
  }
  rows.push(...sampleRows);
  for (const row of sampleRows) console.log(JSON.stringify({ arena: row.arena, policy: row.policy, won: row.won, clears: row.clears,
    approaches: row.plans.length, counts: Object.fromEntries(['mark','break','exchange','lost','arm','threshold','relay','arrive'].map(action => [action, row.events.filter(e => e.action === action).length])) }));
}
receipt(destination, { stageOnly: true, visiblePathNavigation: true, contentRevision: CONTENT_REVISION,
  bundleSha256: verified.bundle, mode, cohort, rows, controls });
