import { routePilot } from './route-pilot.mjs';

export function fittingRoutePilot(context, record) {
  const approach = routePilot(context, record);
  return (view, owner, base, player) => {
    const state = owner.kit.slipRoute;
    if (state?.phase === 'relay') return { technique2: true, aim: owner.aim };
    if (state?.phase === 'relaying') return base;
    if (state?.phase === 'watch') {
      if (state.until - view.combatTick <= 8 && !context.danger(view, owner, 4)) return { technique2: true, aim: owner.aim };
      const range = context.distance(owner, state.ground);
      return range < 158 || context.danger(view, owner, 4) ? base : { ...base, moveX: 0, moveY: 0 };
    }
    return approach(view, owner, base, player);
  };
}
