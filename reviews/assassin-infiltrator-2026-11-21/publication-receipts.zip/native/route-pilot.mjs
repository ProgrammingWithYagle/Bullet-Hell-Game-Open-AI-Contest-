export function routePilot({ game, rules, distance, segmentRect, clearTrialWalk, danger, HZ }, record) {
  let plan, lastScan = -Infinity, encounter = -1;

  function point({ x, y }) { return { x, y }; }
  function bearing(from, to) { return Math.atan2(to.y - from.y, to.x - from.x); }
  function nearest({ x, y }, wall) {
    return { x: Math.min(Math.max(x, wall.x), wall.x + wall.width),
      y: Math.min(Math.max(y, wall.y), wall.y + wall.height) };
  }
  function sight(threat, from, to, wall, obstacles) {
    const hit = segmentRect(threat, to, wall);
    return distance(threat, from) < rules.threatReach - 10 && distance(threat, to) < rules.threatReach - 10 &&
      hit && hit.t > 0 && hit.t < .995 && !obstacles.some(rect => segmentRect(threat, from, rect));
  }
  function choose(view, owner, world) {
    const threats = [...view.minions.filter(member => member.health > 0), view.boss]
      .filter(body => body.health > 0 && distance(body, owner) < rules.threatReach + 120);
    if (!threats.length) return;
    const moves = [];
    for (const wall of game.arena.obstacles) {
      if (distance(owner, nearest(owner, wall)) > rules.screenReach + 145) continue;
      for (const horizontal of [true, false]) {
        const side = horizontal ? 'y' : 'x', along = horizontal ? 'x' : 'y';
        const thickness = horizontal ? wall.height : wall.width, length = horizontal ? wall.width : wall.height;
        for (const facing of [-1, 1]) for (const direction of [-1, 1]) {
          const edge = wall[side] + (facing < 0 ? 0 : thickness);
          const corner = wall[along] + (direction > 0 ? 0 : length);
          for (const gap of [35, 58, 84]) for (const offset of [8, 32, 58]) {
            const start = { [side]: edge + facing * gap, [along]: corner - direction * offset };
            const approach = distance(owner, start);
            if (approach > 143 || distance(start, nearest(start, wall)) > rules.screenReach - 7 ||
                danger(view, start, 5) || !clearTrialWalk(world, owner, start)) continue;
            for (const length of [108, 142, 178]) {
              const finish = { ...start, [along]: start[along] + direction * length };
              if (!threats.some(threat => sight(threat, start, finish, wall, world.obstacles)) ||
                  danger(view, finish, 5) || !clearTrialWalk(world, start, finish)) continue;
              moves.push({ wall, start, finish, score: approach + length * .19 });
              break;
            }
          }
        }
      }
    }
    return moves.sort((a, b) => a.score - b.score)[0];
  }

  function steer(owner, destination, speed, bend) {
    const gap = distance(owner, destination);
    const scale = Math.max(speed / HZ, gap);
    return { moveX: (destination.x - owner.x) / scale, moveY: (destination.y - owner.y) / scale, aim: bearing(owner, bend) };
  }

  return (view, owner, base, player) => {
    const now = view.combatTick, status = owner.kit.slipRoute;
    if (encounter !== game.encounter) {
      encounter = game.encounter;
      plan = undefined;
      lastScan = -Infinity;
    }
    if (owner.health < owner.maxHealth * .32 || (base.dodge && danger(view, owner, 5))) {
      plan = undefined;
      return base;
    }
    const world = { ...game.arena, obstacles: game.obstacles, tick: now };
    if (status?.phase === 'exit') return { technique2: true, aim: bearing(owner, status.cover) };
    if (status?.phase === 'walk') {
      if (!plan || distance(owner, plan.finish) <= 1 || !clearTrialWalk(world, owner, plan.finish)) return base;
      return steer(owner, plan.finish, game.movementSpeed(player), status.cover);
    }
    if (player.qAt > now || owner.kit.passageUntil > now || player.reloadAt > now || player.dashUntil > now) {
      plan = undefined;
      return base;
    }
    if (!plan || now > plan.at + 29 || distance(owner, plan.start) > 145) {
      if (now < lastScan + 15) return base;
      lastScan = now;
      const result = choose(view, owner, world);
      plan = result && { ...result, at: now };
      if (plan) record({ at: now, boss: view.boss.id, from: point(owner), approach: plan.start, exit: plan.finish, cover: plan.wall });
    }
    if (!plan || !clearTrialWalk(world, owner, plan.start)) return base;
    const gap = distance(owner, plan.start), corner = nearest(owner, plan.wall);
    if (gap <= 2) return { technique2: true, aim: bearing(owner, corner) };
    return steer(owner, plan.start, game.movementSpeed(player), corner);
  };
}
