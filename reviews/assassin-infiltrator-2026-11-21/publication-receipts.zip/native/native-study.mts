import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fittingRoutePilot } from './fitting-route-pilot.mjs';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL, HZ } = await repoImport('src/shared/protocol.ts');
const { infiltratorIds, slipRouteRules: rules } = await repoImport('src/shared/assassin-slip-route.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect } = await repoImport('src/shared/geometry.ts');

const [transport, fitting, out, supplied, testAudience = 'public'] = process.argv.slice(2);
assert(PROTOCOL === 91 && ['worker','peer'].includes(transport) && ['entry','relay','threshold'].includes(fitting) && out);
const setup = { mode:'short', difficulty:'baby', arenaSelection:'fixed', openingArenaId:'gatehouse' } as const;
const point = ({ x,y }) => ({ x,y });
const bearing = (from,to) => Math.atan2(to.y-from.y,to.x-from.x);
const heading = angle => Math.atan2(Math.sin(angle),Math.cos(angle));
const step = (p,angle,reach) => ({ x:p.x+Math.cos(angle)*reach,y:p.y+Math.sin(angle)*reach });
const closeHealth = (view,id) => view?.players.find(player => player.id === id);
const spending = p => p.skills.reduce((sum,id) => sum+[...data.specializationSkills,...data.skills].find(row => row.id === id).cost,0);

async function wait(truth, detail, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(8);
  }
}
function pilotState() {
  return { events: [], observed: new Map(), cues: new Map() };
}
function recordCues(cues, view) {
  for (const cue of view.classCues) {
    if (cue.kind !== 'decoy' || !cue.slipRouteEcho) continue;
    const snapshot = { id: cue.id, owner: cue.owner, x: cue.x, y: cue.y, until: cue.until, health: cue.health, maxHealth: cue.maxHealth };
    const existing = cues.get(cue.id);
    if (!existing) cues.set(cue.id, { first: snapshot, last: snapshot, steps: [snapshot] });
    else {
      if (distance(existing.last, snapshot) > .01) existing.steps.push(snapshot);
      existing.last = snapshot;
    }
  }
}

async function slipOperation(adapter, view, owner, status, submit, next) {
  const observations = [], marks = [], positions = [];
  let pastPhase, planEnd;
  const projection = {
    get encounter() { return view().encounter; },
    get arena() { const seen = view(); return runtimeArena(seen.arenaId, seen.run.difficulty); },
    get obstacles() { return bulwarkTrialWorld(view()).obstacles; },
    movementSpeed(player) { return player.speed; },
  };
  const danger = (seen, p, horizon) => {
    if (seen.minions.some(actor => actor.health > 0 && distance(actor, p) < 24 + horizon)) return true;
    return seen.fields.some(field => field.kind === 'zone' && distance(field, p) < field.radius + 8);
  };
  const plan = fittingRoutePilot({ game: projection, rules, distance, segmentRect, clearTrialWalk, danger, HZ }, row => positions.push(row));
  const start = adapter.events.length, original = owner().qAt, limit = Date.now() + 115_000;
  function ownedEvents() {
    return adapter.events.slice(start).filter(event => event.type === 'sound' && event.owner === adapter.id && event.id.startsWith('assassin-slip-'));
  }
  while (true) {
    const seen = view(), player = owner(), route = status();
    if (Date.now() >= limit || seen.phase !== 'combat' || player.status !== 'active') {
      assert.fail(JSON.stringify({ fitting, transport, phase: seen.phase, at: seen.combatTick, body: point(player),
        observations, positions, marks, sounds: ownedEvents().map(e => e.id) }));
    }
    if (route?.phase !== pastPhase) {
      pastPhase = route?.phase;
      observations.push({ phase: pastPhase, at: seen.combatTick, body: point(player), kit: route, qAt: player.qAt, veilUntil: player.kit.veilUntil });
    }
    if (route?.phase === 'walk' && route.ground && player.qAt > original && !marks.some(row => row.q === player.qAt)) {
      marks.push({ q: player.qAt, origin: route.ground, at: seen.combatTick, veil: player.kit.veilUntil });
    }
    if (route?.phase === 'exit' && route.bentAt && route.ground) {
      planEnd = { origin: route.ground, bend: route.bentAt, body: point(player), until: route.until };
    }
    const sounds = ownedEvents().map(e => e.id.slice('assassin-slip-'.length));
    const candidates = [...adapter.cues.values()].filter(row => row.first.owner === adapter.id);
    const echo = candidates.at(-1);
    const fitted = fitting === 'relay' ? sounds.includes('relay') && sounds.includes('arrive') && echo?.steps.length > 1 :
      fitting === 'threshold' ? sounds.includes('arm') : true;
    if (planEnd && echo && fitted && sounds.includes('exchange')) {
      const paid = player.qAt, mark = marks.find(row => row.q === paid);
      assert(mark && paid > original && player.kit.veilUntil < mark.veil);
      assert(distance(planEnd.body, planEnd.origin) >= rules.leaveDistance - .6);
      assert(distance(echo.first, mark.origin) <= .5 && echo.first.until <= mark.veil);
      assert(sounds.includes('mark') && sounds.includes('break'));
      if (fitting === 'relay') {
        assert(echo.last.id === echo.first.id && echo.last.until === echo.first.until && echo.last.health <= echo.first.health);
        assert(distance(echo.first, echo.last) >= 36 && distance(echo.first, echo.last) <= rules.relayTravel + .1);
      }
      return { paid, original, mark, planEnd, echo, sounds, observations, positions,
        held: fitting === 'threshold', autoThreshold: sounds.includes('threshold'), linkedFootsteps: fitting === 'relay' };
    }
    const base = restRaidInput(seen, player, [...adapter.observed.values()]);
    const input = { ...base, q: false, e: false, ultimate: false, fire: false, reload: false, supply: -1 };
    if (seen.combatTick < next.start + 20) {
      adapter.input(input);
      await sleep(24);
    } else await submit(plan(seen, player, input, player));
  }
}

async function earnedFlow(adapter) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const p = closeHealth(view(),adapter.id); assert(p); return p; };
  const status = () => owner().kit.slipRoute;
  const purchased = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind:'skill',item });
    assert(result.ok,JSON.stringify({ item,result }));
    purchased.push({ item,earned:owner().sp+spending(owner()),clears:owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(row => row.classId === 'assassin').sort((a,b) => b.tier-a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind:'weapon',item:weapon.id })).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({ kind:'upgrade',item });
  }
  async function submit(input) {
    const sequence = adapter.input(input);
    await wait(() => owner().ack >= sequence,'Ordinary control is acknowledged');
  }

  const isFitted = fitting !== 'entry';
  assert.equal(owner().sp,3);
  await buy('assassin-ambush-1');
  await buy(infiltratorIds.entry);
  if (isFitted) assert(!(await adapter.purchase({ kind:'skill',item:infiltratorIds[fitting] })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat','The ordinary opening encounter begins');
  if (isFitted) {
    const shopLimit = Date.now()+135_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase),'Reach the first shop after an ordinary clear');
      if (view().phase === 'combat') {
        adapter.input({...restRaidInput(view(),owner(),[...adapter.observed.values()]),q:false,e:false,ultimate:false});
        adapter.allyPressure?.();
      } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(owner().sp+spending(owner()),9);
    await buy(infiltratorIds[fitting]);
    const other = fitting === 'relay' ? infiltratorIds.threshold : infiltratorIds.relay;
    assert.equal((await adapter.purchase({ kind:'skill',item:other })).reason,'incompatibleItem');
    await equip();
    await wait(() => view().phase === 'combat','The second ordinary encounter begins',95_000);
  }
  const next = { boss:view().boss.id,arena:view().arenaId,start:view().combatTick };
  const firstClear = owner().progress.clears;

  adapter.pause(true);
  await wait(() => adapter.paused(),'The authority acknowledges pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ technique2:true });
  await sleep(90);
  assert.equal(view().combatTick,pausedAt);
  assert(owner().ack < ignored && status()?.phase === 'idle',
    JSON.stringify({ fitting,transport,pausedAt,ack:owner().ack,ignored,privateStatus:status() }));
  adapter.pause(false);
  await wait(() => !adapter.paused(),'The authority acknowledges resume');
  await adapter.stopAlly?.();

  const operation=await slipOperation(adapter,view,owner,status,submit,next);
  const witnessed=await adapter.peerWitness?.(operation);
  return {passed:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,transport,fitting,bought:purchased,firstClear,next,
    result:operation,witnessed,pausedCommandsDiscarded:true,noCheckpointImports:true};
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Nyx', classId: 'assassin' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'duel-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), assassin = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], assassin: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  assassin.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, assassin.id)?.kit.slipRoute !== undefined) leaks++;
  };
  assassin.onEvents = batch => remember(state.events, state.observed, batch, assassin.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  assassin.onPurchase = entry => replies.assassin.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await assassin.connect({ ...setup, name: 'Nyx', classId: 'assassin', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => assassin.view?.players.length === 2 && host.view?.players.length === 2, 'The Assassin joins as the second player');
    assert.equal(assassin.view.owner, host.id);
    assert.notEqual(assassin.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: assassin.id, view: () => assassin.view,
      input: props => { assassin.input(inputFrame(assassin.view, ++sequence, props)); return sequence; },
      purchase: request => reply(assassin, replies.assassin, request), start: () => host.start(),
      vote: i => { host.vote(i); assassin.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => assassin.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'The host stops on the ordinary map');
      },
      peerWitness: async operation => {
        const id = operation.echo.first.id;
        await wait(() => peers.cues.has(id), 'The host sees the exact physical echo');
        const shared = peers.cues.get(id);
        assert.equal(shared.first.owner, assassin.id);
        assert.equal(shared.first.until, operation.echo.first.until);
        if (fitting === 'relay') {
          await wait(() => distance(shared.last, operation.echo.last) <= .1, 'The host sees the same relay destination');
          assert(shared.steps.length > 1);
        }
        assert.equal(leaks, 0);
        assert(!peers.events.some(e => e.type === 'sound' && e.owner === assassin.id && e.id.startsWith('assassin-slip-')));
        return { nonHost: true, shared, ownedStatePrivate: true, ownedSoundsPrivate: true };
      },
    });
    host.endMatch();
    await wait(() => [host, assassin].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    assassin.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, driverSha256: sha256(readFileSync(new URL(import.meta.url))), testedAudience: testAudience });
console.log(JSON.stringify({ passed:true,transport,fitting,encounter:result.next.boss,firstClear:result.firstClear,paid:result.result.paid,linkedFootsteps:result.result.linkedFootsteps,held:result.result.held,echo:result.result.echo.first.id }));
