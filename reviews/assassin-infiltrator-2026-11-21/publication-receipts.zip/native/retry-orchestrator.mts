import assert from 'node:assert/strict';
import { copyFileSync, existsSync, mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const here = (name: string) => fileURLToPath(new URL('./' + name, import.meta.url));
const [attempt] = process.argv.slice(2);
assert(/^frozen-public-threshold-retry\d\d$/.test(attempt));
const first = readJson(here('frozen01/frozen-verification.json'));
const original = readJson(here('source-commit01.json'));
assert(!first.passed && first.sourceCommit === original.sourceCommit && first.audiences.length === 2);
const prior = first.audiences.find(row => row.audience === 'public');
const failed = prior.cases.filter(row => !row.passed);
assert.equal(failed.length, 1);
assert(failed[0].transport === 'worker' && failed[0].fitting === 'threshold');
const stem = 'public-worker-threshold';
const digest = path => sha256(readFileSync(path));
assert.equal(digest(here('frozen01/' + stem + '.log')), failed[0].logSha256);

const target = readJson(here(attempt + '/' + stem + '.json'));
const preview = readJson(join(checkout, 'reviews/assassin-infiltrator-2026-11-21/preview-public.json'));
assert(target.passed && target.transport === 'worker' && target.fitting === 'threshold' && target.testedAudience === 'public');
assert(target.contentRevision === first.contentRevision && target.protocol === 91 && !target.workerPatched && target.wholeOptimizedWorker);
assert.equal(target.workerSha256, prior.worker.sha256);
assert.equal(digest(join(preview.root, prior.worker.path)), prior.worker.sha256);
const driver = 'native-study.mts';
assert.equal(target.driverSha256, first.nativeDriverSha256);
assert.equal(digest(here(driver)), first.nativeDriverSha256);
assert(target.pausedCommandsDiscarded && target.noCheckpointImports && target.firstClear === 1);
assert.deepEqual(target.bought.map(row => row.earned), [3, 3, 9]);
const result = target.result;
assert(result.mark.q === result.paid && result.paid > result.original && result.echo.first.id === result.echo.last.id);
assert(result.held && ['break', 'arm', 'exchange'].every(note => result.sounds.includes(note)));

async function endpoint(audience) {
  const health = await fetch(audience.endpoint + '/api/health', { signal: AbortSignal.timeout(5_000) });
  const metrics = await fetch(audience.endpoint + '/api/metrics', { signal: AbortSignal.timeout(5_000) });
  assert(health.ok && metrics.ok);
  const body = await health.json();
  assert(body.sourceCommit === first.sourceCommit && body.protocolVersion === 91 && body.audience === audience.audience);
  assert.equal(body.startedAt, audience.backendStartedAt);
  const idle = await metrics.json();
  assert(idle.rooms === 0 && idle.connections === 0);
}
await Promise.all(first.audiences.map(endpoint));

const final = 'frozen02';
const directory = here(final);
assert(!existsSync(directory));
mkdirSync(directory);
const paths = { raw: stem + '.json', log: stem + '.log' };
for (const path of Object.values(paths)) copyFileSync(here(attempt + '/' + path), join(directory, path));
const communities = first.audiences.map(audience => {
  const cases = audience.cases.map(row => {
    if (row.passed) return { ...row, folder: 'frozen01' };
    assert(audience.audience === 'public' && row === failed[0]);
    return { ...row, ...paths, passed: true, status: 0, folder: final, resultSha256: digest(join(directory, paths.raw)),
      logSha256: digest(join(directory, paths.log)), firstAttempt: { folder: 'frozen01', log: row.log, sha256: row.logSha256, status: row.status } };
  });
  assert(cases.length === 6 && cases.every(row => row.passed));
  return { ...audience, passed: true, cases };
});
for (const audience of communities) receipt(join(directory, 'result-' + audience.audience + '.json'), audience);
const checked = { ...first, passed: true, checkedAt: new Date().toISOString(), audiences: communities,
  retryDriver: driver, retryDriverSha256: digest(here(driver)), retriedCases: 1, firstAttemptSha256: digest(here('frozen01/frozen-verification.json')) };
receipt(join(directory, 'frozen-verification.json'), checked);
console.log(JSON.stringify({ passed: true, source: first.sourceCommit, cases: 14, retainedFirstPasses: 13, repeatedCase: stem, patchedWorker: false }));
