import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {Game,data} from 'file:///C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI%20Multiplayer%20Game%20Contest%20(Bullet%20Hell)/src/shared/game.ts';
import {root,stage,read,write,sha,fingerprints,git,baseline} from './common.mjs';
process.chdir(root);const before=fingerprints(),build={definition:{id:'tank-interceptor-1'},fittings:[{id:'tank-interceptor-crossing-1'},{id:'tank-interceptor-standfast-1'}]},previous=read('reviews/tank-mobile-bulwark-r2-2026-11-14/build-census.json');
const verifiedGate=read(stage+'/gate76-runtime-verification.json');assert(verifiedGate.passed&&verifiedGate.checks.length===7);assert.equal(before.runtimeSourceSha256,verifiedGate.runtimeSourceSha256);assert.equal(before.sourceSnapshotSha256,verifiedGate.sourceSnapshotSha256);
const {conflictingSkill}=await import(pathToFileURL(root+'/src/shared/skill-conflicts.ts'));
const fittingIds=build.fittings.map(f=>f.id),all=[...data.skills,...data.generalSkills,...data.specializationSkills],byId=new Map(all.map(s=>[s.id,s])),sharedIds=new Set(data.generalSkills.map(s=>s.id)),reports=[];
const conflicts=(owned,id)=>conflictingSkill(owned,id);
for(const classId of ['engineer','soldier','heavy','tank']){
 const techniques=data.specializationSkills.filter(s=>s.classId===classId),techniqueIds=new Set(techniques.map(s=>s.id)),candidate=new Set();
 function addWithParents(id){if(candidate.has(id))return;const node=byId.get(id);assert(node);if(node.prerequisite)addWithParents(node.prerequisite);candidate.add(id);}
 for(const id of [...techniqueIds,...sharedIds])addWithParents(id);const ordered=[...candidate].map(id=>byId.get(id)),owned=[],distinct=new Map();let rawSets=0;
 function enumerate(index,spent,capstones){
  if(index===ordered.length){if(!owned.some(id=>techniqueIds.has(id)))return;rawSets++;const signature=owned.filter(id=>techniqueIds.has(id)||sharedIds.has(id)).sort().join('|'),old=distinct.get(signature);if(!old||spent<old.spent)distinct.set(signature,{skills:[...owned],spent,remaining:27-spent,capstones,operationAndSharedSignature:signature});return;}
  enumerate(index+1,spent,capstones);const node=ordered[index];if((node.prerequisite&&!owned.includes(node.prerequisite))||Number(node.freePlaySpRequired??0)>27||spent+node.cost>27||(node.capstone&&capstones)||conflicts(owned,node.id))return;owned.push(node.id);enumerate(index+1,spent+node.cost,capstones+Number(node.capstone));owned.pop();
 }
 enumerate(0,0,0);const builds=[...distinct.values()];let purchases=0;
 for(const candidate of builds){
  const g=new Game({mode:'endless',seed:41,maxPlayers:1});g.encounter=9;const p=g.addPlayer('solo','Research build legality',classId);assert.equal(p.totalSp,27);
  for(const item of candidate.skills){const result=g.transact(p.id,{id:'research-'+ ++purchases,kind:'skill',item});assert(result.ok,JSON.stringify({classId,item,result,skills:p.skills}));}assert.deepEqual(p.skills,candidate.skills);assert.equal(p.skills.reduce((n,id)=>n+g.skillCost(id),0),candidate.spent);assert(candidate.capstones<=1);
 }
 const prior=previous.reports.find(r=>r.classId===classId),signatures=new Set(builds.map(b=>b.operationAndSharedSignature));assert(prior.builds.every(b=>signatures.has(b.operationAndSharedSignature)));if(classId!=='tank')assert.equal(signatures.size,prior.distinctSets);
 const variantBreakdown=classId==='tank'?Object.fromEntries(['none','forward','crossing','standfast'].map(mode=>[mode,Object.fromEntries(['none','plain','pivot','port'].map(handling=>[handling,builds.filter(b=>{const actualMode=b.skills.includes(fittingIds[0])?'crossing':b.skills.includes(fittingIds[1])?'standfast':b.skills.includes(build.definition.id)?'forward':'none';const actualHandling=b.skills.includes('tank-bulwark-pivot-1')?'pivot':b.skills.includes('tank-bulwark-port-1')?'port':b.skills.includes('tank-bulwark-carry-1')?'plain':'none';return actualMode===mode&&actualHandling===handling;}).length]))])):undefined;
 reports.push({classId,techniques:techniques.length,distinctSets:builds.length,rawSetsBeforeSignatureDeduplication:rawSets,purchases,priorSetsPreserved:prior.distinctSets,variantBreakdown,builds});
}
assert.deepEqual(fingerprints(),before);assert.equal(git('rev-parse','HEAD'),baseline);const report={at:new Date().toISOString(),base:baseline,runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,contentRevision:read('content/revision.json').sha256,driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),totalSets:reports.reduce((n,r)=>n+r.distinctSets,0),priorSetCount:previous.totalSets,reports,canonicalSourceEdited:true,canonicalCardsRegistered:3,onlineProof:false,scope:'Actual current canonical source imports; local uncommitted working-tree measurement only. Distinct operation/shared signatures use actual controlled27SP purchases; minimal-SP representatives deduplicate unused numerical ancestors. Current canonical conflict authority predicts candidates; actual current Game.transact validates every final purchase. Excludes numerical General variations, natural acquisition, balance and network proof.'};write(stage+'/canonical-census81.json',report);console.log(JSON.stringify({totalSets:report.totalSets,priorSets:previous.totalSets,classes:reports.map(({builds,...row})=>row)}));
