import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {Game,data} from 'file:///C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI%20Multiplayer%20Game%20Contest%20(Bullet%20Hell)/src/shared/game.ts';
import {screenPathClear} from 'file:///C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI%20Multiplayer%20Game%20Contest%20(Bullet%20Hell)/src/shared/tank-interceptor.ts';
import {root,stage,read,write,sha,fingerprints,git,baseline} from './common.mjs';
process.chdir(root);const before=fingerprints(),build={definition:{id:'tank-interceptor-1'},fittings:[{id:'tank-interceptor-crossing-1'},{id:'tank-interceptor-standfast-1'}]};
const verifiedGate=read(stage+'/gate76-runtime-verification.json');assert(verifiedGate.passed&&verifiedGate.checks.length===7);assert.equal(before.runtimeSourceSha256,verifiedGate.runtimeSourceSha256);assert.equal(before.sourceSnapshotSha256,verifiedGate.sourceSnapshotSha256);
const {idleInput}=await import(pathToFileURL(root+'/src/shared/protocol.ts'));
const {clearTrialWalk}=await import(pathToFileURL(root+'/tests/helpers/tank-bulwark-staging.ts'));
const bearings=Array.from({length:16},(_,i)=>Math.atan2(Math.sin(-Math.PI/2+i*Math.PI/8),Math.cos(-Math.PI/2+i*Math.PI/8))),point=p=>({x:p.x,y:p.y}),distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const variants=[{mode:'forward',side:0},{mode:'crossing',side:-1},{mode:'crossing',side:1},{mode:'standfast',side:0}];
function motion(normal,variant){return variant.mode==='standfast'?{x:0,y:0}:variant.mode==='crossing'?{x:-normal.y*variant.side,y:normal.x*variant.side}:normal;}
function plan(world,start,variant){
 const queue=[{p:point(start),gx:0,gy:0,parent:-1}],seen=new Set(['0:0']);
 for(let at=0;at<queue.length&&at<640;at++){
  const node=queue[at],aim=bearings.find(aim=>{const n={x:Math.cos(aim),y:Math.sin(aim)},m=motion(n,variant);return screenPathClear(world,node.p,{x:node.p.x+m.x*180,y:node.p.y+m.y*180},n);});
  if(aim!==undefined){const path=[];for(let i=at;queue[i].parent>=0;i=queue[i].parent)path.unshift(queue[i].p);return {aim,path,searched:at+1};}
  for(const [dx,dy]of [[0,1],[1,0],[0,-1],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]]){const gx=node.gx+dx,gy=node.gy+dy,key=gx+':'+gy;if(seen.has(key))continue;seen.add(key);const p={x:start.x+gx*24,y:start.y+gy*24};if(clearTrialWalk(world,node.p,p))queue.push({p,gx,gy,parent:at});}
 }
}
const rows=[];
for(const arena of data.arenas)for(const difficulty of data.difficulties)for(const variant of variants){
 let result;try{
  const g=new Game({mode:'endless',difficulty:difficulty.id,seed:41,maxPlayers:1,openingArenaId:arena.id,arenaSelection:'fixed'});g.encounter=9;const p=g.addPlayer('tank','Untouched map fitting geometry','tank');assert.equal(p.totalSp,27);
  const items=['tank-bastion-1',build.definition.id,...(variant.mode==='forward'?[]:[build.fittings.find(f=>f.id.includes(variant.mode==='crossing'?'crossing':'standfast')).id])];for(const item of items)assert(g.transact(p.id,{id:item,kind:'skill',item}).ok);assert(g.start());g.boss.staggerUntil=1_000_000;
  const observedEvents=[];let sequence=0;const step=(input={})=>{assert(g.submitInput(p.id,{...idleInput(),sequence:++sequence,clientTick:g.combatTick,aim:0,...input}));g.step();observedEvents.push(...g.drainEvents());};while(g.combatTick<=p.invulnerableUntil)step();
  const world=()=>({tick:g.combatTick,playerRadius:data.rules.playerRadius,bounds:g.arena.bounds,obstacles:g.obstacles,lavaPits:g.arena.lavaPits}),route=plan(world(),p,variant);assert(route,'Actually walkable full-width staging route');
  const initialTerrainSha256=sha(JSON.stringify({arena:g.arena,obstacles:g.obstacles}));
  for(const target of route.path){for(let n=0;distance(p,target)>.5;n++){assert(n<180);const size=Math.max(distance(p,target),g.movementSpeed(p)/30);step({moveX:(target.x-p.x)/size,moveY:(target.y-p.y)/size,aim:route.aim});}step({aim:route.aim});}
  step({technique3:true,aim:route.aim});assert.equal(g.interceptor.stateSnapshot(p.id)?.phase,'winding');while(g.interceptor.stateSnapshot(p.id)?.phase==='winding')step({aim:route.aim});assert.equal(g.interceptor.stateSnapshot(p.id)?.phase,'ready');
  const invuln=p.invulnerableUntil,n={x:Math.cos(route.aim),y:Math.sin(route.aim)},m=motion(n,variant);step({technique3:true,aim:route.aim,moveX:variant.mode==='crossing'?m.x:0,moveY:variant.mode==='crossing'?m.y:0});const state=g.interceptor.stateSnapshot(p.id);assert.equal(state?.phase,'screen');assert.equal(state.mode,variant.mode);assert.equal(p.invulnerableUntil,invuln);const origin=point(p),eAt=p.eAt;
  const hp=p.health+p.shield,round=g.emitShot('hostile',p.x+n.x*80,p.y+n.y*80,Math.atan2(-n.y,-n.x),2400,25,3);assert(round);step({aim:route.aim});assert(!g.shots.has(round.id));assert(observedEvents.some(e=>e.type==='sound'&&e.owner===p.id&&e.id==='tank-intercept-impact'));assert.equal(p.health+p.shield,hp);
  while(g.combatTick<state.until)step({aim:route.aim});assert(!g.interceptor.stateSnapshot(p.id));const expected=variant.mode==='standfast'?0:180;assert(Math.abs(distance(origin,p)-expected)<.1);assert(Math.abs(p.x-origin.x-m.x*expected)<.1);assert(Math.abs(p.y-origin.y-m.y*expected)<.1);assert.equal(p.eAt,eAt);assert.equal(sha(JSON.stringify({arena:g.arena,obstacles:g.obstacles})),initialTerrainSha256);
  result={arena:arena.id,difficulty:difficulty.id,...variant,passed:true,actualWalkWaypoints:route.path.length,searched:route.searched,aim:route.aim,actualDistance:distance(origin,p),dx:p.x-origin.x,dy:p.y-origin.y,actualBlockedShot:round.id,recovery:eAt-state.at,initialTerrainSha256,terrainUnchanged:true};
 }catch(error){result={arena:arena.id,difficulty:difficulty.id,...variant,passed:false,error:String(error),stack:error.stack};}
 rows.push(result);console.log(JSON.stringify(result));
}
assert.deepEqual(fingerprints(),before);assert.equal(git('rev-parse','HEAD'),baseline);const passed=rows.filter(r=>r.passed).length;
write(stage+'/canonical-geometry81.json',{at:new Date().toISOString(),base:baseline,runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,contentRevision:read('content/revision.json').sha256,driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),passed,total:rows.length,failed:rows.length-passed,rows,canonicalSourceEdited:true,canonicalCardsRegistered:3,onlineProof:false,scope:'Actual current canonical source imports; local uncommitted working-tree measurement only. Controlled27SP purchases with actual original arenas across all6maps/6difficulties, forward/both sideways/Standfast. Actual manual walk staging and projectiles; boss stagger isolates geometry. Terrain and bodies are never teleported or cleared. Separate natural3-to9SP acquisition is in fittings24.'});console.log(JSON.stringify({passed,total:rows.length,failed:rows.length-passed}));if(passed!==rows.length)process.exitCode=1;
