import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
import {Game,data} from 'file:///C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI%20Multiplayer%20Game%20Contest%20(Bullet%20Hell)/src/shared/game.ts';
import {screenPathClear,interceptorRules} from 'file:///C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI%20Multiplayer%20Game%20Contest%20(Bullet%20Hell)/src/shared/tank-interceptor.ts';
import {root,stage,read,write,sha,fingerprints,git,baseline} from './common.mjs';
process.chdir(root);const before=fingerprints(),build={definition:{id:'tank-interceptor-1'},fittings:[{id:'tank-interceptor-crossing-1'},{id:'tank-interceptor-standfast-1'}]};const gate=read(stage+'/gate76-runtime-verification.json');assert(gate.passed&&gate.checks.length===7);assert.equal(before.runtimeSourceSha256,gate.runtimeSourceSha256);assert.equal(before.sourceSnapshotSha256,gate.sourceSnapshotSha256);
const {Game:IssuedGame}=await import(pathToFileURL(root+'/src/shared/game.ts'));
const {viewOf}=await import(pathToFileURL(root+'/src/shared/view.ts'));
const {idleInput,HZ}=await import(pathToFileURL(root+'/src/shared/protocol.ts'));
const {restRaidInput}=await import(pathToFileURL(root+'/tests/helpers/sniper-rest-raid-policy.ts'));
const pilot=process.argv[2]==='pilot',scope=pilot?'pilot':'matrix',id=build.definition.id;
const gameplayFields=['phase','encounter','combatTick','x','y','health','shield','ammo','qAt','eAt','ultimateAt','dodgeAt','reloadAt','bossX','bossY','bossHealth','clears'];
function trial(arena,difficulty,seed,choice,policy,tapped=true){
 const g=new (policy==='banked'?IssuedGame:Game)({mode:'short',difficulty,seed,maxPlayers:1,openingArenaId:arena,arenaSelection:'fixed'}),p=g.addPlayer('solo','Ordinary Interceptor trial','tank'),fitting=choice==='forward'?undefined:build.fittings.find(f=>f.id.includes(choice)).id;
 const observed=new Map(),purchases=[],clears=[],phases=[],earned=[3],trajectory=createHash('sha256'),inputs=createHash('sha256');
 const operationEvents=[],originalObserver=g.interceptor.observe;assert.equal(typeof originalObserver,'function');
 if(tapped)g.interceptor.observe=event=>{originalObserver(event);operationEvents.push(structuredClone(event));};
 let sequence=0,transaction=0,lastPhase='',lastClears=0,normalE=0,primary=0,attempts=0,steps=0,plannedSide=0;
 const remaining=()=>p.totalSp-p.skills.reduce((n,skill)=>n+g.skillCost(skill),0);
 function buy(kind,item){const result=g.transact(p.id,{id:'natural-'+ ++transaction,kind,item});if(result.ok)purchases.push({kind,item,earned:p.totalSp,encounter:g.encounter});return result.ok;}
 function shop(){
  if(!p.skills.includes('tank-bastion-1'))assert(buy('skill','tank-bastion-1'));
  if(policy!=='banked'&&!p.skills.includes(id))assert(buy('skill',id));
  if(policy!=='banked'&&fitting&&p.totalSp>=5&&!p.skills.includes(fitting))assert(buy('skill',fitting));
  if(g.encounter>0)for(const item of ['general-sprint','general-brake-step','general-double-dash']){
   if(p.skills.includes(item))continue;const node=data.generalSkills.find(node=>node.id===item);assert(node);
   if(policy==='banked'&&remaining()-node.cost<(fitting?4:2))continue;buy('skill',item);
  }
  for(const weapon of data.weapons.filter(w=>w.classId==='tank').sort((a,b)=>b.tier-a.tier))if(p.weapon===weapon.id||buy('weapon',weapon.id))break;
  for(const item of ['damage','health','fire-rate','reload','magazine'])buy('upgrade',item);buy('supply','medkit');
 }
 function aimForScreen(){
  if(p.eAt>g.combatTick||p.dashUntil>g.combatTick||p.reloadAt>g.combatTick||p.status!=='active')return;
  const candidates=[],mode=fitting&&p.skills.includes(fitting)?choice:'forward';
  for(const shot of observed.values()){
   if(shot.owner!=='hostile'||shot.expires<=g.combatTick)continue;const speed=Math.hypot(shot.vx,shot.vy);if(speed<10)continue;
   const age=Math.max(0,g.combatTick-shot.seenAt)/HZ,pos={x:shot.x+shot.vx*age,y:shot.y+shot.vy*age},n={x:-shot.vx/speed,y:-shot.vy/speed};
   const dx=pos.x-p.x,dy=pos.y-p.y,along=dx*n.x+dy*n.y,across=-dx*n.y+dy*n.x,time=along/speed;
   const contact=(along-speed*(interceptorRules.windTicks+1)/HZ-interceptorRules.lead-12-shot.radius)/(speed+(mode==='forward'?interceptorRules.speed:0));
   if(time<.25||contact<-.03||contact>.29)continue;
   const world={tick:g.combatTick,playerRadius:data.rules.playerRadius,bounds:g.arena.bounds,obstacles:g.obstacles,lavaPits:g.arena.lavaPits};
   if(mode==='forward'){
    if(Math.abs(across)<=58&&screenPathClear(world,p,{x:p.x+n.x*180,y:p.y+n.y*180},n))candidates.push({aim:Math.atan2(n.y,n.x),time,shot:shot.id,side:0});
   }else if(mode==='standfast'){
    if(Math.abs(across)<=58&&screenPathClear(world,p,p,n))candidates.push({aim:Math.atan2(n.y,n.x),time,shot:shot.id,side:0});
   }else{
    const t={x:-n.y,y:n.x},sides=[-1,1].filter(side=>Math.abs(across-side*600*Math.max(0,contact))<=58&&screenPathClear(world,p,{x:p.x+t.x*side*180,y:p.y+t.y*side*180},n));
    sides.sort((a,b)=>Math.abs(across-a*600*Math.max(0,contact))-Math.abs(across-b*600*Math.max(0,contact)));if(sides.length)candidates.push({aim:Math.atan2(n.y,n.x),time,shot:shot.id,side:sides[0]});
   }
  }return candidates.sort((a,b)=>a.time-b.time)[0];
 }
 for(;steps<100_000&&!['victory','defeat'].includes(g.phase);steps++){
  if(g.phase!==lastPhase){phases.push({phase:g.phase,encounter:g.encounter,combatTick:g.combatTick});lastPhase=g.phase;if(['lobby','shop'].includes(g.phase))shop();}
  if(g.phase==='lobby'){assert(g.start());continue;}
  if(g.phase==='combat'){
   const view=viewOf(g,p.id),player=view.players.find(player=>player.id===p.id);assert(player);let input=restRaidInput(view,player,[...observed.values()]);
   if(policy==='intercept'){
    const state=g.interceptor.stateSnapshot(p.id);
    if(state?.phase==='winding')input={aim:Math.atan2(state.normal.y,state.normal.x)};
    else if(state?.phase==='ready')input={aim:Math.atan2(state.normal.y,state.normal.x),technique3:true,...(state.mode==='crossing'?{moveX:-state.normal.y*plannedSide,moveY:state.normal.x*plannedSide}:{})};
    else if(state?.phase==='screen')input={aim:Math.atan2(state.normal.y,state.normal.x)};
    else {const target=aimForScreen();if(target){input={aim:target.aim,technique3:true};plannedSide=target.side;attempts++;}else input={...input,e:false};}
   }
   const frame={...idleInput(),...input,sequence:++sequence,clientTick:g.combatTick};inputs.update(JSON.stringify(frame)+'\n');const eAt=p.eAt;assert(g.submitInput(p.id,frame));g.step();if(input.e&&p.eAt>eAt)normalE++;
   trajectory.update(JSON.stringify([g.phase,g.encounter,g.combatTick,p.x,p.y,p.health,p.shield,p.ammo,p.qAt,p.eAt,p.ultimateAt,p.dodgeAt,p.reloadAt,g.boss.x,g.boss.y,g.boss.health,p.progress.clears])+'\n');
  }else{if(['mutationVote','contractVote'].includes(g.phase))g.vote(p.id,0);g.step();}
  for(const event of g.drainEvents()){
   if(event.type==='shots')for(const shot of event.shots){observed.set(shot.id,{...shot,seenAt:g.combatTick});if(shot.owner===p.id&&!shot.visual)primary++;}
   if(event.type==='remove')for(const shotId of event.ids)observed.delete(shotId);
  }
  if(p.progress.clears>lastClears){lastClears=p.progress.clears;clears.push({count:lastClears,earned:p.totalSp,combatTick:g.combatTick});if(!earned.includes(p.totalSp))earned.push(p.totalSp);}
 }
 const operations=operationEvents,launches=operations.filter(e=>e.kind==='launched'),blocks=operations.filter(e=>e.kind==='blocked-shot');
 g.interceptor.observe=originalObserver;assert.equal(g.interceptor.observe,originalObserver);
 return {observationCallbackTapped:tapped,observationCallbackRestored:true,originalObserverSha256:sha(String(originalObserver)),arena,difficulty,seed,choice,policy,outcome:['victory','defeat'].includes(g.phase)?g.phase:'timeout',steps,combatTicks:g.combatTick,clears,earned,purchases,phases,endingHealth:p.health,endingShield:p.shield,remainingSP:remaining(),skills:[...p.skills],normalECasts:normalE,paidPrimaryProjectiles:primary,screenAttempts:attempts,screenLaunches:launches.length,actualScreenBlocks:blocks.length,fittingBought:!!fitting&&p.skills.includes(fitting),fittingLaunches:launches.filter(e=>e.mode===choice&&choice!=='forward').length,windInterruptions:operations.filter(e=>e.kind.includes('interruption')).length,operations,selectedGameplayTrajectorySha256:trajectory.digest('hex'),inputFramesSha256:inputs.digest('hex')};
}

export {trial,before,build,gameplayFields,data};
