import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {git, read, root, stage, walk, write} from './common.mjs';
import {checkCheckout, checkGate, countFields, digestFile, listExpandedRoots, ports, preserveCheck,
  protocol, revision, scope, source} from './publication82.mjs';
import {checkInterceptionAcquisition} from './interception-proof88.mjs';

process.chdir(root);
const commit = source();
checkCheckout(commit);
const {proof, counts} = checkGate();
const build = read(scope + '/frozen-build-binding.json');
const testing = read(stage + '/review-gate86-proof.json');
assert(build.passed && build.sourceCommit === commit && build.optimizedTestingGateOutputReused);
assert(testing.passed && testing.sourceCommit === commit && testing.boundReportSha256 === build.testingGateReportSha256);
assert.deepEqual(testing.counts, counts);
const ci = read(scope + '/source-ci.json'), binding = read(scope + '/source-binding.json');
assert(binding.passed && binding.sourceCommit === commit && binding.allWorkingAndCommittedCoreBytesExact);
assert(ci.passed && ci.phase === 'source' && ci.head === commit && ci.draftPR14);
assert.deepEqual(ci.events.map(event => event.event).sort(), ['pull_request', 'push']);
for (const event of ci.events) {
  assert(event.headSha === commit && event.status === 'completed' && event.conclusion === 'success' && event.jobs.length > 0);
  for (const job of event.jobs) {
    assert(job.verified && job.runtimeEvidence.verified && job.runtimeEvidence.runAttempt === event.runAttempt);
    assert(job.status === 'completed' && job.conclusion === 'success');
    assert(job.steps.length && job.steps.every(step => step.status === 'completed' && step.conclusion === 'success'));
    for (const key of countFields) assert.equal(job[key], counts[key]);
    assert.equal(digestFile(job.log), job.decodedLogSha256);
    for (const key of ['runtimeSourceSha256', 'sourceSnapshotSha256', 'contentRevision', 'verificationDriverSha256']) {
      assert.equal(job.runtimeEvidence[key], proof[key]);
    }
  }
}
const processPath = scope + '/process-identities.json';
const identities = read(processPath);
assert(identities.passed && identities.sourceCommit === commit && identities.identities.length === 4);
assert.equal(identities.olderRecordedIdentities.length, 4);
for (const identity of identities.identities) {
  assert(identity.expectedFullCommandExact && identity.utcCreationExactAtCimResolution && identity.exactListener);
  assert.equal(identity.port, ports[identity.audience][identity.role === 'client' ? 'client' : 'backend']);
}
const preserved = await preserveCheck();
const rows = [];
async function get(endpoint, name) {
  const result = await fetch(endpoint + '/api/' + name, {signal: AbortSignal.timeout(10_000)});
  assert(result.ok, name + ' status ' + result.status);
  return result.json();
}
for (const [audience, pair] of Object.entries(ports)) {
  const preview = read(scope + '/preview-' + audience + '.json');
  assert(preview.passed && preview.sourceCommit === commit && preview.protocol === protocol && preview.contentRevision === revision);
  assert.equal(preview.endpoint, 'http://127.0.0.1:' + pair.backend);
  assert.equal(preview.url, 'http://127.0.0.1:' + pair.client + '/');
  for (const key of ['runtimeSourceSha256', 'sourceSnapshotSha256']) assert.equal(preview[key], proof[key]);
  assert.equal(digestFile(preview.manifestPath), preview.manifestSha256);
  assert.equal(digestFile(preview.backend.path), preview.backend.sha256);
  const manifest = read(preview.manifestPath);
  assert.equal(manifest.sourceCommit, commit);
  assert.equal(manifest.members.length, preview.files);
  const rootPath = path.resolve(preview.root);
  const actual = walk(rootPath.replaceAll('\\', '/')).map(file => path.relative(rootPath, file).replaceAll('\\', '/')).sort();
  assert.deepEqual(actual, manifest.members.map(member => member.path).sort());
  for (const member of manifest.members) {
    assert(!path.isAbsolute(member.path) && !member.path.split('/').includes('..'));
    const file = path.resolve(rootPath, member.path);
    assert(file.startsWith(rootPath + path.sep));
    assert.equal(fs.statSync(file).size, member.bytes);
    assert.equal(digestFile(file), member.sha256, member.path);
  }
  const nativePath = stage + '/native96-' + audience + '-result.json';
  const native = read(nativePath);
  assert(native.passed && native.sourceCommit === commit && native.protocol === protocol &&
    native.contentRevision === revision && native.audience === audience);
  assert.equal(native.driverSha256, digestFile(stage + '/native-interceptor96.mts'));
  assert.equal(native.caseCount, 7);
  assert.equal(native.actualFreshCases, 6);
  assert(native.reusedOriginalHttpProof);
  const firstAttemptPath = stage + '/native89-' + audience + '-result.json';
  const firstAttempt = read(firstAttemptPath);
  assert.equal(firstAttempt.sourceCommit, commit);
  assert.equal(firstAttempt.httpReportSha256, native.httpReportSha256);
  for (const test of firstAttempt.cases) {
    assert.equal(digestFile(test.log), test.logSha256);
    if (test.receipt) assert.equal(digestFile(test.receipt), test.receiptSha256);
  }
  assert.equal(native.cases.length, 6);
  assert.equal(native.remainingProbeRooms + native.remainingProbeConnections, 0);
  assert.equal(digestFile(native.httpReport), native.httpReportSha256);
  assert.equal(digestFile(native.httpLog), native.httpLogSha256);
  const http = read(native.httpReport);
  assert(http.passed && http.probeRoomsClosed && http.sourceCommit === commit && http.backendBundleSha256 === preview.backend.sha256);
  const health = await get(preview.endpoint, 'health');
  assert(health.sourceCommit === commit && health.protocolVersion === protocol && health.contentRevision === revision && health.audience === audience);
  const metrics = await get(preview.endpoint, 'metrics');
  assert.equal(metrics.rooms + metrics.connections, 0);
  const expected = new Set(['worker', 'peer'].flatMap(transport => ['forward', 'crossing', 'standfast'].map(choice => transport + ':' + choice)));
  const cases = [];
  for (const execution of native.cases) {
    assert(execution.passed && execution.code === 0 && execution.signal === null);
    assert(expected.delete(execution.transport + ':' + execution.fitting));
    assert.equal(digestFile(execution.log), execution.logSha256);
    assert.equal(digestFile(execution.receipt), execution.receiptSha256);
    const receipt = read(execution.receipt);
    assert(receipt.sourceCommit === commit && receipt.protocol === protocol && receipt.contentRevision === revision &&
      receipt.audience === audience && receipt.noCheckpointImport);
    assert.equal(receipt.backendStartedAt, health.startedAt);
    assert.equal(receipt.backendBundleSha256, preview.backend.sha256);
    assert.equal(receipt.driverSha256, native.driverSha256);
    const worker = manifest.members.find(member => member.path === receipt.servedWorker.path);
    assert(worker && worker.sha256 === receipt.servedWorker.sha256);
    checkInterceptionAcquisition(receipt, execution.transport, execution.fitting);
    if (execution.transport === 'peer') {
      assert(receipt.sharedDodge && receipt.sharedDodge.ack >= receipt.sharedDodge.sequence);
      assert(Number.isInteger(receipt.ordinarySharedHostileEvents) && receipt.ordinarySharedHostileEvents >= 0);
    }
    cases.push({transport: execution.transport, choice: execution.fitting, earned: receipt.actualEarnedSequence,
      distance: receipt.later.actualDistance, earlyImpactSounds: receipt.early.actualImpactSounds, laterImpactSounds: receipt.later.actualImpactSounds});
  }
  assert.equal(expected.size, 0);
  assert.equal(native.emittedEmblems.length, 3);
  for (const emblem of native.emittedEmblems) {
    const member = manifest.members.find(member => member.path === emblem.path);
    assert(member && member.sha256 === emblem.sha256);
  }
  rows.push({audience, url: preview.url, endpoint: preview.endpoint, filesHashed: manifest.members.length,
    manifestSha256: preview.manifestSha256, backendBundleSha256: preview.backend.sha256, nativeCases: 7,
    httpReport: native.httpReport, httpReportSha256: native.httpReportSha256,
    nativeOriginalReceipt: nativePath, nativeOriginalReceiptSha256: digestFile(nativePath),
    initialAttempt: firstAttemptPath, initialAttemptSha256: digestFile(firstAttemptPath),
    cases, threeEarnedShortWorkerChoices: true, threeEarnedNonHostChoices: true, noCheckpointImports: true, allNativeCasesPassed: true});
}
const retention = read('output/review-retention.json');
const expectedRoots = [...retention.currentRoots, ...rows.map(row => read(scope + '/preview-' + row.audience + '.json').root)];
assert.deepEqual(listExpandedRoots(), expectedRoots.map(file => path.resolve(file)).sort());
assert.equal(expectedRoots.length, 4);
assert.equal(git('diff', commit, '--', 'src', 'tests', 'content', 'assets', 'locales', 'tools/verify.mjs'), '');
write(scope + '/frozen-verification.json', {passed: true, verifiedAt: new Date().toISOString(), sourceCommit: commit,
  protocol, contentRevision: revision, buildId: read('src/shared/update-history.json').buildId,
  runtimeSourceSha256: proof.runtimeSourceSha256, sourceSnapshotSha256: proof.sourceSnapshotSha256,
  verificationDriverSha256: proof.verificationDriverSha256, tests: counts, checks: proof.checks,
  exactSourceCI: scope + '/source-ci.json', allSourceCIJobsStepsDecodedLogsAndOwnArtifactsPass: true,
  sourceBinding: scope + '/source-binding.json', sourceBindingSha256: digestFile(scope + '/source-binding.json'),
  testingLoopbackGate: testing, sourceAndCommittedCoreBytesExact: true, rows, processIdentities: processPath,
  processIdentitiesSha256: digestFile(processPath), ...preserved,
  boundedStorage: {priorPairRetainedAtVerification: true, pendingPairCount: 1, expandedRoots: 4, promotionPending: true},
  humanAcceptance: false, openAcceptance: ['human', 'rendered', 'device', 'native-language', 'listening', 'motion', 'final-balance']});
console.log(JSON.stringify({passed: true, sourceCommit: commit, tests: counts.pass,
  audiences: rows.map(({audience, filesHashed, nativeCases, cases}) => ({
    audience, filesHashed, nativeCases, impactSounds: cases.reduce((sum, row) => sum + row.earlyImpactSounds + row.laterImpactSounds, 0),
  })), promotionPending: true}));
