import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';

const [destination, cohort, bundle = 'game07', mode = 'standard', seedFilter] = process.argv.slice(2);
assert(destination && ['solo','party'].includes(cohort) && /^game\d\d$/.test(bundle));
const local = name => new URL('./' + name, import.meta.url);
const bound = readJson(local(bundle + '.json'));
assert(['standard','short'].includes(mode));
const { Game, data, viewOf, HZ, idleInput, CONTENT_REVISION, preventiveCareIds, precautionRules, fieldSurgeryIds, fieldDressingRules, rapidResponseIds, rapidResponseRules, distance,
  segmentRect, segmentCircle, stitchSeamContact, restRaidInput, clearTrialWalk } = await verifiedBundle(fileURLToPath(local(bundle + '.mjs')), bound.bundle);
const maps = [['gatehouse','baby',41], ['crown-crypt','normal',73], ['ossuary-works','normal',109]]
  .filter(([, ,seed]) => !seedFilter || seed === Number(seedFilter));
assert(maps.length);
const order = ['surgery','response','care'];
const portfolios = ['tie','wrap'].flatMap(dressing => ['switchback','handoff'].flatMap(response =>
  ['doorstep','layered'].map(care => ({ dressing,response,care })))).map((kit,i) => ({ ...kit, opening: order[i % order.length] }));
const point = ({ x,y }) => ({ x,y });
const bearing = (from,to) => Math.atan2(to.y - from.y, to.x - from.x);

function run(arena, difficulty, seed, portfolio, active, restore = false) {
  let game = new Game({ mode, difficulty, seed, arenaSelection: 'route', openingArenaId: arena,
    maxPlayers: cohort === 'solo' ? 1 : 2 });
  let medic = game.addPlayer('solo', 'Iona', 'medic');
  const ally = cohort === 'party' ? game.addPlayer('ally', 'Adelaide', 'soldier') : undefined;
  let actors = ally ? [medic, ally] : [medic];
  const style = portfolio.care;
  const shots = new Map(), support = [], encounters = [], reachedOutside = new Set(), observations = [], phases = [], checks = [], purchases = [];
  const trace = createHash('sha256');
  let serial = 0, steps = 0, lastShop = -1, savedShop, encounter = -1;
  const buy = (player, kind, item) => game.transact(player.id, { kind, item, id: 'wrap-trial-' + ++serial });
  const fieldIds = fieldSurgeryIds, responseIds = rapidResponseIds;
  const roots = {
    surgery: ['medic-triage-1', fieldIds.entry],
    response: ['medic-recovery-1', responseIds.entry],
    care: ['medic-chemistry-1', preventiveCareIds.entry],
  };
  const chosen = {
    surgery: [fieldIds[portfolio.dressing === 'tie' ? 'step' : 'aside'], fieldIds[portfolio.dressing]],
    response: [responseIds[portfolio.response]],
    care: [preventiveCareIds[portfolio.care]],
  };
  const order = ['surgery','response','care'];
  while (order[0] !== portfolio.opening) order.push(order.shift());
  const [first, second, third] = order;
  const remainingSp = () => medic.totalSp - medic.skills.reduce((sum, id) => sum + game.skillCost(id), 0);
  function add(id, gate) {
    if (medic.skills.includes(id) || medic.totalSp < gate) return;
    if (remainingSp() < game.skillCost(id)) return;
    const admitted = buy(medic,'skill',id);
    assert(admitted.ok, JSON.stringify({ id, gate, portfolio, admitted, earned: medic.totalSp, points: remainingSp() }));
    assert(remainingSp() >= 0);
    purchases.push({ item: id, earned: medic.totalSp, clears: medic.progress.clears, at: game.combatTick, remaining: remainingSp() });
  }
  function route(name, gate) {
    const missing = roots[name].filter(id => !medic.skills.includes(id));
    if (medic.totalSp < gate || remainingSp() < missing.reduce((sum, id) => sum + game.skillCost(id), 0)) return;
    for (const id of missing) add(id, gate);
  }
  function kitShop() {
    if (medic.totalSp === 5) {
      add('medic-chemistry-1',5);
      add('medic-chemistry-path-1-1',5);
      add('medic-recovery-1',5);
    }
    if (medic.skills.includes(roots[first][1])) add(chosen[first][0],8);
    route(second,8);
    if (medic.skills.includes(roots[second][1])) add(chosen[second][0],11);
    route(third,13);
    if (medic.skills.includes(roots[third][1])) add(chosen[third][0],17);
    if (medic.skills.includes(chosen.surgery[0])) add(chosen.surgery[1],19);
    if (medic.totalSp >= 21 && remainingSp() > 0) {
      for (const talent of ['medic-triage-1','medic-recovery-1','medic-chemistry-path-1-1','general-sprint']) add(talent,21);
    }
  }
  assert.equal(medic.totalSp,3);
  route(first,3);
  assert.equal(remainingSp(),0);

  const travelOffsets = [0,.30,-.30,.64,-.64,1.05,-1.05,Math.PI / 2,-Math.PI / 2,2.1,-2.1,Math.PI];
  const lack = patient => patient.maxHealth - patient.health;
  function legalStep(view, start, heading, length, duration) {
    const to = { x:start.x + Math.cos(heading) * length, y:start.y + Math.sin(heading) * length };
    const world = { ...game.arena, obstacles: game.obstacles, tick: view.combatTick };
    return clearTrialWalk(world,start,to) && !danger(view,to,duration) ? to : undefined;
  }
  let initiatedRun, lastDressingHold;
  const ownedAction = (id) => medic.skills.includes(id);
  function treatmentFrame(view, player, allyView, ordinary) {
    const w = player.kit.fieldDressing;
    if (!w || ordinary.dodge || (ordinary.ultimate && player.health < player.maxHealth * .36)) return;
    const now = view.combatTick;
    const aimAway = allyView?.status === 'active' ? bearing(allyView,player) : ordinary.aim;
    const within = (target,distanceLimit) => target?.status === 'active' && distance(player,target) <= distanceLimit &&
      !game.obstacles.some(wall => segmentRect(player,target,wall,1));
    const near = within(allyView,fieldDressingRules.range - 5) && lack(allyView) >= 18 ? allyView : player;
    const target = w.patient && view.players.find(x => x.id === w.patient);
    const aim = target && target.id === allyView?.id ? bearing(player,target) : near.id === allyView?.id ? bearing(player,near) : aimAway;
    if (w.phase === 'preparing') {
      if (w.canWrap && ordinary.fire && (danger(view,player,5) || view.boss.health < view.boss.maxHealth * .4)) {
        lastDressingHold = now;
        return { technique1:true, aim };
      }
      return danger(view,player,3) ? undefined : { aim };
    }
    if (w.phase === 'wrapped' || w.phase === 'held') {
      if (w.ready && !danger(view,player,5) && (lastDressingHold ?? 0) + 2 < now)
        return { technique1:true, aim };
      return;
    }
    if (w.phase === 'tied') return danger(view,player,5) ? undefined : { fire:ordinary.fire, aim:ordinary.aim };
    if (w.phase === 'applying') {
      if (w.canHold && lack(target ?? player) >= 8 && ordinary.fire && !danger(view,player,3)) {
        lastDressingHold = now;
        return { technique1:true, aim };
      }
      const movement = Math.hypot(ordinary.moveX ?? 0, ordinary.moveY ?? 0);
      if (w.stepRemaining && movement > .25 && !danger(view,player,4)) {
        const heading = Math.atan2(ordinary.moveY,ordinary.moveX);
        if (legalStep(view,player,heading,8,4)) return { moveX:ordinary.moveX, moveY:ordinary.moveY, technique1:!!w.canTie, aim };
      }
      return danger(view,player,3) ? undefined : { aim };
    }
    if (w.phase === 'idle' && medic.qAt <= now && medic.reloadAt <= now && medic.dashUntil <= now &&
        lack(near) >= 23 && player.kit.precautionWrap?.phase !== 'settling' && !danger(view,player,12))
      return { technique1:true, aim };
  }
  function responseFrame(view, player, partner, ordinary) {
    const status = player.kit.rapidResponse;
    if (!status) return;
    const allyWounded = partner?.status === 'active' && lack(partner) >= 15 ? partner : undefined;
    const aimFrom = where => allyWounded && distance(where,allyWounded) <= rapidResponseRules.range - 4 &&
      !game.obstacles.some(wall => segmentRect(where,allyWounded,wall,1)) ? bearing(where,allyWounded) :
      partner?.status === 'active' ? bearing(partner,where) : ordinary.aim;
    if (ordinary.dodge && danger(view,player,4)) return;
    if (status.phase === 'arrived') return { technique2:true, aim:aimFrom(player) };
    if (status.phase === 'running') {
      const course = initiatedRun ?? player.aim, walked = status.walked ?? 0;
      if (ownedAction(responseIds.switchback) && !status.switched && walked >= rapidResponseRules.switchWalk) {
        const bend = [1.57,-1.57,2.1,-2.1].map(offset => course + offset).find(heading => legalStep(view,player,heading,36,8));
        if (bend !== undefined) {
          initiatedRun = bend;
          return { technique2:true, moveX:Math.cos(bend), moveY:Math.sin(bend), aim:aimFrom(player) };
        }
      }
      if (walked >= rapidResponseRules.requiredWalk) {
        if (ownedAction(responseIds.handoff)) {
          const moving = travelOffsets.map(delta => course + delta).map(heading => ({ heading,end:legalStep(view,player,heading,14,4) }))
            .filter(row => row.end).find(({ end }) => allyWounded ?
              distance(end,allyWounded) <= rapidResponseRules.range - 8 && !game.obstacles.some(wall => segmentRect(end,allyWounded,wall,1)) :
              lack(player) > 10);
          if (moving) return { technique2:true, moveX:Math.cos(moving.heading), moveY:Math.sin(moving.heading), aim:aimFrom(moving.end) };
        }
        return { aim:aimFrom(player) };
      }
      const walk = travelOffsets.map(delta => course + delta).find(dir => legalStep(view,player,dir,17,5));
      if (walk !== undefined) return { moveX:Math.cos(walk),moveY:Math.sin(walk),aim:aimFrom(player) };
    }
    if (status.phase === 'idle' && medic.eAt <= view.combatTick && !ordinary.dodge &&
        player.kit.fieldDressing?.phase !== 'preparing' && !danger(view,player,4) &&
        (lack(player) >= 21 || allyWounded && distance(player,allyWounded) < 137)) {
      const goal = allyWounded ? bearing(player,allyWounded) : bearing(player,view.boss) + Math.PI / 2;
      const heading = travelOffsets.map(off => goal + off).find(h => legalStep(view,player,h,58,8));
      if (heading !== undefined) {
        initiatedRun = heading;
        return { technique2:true,moveX:Math.cos(heading),moveY:Math.sin(heading),aim:aimFrom(player) };
      }
    }
  }

  function equip(player) {
    for (const w of data.weapons.filter(w => w.classId === player.classId).sort((a,b) => b.tier-a.tier)) {
      if (player.weapon === w.id || buy(player, 'weapon', w.id).ok) break;
    }
    for (const upgrade of ['damage','health','fire-rate','reload','magazine']) buy(player, 'upgrade', upgrade);
    buy(player, 'supply', 'medkit');
  }
  for (const actor of actors) equip(actor);
  assert(game.start());

  function predictedContact(patient, view) {
    const now = game.combatTick, walls = game.obstacles;
    let soonest;
    for (const cue of view.bossCues) {
      if (cue.kind !== 'stitch-seam' || cue.disabled || cue.until < now + 5 || cue.at >= now + precautionRules.wearTicks - 6) continue;
      if (!stitchSeamContact(patient, patient, cue)) continue;
      const forecast = Math.max(4, cue.at - now);
      soonest = Math.min(soonest ?? Infinity, forecast);
    }
    for (const shot of shots.values()) {
      if (distance(shot,patient) > 650) continue;
      const lifetime = Math.min(precautionRules.wearTicks - 6, shot.expires - now);
      if (lifetime < 5) continue;
      const from = { x: shot.x + shot.vx * (now - shot.seenAt) / HZ, y: shot.y + shot.vy * (now - shot.seenAt) / HZ };
      const to = { x: from.x + shot.vx * lifetime / HZ, y: from.y + shot.vy * lifetime / HZ };
      const hit = segmentCircle(from,to,patient, shot.radius + data.rules.playerRadius + 5);
      if (hit === null || hit * lifetime < 4 || (soonest !== undefined && soonest <= hit * lifetime)) continue;
      if (walls.some(wall => (segmentRect(from,to,wall,shot.radius)?.t ?? Infinity) <= hit)) continue;
      soonest = hit * lifetime;
    }
    return soonest;
  }

  function ringForecast(view, player, steps) {
    let nearest;
    const now = view.combatTick;
    for (const pulse of view.bossCues) {
      if (pulse.kind !== 'matron-pulse' || pulse.until <= now || pulse.at > now + steps) continue;
      const span = distance(pulse,player);
      const a = bearing(pulse,player) - pulse.gapAngle;
      const delta = Math.abs(Math.atan2(Math.sin(a),Math.cos(a)));
      const margin = Math.min(.26, Math.asin(Math.min(1,12 / Math.max(12,span))));
      if (delta + margin < pulse.gap / 2) continue;
      const nowRadius = Math.max(0,now - pulse.at) * pulse.speed / HZ;
      const laterRadius = Math.max(0,Math.min(pulse.until,now+steps) - pulse.at) * pulse.speed / HZ;
      const halfWidth = pulse.width / 2 + data.rules.playerRadius + 2;
      if (span < nowRadius - halfWidth || span > laterRadius + halfWidth) continue;
      const due = Math.max(0,pulse.at + (span - halfWidth) * HZ / pulse.speed - now);
      if (!nearest || due < nearest.due) nearest = { pulse,due };
    }
    return nearest;
  }
  let steeringTicks = 0, warningDodges = 0;
  function useMatronGap(view, player, input) {
    if (view.boss.id !== 'matron' || view.fields.some(field => field.kind === 'accord')) return input;
    const threat = ringForecast(view,player,18);
    if (!threat) return input;
    const { pulse,due } = threat;
    const radius = distance(pulse,player), tangent = bearing(pulse,player);
    const difference = pulse.gapAngle - tangent;
    const rotate = Math.sign(Math.atan2(Math.sin(difference),Math.cos(difference))) || 1;
    const aim = tangent + rotate * Math.PI / 2;
    const world = { ...game.arena, tick:view.combatTick, obstacles:game.obstacles };
    const options = [aim,aim-.5*rotate,aim+.5*rotate,tangent,tangent+Math.PI]
      .map(heading => ({ heading,point:{x:player.x+Math.cos(heading)*58,y:player.y+Math.sin(heading)*58} }))
      .filter(option => clearTrialWalk(world,player,option.point) && !ringForecast(view,option.point,16));
    const gapDirection = options.find(option => {
      const delta = bearing(pulse,option.point)-pulse.gapAngle;
      return Math.abs(Math.atan2(Math.sin(delta),Math.cos(delta))) < pulse.gap/2-.08;
    });
    const course = gapDirection ?? options[0];
    if (!course) return input;
    const shouldDodge = due <= 6 && player.dodgeCharges > 0 && (!gapDirection || radius > 80);
    steeringTicks++;
    if (shouldDodge) warningDodges++;
    return { ...input,moveX:Math.cos(course.heading),moveY:Math.sin(course.heading),dodge:shouldDodge || input.dodge };
  }
  function danger(view, position, ticks) {
    if (view.boss.id === 'matron' && ringForecast(view,position,ticks)) return true;
    for (const field of view.fields) if (field.kind === 'zone' && distance(field, position) < field.radius + 18) return true;
    for (const shot of shots.values()) {
      const remaining = Math.min(ticks, shot.expires - view.combatTick);
      if (remaining <= 0 || distance(shot, position) > 440) continue;
      const from = { x: shot.x + shot.vx * (view.combatTick - shot.seenAt) / HZ,
        y: shot.y + shot.vy * (view.combatTick - shot.seenAt) / HZ };
      const to = { x: from.x + shot.vx * remaining / HZ, y: from.y + shot.vy * remaining / HZ };
      const hit = segmentCircle(from, to, position, shot.radius + data.rules.playerRadius + 5);
      if (hit !== null && !game.obstacles.some(wall => (segmentRect(from, to, wall, shot.radius)?.t ?? Infinity) <= hit)) return true;
    }
    return false;
  }

  const navigation = new Map();
  const navigationPlans = [];
  const radius = data.rules.playerRadius;
  const aimVector = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  function firingLane(player, target, input) {
    const boss = point(target);
    const walls = game.obstacles;
    const occluded = (from) => walls.some(wall => segmentRect(from, boss, wall, 4));
    if (!occluded(player)) {
      navigation.delete(player.id);
      return;
    }
    if (player.health < player.maxHealth * .28 || danger(viewOf(game, player.id), player, 10)) return;
    const now = game.combatTick;
    const world = { ...game.arena, obstacles: walls, tick: now, playerRadius: radius };
    const clear = (a, b) => clearTrialWalk(world, a, b);
    let chase = navigation.get(player.id);
    if (!chase || chase.encounter !== game.encounter || now >= chase.at + 55 || chase.target !== target.id) {
      const margin = radius + 14;
      const bends = walls.flatMap(wall => [
        { x: wall.x - margin, y: wall.y - margin }, { x: wall.x + wall.width + margin, y: wall.y - margin },
        { x: wall.x - margin, y: wall.y + wall.height + margin }, { x: wall.x + wall.width + margin, y: wall.y + wall.height + margin },
      ]).filter(p => clear(p, p));
      const goals = [142, 200, 275, 360].flatMap(range => Array.from({ length: 20 }, (_, i) => {
        const aim = aimVector(i * Math.PI / 10);
        return { x: boss.x + aim.x * range, y: boss.y + aim.y * range };
      })).filter(p => clear(p, p) && !occluded(p));
      const points = [point(player), ...bends, ...goals];
      const cheapest = points.map((_, i) => i === 0 ? 0 : Infinity);
      const parent = points.map(() => -1), visited = new Set();
      let path = [];
      for (let pass = 0; pass < points.length; pass++) {
        let index = -1, shortest = Infinity;
        for (let i = 0; i < points.length; i++) if (!visited.has(i) && cheapest[i] < shortest) {
          index = i;
          shortest = cheapest[i];
        }
        if (index < 0) break;
        if (index > bends.length) {
          for (let start = index; start > 0; start = parent[start]) path.unshift(points[start]);
          break;
        }
        visited.add(index);
        for (let next = 1; next < points.length; next++) {
          const step = distance(points[index], points[next]);
          if (visited.has(next) || shortest + step >= cheapest[next] || !clear(points[index], points[next])) continue;
          cheapest[next] = shortest + step;
          parent[next] = index;
        }
      }
      chase = { at: now, encounter: game.encounter, path, target: target.id };
      navigation.set(player.id, chase);
      if (path.length) navigationPlans.push({ player: player.id, encounter: game.encounter, tick: now, from: point(player), route: [...path] });
    }
    while (chase.path.length && distance(player, chase.path[0]) < 2) chase.path.shift();
    const next = chase.path[0];
    if (!next || !clear(player, next)) return;
    const scale = Math.max(distance(player, next), game.movementSpeed(player) / HZ);
    return { ...input, moveX: (next.x - player.x) / scale, moveY: (next.y - player.y) / scale, dodge: false };
  }


  function aimEncounter(view, player, input) {
    const now = view.combatTick;
    const targets = view.bossCues.filter(cue => 'health' in cue && cue.health > 0 && 'x' in cue && 'y' in cue &&
      cue.until > now + 10 && (cue.kind === 'stitch-pin' || cue.kind === 'raid-prop' ||
        cue.kind === 'early-prop' || cue.kind === 'service-prop'));
    const candidates = targets.filter(target => distance(player, target) < 600 &&
      !game.obstacles.some(wall => segmentRect(player, target, wall, 3))).sort((a, b) => distance(player, a) - distance(player, b));
    const boss = view.boss;
    const target = candidates[0] ?? boss;
    const command = { ...input, aim: bearing(player, target) };
    return firingLane(player, target, command) ?? command;
  }

  const usesCare = active;
  function stationRoute(view, player, ordinary) {
    const station = view.classCues.find(cue => cue.kind === 'medic-precaution-station' && cue.owner === medic.id);
    if (!station || ordinary.dodge || (predictedContact(player, view) ?? Infinity) < 11 ||
        station.until < view.combatTick + 6 || distance(player,station) > 88) return ordinary;
    if (ally && player.id === medic.id) return ordinary;
    const radius = station.radius;
    const crossing = station.id + '/' + player.id;
    if (distance(player,station) > radius) reachedOutside.add(crossing);
    const separated = reachedOutside.has(crossing);
    const center = bearing(station, view.boss);
    const targets = separated ? [station] : [Math.PI, 1.57, -1.57, 2.37, -2.37, 0].map(offset => ({
      x: station.x + (radius + 14) * Math.cos(center + offset), y: station.y + (radius + 14) * Math.sin(center + offset),
    }));
    const bounds = game.arena.bounds, body = data.rules.playerRadius;
    const goal = targets.find(p => p.x >= bounds.x + body && p.x <= bounds.x + bounds.width - body &&
      p.y >= bounds.y + body && p.y <= bounds.y + bounds.height - body &&
      !game.obstacles.some(wall => segmentRect(player,p,wall,body)));
    if (!goal) return ordinary;
    const toward = bearing(player,goal);
    return { ...ordinary, moveX: Math.cos(toward), moveY: Math.sin(toward), dodge: false, sprint: false };
  }

  function preventiveInput(view, player, ordinary) {
    const partner = ally && view.players.find(target => target.id === ally.id);
    const now = view.combatTick;
    const allyInRange = partner?.status === 'active' && distance(player,partner) <= precautionRules.reach - 5 &&
      !game.obstacles.some(wall => segmentRect(player,partner,wall,1));
    const fallen = partner?.status === 'downed' && distance(player,partner) <= 53 &&
      !game.obstacles.some(wall => segmentRect(player,partner,wall,1));
    const ultimate = Boolean(ordinary.ultimate && (player.health < player.maxHealth * .42 ||
      partner?.status === 'downed' && distance(player,partner) < 210));
    if (fallen && !ordinary.dodge && predictedContact(player, view) === undefined) return { aim: bearing(player,partner), interact: true };
    const reservation = player.kit.precautionWrap;
    const canCommand = usesCare && !ordinary.dodge && !ultimate && medic.reloadAt <= now && medic.dashUntil <= now;
    const reservedPatient = view.players.find(target => target.id === reservation?.patient);
    const reachable = reservedPatient?.id === medic.id || reservedPatient?.id === partner?.id && allyInRange;
    const prepareAim = allyInRange ? bearing(partner,player) : ordinary.aim;
    if (canCommand && reservation && (reservation.until ?? 0) > now) {
      if (reservation.phase === 'armed' && reservation.canPlace && style === 'doorstep')
        return { technique3: true, aim: prepareAim };
      if (reservation.phase === 'armed' && reservation.canLayer && reachable && style === 'layered')
        return { technique3: true, aim: reservedPatient.id === medic.id ? prepareAim : bearing(player,reservedPatient) };
      if (reservation.phase === 'layered' && reachable && reservation.capturedHits &&
          (reservation.capturedHits === 2 || reservation.until <= now + 17 || reservedPatient.health < reservedPatient.maxHealth * .56))
        return { technique3: true, aim: reservedPatient.id === medic.id ? prepareAim : bearing(player,reservedPatient) };
    }
    if (canCommand && medic.qAt <= now && player.health >= player.maxHealth * .43 &&
        reservation?.phase === 'idle' && (reservation.until ?? 0) <= now) {
      const potential = [player, ...(allyInRange ? [partner] : [])].map(patient => ({ patient, impact: predictedContact(patient, view) }))
        .filter(row => row.impact !== undefined).sort((a,b)=>a.impact-b.impact)[0];
      if (potential) {
        const place = style === 'doorstep' && medic.skills.includes(preventiveCareIds.doorstep) &&
          potential.impact > 12 && !game.obstacles.some(wall => segmentRect(player,player,wall,precautionRules.stationRadius));
        const aimed = place || potential.patient.id === player.id ? prepareAim : bearing(player,potential.patient);
        checks.push({ at: now, owner: point(player), patient: place ? player.id : potential.patient.id, impactEstimate: potential.impact, place });
        return { technique3: true, aim: aimed };
      }
    }
    ordinary = style === 'doorstep' ? stationRoute(view,player,ordinary) : ordinary;
    return { ...ordinary, q: Boolean(ordinary.q && (player.health <= player.maxHealth - 22 || allyInRange && partner.health <= partner.maxHealth - 26) &&
      (!usesCare || reservation?.phase === 'idle' || player.health < player.maxHealth * .31 || allyInRange && partner.health < partner.maxHealth * .31)),
      e: Boolean(ordinary.e && (player.health <= player.maxHealth - 19 || allyInRange && partner.health <= partner.maxHealth - 22 || player.slowUntil > now || player.poisonUntil > now)),
      ultimate };
  }

  function medicInput(view, player, ordinary) {
    const care = preventiveInput(view,player,ordinary);
    if (!active || ordinary.dodge && danger(view,player,4) || care.interact) return care;
    const partner = ally && view.players.find(p => p.id === ally.id);
    const response = player.kit.rapidResponse, dressing = player.kit.fieldDressing;
    if (response?.phase === 'running' || response?.phase === 'arrived')
      return responseFrame(view,player,partner,ordinary) ?? care;
    if (dressing && dressing.phase !== 'idle' && dressing.phase !== 'held' && dressing.phase !== 'wrapped')
      return treatmentFrame(view,player,partner,ordinary) ?? care;
    if (care.technique3 || player.kit.precautionWrap?.phase === 'station' && style === 'doorstep' && !ally)
      return care;
    if (portfolio.opening === 'response')
      return responseFrame(view,player,partner,ordinary) ?? treatmentFrame(view,player,partner,ordinary) ?? care;
    return treatmentFrame(view,player,partner,ordinary) ?? responseFrame(view,player,partner,ordinary) ?? care;
  }

  while (!['victory','defeat'].includes(game.phase) && steps++ < 90000) {
    if (game.phase !== 'combat') {
      shots.clear();
      reachedOutside.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const p of actors) game.vote(p.id,0);
      if (game.phase === 'shop' && lastShop !== game.encounter) {
        lastShop = game.encounter;
        kitShop();
        for (const p of actors) equip(p);
        phases.push({ cleared: medic.progress.clears, earned: medic.totalSp, spent: medic.totalSp - remainingSp(), at: game.combatTick });
        if (!savedShop && [fieldIds.entry,responseIds.entry,preventiveCareIds.entry].every(ownedAction)) {
          const save = !ally && game.offlineCheckpoint();
          savedShop = { earned:medic.totalSp, skills:[...medic.skills], at:game.combatTick, clear:medic.progress.clears };
          if (restore) {
            assert(save && save.phase === 'shop');
            game = Game.restoreOffline(save);
            medic = game.players.get('solo');
            actors = [medic];
            assert.deepEqual(medic.skills,savedShop.skills);
          }
        }
      }
      game.step();
      game.drainEvents();
      continue;
    }
    const view = viewOf(game, medic.id);
    if (encounter !== game.encounter) {
      encounter = game.encounter;
      encounters.push({ number:encounter + 1, boss:game.boss.id, arena:game.arena.id, earned:medic.totalSp });
    }
    const before = { heal: medic.healing, qAt: medic.qAt };
    for (const actor of actors) {
      const own = view.players.find(row => row.id === actor.id);
      const control = actor.status === 'downed' ? { interact: true } : actor.status === 'active' ? useMatronGap(view,own,aimEncounter(view,own,restRaidInput(view,own,[...shots.values()]))) : {};
      const input = actor === medic && actor.status === 'active' ? medicInput(view,own,control) :
        active && actor.status === 'active' && style === 'doorstep' ? stationRoute(view,own,control) : control;
      const frame = { ...idleInput(), ...input, sequence: actor.ack+1, clientTick: game.combatTick };
      assert(game.submitInput(actor.id,frame), JSON.stringify({ frame, style, arena, at: game.combatTick }));
      trace.update(JSON.stringify(input));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id,{ ...shot, seenAt:game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== medic.id) continue;
      for (const [prefix,kind] of [['medic-dressing-','surgery'],['medic-response-','response']]) {
        if (!event.id.startsWith(prefix)) continue;
        const command = event.id.slice(prefix.length);
        const pulse = game.classCues().find(cue => cue.kind === (kind === 'surgery' ? 'medic-dressing' : 'medic-response-dose') &&
          cue.at === game.combatTick && cue.owner === medic.id);
        support.push({ kind, command, at:game.combatTick, boss:game.boss.id, phase:game.phase, patient:pulse?.patient ?? null,
          heal: command === 'dose' || command === 'handoff' ? medic.healing - before.heal : 0 });
      }
      if (!event.id.startsWith('medic-precaution-')) continue;
      const type = event.id.slice('medic-precaution-'.length);
      const cue = game.classCues().find(c => type === 'dose' ? c.kind === 'medic-precaution-dose' && c.at === game.combatTick : c.kind === 'medic-precaution-wrap');
      if (type === 'wrap' || type === 'place' || type === 'layer' || type === 'claim') assert(medic.qAt === before.qAt || !cue);
      if (type === 'settle') assert(medic.qAt > game.combatTick);
      if (type === 'capture') assert(medic.qAt > game.combatTick);
      if (type === 'dose') {
        assert(medic.healing > before.heal);
        assert(cue || game.phase !== 'combat');
      }
      observations.push({ type, arena, boss:game.boss.id, at:game.combatTick, qAt:medic.qAt, patient:cue?.patient ??
        game.kitStatus(medic.id).precautionWrap?.patient, heal: type === 'dose' ? medic.healing - before.heal : 0 });
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(p=>[
      p.x,p.y,p.health,p.ammo,p.qAt,p.eAt,p.damageTaken,p.damageDealt,p.healing,p.status]) ]));
  }
  assert(['victory','defeat'].includes(game.phase));
  return { arena,difficulty,seed,portfolio,active,restore,win:game.phase==='victory',clears:medic.progress.clears,
    damage:medic.damageTaken, health:medic.health, earned:medic.totalSp, remaining:remainingSp(), finalSkills:medic.skills,
    trace:trace.digest('hex'), support, checks, observations, phases, purchases, navigationPlans, savedShop, encounters, steeringTicks, warningDodges };
}

const rows = [], comparisons = [];
for (const [arena,difficulty,seed] of maps) for (const portfolio of portfolios) {
  const unused = run(arena,difficulty,seed,portfolio,false);
  const active = run(arena,difficulty,seed,portfolio,true);
  rows.push(unused,active);
  const replay = cohort === 'solo' && active.savedShop ? run(arena,difficulty,seed,portfolio,true,true) : undefined;
  if (replay) rows.push(replay);
  const matchedReplay = replay ? replay.trace === active.trace &&
    JSON.stringify(replay.support) === JSON.stringify(active.support) &&
    JSON.stringify(replay.observations) === JSON.stringify(active.observations) : null;
  const check = { arena,seed,portfolio,unused:unused.clears,active:active.clears,unusedWin:unused.win,activeWin:active.win,
    activeEarned:active.earned, steeringTicks:active.steeringTicks,warningDodges:active.warningDodges, allRoutesAt:active.savedShop?.earned, matchedReplay,
    doses:active.support.filter(event => event.heal > 0).length + active.observations.filter(event => event.heal > 0).length };
  comparisons.push(check);
  console.log(JSON.stringify(check));
}
receipt(destination,{ stageOnly: true, cohort, mode, contentRevision:CONTENT_REVISION, bundleSha256:bound.bundle,
  comparisons, rows, profiles:portfolios, selectedSeeds:maps.map(([, ,seed]) => seed) });
