  const fieldIds = fieldSurgeryIds, responseIds = rapidResponseIds;
  const roots = {
    surgery: ['medic-triage-1', fieldIds.entry],
    response: ['medic-recovery-1', responseIds.entry],
    care: ['medic-chemistry-1', preventiveCareIds.entry],
  };
  const chosen = {
    surgery: [fieldIds[portfolio.dressing === 'tie' ? 'step' : 'aside'], fieldIds[portfolio.dressing]],
    response: [responseIds[portfolio.response]],
    care: [preventiveCareIds[portfolio.care]],
  };
  const order = ['surgery','response','care'];
  while (order[0] !== portfolio.opening) order.push(order.shift());
  const [first, second, third] = order;
  const remainingSp = () => medic.totalSp - medic.skills.reduce((sum, id) => sum + game.skillCost(id), 0);
  function add(id, gate) {
    if (medic.skills.includes(id) || medic.totalSp < gate) return;
    if (remainingSp() < game.skillCost(id)) return;
    const admitted = buy(medic,'skill',id);
    assert(admitted.ok, JSON.stringify({ id, gate, portfolio, admitted, earned: medic.totalSp, points: remainingSp() }));
    assert(remainingSp() >= 0);
    purchases.push({ item: id, earned: medic.totalSp, clears: medic.progress.clears, at: game.combatTick, remaining: remainingSp() });
  }
  function route(name, gate) {
    const missing = roots[name].filter(id => !medic.skills.includes(id));
    if (medic.totalSp < gate || remainingSp() < missing.reduce((sum, id) => sum + game.skillCost(id), 0)) return;
    for (const id of missing) add(id, gate);
  }
  function kitShop() {
    if (medic.totalSp === 5) {
      add('medic-chemistry-1',5);
      add('medic-chemistry-path-1-1',5);
      add('medic-recovery-1',5);
    }
    if (medic.skills.includes(roots[first][1])) add(chosen[first][0],8);
    route(second,8);
    if (medic.skills.includes(roots[second][1])) add(chosen[second][0],11);
    route(third,13);
    if (medic.skills.includes(roots[third][1])) add(chosen[third][0],17);
    if (medic.skills.includes(chosen.surgery[0])) add(chosen.surgery[1],19);
    if (medic.totalSp >= 21 && remainingSp() > 0) {
      for (const talent of ['medic-triage-1','medic-recovery-1','medic-chemistry-path-1-1','general-sprint']) add(talent,21);
    }
  }
  assert.equal(medic.totalSp,3);
  route(first,3);
  assert.equal(remainingSp(),0);

  const travelOffsets = [0,.30,-.30,.64,-.64,1.05,-1.05,Math.PI / 2,-Math.PI / 2,2.1,-2.1,Math.PI];
  const lack = patient => patient.maxHealth - patient.health;
  function legalStep(view, start, heading, length, duration) {
    const to = { x:start.x + Math.cos(heading) * length, y:start.y + Math.sin(heading) * length };
    const world = { ...game.arena, obstacles: game.obstacles, tick: view.combatTick };
    return clearTrialWalk(world,start,to) && !danger(view,to,duration) ? to : undefined;
  }
  let initiatedRun, lastDressingHold;
  const ownedAction = (id) => medic.skills.includes(id);
  function treatmentFrame(view, player, allyView, ordinary) {
    const w = player.kit.fieldDressing;
    if (!w || ordinary.dodge || (ordinary.ultimate && player.health < player.maxHealth * .36)) return;
    const now = view.combatTick;
    const aimAway = allyView?.status === 'active' ? bearing(allyView,player) : ordinary.aim;
    const within = (target,distanceLimit) => target?.status === 'active' && distance(player,target) <= distanceLimit &&
      !game.obstacles.some(wall => segmentRect(player,target,wall,1));
    const near = within(allyView,fieldDressingRules.range - 5) && lack(allyView) >= 18 ? allyView : player;
    const target = w.patient && view.players.find(x => x.id === w.patient);
    const aim = target && target.id === allyView?.id ? bearing(player,target) : near.id === allyView?.id ? bearing(player,near) : aimAway;
    if (w.phase === 'preparing') {
      if (w.canWrap && ordinary.fire && (danger(view,player,5) || view.boss.health < view.boss.maxHealth * .4)) {
        lastDressingHold = now;
        return { technique1:true, aim };
      }
      return danger(view,player,3) ? undefined : { aim };
    }
    if (w.phase === 'wrapped' || w.phase === 'held') {
      if (w.ready && !danger(view,player,5) && (lastDressingHold ?? 0) + 2 < now)
        return { technique1:true, aim };
      return;
    }
    if (w.phase === 'tied') return danger(view,player,5) ? undefined : { fire:ordinary.fire, aim:ordinary.aim };
    if (w.phase === 'applying') {
      if (w.canHold && lack(target ?? player) >= 8 && ordinary.fire && !danger(view,player,3)) {
        lastDressingHold = now;
        return { technique1:true, aim };
      }
      const movement = Math.hypot(ordinary.moveX ?? 0, ordinary.moveY ?? 0);
      if (w.stepRemaining && movement > .25 && !danger(view,player,4)) {
        const heading = Math.atan2(ordinary.moveY,ordinary.moveX);
        if (legalStep(view,player,heading,8,4)) return { moveX:ordinary.moveX, moveY:ordinary.moveY, technique1:!!w.canTie, aim };
      }
      return danger(view,player,3) ? undefined : { aim };
    }
    if (w.phase === 'idle' && medic.qAt <= now && medic.reloadAt <= now && medic.dashUntil <= now &&
        lack(near) >= 23 && player.kit.precautionWrap?.phase !== 'settling' && !danger(view,player,12))
      return { technique1:true, aim };
  }
  function responseFrame(view, player, partner, ordinary) {
    const status = player.kit.rapidResponse;
    if (!status) return;
    const allyWounded = partner?.status === 'active' && lack(partner) >= 15 ? partner : undefined;
    const aimFrom = where => allyWounded && distance(where,allyWounded) <= rapidResponseRules.range - 4 &&
      !game.obstacles.some(wall => segmentRect(where,allyWounded,wall,1)) ? bearing(where,allyWounded) :
      partner?.status === 'active' ? bearing(partner,where) : ordinary.aim;
    if (ordinary.dodge && danger(view,player,4)) return;
    if (status.phase === 'arrived') return { technique2:true, aim:aimFrom(player) };
    if (status.phase === 'running') {
      const course = initiatedRun ?? player.aim, walked = status.walked ?? 0;
      if (ownedAction(responseIds.switchback) && !status.switched && walked >= rapidResponseRules.switchWalk) {
        const bend = [1.57,-1.57,2.1,-2.1].map(offset => course + offset).find(heading => legalStep(view,player,heading,36,8));
        if (bend !== undefined) {
          initiatedRun = bend;
          return { technique2:true, moveX:Math.cos(bend), moveY:Math.sin(bend), aim:aimFrom(player) };
        }
      }
      if (walked >= rapidResponseRules.requiredWalk) {
        if (ownedAction(responseIds.handoff)) {
          const moving = travelOffsets.map(delta => course + delta).map(heading => ({ heading,end:legalStep(view,player,heading,14,4) }))
            .filter(row => row.end).find(({ end }) => allyWounded ?
              distance(end,allyWounded) <= rapidResponseRules.range - 8 && !game.obstacles.some(wall => segmentRect(end,allyWounded,wall,1)) :
              lack(player) > 10);
          if (moving) return { technique2:true, moveX:Math.cos(moving.heading), moveY:Math.sin(moving.heading), aim:aimFrom(moving.end) };
        }
        return { aim:aimFrom(player) };
      }
      const walk = travelOffsets.map(delta => course + delta).find(dir => legalStep(view,player,dir,17,5));
      if (walk !== undefined) return { moveX:Math.cos(walk),moveY:Math.sin(walk),aim:aimFrom(player) };
    }
    if (status.phase === 'idle' && medic.eAt <= view.combatTick && !ordinary.dodge &&
        player.kit.fieldDressing?.phase !== 'preparing' && !danger(view,player,4) &&
        (lack(player) >= 21 || allyWounded && distance(player,allyWounded) < 137)) {
      const goal = allyWounded ? bearing(player,allyWounded) : bearing(player,view.boss) + Math.PI / 2;
      const heading = travelOffsets.map(off => goal + off).find(h => legalStep(view,player,h,58,8));
      if (heading !== undefined) {
        initiatedRun = heading;
        return { technique2:true,moveX:Math.cos(heading),moveY:Math.sin(heading),aim:aimFrom(player) };
      }
    }
  }
