import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';

const here = name => new URL('./' + name, import.meta.url);
const [output] = process.argv.slice(2);
assert(output);
const source = readJson(here('game07.json'));
const g = await verifiedBundle(fileURLToPath(here('game07.mjs')), source.bundle);
const { Game, data, PROTOCOL, CONTENT_REVISION, idleInput, viewOf, distance, segmentRect, preventiveCareIds: care,
  rapidResponseIds: response, rapidResponseRules, fieldSurgeryIds: surgery, precautionRules } = g;
assert.equal(PROTOCOL,86);

function create(caseId, party, fittings) {
  const game = new Game({ mode:'endless', seed:41, maxPlayers:party ? 3 : 1, difficulty:'normal',
    arenaSelection:'fixed', openingArenaId:'gatehouse' });
  game.encounter = 9;
  const medic = game.addPlayer('solo','Iona','medic');
  const partners = party ? [game.addPlayer('lane','Lane','soldier'),game.addPlayer('sill','Sill','soldier')] : [];
  const owned = [
    'medic-triage-1',surgery.entry,surgery[fittings.surgery === 'tie' ? 'step' : 'aside'],surgery[fittings.surgery],
    'medic-recovery-1',response.entry,response[fittings.response],
    'medic-chemistry-1',care.entry,care[fittings.care],
  ];
  assert.equal(medic.totalSp,27);
  for (const item of owned) assert(game.transact(medic.id,{ id:caseId + '-' + item,kind:'skill',item }).ok, item);
  const spent = owned.reduce((sum,id) => sum + game.skillCost(id),0);
  assert.equal(spent,18);
  const issued = game.offlineCheckpoint();
  if (!party) {
    assert(issued?.phase === 'lobby' && issued.practiceOnly);
    assert.deepEqual(Game.restoreOffline(issued).players.get(medic.id).skills,owned);
  }
  assert(game.start());
  game.boss.deadline = game.boss.staggerUntil = 10000;
  const actors = [medic,...partners];
  function tick(input = {}) {
    for (const actor of actors) assert(game.submitInput(actor.id,{ ...idleInput(), sequence:actor.ack + 1,
      clientTick:game.combatTick,...(actor === medic ? input : {}) }));
    game.step();
    return game.drainEvents();
  }
  function wait(number) { for (let count = 0; count < number; count++) tick(); }
  wait(Math.max(...actors.map(actor => actor.invulnerableUntil)));
  const walls = game.obstacles, bounds = game.arena.bounds;
  let clear;
  for (let y = bounds.y + 110; y < bounds.y + bounds.height - 125 && !clear; y += 32) {
    for (let x = bounds.x + 110; x < bounds.x + bounds.width - 145; x += 32) {
      const from = { x:x-22,y:y-32 }, to = { x:x+115,y:y+62 };
      if (walls.some(wall => segmentRect(from,to,wall,65))) continue;
      if (distance({ x,y },game.boss) < 190) continue;
      clear = {x,y};
      break;
    }
  }
  assert(clear);
  Object.assign(medic,clear);
  if (party) {
    Object.assign(partners[0],{ x:clear.x,y:clear.y+53 });
    Object.assign(partners[1],{ x:clear.x+94,y:clear.y });
  }
  function hostile(target, damage) {
    target.shield = 0;
    const projectile = game.emitShot('hostile', target.x,target.y + 22,-Math.PI/2,900,damage,3);
    assert(projectile);
    tick();
    return projectile.id;
  }
  function kit() { return game.kitStatus(medic.id); }
  function viewFor(id) { return viewOf(game,id); }
  const point = () => ({ x:medic.x,y:medic.y });
  return { game,medic,partners,tick,wait,hostile,kit,viewFor,point,spent,clear };
}

function chargeArbitration() {
  const f = create('walk-and-wrap',false,{ surgery:'tie', response:'switchback', care:'doorstep' });
  const { game,medic,point,kit,tick,wait,hostile } = f;
  tick({ technique3:true });
  tick({ technique3:true });
  const station = game.classCues().find(cue => cue.kind === 'medic-precaution-station');
  assert(station);
  for (let index = 0; index < 5; index++) tick({ moveX:1 });
  assert(distance(point(),station) > station.radius && kit().precautionWrap.phase === 'station' && medic.qAt === 0);
  const launched = game.combatTick;
  tick({ moveX:-1,technique2:true });
  assert(kit().rapidResponse.phase === 'running');
  for (let count = 0; count < 6 && kit().precautionWrap.phase === 'station'; count++) tick({ moveX:-1 });
  const saw = kit();
  assert(saw.rapidResponse.phase === 'running' && saw.precautionWrap.phase === 'armed');
  assert(saw.precautionWrap.until === station.until && saw.precautionWrap.patient === medic.id && medic.qAt === 0);
  const paidE = medic.eAt;
  assert(paidE > launched);
  const health = medic.health;
  const shot = hostile(medic,30), wounded = medic.health;
  const paidQ = medic.qAt;
  assert(wounded < health && paidQ > game.combatTick && kit().precautionWrap.phase === 'settling');
  tick({ technique1:true });
  assert.equal(kit().fieldDressing.phase,'idle');
  wait(precautionRules.settleTicks);
  const recovered = medic.health;
  assert(recovered > wounded && recovered <= wounded + (health-wounded)*precautionRules.acceptedLossFraction + 1e-6);
  assert.equal(medic.qAt,paidQ);
  assert.equal(medic.eAt,paidE);
  wait(paidQ - game.combatTick);
  tick({ technique1:true });
  assert.equal(kit().fieldDressing.phase,'preparing');
  wait(16);
  assert(medic.qAt > paidQ);
  assert(medic.health > recovered);
  const surgeryPaid = medic.qAt, firstDressing = medic.health;
  tick({ moveX:-1 });
  assert(kit().fieldDressing.canTie);
  tick({ moveX:-1,technique1:true });
  assert(kit().fieldDressing.phase === 'tied');
  const knot = game.classCues().find(cue => cue.kind === 'medic-dressing-knot' && cue.owner === medic.id);
  assert(knot);
  wait(kit().fieldDressing.nextAt - game.combatTick);
  assert(medic.health > firstDressing && medic.qAt === surgeryPaid);
  return { caseId:'walk-and-wrap', spent:f.spent, station:station.id, shot, paidE, paidQ, recovered:recovered-wounded,
    newSurgeryRecovery:medic.qAt, bothRecoveriesIndependent:true, samePointDeadline:station.until,
    tiedDose:medic.health-firstDressing, knot:knot.id };
}

function twoPatients() {
  const f = create('two-patients',true,{ surgery:'wrap', response:'handoff', care:'layered' });
  const { game,medic,partners:[patient,movingPatient],kit,tick,wait,hostile,viewFor } = f;
  hostile(movingPatient,35);
  const secondBefore = movingPatient.health;
  tick({ technique3:true,aim:Math.PI/2 });
  assert.equal(kit().precautionWrap.patient,patient.id);
  const originalDeadline = kit().precautionWrap.until;
  tick({ technique3:true,aim:Math.PI/2 });
  assert.equal(kit().precautionWrap.phase,'layered');
  tick({ moveX:1,technique2:true });
  const paidE = medic.eAt;
  while (kit().rapidResponse.phase === 'running' && kit().rapidResponse.walked < rapidResponseRules.requiredWalk) tick({ moveX:1 });
  assert(kit().rapidResponse.canHandoff || kit().rapidResponse.walked >= rapidResponseRules.requiredWalk);
  const responseSteps = tick({ moveX:1,technique2:true,aim:0 });
  assert(responseSteps.some(event => event.type === 'sound' && event.id === 'medic-response-handoff'));
  assert(movingPatient.health > secondBefore && medic.eAt === paidE);
  assert.equal(kit().precautionWrap.patient,patient.id);
  assert.equal(kit().precautionWrap.until,originalDeadline);
  assert.equal(medic.qAt,0);
  const root = patient.health;
  hostile(patient,22);
  assert.equal(kit().precautionWrap.capturedHits,1);
  const paidQ = medic.qAt, wounded = patient.health;
  assert(paidQ > game.combatTick && wounded < root);
  tick({ technique3:true,aim:Math.atan2(patient.y-medic.y,patient.x-medic.x) });
  assert.equal(kit().precautionWrap.phase,'settling');
  wait(precautionRules.settleTicks);
  const pulse = game.classCues().find(cue => cue.kind === 'medic-precaution-dose' && cue.patient === patient.id);
  assert(pulse && patient.health > wounded && medic.qAt === paidQ && medic.eAt === paidE);
  for (const observer of [patient,movingPatient]) {
    const view = viewFor(observer.id);
    assert(view.classCues.some(cue => cue.id === pulse.id));
    const privateKit = view.players.find(actor => actor.id === medic.id).kit;
    assert.equal(privateKit.precautionWrap,undefined);
    assert.equal(privateKit.fieldDressing,undefined);
    assert.equal(privateKit.rapidResponse,undefined);
  }
  const firstDose = patient.health-wounded, secondDose = movingPatient.health-secondBefore;
  wait(paidQ - game.combatTick);
  const aim = Math.atan2(patient.y-medic.y,patient.x-medic.x);
  tick({ technique1:true,aim });
  assert.equal(kit().fieldDressing.phase,'preparing');
  wait(8);
  assert(kit().fieldDressing.canWrap);
  tick({ technique1:true,aim });
  assert.equal(kit().fieldDressing.phase,'wrapped');
  assert.equal(medic.qAt,paidQ);
  const ammo = medic.ammo;
  tick({ fire:true,aim:0 });
  assert(medic.ammo < ammo);
  const dressedBefore = patient.health;
  tick({ technique1:true,aim });
  assert.equal(kit().fieldDressing.phase,'preparing');
  for (let count = 0; count < 16 && medic.qAt === paidQ; count++) tick({ aim });
  assert(patient.health > dressedBefore && medic.qAt > paidQ && medic.eAt === paidE);
  return { caseId:'two-patients', spent:f.spent, firstPatient:patient.id, secondPatient:movingPatient.id,
    firstDose, secondDose, paidQ, paidE, sharedPulse:pulse.id,
    observerPrivateStateExcluded:true, wrappedDressingDose:patient.health-dressedBefore, wrappedShots:ammo-medic.ammo };
}

const cases = [chargeArbitration(),twoPatients()];
receipt(output,{ passed:true, controlledGameFixture:true, probeProtocol:PROTOCOL, contentRevision:CONTENT_REVISION,
  bundleSha256:source.bundle, sameAuthoredArena:true, cases });
console.log(JSON.stringify(cases));
