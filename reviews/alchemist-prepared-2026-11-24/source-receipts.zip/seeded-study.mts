import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { navigationPolicy } from './study-navigation.mjs';
import { preparedPolicy } from './prepared-policy.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { preparedIds, compoundRules } = await repoImport('src/shared/alchemist-prepared.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [mode, party, output, subset, edition] = process.argv.slice(2);
assert(PROTOCOL === (edition === 'staged' ? 105 : 106) && ['short', 'standard'].includes(mode) && ['solo', 'pair'].includes(party) && output);
assert(['full','replay','pilot'].includes(subset) && ['source','staged'].includes(edition));
const fittings = ['entry', 'brew', 'toss'] as const;
const worlds = [['gatehouse', 41], ['sunken-chapel', 67], ['ossuary-works', 103]] as const;
const rules = data.rules.alchemy;
const nav = { ordinary: restRaidInput, arenaFor: runtimeArena, segmentRect, segmentCircle, playerRadius:data.rules.playerRadius };
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

function simulate(arena, seed, fitting, active) {
  const game = new Game({ mode, difficulty:'normal', seed, openingArenaId:arena, arenaSelection:'fixed', maxPlayers:party === 'solo' ? 1 : 2 });
  const owner = game.addPlayer('perrin', 'Perrin', 'alchemist');
  const players = party === 'solo' ? [owner] : [owner, game.addPlayer('mara', 'Mara', 'soldier')];
  const route = navigationPolicy(nav), routeAlly = navigationPolicy(nav);
  const choose = preparedPolicy({ route, arenaFor:runtimeArena, segmentRect, segmentCircle, reach:rules.flaskRange });
  const chemistry = { select:recipe => game.selectAlchemy(owner.id,recipe), throw:point => game.throwAlchemy(owner.id,point) };
  const hostile = new Map(), purchases = [], stowed = [], returns = [], expired = [], landings = [];
  const trace = createHash('sha256');
  let nextFlare, returned, threwBinding, spent = false;
  let serial = 0, shop = -1, frames = 0;
  function buy(actor, kind, item) {
    const result = game.transact(actor.id, { id:'prepared-study-' + ++serial, kind, item });
    if (result.ok) purchases.push({ owner:actor.id,kind,item,earned:actor.totalSp,clears:actor.progress.clears });
    return result.ok;
  }
  function outfit(actor) {
    for (const weapon of data.weapons.filter(w => w.classId === actor.classId).sort((a,b) => b.tier - a.tier)) {
      if (actor.weapon === weapon.id || buy(actor,'weapon',weapon.id)) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy(actor,'upgrade',item);
    buy(actor,'supply','medkit');
  }
  assert.equal(owner.totalSp,3);
  assert(buy(owner,'skill','alchemist-reagents-1') && buy(owner,'skill',preparedIds.entry));
  if (fitting !== 'entry') assert(!buy(owner,'skill',preparedIds[fitting]));
  players.forEach(outfit);
  assert(game.start());
  while (!['victory','defeat'].includes(game.phase) && frames++ < 90000) {
    if (game.phase !== 'combat') {
      hostile.clear(); nextFlare=returned=undefined; spent=threwBinding=false;
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of players) game.vote(actor.id,1);
      if (game.phase === 'shop' && shop !== game.encounter) {
        shop = game.encounter;
        if (fitting !== 'entry' && owner.totalSp >= 5 && !owner.skills.includes(preparedIds[fitting])) assert(buy(owner,'skill',preparedIds[fitting]));
      }
      game.step(); game.drainEvents(); continue;
    }
    const view = viewOf(game,owner.id), shots = [...hostile.values()];
    const directBefore = owner.damageDealt, fitAvailable = owner.skills.includes(preparedIds[fitting]);
    const holder = view.players.find(row => row.id === owner.id).kit.alchemyReserve?.held;
    let tried = false;
    for (const actor of players) {
      const player = view.players.find(p => p.id === actor.id);
      assert(player);
      const control = actor.status !== 'active' ? { interact:true } : actor === owner ? choose(view,player,shots,chemistry,fitAvailable,active,spent) : routeAlly(view,player,shots);
      const input = { ...idleInput(), ...control, sequence:actor.ack + 1, clientTick:game.combatTick };
      input.aim = Math.atan2(Math.sin(input.aim), Math.cos(input.aim));
      if (actor === owner) tried = input.technique2;
      trace.update(JSON.stringify(input));
      assert(game.submitInput(actor.id,input));
    }
    game.step();
    const batch = game.drainEvents();
    for (const event of batch) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') hostile.set(shot.id,{ ...shot, seenAt:game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) hostile.delete(id);
    }
    const at = game.combatTick;
    const state = game.kitStatus(owner.id), held = state.alchemyReserve?.held;
    if (held && !holder) {
      assert(active && fitAvailable && tried && held.recipe === 'flare' && held.until === at + compoundRules.holdingTicks);
      stowed.push({ ...held,at,boss:view.boss.id,encounter:game.encounter });
      spent=true; threwBinding=false;
    }
    if (holder || nextFlare || returned) {
      const cues = game.classCues().filter(cue => 'recipe' in cue && cue.owner === owner.id);
      if (holder && cues.some(cue => cue.kind === 'alchemy-flask' && cue.recipe === 'binding' && cue.at >= at - 1)) threwBinding=true;
      if (holder && !held && game.phase === 'combat' && owner.status === 'active') {
        if (at >= holder.until) expired.push({ at,boss:view.boss.id,recipe:holder.recipe });
        else if (state.alchemyPrepared?.[0] === holder.recipe) {
          assert(threwBinding);
          returned={ at,boss:view.boss.id,fitting,recipe:holder.recipe,until:holder.until,servedOtherFirst:true };
          returns.push(returned);
        }
      }
      if (returned && !nextFlare) {
        const flight = cues.find(cue => cue.kind === 'alchemy-flask' && cue.recipe === returned.recipe && cue.at >= returned.at);
        if(flight) nextFlare=flight;
      }
      if (nextFlare && at >= nextFlare.until) {
        const pool = cues.find(cue => cue.kind === 'alchemy-pool' && cue.recipe === 'flare' && cue.at === nextFlare.until &&
          distance(cue,{x:nextFlare.x2,y:nextFlare.y2}) < .01);
        if (pool) landings.push({ flight:nextFlare.id,at,ownerCreditOnLandingTick:owner.damageDealt-directBefore });
        nextFlare=returned=undefined;
      }
    }
    trace.update(JSON.stringify([at, game.boss.health, owner.x, owner.y, owner.health, owner.ammo, owner.damageDealt, owner.qAt, owner.eAt, batch]));
  }
  assert(['defeat','victory'].includes(game.phase));
  assert(returns.length + expired.length <= stowed.length && landings.length <= returns.length);
  if (!active) assert(!stowed.length && !returns.length && !expired.length);
  return { arena,seed,fitting,active,won:game.phase === 'victory',clears:owner.progress.clears,acquired:owner.skills.includes(preparedIds[fitting]),
    purchases,stowed,returns,expired,landings,totalDamage:owner.damageDealt,trace:trace.digest('hex') };
}

const rows = [];
for (const [worldIndex,[arena,seed]] of worlds.entries()) for (const [index,fitting] of fittings.entries()) for (const active of [false,true]) {
  if (subset === 'replay' && (!active || worldIndex !== index)) continue;
  if (subset === 'pilot' && worldIndex !== index) continue;
  const row = simulate(arena,seed,fitting,active);
  rows.push(row);
  console.log(JSON.stringify({arena,fitting,active,won:row.won,clears:row.clears,stowed:row.stowed.length,released:row.returns.length,landed:row.landings.length}));
}
assert.equal(rows.length, subset === 'full' ? 18 : subset === 'replay' ? 3 : 6);
function runtimeFiles(dir) {
  const base = new URL('stage/' + dir + '/',import.meta.url);
  const names = new Map(readdirSync(join(checkout,dir),{withFileTypes:true}).map(row => [row.name,row]));
  if (edition === 'staged') for (const layer of [new URL('../alchemist-reactive/stage/' + dir + '/',import.meta.url),base]) {
    if (existsSync(layer)) for (const row of readdirSync(layer,{withFileTypes:true})) names.set(row.name,row);
  }
  return [...names.values()].flatMap(row => row.isDirectory() ? runtimeFiles(dir + '/' + row.name) : [dir + '/' + row.name]);
}
const source = createHash('sha256');
for (const path of runtimeFiles('src').sort()) {
  const staged = new URL('stage/' + path,import.meta.url);
  const reaction = new URL('../alchemist-reactive/stage/' + path,import.meta.url);
  const alternate = edition === 'staged' ? [staged,reaction].find(existsSync) : undefined;
  const file = alternate ? fileURLToPath(alternate) : join(checkout,path);
  source.update(path + '\0').update(readFileSync(file));
}
receipt(output, { mode,party,subset,scratchOnly:edition === 'staged',protocol:PROTOCOL,revision:CONTENT_REVISION,runtimeSourceSha256:source.digest('hex'),
  driverSha256:sha256(readFileSync(new URL(import.meta.url))),policySha256:sha256(readFileSync(new URL('prepared-policy.mjs',import.meta.url))),
  navigationSha256:sha256(readFileSync(new URL('study-navigation.mjs',import.meta.url))),rows });
