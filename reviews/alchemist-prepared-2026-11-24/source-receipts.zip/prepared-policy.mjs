const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);

export function preparedPolicy({ route, arenaFor, segmentRect, segmentCircle, reach }) {
  const clear = (map,a,b,pad) => !map.obstacles.some(wall => segmentRect(a,b,wall,pad) !== null);
  return (view,player,hostile,chemistry,fitAvailable,use,spent) => {
    const base = route(view,player,hostile);
    const input = { ...base,q:false,e:false };
    if (base.dodge || base.supply >= 0 || player.status !== 'active') return input;
    const tick = view.combatTick, boss = view.boss, { kit } = player;
    if ((kit.alchemyBrewUntil ?? 0) > tick) return input;
    const map = arenaFor(view.arenaId,view.run.difficulty), range = distance(player,boss);
    const open = range < reach - 35 && clear(map,player,boss,8);
    const ready = tick >= player.eAt && tick >= player.dashUntil;
    const vials = kit.alchemyPrepared ?? [], reserve = kit.alchemyReserve;
    const held = reserve?.held;
    function brew(recipe) {
      if (kit.alchemyRecipe !== recipe) chemistry.select(recipe);
      else if (tick >= player.qAt) return { ...input,q:true };
      return input;
    }
    if (held) {
      if (vials[0] === 'binding' && open && ready && chemistry.throw(boss)) return input;
      if (vials.length) return input;
      if (reserve.stage === 'return') return { ...input,technique2:true,fire:false,ultimate:false };
      if (reserve.stage === 'brew') return brew('mending');
      return input;
    }
    if (fitAvailable && !spent && vials[0] === 'flare') {
      if (vials.length === 1) return brew('binding');
      if (use && open && ready && reserve?.stage === 'stow') return { ...input,technique2:true,fire:false,ultimate:false };
      if (use && range >= reach - 35 && clear(map,player,boss,3)) {
        const x = (boss.x-player.x) / range, y = (boss.y-player.y) / range;
        const ahead = { x:player.x+x*24,y:player.y+y*24 };
        if (clear(map,player,ahead,13) && map.lavaPits.every(pit => segmentCircle(player,ahead,pit,pit.radius+13) === null)) {
          return { ...input,moveX:x,moveY:y };
        }
      }
    }
    if (vials[0] === 'mending' && ready && player.maxHealth - player.health > 16) chemistry.throw(player);
    else if (vials[0] && vials[0] !== 'mending' && open && ready) chemistry.throw(boss);
    if (!vials.length) return brew('flare');
    return input;
  };
}
