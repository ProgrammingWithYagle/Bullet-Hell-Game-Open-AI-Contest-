import assert from 'node:assert/strict';
import { join } from 'node:path';
import { checkout, readJson, receipt, repoImport } from '../bonded/study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION } = await repoImport('src/shared/protocol.ts');
const { conflictingSkill } = await repoImport('src/shared/skill-conflicts.ts');
const { reactiveIds } = await repoImport('src/shared/alchemist-reactive.ts');
const { preparedIds } = await repoImport('src/shared/alchemist-prepared.ts');
const [target, edition] = process.argv.slice(2);
assert(target && PROTOCOL === (edition === 'staged' ? 105 : 106));
const prior = readJson(edition === 'staged' ? new URL('../alchemist-reactive/census-stage01.json',import.meta.url) :
  join(checkout, 'reviews/alchemist-reactive-2026-11-24/build-census.json'));
assert.equal(prior.totalSets,31969);
const issued = prior.reports.find(report => report.classId === 'alchemist');
assert.equal(issued.distinctSets,342);

const skills = new Map([...data.skills, ...data.generalSkills, ...data.specializationSkills].map(node => [node.id, node]));
const transforms = data.skills.filter(node => node.classId === 'alchemist' && node.transform);
const techniques = data.specializationSkills.filter(node => node.classId === 'alchemist');
assert.deepEqual(transforms.map(node => node.transform).sort(), ['second-extraction', 'settled-batch', 'split-pour']);
assert.deepEqual(techniques.map(node => node.id), [...Object.values(reactiveIds),...Object.values(preparedIds)]);
const significant = new Set([...techniques, ...transforms, ...data.generalSkills].map(node => node.id));
const prerequisites = new Set<string>();
function include(id: string) {
  if (prerequisites.has(id)) return;
  const node = skills.get(id);
  assert(node, id);
  if (node.prerequisite) include(node.prerequisite);
  prerequisites.add(id);
}
for (const id of significant) include(id);
const choices = [...prerequisites], acquired: string[] = [], additions = new Map();
function walk(index: number, spent: number, capstones: number) {
  if (index === choices.length) {
    if (!acquired.includes(preparedIds.entry)) return;
    const signature = acquired.filter(id => significant.has(id)).sort().join('|');
    if (!additions.has(signature) || additions.get(signature).spent > spent) {
      additions.set(signature, { skills: [...acquired], spent, remaining: 27 - spent, capstones, operationAndSharedSignature: signature });
    }
    return;
  }
  const id = choices[index], node = skills.get(id)!;
  walk(index + 1, spent, capstones);
  if (spent + node.cost > 27 || Number(node.freePlaySpRequired ?? 0) > 27 || node.capstone && capstones ||
      node.prerequisite && !acquired.includes(node.prerequisite) || conflictingSkill(acquired, id)) return;
  acquired.push(id);
  walk(index + 1, spent + node.cost, capstones + Number(node.capstone));
  acquired.pop();
}
walk(0, 0, 0);
const count = (id: string) => [...additions.values()].filter(row => row.skills.includes(id)).length;
const fitting = { brew:count(preparedIds.brew), toss:count(preparedIds.toss), bothRoutes:count(reactiveIds.entry),
  transformations:Object.fromEntries(transforms.map(node => [node.transform,count(node.id)])), exclusions:0, retainedReactiveExclusions:0 };
assert(fitting.brew > 0 && fitting.brew === fitting.toss && fitting.bothRoutes > 0);
assert(Object.values(fitting.transformations).every(value => value > 0));
assert(issued.builds.every(row => !additions.has(row.operationAndSharedSignature)));
const traced = prior.reports.map(report => report.classId === 'alchemist' ? { ...report,techniques:techniques.length,fitting,
  builds:[...report.builds,...additions.values()] } : report);
const reports = traced.map(report => {
  let purchases = 0;
  for (const row of report.builds) {
    const game = new Game({ mode: 'endless', seed: 41, maxPlayers: 1 });
    game.encounter = 9;
    const actor = game.addPlayer('solo', 'Build census', report.classId);
    assert.equal(actor.totalSp, 27);
    for (const item of row.skills) assert(game.transact(actor.id, { id:'buy-' + ++purchases, kind:'skill', item }).ok, item);
    assert.deepEqual(actor.skills, row.skills);
    assert.equal(actor.skills.reduce((spent, id) => spent + game.skillCost(id), 0), row.spent);
    if (report.classId !== 'alchemist') continue;
    const status = game.kitStatus(actor.id);
    assert.equal(Boolean(status.alchemyReserve),row.skills.includes(preparedIds.entry));
    assert.equal(Boolean(status.alchemyReaction),row.skills.includes(reactiveIds.entry));
    const brew = row.skills.includes(preparedIds.brew), toss = row.skills.includes(preparedIds.toss);
    if (status.alchemyReserve) assert.equal(status.alchemyReserve.fitting,brew ? 'brew' : toss ? 'toss' : 'standard');
    for (const [a,b,key] of [[preparedIds.brew,preparedIds.toss,'exclusions'],[reactiveIds.wick,reactiveIds.vent,'retainedReactiveExclusions']]) {
      const denied = row.skills.includes(a) ? b : row.skills.includes(b) ? a : undefined;
      if (!denied) continue;
      assert.equal(game.transact(actor.id,{id:'excluded-' + denied,kind:'skill',item:denied}).reason,'incompatibleItem');
      assert(!actor.skills.includes(denied));
      fitting[key]++;
    }
  }
  return { ...report, purchases, priorSetsPreserved: report.distinctSets, distinctSets: report.builds.length };
});
const priorSetCount = reports.reduce((sum, report) => sum + report.priorSetsPreserved, 0);
const totalSets = reports.reduce((sum, report) => sum + report.distinctSets, 0);
assert.equal(priorSetCount, prior.totalSets);
assert.equal(totalSets,priorSetCount + additions.size);
assert.equal(fitting.exclusions,fitting.brew + fitting.toss);
assert(fitting.retainedReactiveExclusions >= issued.fitting.exclusions);
receipt(target, { scratchOnly: edition === 'staged', protocol:PROTOCOL, contentRevision:CONTENT_REVISION, priorSetCount,
  totalSets,alchemistPreparedSets:additions.size,reports,
  scope:'Canonical 27-SP purchases. Preserve issued sets and enumerate Prepared Compounds with Reactive Mixtures, General and the three issued Alchemist transformations.' });
console.log(JSON.stringify({passed:true,totalSets,priorSetCount,alchemistPreparedSets:additions.size,fitting}));
