import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { Worker } from 'node:worker_threads';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { preparedFlow, waitFor as until } from './native-flow.mts';

const { data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [transport, fitting, outcome, supplied, audience = 'public', difficulty = 'normal', edition = 'source'] = process.argv.slice(2);
assert(['source','staged'].includes(edition));
assert(PROTOCOL === (edition==='staged'?105:106) && ['worker','peer'].includes(transport) && ['entry','brew','toss'].includes(fitting) && outcome);
assert(['testing','public'].includes(audience) && ['normal','baby'].includes(difficulty));
const setup = { mode: fitting === 'entry' ? 'short' : 'standard', difficulty, arenaSelection: 'fixed', openingArenaId: 'gatehouse',
  freePlay: { openingBossId: 'constable', variant: 'normal', seed: 73 } };
const inputKeys = new Set(Object.keys(idleInput()));
function legalFrame(view, sequence, controls) {
  const action = Object.fromEntries(Object.entries(controls).filter(([key, value]) => inputKeys.has(key) && value !== undefined));
  if (Number.isFinite(action.aim)) action.aim = Math.atan2(Math.sin(action.aim), Math.cos(action.aim));
  return inputFrame(view, sequence, action);
}
const playerIn = (view, id) => view?.players.find(player => player.id === id);
const state = () => ({ events:[], observed:new Map() });
const play = adapter => preparedFlow(adapter, fitting);

async function runWorker() {
  let code = supplied && supplied !== '-' ? readFileSync(supplied, 'utf8') : undefined;
  if (code === undefined) {
    const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
    const output = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'],
      bundle: true, minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(audience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = output.outputFiles[0].text;
  }
  const wrapper = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" + code +
    "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(wrapper).toString('base64')), { execArgv: [] });
  const captured = state(), purchases = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', failure => { error = failure; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    if (message.type === 'error') error = Error(JSON.stringify(message));
    if (message.type === 'view') view = message.view;
    if (message.type === 'events') remember(captured.events, captured.observed, message.events, view?.combatTick ?? 0);
    if (message.type === 'purchaseResult') purchases.set(message.id, message);
    if (message.type === 'pauseState') paused = message.value;
  });
  const send = message => worker.postMessage(message);
  try {
    await until(() => ready || error, 'whole worker ready');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: setup.freePlay.seed, maxPlayers: 1 }, name: 'Perrin', classId: 'alchemist' });
    await until(() => !!view || error, 'worker lobby');
    if (error) throw error;
    const result = await play({ ...captured, id: 'solo', view: () => { if (error) throw error; return view; },
      input: props => { send({ type: 'input', input: legalFrame(view, ++sequence, props) }); return sequence; },
      purchase: async request => {
        const id = 'alchemist-prepared-' + ++serial;
        send({ type: 'purchase', request: { ...request, id } });
        await until(() => confirmedPurchase(view, 'solo', request, purchases.get(id)), 'worker purchase response');
        return purchases.get(id);
      }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
      select: recipe => send({ type: 'alchemyRecipe', recipe }), throw: point => send({ type: 'alchemyThrow', point }),
      pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeer() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const transient = supplied && supplied !== '-' ? undefined : createGameServer({ audience });
  if (transient) await transient.server.listen(0, '127.0.0.1');
  const endpoint = transient ? 'http://127.0.0.1:' + transient.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), chemist = new Session(endpoint);
  const ownerState = state(), hostState = state(), ownerReplies = [], hostReplies = [];
  let seq = 0, hostSeq = 0, leaks = 0;
  host.onView = view => {
    const raw = host.room?.state.players.get(chemist.id)?.lineworkOwner;
    if (playerIn(view, chemist.id)?.kit.alchemyReserve !== undefined || raw && JSON.parse(raw).alchemyReserve !== undefined) leaks++;
  };
  chemist.onEvents = batch => remember(ownerState.events, ownerState.observed, batch, chemist.view?.combatTick ?? 0);
  host.onEvents = batch => remember(hostState.events, hostState.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = response => hostReplies.push(response);
  chemist.onPurchase = response => ownerReplies.push(response);
  async function purchase(client, replies, request) {
    const i = replies.length;
    client.purchase(request);
    await until(() => confirmedPurchase(client.view, client.id, request, replies[i]), 'room purchase response');
    return replies[i];
  }
  try {
    await host.connect({ ...setup, name: 'Natural host', classId: 'soldier', maxPlayers: 2 });
    await chemist.connect({ ...setup, name: 'Perrin', classId: 'alchemist', maxPlayers: 2 }, { roomId: host.room.roomId });
    await until(() => chemist.view?.players.length === 2 && host.view?.players.length === 2, 'two real peers');
    assert.equal(chemist.view.owner, host.id);
    assert.notEqual(chemist.id, host.id);
    const hostPlayer = () => playerIn(host.view, host.id);
    for (const weapon of data.weapons.filter(row => row.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (hostPlayer().weapon === weapon.id || (await purchase(host, hostReplies, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const result = await play({ ...ownerState, id: chemist.id, view: () => chemist.view,
      input: props => { chemist.input(legalFrame(chemist.view, ++seq, props)); return seq; },
      purchase: request => purchase(chemist, ownerReplies, request), start: () => host.start(),
      select: recipe => chemist.selectAlchemy(recipe), throw: point => chemist.throwAlchemy(point),
      vote: index => { host.vote(index); chemist.vote(index); }, pause: value => host.setMatchPaused(value), paused: () => chemist.view?.matchPaused === true,
      ally: pressure => {
        const control = restRaidInput(host.view, hostPlayer(), [...hostState.observed.values()]);
        host.input(legalFrame(host.view, ++hostSeq, pressure ? control : { ...control, q: false, e: false, ultimate: false, fire: false }));
      },
      witness: async trace => {
        const raw = chemist.room.state.players.get(chemist.id)?.lineworkOwner;
        assert(raw);
        const owned = JSON.parse(raw).alchemyReserve;
        assert(owned?.held?.recipe === 'flare');
        assert.deepEqual(owned.held, trace.held);
        assert.equal(leaks,0);
        return { joinedNonHost:true,ownerStateStayedPrivate:true,observedSleeve:!!trace.held };
      },
    });
    host.endMatch();
    await until(() => [host, chemist].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'close joined proof room');
    return { ...result, endpoint, peers: 2 };
  } finally {
    await chemist.close();
    await host.close();
    if (transient) await transient.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeer());
receipt(outcome, { ...result, scratchOnly: edition==='staged', protocol: PROTOCOL, contentRevision: CONTENT_REVISION, transport, audience, difficulty,
  flowSha256: sha256(readFileSync(new URL('./native-flow.mts', import.meta.url))), driverSha256: sha256(readFileSync(new URL(import.meta.url))), policySha256: sha256(readFileSync(join(checkout, 'tests/helpers/sniper-rest-raid-policy.ts'))) });
console.log(JSON.stringify({ passed: true, transport, fitting, firstClear: result.firstClear, boss: result.boss, hit: result.result.hit }));
