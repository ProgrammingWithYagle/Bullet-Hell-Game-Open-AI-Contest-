import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { repoImport } from '../bonded/study-paths.mjs';
import { waitFor } from '../formation/native-flow-v4.mts';
import { navigationPolicy } from '../ranger-whole/navigation-policy.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { preparedIds, compoundRules } = await repoImport('src/shared/alchemist-prepared.ts');
const recipeRules = data.rules.alchemy;
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
export { waitFor };

const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const heading = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
const offset = (point, direction, travel) => ({ x: point.x + Math.cos(direction) * travel, y: point.y + Math.sin(direction) * travel });
const quiet = (frame, aim = frame.aim) => ({ ...frame, aim, q: false, e: false, ultimate: false, technique1: false, technique2: false, technique3: false,
  fire: false, reload: false, sprint: false });
const move = (frame, aim) => ({ ...frame, moveX: Math.cos(aim), moveY: Math.sin(aim) });
const visible = (map, a, b, pad) => !map.obstacles.some(wall => segmentRect(a, b, wall, pad) !== null);

export async function preparedFlow(adapter, fitting) {
  const view = () => { const state = adapter.view(); assert(state); return state; };
  const actor = () => { const row = view().players.find(p => p.id === adapter.id); assert(row); return row; };
  const kit = () => actor().kit;
  const controls = navigationPolicy({ ordinary: restRaidInput, arenaFor: runtimeArena, segmentRect, segmentCircle, playerRadius: data.rules.playerRadius });
  const ordinary = () => controls(view(), actor(), [...adapter.observed.values()]);
  const cues = (kind, recipe) => view().classCues.filter(cue => cue.kind === kind && cue.owner === adapter.id && (!recipe || cue.recipe === recipe));
  const purchases = [];
  const owned = () => actor().skills.reduce((cost, id) => cost + [...data.skills, ...data.specializationSkills].find(row => row.id === id).cost, 0);
  const diagnose = () => JSON.stringify({ fitting, boss: view().boss.id, phase: view().phase, tick: view().combatTick,
    eAt: actor().eAt, qAt: actor().qAt, health: actor().health, kit: kit().alchemyReserve, prepared: kit().alchemyPrepared });
  async function buy(id) {
    assert((await adapter.purchase({ kind: 'skill', item: id })).ok, id);
    purchases.push({ item: id, earned: owned() + actor().sp, clears: actor().progress.clears });
  }
  async function outfit() {
    for (const weapon of data.weapons.filter(weapon => weapon.classId === 'alchemist').sort((a, b) => b.tier - a.tier)) {
      if (actor().weapon === weapon.id || (await adapter.purchase({ kind: 'weapon', item: weapon.id })).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) await adapter.purchase({ kind: 'upgrade', item });
    await adapter.purchase({ kind: 'supply', item: 'medkit' });
  }
  assert.equal(actor().sp, 3);
  await buy('alchemist-reagents-1');
  await buy(preparedIds.entry);
  await waitFor(() => !!kit().alchemyReserve, 'owner Action 2 arrived');
  if (fitting !== 'entry') assert(!(await adapter.purchase({ kind: 'skill', item: preparedIds[fitting] })).ok);
  await outfit();
  adapter.start();
  await waitFor(() => view().phase === 'combat', 'opening combat');
  if (fitting !== 'entry') {
    const deadline = Date.now() + 125_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < deadline && !['defeat', 'victory'].includes(view().phase), diagnose());
      if (view().phase === 'combat') {
        const frame = ordinary();
        adapter.input({ ...quiet(frame), fire: frame.fire === true, reload: frame.reload === true });
        adapter.ally?.(true);
      } else if (['mutationVote', 'contractVote', 'secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(24);
    }
    assert.equal(actor().progress.clears, 1);
    assert.equal(owned() + actor().sp, 5);
    await buy(preparedIds[fitting]);
    assert.equal((await adapter.purchase({ kind: 'skill', item: preparedIds[fitting === 'brew' ? 'toss' : 'brew'] })).reason, 'incompatibleItem');
    await outfit();
    await waitFor(() => view().phase === 'combat', 'fitted combat', 90000);
  }
  const firstClear = actor().progress.clears;
  console.log(JSON.stringify({ fitting, firstClear, purchases, boss: view().boss.id }));

  let witness, pauseRejected = false;
  const quietFrame = () => quiet(ordinary());
  const ready = (check, note) => waitFor(check,note,8000);
  const tick = () => view().combatTick;
  const sameEncounter = () => view().phase === 'combat' && actor().progress.clears === firstClear;
  async function steerUntil(check,label,command = () => {}) {
    const deadline = Date.now() + 45000;
    while (!check()) {
      assert(sameEncounter() && Date.now() < deadline, label + ' ' + diagnose());
      const frame = quietFrame();
      command(frame);
      adapter.ally?.(false);
      adapter.input(frame);
      await sleep(25);
    }
  }
  async function brew(recipe,count) {
    let last = -Infinity;
    await steerUntil(() => kit().alchemyPrepared?.length === count,
      'paid brew ' + recipe,frame => {
        const p = actor(), state = kit();
        if (state.alchemyRecipe !== recipe && tick() >= last + 8) {
          adapter.select(recipe); last = tick();
        }
        if (state.alchemyRecipe === recipe && tick() >= p.qAt && tick() >= (state.alchemyBrewUntil ?? 0) && !frame.dodge) frame.q = true;
      });
  }
  function legalThrow(reach = 240) {
    const state = view(), p = actor();
    const map = runtimeArena(state.arenaId,state.run.difficulty);
    return tick() >= p.eAt && tick() >= p.dashUntil && distance(p,state.boss) <= reach && visible(map,p,state.boss,8);
  }
  async function flight(recipe) {
    await steerUntil(legalThrow,'safe legal Cast Flask',frame => {
      const state = view(), p = actor(), boss = state.boss;
      const map = runtimeArena(state.arenaId,state.run.difficulty);
      const angle = heading(p,boss);
      const ahead = offset(p,angle,28);
      if (distance(p,boss) > 205 && !frame.dodge && frame.supply < 0 && visible(map,p,ahead,14) &&
          map.lavaPits.every(pit => segmentCircle(p,ahead,pit,pit.radius + 13) === null)) Object.assign(frame,move(frame,angle));
    });
    const requested = tick(), point = { x:view().boss.x,y:view().boss.y }, health = view().boss.health, clock = actor().eAt;
    adapter.throw(point);
    const pending = () => cues('alchemy-flask',recipe).find(row => row.at >= requested);
    await ready(() => !!pending(),'a real ' + recipe + ' flight');
    const thrown = pending();
    assert(thrown && thrown.until - thrown.at === recipeRules.flightTicks && distance({x:thrown.x2,y:thrown.y2},point) < .01);
    assert(actor().eAt > clock);
    return { thrown,health,clock:actor().eAt };
  }

  await brew('flare',1);
  if (fitting !== 'brew') await brew('binding',2);
  else await steerUntil(() => tick() >= actor().qAt,'ready to fit a second recipe');
  const pre = { qAt:actor().qAt,eAt:actor().eAt,ammo:actor().ammo };
  adapter.input({ technique2:true });
  await ready(() => kit().alchemyReserve?.held?.recipe === 'flare','private stowed Flare');
  const held = kit().alchemyReserve.held;
  assert.equal(held.until - held.readyAt,compoundRules.holdingTicks - compoundRules.settleTicks);
  assert.deepEqual({ qAt:actor().qAt,eAt:actor().eAt,ammo:actor().ammo },pre);
  assert.deepEqual(kit().alchemyPrepared,fitting === 'brew' ? [] : ['binding']);
  witness = await adapter.witness?.({ held });
  if (fitting === 'entry') await steerUntil(() => kit().alchemyReserve?.stage === 'return','actual manual release window');
  adapter.pause(true);
  await ready(() => adapter.paused(),'paused with stowed vial');
  const pausedAt = tick();
  adapter.input({ technique2:true });
  await sleep(115);
  assert.equal(tick(),pausedAt);
  assert.deepEqual(kit().alchemyReserve?.held,held);
  pauseRejected = true;
  adapter.pause(false);
  await ready(() => !adapter.paused() && tick() > pausedAt,'resume stowed vial clock');

  let firstThrow;
  if (fitting === 'brew') {
    await brew('binding',2);
    assert.deepEqual(kit().alchemyPrepared,['flare','binding']);
  } else {
    firstThrow = await flight('binding');
    if (fitting === 'entry') {
      assert.deepEqual(kit().alchemyReserve?.held,held);
      adapter.input({ technique2:true });
      await ready(() => !kit().alchemyReserve?.held,'manual release after the other vial');
    }
    assert.deepEqual(kit().alchemyPrepared,['flare']);
  }
  assert.equal(kit().alchemyReserve?.held,undefined);
  const released = { at:tick(), queue:[...kit().alchemyPrepared], eAt:actor().eAt };
  assert(released.at < held.until);
  const { thrown,health,clock } = await flight('flare');
  await steerUntil(() => tick() >= thrown.until,'returned Flare lands');
  const landed = cues('alchemy-pool','flare').find(cue => cue.at === thrown.until && Math.hypot(cue.x - thrown.x2,cue.y - thrown.y2) < .01);
  const hit = health - view().boss.health;
  assert(landed && hit > 0, 'returned Flare did not deal a positive hit ' + diagnose());
  return { passed:true,fitting,firstClear,boss:view().boss.id,bought:purchases,witness,pauseRejected,
    result:{ hit:true,damage:hit,held,released,earlierBinding:firstThrow?.thrown,flight:thrown,landed,readyAt:clock } };
}
