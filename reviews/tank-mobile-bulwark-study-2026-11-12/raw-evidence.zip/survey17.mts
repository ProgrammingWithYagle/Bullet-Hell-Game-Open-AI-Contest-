import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { root, read, sha, write, git, fingerprints } from '../heavy-corner-guide-stage/common.mjs';

const stage = path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const before = fingerprints();
const { Game, data } = await import(pathToFileURL(root + '/src/shared/game.ts').href);
const { idleInput, HZ } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { moveBody, distance } = await import(pathToFileURL(root + '/src/shared/geometry.ts').href);
const { constructHit } = await import(pathToFileURL(root + '/src/shared/class-kits.ts').href);
const playerRadius = data.rules.playerRadius;
const directions = [-Math.PI / 4, -Math.PI / 8, 0, Math.PI / 8, Math.PI / 4];
const spans = [110, 55];
const point = (p) => ({ x: p.x, y: p.y });
const offset = (p, x, y, scale) => ({ x: p.x + x * scale, y: p.y + y * scale });
const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

function footprintClear(world, center, normal, halfSpan) {
  const along = { x: -normal.y, y: normal.x }, thickness = 12;
  const xReach = thickness * Math.abs(normal.x) + halfSpan * Math.abs(along.x);
  const yReach = thickness * Math.abs(normal.y) + halfSpan * Math.abs(along.y);
  const { x, y, width, height } = world.bounds;
  if (center.x - xReach < x || center.x + xReach > x + width || center.y - yReach < y || center.y + yReach > y + height) return false;
  for (const wall of world.obstacles) {
    const dx = wall.x + wall.width / 2 - center.x, dy = wall.y + wall.height / 2 - center.y;
    const rw = wall.width / 2, rh = wall.height / 2;
    if (Math.abs(dx) > xReach + rw || Math.abs(dy) > yReach + rh) continue;
    if (Math.abs(dx * normal.x + dy * normal.y) > thickness + rw * Math.abs(normal.x) + rh * Math.abs(normal.y)) continue;
    if (Math.abs(dx * along.x + dy * along.y) > halfSpan + rw * Math.abs(along.x) + rh * Math.abs(along.y)) continue;
    return false;
  }
  for (const lava of world.lavaPits) {
    const dx = lava.x - center.x, dy = lava.y - center.y;
    const localX = dx * normal.x + dy * normal.y, localY = dx * along.x + dy * along.y;
    if (Math.hypot(localX - clamp(localX, -thickness, thickness), localY - clamp(localY, -halfSpan, halfSpan)) <= lava.radius) return false;
  }
  return true;
}

function surveyedRoute(arena, difficulty, turn) {
  const game = new Game({ mode: 'short', difficulty, seed: 41, openingArenaId: arena, arenaSelection: 'fixed' });
  const tank = game.addPlayer('solo', 'Controlled Tank Barrier survey', 'tank');
  assert(game.start());
  game.boss.staggerUntil = 400;
  const bearing = Math.atan2(game.boss.y - tank.y, game.boss.x - tank.x) + turn;
  const aim = Math.atan2(Math.sin(bearing), Math.cos(bearing));
  const normal = { x: Math.cos(aim), y: Math.sin(aim) }, spawn = point(tank);
  let sequence = 0;
  function step(input = {}) {
    assert(game.submitInput(tank.id, { ...idleInput(), sequence: ++sequence, clientTick: game.combatTick, aim, ...input }));
    game.step();
    game.drainEvents();
  }
  step({ q: true });
  const wall = game.classKits.cues().find(cue => cue.kind === 'wall' && cue.owner === tank.id);
  assert(wall?.kind === 'wall');
  const found = { x: wall.x, y: wall.y, aim: wall.aim, id: wall.id, at: wall.at, until: wall.until, health: wall.health, recovery: tank.qAt };
  assert.equal(wall.until - wall.at, HZ * 5);
  const take = offset(wall, normal.x, normal.y, -32), world = game.arena;
  for (let tick = 0; tick < 40 && distance(tank, take) > 0.55; tick++) {
    const scale = Math.max(distance(tank, take), game.movementSpeed(tank) / HZ);
    step({ moveX: (take.x - tank.x) / scale, moveY: (take.y - tank.y) / scale });
  }
  const takeAt = game.combatTick, body = point(tank);
  const near = distance(body, take) <= 0.55;
  const clearIssuedPlacement = footprintClear(world, wall, normal, wall.halfSpan ?? 110);
  const routes = [];
  for (const sign of [-1, 1]) {
    const side = { x: -normal.y * sign, y: normal.x * sign };
    for (const halfSpan of spans) {
      let p = body, clearSteps = 0;
      const carryPoint = offset(p, normal.x, normal.y, 32);
      if (near && footprintClear(world, carryPoint, normal, halfSpan)) {
        for (let tick = 0; tick < 42; tick++) {
          const next = moveBody(p, { x: side.x * 4, y: side.y * 4 }, playerRadius, game.obstacles);
          if (distance(p, next) < 3.5 || !footprintClear(world, offset(next, normal.x, normal.y, 32), normal, halfSpan)) break;
          p = next;
          clearSteps++;
        }
      }
      const destination = offset(p, normal.x, normal.y, 32);
      const canSetFullWidth = clearSteps > 0 && footprintClear(world, destination, normal, wall.halfSpan ?? 110);
      const line = offset(p, normal.x, normal.y, -18);
      const from = offset(p, normal.x, normal.y, 100);
      const carried = { ...wall, ...destination, halfSpan };
      const centeredThreatWouldCrossCarried = constructHit(from, line, carried, 3) !== null;
      const centeredThreatWouldCrossStationary = constructHit(from, line, wall, 3) !== null;
      const remainingAtEnd = wall.until - takeAt - clearSteps;
      routes.push({ sign, halfSpan, clearSteps, traveled: distance(body, p), canSetFullWidth, remainingAtEnd,
        centeredThreatWouldCrossCarried, centeredThreatWouldCrossStationary });
    }
  }
  return { aim, spawn, found, clearIssuedPlacement, takeAt, pickupDistance: distance(tank, wall), near, routes };
}

const rows = [];
const difficulties = ['baby', 'easy', 'normal', 'hard', 'insane', 'hellish'];
for (const { id: arena } of data.arenas) for (const difficulty of difficulties) {
  const surveyed = directions.map(turn => surveyedRoute(arena, difficulty, turn));
  const suitable = surveyed.flatMap(trial => trial.routes.filter(route => route.traveled >= 112 && route.remainingAtEnd > 30 && route.canSetFullWidth && route.centeredThreatWouldCrossCarried && !route.centeredThreatWouldCrossStationary));
  const narrowGains = surveyed.flatMap(trial => trial.routes.filter(route => route.halfSpan === 55 && route.traveled >= 100 && route.traveled >= trial.routes.find(other => other.halfSpan === 110 && other.sign === route.sign).traveled + 32));
  rows.push({ arena, difficulty, reachablePickup: surveyed.some(trial => trial.near && trial.clearIssuedPlacement), moveAndSet: suitable.length > 0, narrowGains: narrowGains.length, surveyed });
}
assert.equal(rows.length, 36);
assert.deepEqual(fingerprints(), before);
const report = { measuredAt: new Date().toISOString(), base: git('rev-parse', 'HEAD'), contentRevision: read('content/revision.json').sha256,
  runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256,
  driverSha256: sha(fs.readFileSync(new URL(import.meta.url))), rows,
  scope: 'Actual ordinary Tank Barrier cast, original lifetime and actual player walk to pickup distance. Proposed carried footprints and rays are geometric observations. No carry command, new card, live projectile interception, altered game source or earned ownership is executed.' };
write(stage + '/survey17.json', report);
console.log(JSON.stringify({ pairs: rows.length, reachablePickup: rows.filter(row => row.reachablePickup).length,
  moveAndSet: rows.filter(row => row.moveAndSet).length, narrowGains: rows.filter(row => row.narrowGains).length,
  missing: rows.filter(row => !row.moveAndSet).map(row => row.arena + '/' + row.difficulty) }));
