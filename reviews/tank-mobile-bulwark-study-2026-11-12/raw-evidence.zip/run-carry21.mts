import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { root, read, sha, write, fingerprints } from '../heavy-corner-guide-stage/common.mjs';

const stage = path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const proof = read(stage + '/tank-carry-build18.json'), before = fingerprints();
assert.equal(proof.sourceSnapshotSha256, before.sourceSnapshotSha256);
const bundle = stage + '/tank-game18.mjs';
assert.equal(sha(fs.readFileSync(bundle)), proof.bundleSha256);
const { Game, data } = await import(pathToFileURL(bundle).href);
assert.equal(sha(JSON.stringify(data)), proof.copiedRegistrySha256);
const { idleInput, HZ } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { distance, segmentRect } = await import(pathToFileURL(root + '/src/shared/geometry.ts').href);
const { constructHit } = await import(pathToFileURL(root + '/src/shared/class-kits.ts').href);
const geometry = read(stage + '/survey17.json');
assert.equal(geometry.sourceSnapshotSha256, proof.sourceSnapshotSha256);
const point = p => ({ x: p.x, y: p.y });

function trial(row, survey, route, carry) {
  const { arena, difficulty } = row, aim = survey.aim;
  const game = new Game({ mode: 'short', difficulty, seed: 41, openingArenaId: arena, arenaSelection: 'fixed' });
  const tank = game.addPlayer('solo', 'Controlled Shoulder Wall study', 'tank');
  assert.equal(tank.totalSp, 3);
  const buy = item => game.transact(tank.id, { kind: 'skill', id: item, item });
  assert(buy('tank-protection-1').ok);
  if (carry) assert(buy(proof.definition.id).ok);
  assert(game.start());
  game.boss.staggerUntil = 400;
  const normal = { x: Math.cos(aim), y: Math.sin(aim) };
  const side = { x: -normal.y * route.sign, y: normal.x * route.sign };
  const wall = () => game.classKits.cues().find(cue => cue.kind === 'wall' && cue.owner === tank.id);
  let sequence = 0;
  function step(input = {}) {
    assert(game.submitInput(tank.id, { ...idleInput(), sequence: ++sequence, clientTick: game.combatTick, aim, ...input }));
    game.step();
    return game.drainEvents();
  }
  step({ q: true });
  const original = wall(), originalRecovery = tank.qAt;
  assert(original?.kind === 'wall' && original.until - original.at === 150);
  const take = { x: original.x - 32 * normal.x, y: original.y - 32 * normal.y };
  for (let n = 0; n < 40 && distance(tank, take) > 0.55; n++) {
    const length = Math.max(distance(tank, take), game.movementSpeed(tank) / HZ);
    step({ moveX: (take.x - tank.x) / length, moveY: (take.y - tank.y) / length });
  }
  assert(distance(tank, take) <= 0.55);
  const ammo = tank.ammo;
  const pick = step(carry ? { technique1: true, fire: true } : {});
  if (carry) {
    assert(pick.some(e => e.type === 'sound' && e.id === 'tank-wall-lift'));
    assert.equal(tank.ammo, ammo);
    assert.equal(wall()?.halfSpan, 55);
  }
  const start = point(tank), stride = 4 * HZ / game.movementSpeed(tank);
  for (let tick = 0; tick < route.clearSteps; tick++) step({ moveX: side.x * stride, moveY: side.y * stride });
  assert(distance(tank, start) > 112);
  const beforeShot = wall();
  assert(beforeShot?.kind === 'wall');
  const from = { x: tank.x + 49 * normal.x, y: tank.y + 49 * normal.y };
  assert(!game.obstacles.some(rect => segmentRect(from, tank, rect, 3)), 'Controlled shot needs a clear masonry ray');
  assert.equal(constructHit(from, tank, beforeShot, 3) !== null, carry);
  const health = tank.health, shield = tank.shield;
  const projectile = game.emitShot('hostile', from.x, from.y, Math.atan2(-normal.y, -normal.x), 720, 25, 3);
  assert(projectile);
  const id = projectile.id;
  for (let tick = 0; tick < 5 && game.shots.has(id); tick++) step();
  assert(!game.shots.has(id));
  const afterShot = wall();
  assert(afterShot?.kind === 'wall');
  const wallDamage = beforeShot.health - afterShot.health, actorDamage = health - tank.health, shieldDamage = shield - tank.shield;
  if (carry) {
    assert.equal(wallDamage, 25);
    assert.equal(actorDamage, 0);
    assert.equal(shieldDamage, 0);
    const set = step({ technique1: true });
    assert(set.some(e => e.type === 'sound' && e.id === 'tank-wall-set'));
  } else {
    assert.equal(wallDamage, 0);
    assert(actorDamage + shieldDamage > 0);
  }
  const end = wall();
  assert(end?.kind === 'wall' && end.halfSpan === original.halfSpan);
  assert.equal(end.id, original.id);
  assert.equal(end.health, original.health - wallDamage);
  assert.equal(end.until, original.until);
  assert.equal(tank.qAt, originalRecovery);
  const result = { carry, body: point(tank), originalCenter: point(original), finalCenter: point(end), originalId: original.id,
    moved: distance(tank, start), wallDamage, actorDamage, shieldDamage, initialShield: shield, remainingShield: tank.shield, originalHealth: original.health, remainingHealth: end.health,
    originalExpiry: original.until, setAt: game.combatTick, originalRecovery, projectileId: id, spentSP: carry ? 3 : 1 };
  while (game.combatTick < original.until) step();
  assert(!wall());
  return result;
}

const rows = [];
for (const row of geometry.rows) {
  const options = row.surveyed.flatMap(survey => survey.routes.filter(route => route.halfSpan === 55 && route.canSetFullWidth &&
    route.traveled > 116 && route.remainingAtEnd > 30 && route.centeredThreatWouldCrossCarried && !route.centeredThreatWouldCrossStationary)
    .flatMap(route => Array.from({ length: Math.max(0, route.clearSteps - 29) }, (_, n) => ({ survey, route: { ...route, clearSteps: route.clearSteps - n } }))));
  const attempts = [];
  for (const { survey, route } of options) {
    try {
      const carried = trial(row, survey, route, true), stock = trial(row, survey, route, false);
      assert.deepEqual(carried.body, stock.body);
      assert.equal(carried.originalExpiry, stock.originalExpiry);
      attempts.push({ passed: true, aim: survey.aim, side: route.sign, carried, stock });
      break;
    } catch (error) {
      attempts.push({ passed: false, aim: survey.aim, side: route.sign, error: error.message });
    }
  }
  rows.push({ arena: row.arena, difficulty: row.difficulty, passed: attempts.some(attempt => attempt.passed), attempts });
}
assert.deepEqual(fingerprints(), before);
const passed = rows.filter(row => row.passed).length;
write(stage + '/tank-carry-controlled21.json', { measuredAt: new Date().toISOString(), bundleSha256: proof.bundleSha256,
  candidateRegistrySha256: proof.copiedRegistrySha256, runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256,
  passed, total: rows.length, rows, scope: 'Isolated Game copy with actual 3-SP entry and manual commands. Boss stagger and one injected ordinary hostile round isolate geometry. Matched original Barrier and Shoulder Wall execute identical Tank routes. No canonical card, natural enemy sequence, human or online acceptance.' });
console.log(JSON.stringify({ passed, total: rows.length, failures: rows.filter(row => !row.passed).map(row => ({ arena: row.arena, difficulty: row.difficulty, failures: row.attempts.map(attempt => attempt.error) })) }));
if (passed !== rows.length) process.exitCode = 1;
