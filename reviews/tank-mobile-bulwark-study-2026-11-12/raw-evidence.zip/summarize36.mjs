import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { root, read, write, sha, fingerprints } from '../heavy-corner-guide-stage/common.mjs';

const stage=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const source=read('reviews/heavy-corner-guide-r2-2026-11-12/source-verification.json');
const before=fingerprints();
assert.equal(source.runtimeSourceSha256,before.runtimeSourceSha256);
assert.equal(source.sourceSnapshotSha256,before.sourceSnapshotSha256);
const matrix=read(stage+'/tank-carry-earned34-matrix.json');
const previous=read(stage+'/tank-carry-earned30-matrix.json');
const geometry=read(stage+'/tank-carry-controlled34.json');
const lifecycle=read(stage+'/tank-carry-lifecycle34.json');
const compatibility=read(stage+'/tank-carry-compatibility34.json');
const transformations=read(stage+'/tank-carry-transformations35.json');
const bundle=read(stage+'/tank-carry-build33.json');
assert(matrix.rows.length===48&&previous.rows.length===48);
assert(geometry.passed===36&&geometry.total===36&&lifecycle.passed===9&&lifecycle.total===9);
assert(compatibility.passed===4&&compatibility.total===4&&transformations.passed===4&&transformations.total===4);
for(const report of [matrix,geometry,lifecycle,compatibility,transformations]){
  assert.equal(report.runtimeSourceSha256,before.runtimeSourceSha256);
  assert.equal(report.sourceSnapshotSha256,before.sourceSnapshotSha256);
}
assert.equal(matrix.copiedGameBundleSha256,bundle.bundleSha256);
assert.equal(sha(fs.readFileSync(stage+'/tank-game33.mjs')),bundle.bundleSha256);
const key=row=>[row.arena,row.difficulty,row.seed,row.useCarry].join('|');
const old=new Map(previous.rows.map(row=>[key(row),row]));
const changed=[];
for(const row of matrix.rows){
  const prior=old.get(key(row));assert(prior);
  const fields=Object.keys(row).filter(field=>JSON.stringify(row[field])!==JSON.stringify(prior[field]));
  if(fields.length)changed.push({case:key(row),fields});
}
const byPolicy=[false,true].map(useCarry=>{
  const rows=matrix.rows.filter(row=>row.useCarry===useCarry);
  assert(rows.length===24&&rows.every(row=>['victory','defeat'].includes(row.outcome)));
  return {useCarry,trials:rows.length,victories:rows.filter(row=>row.outcome==='victory').length,
    defeats:rows.filter(row=>row.outcome==='defeat').length,
    liftAdmissions:rows.reduce((sum,row)=>sum+row.operations.filter(op=>op.kind==='tank-wall-lift').length,0),
    casesWithActualCarriedInterception:rows.filter(row=>row.actualCarriedWallDamage>0).length,
    actualCarriedWallDamage:rows.reduce((sum,row)=>sum+row.actualCarriedWallDamage,0),
    heldTriggerTicks:rows.reduce((sum,row)=>sum+row.triggerHeldWhileCarriedTicks,0)};
});
const sample=matrix.rows.filter(row=>row.useCarry&&row.actualCarriedWallDamage>0)
  .map(({arena,difficulty,seed,outcome,actualCarriedWallDamage})=>({arena,difficulty,seed,outcome,actualCarriedWallDamage}));
const files=['tank-carry-controlled19.json','tank-carry-controlled20.json','tank-carry-controlled21.json','tank-carry-controlled23.json',
  'tank-carry-lifecycle24.json','tank-carry-compatibility31.json','tank-carry-controlled34.json','tank-carry-lifecycle34.json',
  'tank-carry-compatibility34.json','tank-carry-transformations35.json','tank-carry-earned27-pilot.json','tank-carry-earned28-pilot.json',
  'tank-carry-earned30-matrix.json','tank-carry-earned34-matrix.json','tank-carry-build33.json'];
assert.deepEqual(fingerprints(),before);
write(stage+'/summary36.json',{measuredAt:new Date().toISOString(),verificationSourceCommit:source.sourceCommit,
  runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,
  copiedGameBundleSha256:bundle.bundleSha256,copiedRegistrySha256:bundle.copiedRegistrySha256,
  canonicalSpecializationCount:read('content/catalog.json').specializationSkills.length,
  canonicalTankSpecializationCount:read('content/catalog.json').specializationSkills.filter(skill=>skill.classId==='tank').length,
  canonicalCardRegistered:false,canonicalPurchaseVerified:false,onlineProof:false,
  controlledGeometryCases:36,lifecycleCases:9,baseAndTransformationCases:4,fullTransformationHandlingCases:4,
  naturalTrials:48,byPolicy,actualInterceptionCases:sample,
  earlierSingleWallRowsCompared:matrix.rows.length,earlierSingleWallRowsExactlyEqual:matrix.rows.length-changed.length,
  changedRawFields:changed,originalFailuresRetained:true,
  evidence:files.map(file=>({file,sha256:sha(fs.readFileSync(stage+'/'+file))})),
  scope:'Tank carry remains a copied-Game research operation. The natural runs use actual starting 3-SP research purchases, original enemies and ordinary progression. Outcome counts describe the sampled policies. Human, rendered, device and final balance acceptance remain open.'});
console.log(JSON.stringify({naturalTrials:48,byPolicy,earlierSingleWallRowsExactlyEqual:48-changed.length,changedFields:changed,
  fullTransformationCases:4,canonicalCardRegistered:false}));
