import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { root, read, sha, write, fingerprints } from '../heavy-corner-guide-stage/common.mjs';

const stage = path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const before = fingerprints(), build = read(stage + '/tank-carry-build18.json');
assert.equal(before.sourceSnapshotSha256, build.sourceSnapshotSha256);
assert.equal(sha(fs.readFileSync(stage + '/tank-game18.mjs')), build.bundleSha256);
const { Game } = await import(pathToFileURL(stage + '/tank-game18.mjs').href);
const { idleInput, HZ } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { distance } = await import(pathToFileURL(root + '/src/shared/geometry.ts').href);
const carried = (g, p) => g.classKits.tankWallCarried(p.id, g.combatTick);
const point = ({ x, y }) => ({ x, y });

function fixture() {
  const g = new Game({ mode: 'short', difficulty: 'baby', seed: 41, openingArenaId: 'gatehouse', arenaSelection: 'fixed' });
  const p = g.addPlayer('tank', 'Controlled carried wall', 'tank');
  g.addPlayer('ally', 'Present ally', 'soldier');
  for (const item of ['tank-protection-1', build.definition.id]) assert(g.transact(p.id, { kind: 'skill', id: item, item }).ok);
  assert.equal(p.totalSp, 3);
  assert(g.start());
  g.boss.staggerUntil = 400;
  const wall = () => g.classKits.cues().find(cue => cue.kind === 'wall' && cue.owner === p.id);
  let sequence = 0;
  const aim = Math.atan2(g.boss.y - p.y, g.boss.x - p.x);
  const step = (input = {}) => {
    assert(g.submitInput(p.id, { ...idleInput(), sequence: ++sequence, clientTick: g.combatTick, aim, ...input }));
    g.step();
    return g.drainEvents();
  };
  step({ q: true });
  const first = wall();
  assert(first?.kind === 'wall');
  const target = { x: first.x - 32 * Math.cos(aim), y: first.y - 32 * Math.sin(aim) };
  for (let tick = 0; distance(p, target) > 0.4 && tick < 40; tick++) {
    const length = Math.max(distance(p, target), g.movementSpeed(p) / HZ);
    step({ moveX: (target.x - p.x) / length, moveY: (target.y - p.y) / length });
  }
  assert(distance(p, target) <= 0.4);
  step({ technique1: true });
  assert(carried(g, p));
  return { g, p, step, wall, first, aim };
}

const rows = [];
function run(name, execute) {
  try { rows.push({ name, passed: true, evidence: execute() }); }
  catch (error) { rows.push({ name, passed: false, error: error.message }); }
}

run('carrying commits both hands and the original heading under active inputs', () => {
  const f = fixture(), ammo = f.p.ammo, initial = f.wall();
  const clocks = [f.p.qAt, f.p.eAt, f.p.ultimateAt];
  for (let tick = 0; tick < 4; tick++) f.step({ aim: 0.5, fire: true, reload: true, dodge: true, e: true, q: true, ultimate: true });
  assert(carried(f.g, f.p));
  assert.equal(f.p.ammo, ammo);
  assert.equal(f.p.reloadAt, 0);
  assert.deepEqual([f.p.qAt, f.p.eAt, f.p.ultimateAt], clocks);
  assert.equal(f.wall().aim, initial.aim);
  assert.equal(f.wall().until, f.first.until);
  return { ticks: 4, paidPrimary: 0, originalUntil: f.first.until };
});
run('setdown rejects a blocked broad footprint and preserves the lifted shield', () => {
  const f = fixture(), wall = f.wall(), along = { x: -Math.sin(f.aim), y: Math.cos(f.aim) };
  const blocker = { x: wall.x + along.x * 80 - 3, y: wall.y + along.y * 80 - 3, width: 6, height: 6 };
  f.g.arena.obstacles.push(blocker);
  f.step({ technique1: true });
  assert(carried(f.g, f.p) && f.wall().halfSpan === 55);
  assert.equal(f.wall().until, f.first.until);
  assert.equal(f.g.arena.obstacles.pop(), blocker);
  f.step({ technique1: true });
  assert(!carried(f.g, f.p) && f.wall().halfSpan === f.first.halfSpan);
  return { refusedBlockedSet: true, allowedClearSet: true };
});
run('current masonry obstructing the held shield retires its dependent work', () => {
  const f = fixture(), wall = f.wall();
  f.g.arena.obstacles.push({ x: wall.x - 6, y: wall.y - 6, width: 12, height: 12 });
  f.step();
  assert(!carried(f.g, f.p) && !f.wall());
  return { wallRemoved: true };
});
run('losing the carry skill removes the carried wall before further movement', () => {
  const f = fixture();
  f.p.skills = f.p.skills.filter(item => item !== build.definition.id);
  f.step();
  assert(!carried(f.g, f.p) && !f.wall());
  return { wallRemoved: true };
});
run('disconnect immediately retires the carried wall while the ally remains', () => {
  const f = fixture();
  f.g.setConnected(f.p.id, false);
  assert(!carried(f.g, f.p) && !f.wall());
  return { immediatelyRetired: true };
});
run('fatal owner damage immediately retires the carried wall in an active party', () => {
  const f = fixture();
  while (f.g.combatTick < f.p.invulnerableUntil) f.step();
  f.g.damage(f.p, 100_000);
  assert.equal(f.p.status, 'downed');
  assert(!carried(f.g, f.p) && !f.wall());
  return { owner: f.p.status, immediatelyRetired: true };
});
run('host exit clears the wall and carry controller', () => {
  const f = fixture();
  assert(f.g.endByHost());
  assert(!carried(f.g, f.p) && !f.wall());
  return { phase: f.g.phase };
});
run('setting and picking up again retains damage, identity and first expiry', () => {
  const f = fixture();
  f.g.classKits.hitConstruct(f.first.id, 17);
  const health = f.wall().health;
  for (let n = 0; n < 3; n++) {
    f.step({ technique1: true });
    assert(!carried(f.g, f.p));
    f.step({ technique1: true });
    assert(carried(f.g, f.p));
  }
  assert.equal(f.wall().id, f.first.id);
  assert.equal(f.wall().health, health);
  assert.equal(f.wall().until, f.first.until);
  return { rounds: 3, health, until: f.first.until };
});
assert.deepEqual(fingerprints(), before);
const passed = rows.filter(row => row.passed).length;
write(stage + '/tank-carry-lifecycle24.json', { measuredAt: new Date().toISOString(), copiedGameBundleSha256: build.bundleSha256,
  runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256,
  driverSha256: sha(fs.readFileSync(new URL(import.meta.url))), passed, total: rows.length, rows,
  scope: 'Controlled copied Game lifecycle checks at an actual 3-SP research purchase. Selected damage and masonry are injected to isolate state boundaries. No canonical or online claim.' });
console.log(JSON.stringify({ passed, total: rows.length, failures: rows.filter(row => !row.passed) }));
if (passed !== rows.length) process.exitCode = 1;
