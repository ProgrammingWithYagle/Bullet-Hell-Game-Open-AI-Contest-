import { tankCarryId, wallFootprintClear } from './tank-carry25.ts';
export { tankCarryId, wallFootprintClear };

const leadDistance = 32;
const pickupRange = 37;
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const normalOf = wall => ({ x: Math.cos(wall.aim), y: Math.sin(wall.aim) });
const lead = (body, normal) => ({
  x: body.x + normal.x * leadDistance,
  y: body.y + normal.y * leadDistance,
});
type Member = { id: number; halfSpan?: number; offset: { x: number; y: number } };
type HeldWall = { weapon: string; normal: { x: number; y: number }; members: Member[] };

export class TankCarryStudy {
  private held = new Map<string, HeldWall>();
  private commands = new Map<string, number>();

  clear() {
    this.held.clear();
    this.commands.clear();
  }

  remove(id, walls) {
    for (const member of this.held.get(id)?.members ?? []) walls.delete(member.id);
    this.held.delete(id);
    this.commands.delete(id);
  }

  active(id, walls, tick) {
    const held = this.held.get(id);
    if (!held) return;
    held.members = held.members.filter(member => {
      const wall = walls.get(member.id);
      return wall?.owner === id && wall.until > tick && wall.health > 0;
    });
    if (held.members.length) return walls.get(held.members[0].id);
    this.held.delete(id);
  }

  step(players, walls, tick) {
    for (const [id, held] of this.held) {
      if (!this.active(id, walls, tick)) continue;
      const player = players.find(player => player.id === id);
      if (!player?.connected || player.status !== 'active' || player.weapon !== held.weapon ||
          !player.skills.includes(tankCarryId)) this.remove(id, walls);
    }
  }

  private frames(held, center, folded, walls) {
    const fraction = folded ? 0.5 : 1;
    return held.members.map(member => ({
      wall: walls.get(member.id),
      center: {
        x: center.x + member.offset.x * fraction,
        y: center.y + member.offset.y * fraction,
      },
      halfSpan: (member.halfSpan ?? 110) * fraction,
      originalSpan: member.halfSpan,
    }));
  }

  command(player, walls, world) {
    if (!player.skills.includes(tankCarryId) || player.dashUntil > world.tick ||
        player.reloadAt > world.tick || player.input.q || player.input.dodge) return;
    if (player.input.sequence <= (this.commands.get(player.id) ?? -1)) return;
    this.commands.set(player.id, player.input.sequence);
    if (this.active(player.id, walls, world.tick)) {
      const held = this.held.get(player.id)!;
      const frames = this.frames(held, lead(player, held.normal), false, walls);
      if (frames.some(frame => !wallFootprintClear(world, frame.center, normalOf(frame.wall), frame.halfSpan))) return;
      for (const frame of frames) Object.assign(frame.wall, frame.center, { halfSpan: frame.originalSpan });
      this.held.delete(player.id);
      return 'set';
    }

    const available = [...walls.values()]
      .filter(wall => wall.owner === player.id && wall.kind === 'wall' &&
        (!wall.source || wall.source.startsWith('corner-')) && wall.until > world.tick && wall.health > 0)
      .sort((a, b) => b.at - a.at || a.id - b.id);
    const first = available[0];
    if (!first) return;
    const group = first.source
      ? available.filter(wall => wall.source?.startsWith('corner-') && wall.at === first.at)
      : [first];
    const center = {
      x: group.reduce((sum, wall) => sum + wall.x, 0) / group.length,
      y: group.reduce((sum, wall) => sum + wall.y, 0) / group.length,
    };
    const heading = {
      x: group.reduce((sum, wall) => sum + Math.cos(wall.aim), 0),
      y: group.reduce((sum, wall) => sum + Math.sin(wall.aim), 0),
    };
    const length = Math.hypot(heading.x, heading.y);
    if (length < 1e-6) return;
    const normal = group.length === 1 ? normalOf(first) : { x: heading.x / length, y: heading.y / length };
    const carriedCenter = lead(player, normal);
    const rear = (center.x - player.x) * normal.x + (center.y - player.y) * normal.y;
    if (distance(player, center) > pickupRange || rear < 23 || distance(center, carriedCenter) > 12) return;
    const held = {
      weapon: player.weapon,
      normal,
      members: group.map(wall => ({
        id: wall.id, halfSpan: wall.halfSpan,
        offset: { x: wall.x - center.x, y: wall.y - center.y },
      })),
    };
    const frames = this.frames(held, carriedCenter, true, walls);
    if (frames.some(frame => !wallFootprintClear(world, frame.center, normalOf(frame.wall), frame.halfSpan))) return;
    this.held.set(player.id, held);
    for (const frame of frames) Object.assign(frame.wall, frame.center, { halfSpan: frame.halfSpan });
    return 'lift';
  }

  move(player, next, walls, world) {
    if (!this.active(player.id, walls, world.tick)) return next;
    const held = this.held.get(player.id)!;
    const current = this.frames(held, lead(player, held.normal), true, walls);
    if (player.weapon !== held.weapon || !player.skills.includes(tankCarryId) ||
        current.some(frame => !wallFootprintClear(world, frame.center, normalOf(frame.wall), frame.halfSpan))) {
      this.remove(player.id, walls);
      return next;
    }
    const target = this.frames(held, lead(next, held.normal), true, walls);
    const steps = Math.max(1, ...target.map(frame => Math.ceil(distance(frame.wall, frame.center) / 3)));
    for (let n = 1; n <= steps; n++) for (const frame of target) {
      const portion = n / steps;
      const center = {
        x: frame.wall.x + (frame.center.x - frame.wall.x) * portion,
        y: frame.wall.y + (frame.center.y - frame.wall.y) * portion,
      };
      if (!wallFootprintClear(world, center, normalOf(frame.wall), frame.halfSpan)) return player;
    }
    for (const frame of target) Object.assign(frame.wall, frame.center);
    return next;
  }
}
