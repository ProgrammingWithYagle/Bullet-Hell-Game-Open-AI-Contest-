import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { root, read, write, sha, fingerprints } from '../heavy-corner-guide-stage/common.mjs';

const stage=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const before=fingerprints(),build=read(stage+'/tank-carry-build25.json');
assert.equal(before.sourceSnapshotSha256,build.sourceSnapshotSha256);
assert.equal(sha(fs.readFileSync(stage+'/tank-game25.mjs')),build.bundleSha256);
const {Game,data}=await import(pathToFileURL(stage+'/tank-game25.mjs').href);
const {wallFootprintClear}=await import(pathToFileURL(stage+'/tank-carry25.ts').href);
const {idleInput,HZ}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href);
const {viewOf}=await import(pathToFileURL(root+'/src/shared/view.ts').href);
const {moveBody,distance}=await import(pathToFileURL(root+'/src/shared/geometry.ts').href);
const {restRaidInput}=await import(pathToFileURL(root+'/tests/helpers/sniper-rest-raid-policy.ts').href);
const scope=process.argv[2]??'pilot';
assert(scope==='pilot'||scope==='matrix');
const point=({x,y})=>({x,y});

function trial(arena,difficulty,seed,useCarry){
  const g=new Game({mode:'short',difficulty,seed,maxPlayers:1,openingArenaId:arena,arenaSelection:'fixed'});
  const p=g.addPlayer('solo','Earned Shoulder Wall study','tank');
  const observed=new Map(),purchases=[],operations=[],clears=[],phases=[];
  let sequence=0,transaction=0,lastPhase='',lastClears=0,openingAt=0,attempted=false,work,heldTicks=0,paidPrimary=0;
  const buy=(kind,item)=>{
    const r=g.transact(p.id,{id:'tank-study-'+ ++transaction,kind,item});
    if(r.ok)purchases.push({kind,item,earned:p.totalSp,encounter:g.encounter});
    return r.ok;
  };
  function shop(){
    if(!p.skills.includes('tank-protection-1'))assert(buy('skill','tank-protection-1'));
    if(useCarry&&!p.skills.includes(build.definition.id))assert(buy('skill',build.definition.id));
    if(g.encounter>0)for(const id of ['general-sprint','general-brake-step','general-double-dash'])
      if(!p.skills.includes(id))buy('skill',id);
    for(const weapon of data.weapons.filter(w=>w.classId==='tank').sort((a,b)=>b.tier-a.tier))
      if(p.weapon===weapon.id||buy('weapon',weapon.id))break;
    for(const id of ['damage','health','fire-rate','reload','magazine'])buy('upgrade',id);
    buy('supply','medkit');
  }
  const wall=()=>g.classKits.cues().find(cue=>cue.kind==='wall'&&cue.owner===p.id&&!cue.source);
  const note=(kind,fields={})=>operations.push({kind,tick:g.combatTick,encounter:g.encounter,position:point(p),health:p.health,shield:p.shield,...fields});
  const walk=target=>{
    const size=Math.max(distance(p,target),g.movementSpeed(p)/HZ);
    return {moveX:(target.x-p.x)/size,moveY:(target.y-p.y)/size};
  };
  function chooseTarget(wall){
    const normal={x:Math.cos(wall.aim),y:Math.sin(wall.aim)};
    const world={...g.arena,obstacles:g.obstacles};
    return [-1,1].map(sign=>{
      const side={x:-normal.y*sign,y:normal.x*sign};
      let target=point(p),settable;
      for(let n=0;n<30;n++){
        const next=moveBody(target,{x:side.x*4,y:side.y*4},data.rules.playerRadius,g.obstacles);
        const center={x:next.x+normal.x*32,y:next.y+normal.y*32};
        if(distance(target,next)<3.5||!wallFootprintClear(world,center,normal,55))break;
        target=next;
        if(wallFootprintClear(world,center,normal,110))settable=target;
      }
      return settable?{target:settable,score:distance(p,settable)}:undefined;
    }).filter(Boolean).sort((a,b)=>b.score-a.score)[0];
  }
  assert.equal(p.totalSp,3);shop();assert(g.start());
  while(g.tick<30_000&&!['victory','defeat'].includes(g.phase)){
    if(g.phase!==lastPhase){
      lastPhase=g.phase;phases.push({phase:g.phase,encounter:g.encounter,earned:p.totalSp,tick:g.tick});
      if(g.phase==='shop')shop();
      if(g.phase==='combat'){observed.clear();work=undefined;openingAt=g.combatTick;attempted=false;}
    }
    if(g.phase==='combat'){
      const view=viewOf(g,p.id),actor=view.players.find(actor=>actor.id===p.id);
      const ordinary=restRaidInput(view,actor,[...observed.values()]);
      let input={...ordinary,q:false};
      const current=wall();
      if(work&&(!current||current.id!==work.wall)&&work.stage!=='cast'){
        note('wall-gone',{stage:work.stage,originalUntil:work.until});work=undefined;
      }
      if(!attempted&&g.combatTick-openingAt>=40&&g.combatTick>=p.qAt){
        attempted=true;
        note('manual-wall-cast');work={stage:'cast',at:g.combatTick};input.q=true;
      }else if(work?.stage==='cast'){
        if(!current){note('wall-cast-missing');work=undefined;}
        else{
          const normal={x:Math.cos(current.aim),y:Math.sin(current.aim)};
          work={stage:'approach',at:g.combatTick,wall:current.id,until:current.until,recovery:p.qAt,aim:current.aim,
            original:point(current),take:{x:current.x-normal.x*32,y:current.y-normal.y*32}};
          note('wall-ready',{wall:current.id,originalUntil:current.until,recovery:p.qAt});
        }
      }
      if(work?.stage==='approach'){
        if(g.combatTick-work.at>45){note('approach-bound');work=undefined;}
        else if(distance(p,work.take)>0.7)input={...input,...walk(work.take)};
        else{
          const target=chooseTarget(current);
          if(!target||target.score<30){note('no-useful-clear-carry-route');work=undefined;}
          else{work={...work,stage:'moving',at:g.combatTick,target:target.target,start:point(p)};
            input={...input,moveX:0,moveY:0,technique1:useCarry};
            note('lift-command',{useCarry,originalUntil:work.until,target:work.target});}
        }
        input={...input,dodge:false,e:false,ultimate:false};
      }else if(work?.stage==='moving'){
        if(g.combatTick-work.at<40){
          input={...input,...(distance(p,work.target)>0.7?walk(work.target):{moveX:0,moveY:0}),dodge:false,e:false,ultimate:false};
        }else{
          note('set-command',{useCarry,moved:distance(p,work.start),originalUntil:work.until});
          input={...input,moveX:0,moveY:0,technique1:useCarry,dodge:false,e:false,ultimate:false};
          work={...work,stage:'release',at:g.combatTick};
        }
      }else if(work?.stage==='release'){
        if(!useCarry||!g.classKits.tankWallCarried(p.id,g.combatTick)){
          note('hands-free',{useCarry,remainingWall:!!wall(),originalUntil:work.until});work=undefined;
        }else if(g.combatTick-work.at<15)input={...input,technique1:true,dodge:false,e:false,ultimate:false};
        else{note('set-rejected-awaiting-expiry');work=undefined;}
      }
      const carrying=g.classKits.tankWallCarried(p.id,g.combatTick);
      if(carrying&&input.fire)heldTicks++;
      const health=current?.health;
      const currentId=current?.id;
      const encounter=g.encounter;
      assert(g.submitInput(p.id,{...idleInput(),...input,sequence:++sequence,clientTick:g.combatTick}));
      g.step();
      const after=wall();
      if(carrying&&g.phase==='combat'&&g.encounter===encounter&&after?.id===currentId&&after.health<health){
        note('actual-carried-interception',{wall:currentId,wallDamage:health-after.health,remainingWallHealth:after.health,until:after.until});
      }
    }else{
      if(g.phase==='mutationVote'||g.phase==='contractVote')g.vote(p.id,0);
      g.step();
    }
    for(const event of g.drainEvents()){
      if(event.type==='shots')for(const shot of event.shots){
        observed.set(shot.id,{...shot,seenAt:g.combatTick});
        if(shot.owner===p.id&&!shot.visual)paidPrimary++;
      }
      if(event.type==='remove')for(const id of event.ids)observed.delete(id);
      if(event.type==='sound'&&event.owner===p.id&&event.id.startsWith('tank-wall-'))note(event.id);
    }
    if(p.progress.clears>lastClears){lastClears=p.progress.clears;clears.push({count:lastClears,earned:p.totalSp,combatTick:g.combatTick});}
  }
  assert(['victory','defeat'].includes(g.phase));
  return {arena,difficulty,seed,useCarry,outcome:g.phase,clears,purchases,operations,phases,triggerHeldWhileCarriedTicks:heldTicks,paidPrimaryProjectiles:paidPrimary,
    actualCarriedWallDamage:operations.filter(op=>op.kind==='actual-carried-interception').reduce((sum,op)=>sum+op.wallDamage,0),
    endingHealth:p.health,endingShield:p.shield,damageTaken:p.damageTaken};
}

const rows=[];
const arenas=scope==='pilot'?['gatehouse','triage-yard','ossuary-works']:data.arenas.map(arena=>arena.id);
const difficulties=scope==='pilot'?['baby']:['baby','normal'];
for(const arena of arenas)for(const difficulty of difficulties)for(const seed of [41,73])for(const useCarry of [false,true]){
  const row=trial(arena,difficulty,seed,useCarry);rows.push(row);
  console.log(JSON.stringify({arena,difficulty,seed,useCarry,outcome:row.outcome,clears:row.clears.length,lifts:row.operations.filter(op=>op.kind==='tank-wall-lift').length,carriedWallDamage:row.actualCarriedWallDamage,heldTicks:row.triggerHeldWhileCarriedTicks}));
}
assert.deepEqual(fingerprints(),before);
write(stage+'/tank-carry-earned27-'+scope+'.json',{measuredAt:new Date().toISOString(),copiedGameBundleSha256:build.bundleSha256,
  candidateRegistrySha256:build.copiedRegistrySha256,runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,
  driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),rows,
  scope:'Isolated research registry with actual starting3SP purchases and ordinary Short progression. Enemies, positions, rewards and clocks run normally. Both arms cast, approach and reposition one wall per encounter. The stationary-wall arm can fire during movement. Carried interception records actual observed remaining-wall health loss while carried. No canonical card, checkpoint import, online or final balance claim.'});
