export const tankCarryId = 'tank-bulwark-carry-1';
const carryDistance = 32;
const carriedSpan = 55;
const pickupRange = 37;

const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const normalOf = (wall) => ({ x: Math.cos(wall.aim), y: Math.sin(wall.aim) });
const lead = (p, normal) => ({ x: p.x + normal.x * carryDistance, y: p.y + normal.y * carryDistance });
const clamp = (value, low, high) => Math.min(high, Math.max(low, value));

export function wallFootprintClear(world, center, normal, halfSpan) {
  const along = { x: -normal.y, y: normal.x }, thickness = 12;
  const xReach = thickness * Math.abs(normal.x) + halfSpan * Math.abs(along.x);
  const yReach = thickness * Math.abs(normal.y) + halfSpan * Math.abs(along.y);
  const { x, y, width, height } = world.bounds;
  if (center.x - xReach < x || center.x + xReach > x + width || center.y - yReach < y || center.y + yReach > y + height) return false;
  for (const wall of world.obstacles) {
    const dx = wall.x + wall.width / 2 - center.x, dy = wall.y + wall.height / 2 - center.y;
    const rw = wall.width / 2, rh = wall.height / 2;
    if (Math.abs(dx) > xReach + rw || Math.abs(dy) > yReach + rh) continue;
    if (Math.abs(dx * normal.x + dy * normal.y) > thickness + rw * Math.abs(normal.x) + rh * Math.abs(normal.y)) continue;
    if (Math.abs(dx * along.x + dy * along.y) > halfSpan + rw * Math.abs(along.x) + rh * Math.abs(along.y)) continue;
    return false;
  }
  for (const lava of world.lavaPits) {
    const dx = lava.x - center.x, dy = lava.y - center.y;
    const a = dx * normal.x + dy * normal.y, b = dx * along.x + dy * along.y;
    if (Math.hypot(a - clamp(a, -thickness, thickness), b - clamp(b, -halfSpan, halfSpan)) <= lava.radius) return false;
  }
  return true;
}

export class TankCarryStudy {
  private work = new Map<string, { wall: number; originalSpan?: number }>();
  private sequence = new Map<string, number>();

  clear() {
    this.work.clear();
    this.sequence.clear();
  }

  active(id, walls, tick) {
    const order = this.work.get(id);
    if (!order) return;
    const wall = walls.get(order.wall);
    if (wall?.owner === id && wall.until > tick && wall.health > 0) return wall;
    this.work.delete(id);
  }

  command(player, walls, world) {
    if (!player.skills.includes(tankCarryId) || player.dashUntil > world.tick || player.reloadAt > world.tick || player.input.q || player.input.dodge) return;
    if (player.input.sequence <= (this.sequence.get(player.id) ?? -1)) return;
    this.sequence.set(player.id, player.input.sequence);
    const current = this.active(player.id, walls, world.tick);
    if (current) {
      const { originalSpan } = this.work.get(player.id)!;
      if (!wallFootprintClear(world, current, normalOf(current), originalSpan ?? 110)) return;
      current.halfSpan = originalSpan;
      this.work.delete(player.id);
      return 'set';
    }
    const wall = [...walls.values()].find(w => w.owner === player.id && w.kind === 'wall' && !w.source && w.until > world.tick && w.health > 0);
    if (!wall || distance(player, wall) > pickupRange) return;
    const normal = normalOf(wall), center = lead(player, normal);
    const rear = (wall.x - player.x) * normal.x + (wall.y - player.y) * normal.y;
    if (rear < 23 || distance(wall, center) > 12 || !wallFootprintClear(world, center, normal, carriedSpan)) return;
    this.work.set(player.id, { wall: wall.id, originalSpan: wall.halfSpan });
    Object.assign(wall, center, { halfSpan: carriedSpan });
    return 'lift';
  }

  move(player, next, walls, world) {
    const wall = this.active(player.id, walls, world.tick);
    if (!wall) return next;
    const normal = normalOf(wall), current = lead(player, normal);
    if (!player.skills.includes(tankCarryId) || !wallFootprintClear(world, current, normal, carriedSpan)) {
      walls.delete(wall.id);
      this.work.delete(player.id);
      return next;
    }
    const center = lead(next, normal);
    const steps = Math.max(1, Math.ceil(distance(wall, center) / 3));
    for (let n = 1; n <= steps; n++) {
      const part = n / steps;
      const point = { x: wall.x + (center.x - wall.x) * part, y: wall.y + (center.y - wall.y) * part };
      if (!wallFootprintClear(world, point, normal, carriedSpan)) return player;
    }
    Object.assign(wall, center);
    return next;
  }
}
