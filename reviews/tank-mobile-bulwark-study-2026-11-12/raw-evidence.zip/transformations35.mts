import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { root, read, write, sha, fingerprints } from '../heavy-corner-guide-stage/common.mjs';

const stage=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const before=fingerprints(),proof=read(stage+'/tank-carry-build33.json');
assert.equal(before.runtimeSourceSha256,proof.runtimeSourceSha256);
assert.equal(sha(fs.readFileSync(stage+'/tank-game33.mjs')),proof.bundleSha256);
const {Game,data}=await import(pathToFileURL(stage+'/tank-game33.mjs').href);
const {idleInput,HZ}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href);
const {distance}=await import(pathToFileURL(root+'/src/shared/geometry.ts').href);
const all=new Map([...data.skills,...data.specializationSkills].map(node=>[node.id,node]));
const rows=[];
for(const talent of [undefined,'wake-guard','procession','cornerstone']){
  const g=new Game({mode:'endless',difficulty:'baby',seed:41,openingArenaId:'gatehouse',arenaSelection:'fixed'});
  g.encounter=9;
  const p=g.addPlayer('solo','Controlled Tank compatibility','tank');
  assert.equal(p.totalSp,27);
  const purchases=[];
  function buy(id){
    if(p.skills.includes(id))return;
    const node=all.get(id);assert(node);
    if(node.prerequisite)buy(node.prerequisite);
    assert(g.transact(p.id,{kind:'skill',id,item:id}).ok);
    purchases.push(id);
  }
  buy(proof.definition.id);
  if(talent)buy(data.skills.find(node=>node.classId==='tank'&&node.transform===talent).id);
  assert(g.start());g.boss.staggerUntil=400;
  let sequence=0;
  const aim=Math.atan2(g.boss.y-p.y,g.boss.x-p.x);
  function step(input={}){
    assert(g.submitInput(p.id,{...idleInput(),sequence:++sequence,clientTick:g.combatTick,aim,...input}));
    g.step();g.drainEvents();
  }
  step({q:true});
  const panels=()=>g.classKits.cues().filter(cue=>cue.kind==='wall'&&cue.owner===p.id);
  const initial=panels();assert(initial.length);
  const center={x:initial.reduce((sum,wall)=>sum+wall.x,0)/initial.length,y:initial.reduce((sum,wall)=>sum+wall.y,0)/initial.length};
  const take={x:center.x-Math.cos(aim)*32,y:center.y-Math.sin(aim)*32};
  for(let tick=0;distance(p,take)>.5&&tick<40;tick++){
    const size=Math.max(distance(p,take),g.movementSpeed(p)/HZ);
    step({moveX:(take.x-p.x)/size,moveY:(take.y-p.y)/size});
  }
  assert(distance(p,take)<=.5);
  step({technique1:true});
  const carried=g.classKits.tankWallCarried(p.id,g.combatTick);
  assert(carried);
  const start={x:p.x,y:p.y};
  const initialHealth=initial[0].health;
  g.classKits.hitConstruct(initial[0].id,17);
  for(let tick=0;tick<4;tick++)step({moveX:-Math.sin(aim)*.6,moveY:Math.cos(aim)*.6});
  assert(distance(start,p)>8);
  const folded=panels();
  assert.equal(folded.length,initial.length);
  for(const wall of folded){
    const old=initial.find(old=>old.id===wall.id);
    assert(old);
    assert.equal(wall.halfSpan,(old.halfSpan??110)/2);
    assert.equal(wall.until,old.until);
  }
  step({technique1:true});
  assert(!g.classKits.tankWallCarried(p.id,g.combatTick));
  const restored=panels();
  for(const wall of restored){
    const old=initial.find(old=>old.id===wall.id);
    assert.equal(wall.halfSpan,old.halfSpan);
    assert.equal(wall.aim,old.aim);
    assert.equal(wall.health,old.health-(old.id===initial[0].id?17:0));
    assert.equal(wall.until,old.until);
    assert.equal(wall.maxHealth,old.maxHealth);
  }
  if(initial.length===2){
    assert(Math.abs((restored[1].x-restored[0].x)-(initial[1].x-initial[0].x))<1e-8);
    assert(Math.abs((restored[1].y-restored[0].y)-(initial[1].y-initial[0].y))<1e-8);
  }
  step({technique1:true});
  assert(g.classKits.tankWallCarried(p.id,g.combatTick));
  let survivingId;
  if(initial.length===2){
    survivingId=initial[1].id;
    g.classKits.hitConstruct(initial[0].id,initialHealth+1);
    step();
    assert(g.classKits.tankWallCarried(p.id,g.combatTick));
    assert.deepEqual(panels().map(w=>w.id),[survivingId]);
    assert.equal(panels()[0].health,initial[1].health);
  }
  while(g.combatTick<p.invulnerableUntil)step();
  g.damage(p,100_000);
  assert.equal(p.status,'downed');
  assert(!g.classKits.tankWallCarried(p.id,g.combatTick));
  assert.equal(panels().length,0);
  rows.push({moved:distance(start,{x:p.x,y:p.y}),healthPreserved:true,layoutRestored:true,immediateDeathCleanup:true,survivingId,talent:talent??'none',purchases,startingSp:p.totalSp,panels:initial.map(({id,source,aim,halfSpan,health,until})=>({id,source,aim,halfSpan,health,until})),
    actualCarryAdmitted:carried,position:{x:p.x,y:p.y},passed:carried});
}
assert.deepEqual(fingerprints(),before);
write(stage+'/tank-carry-transformations35.json',{measuredAt:new Date().toISOString(),bundleSha256:proof.bundleSha256,runtimeSourceSha256:before.runtimeSourceSha256,
  sourceSnapshotSha256:before.sourceSnapshotSha256,driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),passed:rows.filter(row=>row.passed).length,total:rows.length,rows,
  scope:'Controlled actual research purchases with each issued Tank transformation in a 27-SP Endless lobby. The original Q creates the geometry. No canonical registration or online claim.'});
console.log(JSON.stringify({passed:rows.filter(row=>row.passed).length,total:rows.length,rows:rows.map(({talent,actualCarryAdmitted,panels})=>({talent,actualCarryAdmitted,panels:panels.length}))}));
