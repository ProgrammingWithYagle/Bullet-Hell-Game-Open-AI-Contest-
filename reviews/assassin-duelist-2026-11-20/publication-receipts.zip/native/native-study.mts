import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL } = await repoImport('src/shared/protocol.ts');
const { duelistIds, calledOpeningRules: rules } = await repoImport('src/shared/assassin-called-opening.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect } = await repoImport('src/shared/geometry.ts');

const [transport, fitting, out, supplied, testAudience = 'public'] = process.argv.slice(2);
assert(PROTOCOL === 90 && ['worker','peer'].includes(transport) && ['entry','passing','counter'].includes(fitting) && out);
const setup = { mode:'short', difficulty:'baby', arenaSelection:'fixed', openingArenaId:'gatehouse' } as const;
const point = ({ x,y }) => ({ x,y });
const bearing = (from,to) => Math.atan2(to.y-from.y,to.x-from.x);
const heading = angle => Math.atan2(Math.sin(angle),Math.cos(angle));
const step = (p,angle,reach) => ({ x:p.x+Math.cos(angle)*reach,y:p.y+Math.sin(angle)*reach });
const closeHealth = (view,id) => view?.players.find(player => player.id === id);
const spending = p => p.skills.reduce((sum,id) => sum+[...data.specializationSkills,...data.skills].find(row => row.id === id).cost,0);

async function wait(truth, detail, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(8);
  }
}
function pilotState() {
  return { events: [], observed: new Map(), cues: new Map() };
}
function recordCues(cues,view){
  for(const cue of view.classCues){
    if(cue.kind!=='assassin-duel-focus'&&cue.kind!=='assassin-duel-strike')continue;
    const previous=cues.get(cue.id)??{};
    if(cue.kind==='assassin-duel-strike')previous.cut=cue;
    else{
      previous.focus??=cue;
      if(cue.opened)previous.open=cue;
      if(cue.countering)previous.counter=cue;
    }
    cues.set(cue.id,previous);
  }
}
function sideStride(v,p,target,sign,span=24){
  const direction=bearing(p,target), world=bulwarkTrialWorld(v);
  for(const off of [Math.PI/2,1.26,1.82]){
    const angle=direction+sign*off, end=step(p,angle,span);
    if(distance(end,target)>=rules.maximumReach-8||!clearTrialWalk(world,p,end))continue;
    if(world.obstacles.some(rect=>segmentRect(end,target,rect,rules.pad)))continue;
    return {moveX:Math.cos(angle),moveY:Math.sin(angle),aim:heading(direction)};
  }
}
function candidate(v,p){
  const world=bulwarkTrialWorld(v);
  const actors=[...v.minions.filter(row=>row.health>0),v.boss];
  for(const target of actors.sort((a,b)=>distance(a,p)-distance(b,p))){
    const gap=distance(target,p);
    if(gap<rules.minimumPickRange+5||gap>rules.maximumPickRange-6||
       world.obstacles.some(rect=>segmentRect(p,target,rect,rules.pad)))continue;
    for(const sign of [1,-1]){
      if(sideStride(v,p,target,sign,70))return {target,sign};
    }
  }
}
async function duelOperation(adapter,view,owner,status,submit,next){
  const now=()=>view().combatTick;
  const cue=()=>view().classCues.find(row=>row.kind==='assassin-duel-focus'&&row.owner===adapter.id);
  const notes=(key,at)=>adapter.events.slice(at).filter(e=>e.type==='sound'&&e.owner===adapter.id&&e.id==='assassin-duel-'+key);
  const observations=[];
  const limit=Date.now()+100_000;
  while(true){
    const v=view(),p=owner();
    assert(Date.now()<limit&&v.phase==='combat'&&p.status==='active',
      JSON.stringify({fitting,transport,phase:v.phase,body:point(p),tick:now(),e:p.eAt,observations}));
    if(p.eAt>now()||(status()?.until??0)>now()||now()<next.start+22){
      adapter.input({aim:heading(bearing(p,v.boss))});
      await sleep(27);
      continue;
    }
    const choice=candidate(v,p);
    if(!choice){
      const towards=bearing(p,v.boss),dir=distance(p,v.boss)<rules.minimumPickRange?towards+Math.PI:towards;
      const world=bulwarkTrialWorld(v);
      const angle=[dir,dir+.65,dir-.65,dir+1.56,dir-1.56].find(a=>clearTrialWalk(world,p,step(p,a,22)));
      adapter.input(angle===undefined?{}:{moveX:Math.cos(angle),moveY:Math.sin(angle),aim:heading(towards)});
      await sleep(27);
      continue;
    }
    await submit({aim:heading(bearing(owner(),choice.target))});
    const start=adapter.events.length, original=owner().eAt, origin=point(owner());
    await submit({technique1:true,aim:heading(bearing(owner(),choice.target))});
    const marked=cue();
    if(!marked||status()?.phase!=='measuring')continue;
    assert.equal(owner().eAt,original);
    assert.equal(marked.until-marked.at,rules.prepare);
    for(let i=0;i<30&&cue()&&status()?.phase==='measuring'&&now()+6<marked.until;i++){
      const stride=sideStride(view(),owner(),cue(),choice.sign);
      if(!stride)break;
      await submit(stride);
    }
    if(!cue()||status()?.phase!=='open'){
      observations.push({problem:'The target moved or its lane closed before the opening',mark:marked,phase:status()?.phase,at:now()});
      await submit({});
      await wait(()=>!cue(),'Unpaid focus closes',2_700);
      continue;
    }
    const opened=cue(), openedPosition=point(owner());
    assert.equal(owner().eAt,original);
    let counter, cut;
    if(fitting==='counter'){
      const stride=sideStride(view(),owner(),cue(),-choice.sign);
      if(!stride||!status()?.canCounter){await submit({});await wait(()=>!cue(),'The earlier focus closes',2_700);continue;}
      await submit({...stride,technique1:true});
      if(!cue()?.countering){await submit({});await wait(()=>!cue(),'The unturned focus closes',2_700);continue;}
      counter=cue();
      for(let i=0;i<25&&cue()&&status()?.phase==='reposition'&&now()+4<marked.until;i++){
        const frame=sideStride(view(),owner(),cue(),-choice.sign);
        if(!frame)break;
        await submit(frame);
      }
      if(!cue()||status()?.phase!=='open'){
        observations.push({problem:'The return lane closed during Counterturn',mark:marked,at:now()});
        await submit({});
        await wait(()=>!cue(),'The measured return closes',2_700);
        continue;
      }
      assert.equal(cue().until,marked.until);
      assert(distance(owner(),openedPosition)>18);
    }
    if(fitting==='passing'){
      const stride=sideStride(view(),owner(),cue(),choice.sign);
      if(!stride||!status()?.canPass){await submit({});await wait(()=>!cue(),'The earlier opening closes',2_700);continue;}
      await submit({...stride,technique1:true});
    }else await submit({technique1:true,aim:heading(bearing(owner(),cue()))});
    await sleep(65);
    cut=adapter.cues.get(marked.id)?.cut;
    if(!cut?.landed){
      observations.push({problem:'The last cut was guarded or the target left the lane',mark:marked,cut,at:now()});
      await submit({});
      await wait(()=>!cue(),'The prior opening closes',2_700);
      continue;
    }
    const paid=owner().eAt;
    assert(paid>original&&cut.at<marked.until);
    assert.equal(cut.owner,adapter.id);
    if(fitting==='passing')assert(cut.passing&&notes('pass',start).length===1);
    if(fitting==='counter')assert(cut.turned&&counter.until===marked.until&&notes('turn',start).length===1);
    await wait(()=>notes('hit',start).length===1&&notes('open',start).length>=1,'The strike and opening cues are private',1_700);
    assert.equal(notes('focus',start).length,1);
    return {mark:marked,opened,cut,counter,origin,openedPosition,paid,original,observations,
      ownerActionSounds:notes('focus',start).length+notes('open',start).length+notes('hit',start).length};
  }
}

async function earnedFlow(adapter) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const p = closeHealth(view(),adapter.id); assert(p); return p; };
  const status = () => owner().kit.calledOpening;
  const purchased = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind:'skill',item });
    assert(result.ok,JSON.stringify({ item,result }));
    purchased.push({ item,earned:owner().sp+spending(owner()),clears:owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(row => row.classId === 'assassin').sort((a,b) => b.tier-a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind:'weapon',item:weapon.id })).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({ kind:'upgrade',item });
  }
  async function submit(input) {
    const sequence = adapter.input(input);
    await wait(() => owner().ack >= sequence,'Ordinary control is acknowledged');
  }

  const isFitted = fitting !== 'entry';
  assert.equal(owner().sp,3);
  await buy('assassin-precision-1');
  await buy(duelistIds.entry);
  if (isFitted) assert(!(await adapter.purchase({ kind:'skill',item:duelistIds[fitting] })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat','The ordinary opening encounter begins');
  if (isFitted) {
    const shopLimit = Date.now()+135_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase),'Reach the first shop after an ordinary clear');
      if (view().phase === 'combat') {
        adapter.input({...restRaidInput(view(),owner(),[...adapter.observed.values()]),q:false,e:false,ultimate:false});
        adapter.allyPressure?.();
      } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(owner().sp+spending(owner()),9);
    await buy(duelistIds[fitting]);
    const other = fitting === 'passing' ? duelistIds.counter : duelistIds.passing;
    assert.equal((await adapter.purchase({ kind:'skill',item:other })).reason,'incompatibleItem');
    await equip();
    await wait(() => view().phase === 'combat','The second ordinary encounter begins',95_000);
  }
  const next = { boss:view().boss.id,arena:view().arenaId,start:view().combatTick };
  const firstClear = owner().progress.clears;

  adapter.pause(true);
  await wait(() => adapter.paused(),'The authority acknowledges pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ technique1:true });
  await sleep(90);
  assert.equal(view().combatTick,pausedAt);
  assert(owner().ack < ignored && status()?.phase === 'idle',
    JSON.stringify({ fitting,transport,pausedAt,ack:owner().ack,ignored,privateStatus:status() }));
  adapter.pause(false);
  await wait(() => !adapter.paused(),'The authority acknowledges resume');
  await adapter.stopAlly?.();

  const operation=await duelOperation(adapter,view,owner,status,submit,next);
  const witnessed=await adapter.peerWitness?.(operation);
  return {passed:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,transport,fitting,bought:purchased,firstClear,next,
    result:operation,witnessed,pausedCommandsDiscarded:true,noCheckpointImports:true};
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Nyx', classId: 'assassin' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'duel-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), assassin = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], assassin: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  assassin.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, assassin.id)?.kit.calledOpening !== undefined) leaks++;
  };
  assassin.onEvents = batch => remember(state.events, state.observed, batch, assassin.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  assassin.onPurchase = entry => replies.assassin.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await assassin.connect({ ...setup, name: 'Nyx', classId: 'assassin', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => assassin.view?.players.length === 2 && host.view?.players.length === 2, 'The Assassin joins as the second player');
    assert.equal(assassin.view.owner, host.id);
    assert.notEqual(assassin.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: assassin.id, view: () => assassin.view,
      input: props => { assassin.input(inputFrame(assassin.view, ++sequence, props)); return sequence; },
      purchase: request => reply(assassin, replies.assassin, request), start: () => host.start(),
      vote: i => { host.vote(i); assassin.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => assassin.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'The host stops on the ordinary map');
      },
      peerWitness: async operation => {
        const id=operation.mark.id;
        await wait(()=>!!peers.cues.get(id)?.cut,'The host sees the exact single-target strike');
        const sharedPhysical=peers.cues.get(id);
        assert.deepEqual(sharedPhysical.cut,operation.cut);
        assert(sharedPhysical.focus?.id===operation.mark.id);
        if(fitting==='counter')assert(sharedPhysical.counter?.countering);
        assert.equal(leaks,0);
        assert(!peers.events.some(e=>e.type==='sound'&&e.owner===assassin.id&&e.id.startsWith('assassin-duel-')));
        return {nonHost:true,sharedPhysical,ownedStatePrivate:true,ownedSoundsPrivate:true};
      },
    });
    host.endMatch();
    await wait(() => [host, assassin].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    assassin.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, driverSha256: sha256(readFileSync(new URL(import.meta.url))), testedAudience: testAudience });
console.log(JSON.stringify({ passed:true,transport,fitting,encounter:result.next.boss,firstClear:result.firstClear,paid:result.result.paid,passing:!!result.result.cut.passing,countered:!!result.result.cut.turned }));
