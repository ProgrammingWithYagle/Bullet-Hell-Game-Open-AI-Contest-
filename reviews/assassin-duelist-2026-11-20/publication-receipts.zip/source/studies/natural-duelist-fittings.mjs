import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson,receipt,verifiedBundle } from '../bastion/study-paths.mjs';

const [destination,cohort,bundle='game02',mode='short',sample] = process.argv.slice(2);
assert(destination && ['solo','party'].includes(cohort) && ['short','standard'].includes(mode)&&/^game[0-9]{2}$/.test(bundle));
const here = file => new URL('./'+file,import.meta.url);
const verified = readJson(here(bundle+'.json'));
const { Game,data,viewOf,HZ,idleInput,CONTENT_REVISION,calledOpeningId,duelistIds,calledOpeningRules:rules,distance,
  segmentRect,segmentCircle,restRaidInput,clearTrialWalk } = await verifiedBundle(fileURLToPath(here(bundle+'.mjs')),verified.bundle);
const scenarios = [['gatehouse','baby',41],['sunken-chapel','normal',73],['ossuary-works','normal',109],['crown-crypt','baby',61]];
const policies = ['banked','unused','opening','passing','counter'];
const point = ({x,y}) => ({x,y});
const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const forward = (p,a,d) => ({ x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d });
const around = angle => Math.atan2(Math.sin(angle),Math.cos(angle));

function run(arena,difficulty,seed,policy) {
  const game = new Game({ mode,difficulty,seed,arenaSelection:'route',openingArenaId:arena,maxPlayers:cohort==='solo'?1:2 });
  const duelist = game.addPlayer('solo','Nyx','assassin');
  const ally = cohort==='party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [duelist,ally] : [duelist];
  const shots = new Map(), events = [], fights = [];
  const trace = createHash('sha256');
  const purchases=[];
  let serial=0, steps=0, lastShop=-1, lastEncounter=-1, plan, spentClock, reserveUntil, fitting;
  const buy = (actor,kind,item) => game.transact(actor.id,{ kind,item,id:'duel-study-'+(++serial) });
  assert.equal(duelist.totalSp,3);
  assert(buy(duelist,'skill','assassin-precision-1').ok);
  if(policy!=='banked') assert(buy(duelist,'skill',calledOpeningId).ok);
  function equipment(p) {
    for(const weapon of data.weapons.filter(w=>w.classId===p.classId).sort((a,b)=>b.tier-a.tier))
      if(p.weapon===weapon.id || buy(p,'weapon',weapon.id).ok)break;
    for(const item of ['damage','health','fire-rate','reload','magazine']) buy(p,'upgrade',item);
    buy(p,'supply','medkit');
  }
  for(const p of actors) equipment(p);
  assert(game.start());

  function danger(view,p,horizon) {
    if(view.minions.some(actor=>actor.health>0 && distance(actor,p)<28+Math.min(28,horizon*2.8)))return true;
    if(view.fields.some(field=>field.kind==='zone' && distance(field,p)<field.radius+12))return true;
    for(const shot of shots.values()) {
      const lifetime=Math.min(horizon,shot.expires-view.combatTick);
      if(lifetime<=0 || distance(shot,p)>500)continue;
      const elapsed=(view.combatTick-shot.seenAt)/HZ;
      const origin={ x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed };
      const end={ x:origin.x+shot.vx*lifetime/HZ,y:origin.y+shot.vy*lifetime/HZ };
      const entry=segmentCircle(origin,end,p,shot.radius+data.rules.playerRadius+2);
      if(entry!==null && !game.obstacles.some(wall=>(segmentRect(origin,end,wall,shot.radius)?.t??Infinity)<=entry))return true;
    }
    return false;
  }
  const visible=(a,b,r=1)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,r));
  function movement(view,p,aim) {
    const target=forward(p,aim,23), world={ ...game.arena,obstacles:game.obstacles,tick:view.combatTick };
    return clearTrialWalk(world,p,target) && !danger(view,target,5) ? { moveX:Math.cos(aim),moveY:Math.sin(aim) } : undefined;
  }
  const navigation = new Map();
  const navigationPlans = [];
  const radius = data.rules.playerRadius;
  const aimVector = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  function firingLane(player, target, input) {
    const boss = point(target);
    const walls = game.obstacles;
    const occluded = (from) => walls.some(wall => segmentRect(from, boss, wall, 4));
    if (!occluded(player)) {
      navigation.delete(player.id);
      return;
    }
    if (player.health < player.maxHealth * .28 || danger(viewOf(game, player.id), player, 10)) return;
    const now = game.combatTick;
    const world = { ...game.arena, obstacles: walls, tick: now, playerRadius: radius };
    const clear = (a, b) => clearTrialWalk(world, a, b);
    let chase = navigation.get(player.id);
    if (!chase || chase.encounter !== game.encounter || now >= chase.at + 55 || chase.target !== target.id) {
      const margin = radius + 14;
      const bends = walls.flatMap(wall => [
        { x: wall.x - margin, y: wall.y - margin }, { x: wall.x + wall.width + margin, y: wall.y - margin },
        { x: wall.x - margin, y: wall.y + wall.height + margin }, { x: wall.x + wall.width + margin, y: wall.y + wall.height + margin },
      ]).filter(p => clear(p, p));
      const goals = [142, 200, 275, 360].flatMap(range => Array.from({ length: 20 }, (_, i) => {
        const aim = aimVector(i * Math.PI / 10);
        return { x: boss.x + aim.x * range, y: boss.y + aim.y * range };
      })).filter(p => clear(p, p) && !occluded(p));
      const points = [point(player), ...bends, ...goals];
      const cheapest = points.map((_, i) => i === 0 ? 0 : Infinity);
      const parent = points.map(() => -1), visited = new Set();
      let path = [];
      for (let pass = 0; pass < points.length; pass++) {
        let index = -1, shortest = Infinity;
        for (let i = 0; i < points.length; i++) if (!visited.has(i) && cheapest[i] < shortest) {
          index = i;
          shortest = cheapest[i];
        }
        if (index < 0) break;
        if (index > bends.length) {
          for (let start = index; start > 0; start = parent[start]) path.unshift(points[start]);
          break;
        }
        visited.add(index);
        for (let next = 1; next < points.length; next++) {
          const step = distance(points[index], points[next]);
          if (visited.has(next) || shortest + step >= cheapest[next] || !clear(points[index], points[next])) continue;
          cheapest[next] = shortest + step;
          parent[next] = index;
        }
      }
      chase = { at: now, encounter: game.encounter, path, target: target.id };
      navigation.set(player.id, chase);
      if (path.length) navigationPlans.push({ player: player.id, encounter: game.encounter, tick: now, from: point(player), route: [...path] });
    }
    while (chase.path.length && distance(player, chase.path[0]) < 2) chase.path.shift();
    const next = chase.path[0];
    if (!next || !clear(player, next)) return;
    const scale = Math.max(distance(player, next), game.movementSpeed(player) / HZ);
    return { ...input, moveX: (next.x - player.x) / scale, moveY: (next.y - player.y) / scale, dodge: false };
  }


  function ordinary(view,p,current) {
    const targets=view.bossCues.filter(c=>c.health>0 && ['service-prop','stitch-pin','raid-prop','early-prop'].includes(c.kind) &&
      distance(p,c)<530 && visible(p,c,2)).sort((a,b)=>distance(p,a)-distance(p,b));
    const immediate=view.minions.filter(c=>c.health>0 && distance(p,c)<82 && visible(p,c,2));
    const target=immediate.sort((a,b)=>distance(p,a)-distance(p,b))[0]??targets[0]??view.boss;
    const aim=bearing(p,target);
    if(immediate.length) {
      const retreat=[aim+Math.PI,aim+1.6,aim-1.6].map(h=>movement(view,p,h)).find(Boolean);
      return { ...current,...retreat,aim,fire:true };
    }
    if(visible(p,target,2))
      return { ...current,aim,fire:current.fire || distance(p,target)<320 };
    if(current.dodge || danger(view,p,6))return current;
    return firingLane(p,target,{ ...current,aim }) ?? current;
  }

  function openingTarget(view,p){
    const boss={...view.boss,radius:data.bosses.find(row=>row.id===view.boss.id)?.radius??24,key:'boss'};
    const further=view.minions.filter(row=>row.health>0).map(row=>({...row,key:'actor-'+row.id}));
    return [boss,...further].filter(row=>distance(p,row)>=rules.minimumPickRange+3&&distance(p,row)<=rules.maximumPickRange-3&&
      visible(p,row,rules.pad)).sort((a,b)=>Number(b.key==='boss')-Number(a.key==='boss')||distance(p,a)-distance(p,b))[0];
  }
  function lateralMove(view,p,target,sign){
    const base=bearing(p,target), world={...game.arena,obstacles:game.obstacles,tick:view.combatTick};
    for(const offset of [Math.PI/2,1.24,1.80]){
      const angle=base+sign*offset, end=forward(p,angle,25);
      if(!clearTrialWalk(world,p,end)||!visible(end,target,rules.pad)||danger(view,end,6)||distance(end,target)>rules.maximumReach-10)continue;
      return {moveX:Math.cos(angle),moveY:Math.sin(angle)};
    }
  }
  function decide(view,p,base){
    if(policy==='banked'||policy==='unused')return base;
    const now=view.combatTick,state=p.kit.calledOpening,aim=bearing(p,view.boss);
    const target=view.classCues.find(row=>row.kind==='assassin-duel-focus'&&row.owner===duelist.id);
    const hands=!base.dodge&&duelist.reloadAt<=now&&duelist.dashUntil<=now&&p.health>=p.maxHealth*.36;
    if(target){
      const atTarget=bearing(p,target);
      if(!hands||danger(view,p,4))return base;
      if(state?.phase==='open'){
        const same=lateralMove(view,p,target,plan?.sign??1);
        const others=lateralMove(view,p,target,-(plan?.sign??1));
        if(fitting==='passing'&&state.canPass&&same)return {...same,technique1:true,aim:atTarget};
        if(fitting==='counter'&&state.canCounter&&others&&now+12<state.until){
          plan.turnSign=-plan.sign;
          return {...others,technique1:true,aim:atTarget};
        }
        return {technique1:true,aim:atTarget};
      }
      const sign=state?.phase==='reposition'?plan?.turnSign??1:plan?.sign??1;
      const stride=lateralMove(view,p,target,sign)??lateralMove(view,p,target,-sign);
      return stride?{...stride,fire:base.fire,aim:atTarget}:{...base,e:false};
    }
    if(!hands||duelist.eAt>now||(state?.until??0)>now||duelist.ultimateAt<=now&&p.health<p.maxHealth*.48)return base;
    if(spentClock!==duelist.eAt){spentClock=duelist.eAt;reserveUntil=now+85;}
    if(now>=reserveUntil)return base;
    const pending=openingTarget(view,p);
    const multiple=view.minions.filter(row=>row.health>0&&distance(row,p)<=185&&visible(p,row,2)&&
      Math.abs(around(bearing(p,row)-aim))<.43).length>1;
    if(multiple&&base.e)return base;
    if(pending&&!danger(view,p,8)){
      for(const sign of [1,-1]){
        if(lateralMove(view,p,pending,sign)){
          plan={sign,target:pending.key};
          return {technique1:true,aim:bearing(p,pending)};
        }
      }
    }
    const closer=distance(p,view.boss)>197&&distance(p,view.boss)<390&&visible(p,view.boss,2)&&!danger(view,p,6)
      ?movement(view,p,aim):undefined;
    return {...base,...closer,e:false};
  }
  while(!['victory','defeat'].includes(game.phase)&&steps++<90000) {
    if(game.phase!=='combat') {
      shots.clear();
      if(['mutationVote','contractVote','secretOffer'].includes(game.phase))for(const p of actors)game.vote(p.id,0);
      if(game.phase==='shop' && game.encounter!==lastShop) {
        lastShop=game.encounter;
        for(const p of actors)equipment(p);
        if(!fitting&&(policy==='passing'||policy==='counter')){
          fitting=policy;
          assert.equal(duelist.totalSp,mode==='short'?9:5);
          assert(buy(duelist,'skill',duelistIds[fitting]).ok);
          const other=fitting==='passing'?'counter':'passing';
          assert.equal(buy(duelist,'skill',duelistIds[other]).reason,'incompatibleItem');
          purchases.push({id:duelistIds[fitting],earned:duelist.totalSp,tick:game.combatTick});
        }
      }
      game.step();game.drainEvents();
      continue;
    }
    if(game.encounter!==lastEncounter) {
      lastEncounter=game.encounter;
      fights.push({ boss:game.boss.id,arena:game.arena.id,earned:duelist.totalSp,tick:game.combatTick });
    }
    const view=viewOf(game,duelist.id), before={ eAt:duelist.eAt,pos:point(duelist),health:duelist.health };
    let ownFrame;
    for(const actor of actors) {
      const p=view.players.find(row=>row.id===actor.id);
      const base=actor.status==='active' ? ordinary(view,p,restRaidInput(view,p,[...shots.values()])) :
        actor.status==='downed'?{ interact:true }:{};
      const input=actor===duelist && actor.status==='active'?decide(view,p,base):base;
      const frame={ ...idleInput(),...input,sequence:actor.ack+1,clientTick:game.combatTick };
      frame.aim=around(frame.aim);
      if(actor===duelist)ownFrame=frame;
      trace.update(JSON.stringify(frame));
      assert(game.submitInput(actor.id,frame),JSON.stringify(frame));
    }
    game.step();
    const batch=game.drainEvents();
    for(const event of batch) {
      if(event.type==='shots')for(const s of event.shots)if(s.owner==='hostile')shots.set(s.id,{ ...s,seenAt:game.combatTick });
      if(event.type==='remove')for(const id of event.ids)shots.delete(id);
      if(event.type!=='sound'||event.owner!==duelist.id||!event.id.startsWith('assassin-duel-'))continue;
      const action=event.id.slice('assassin-duel-'.length);
      if(action==='focus'||action==='open'||action==='turn')assert(duelist.eAt===before.eAt);
      if(action==='hit'||action==='guard'||action==='pass')assert(duelist.eAt>before.eAt);
      const cut=['hit','guard','pass'].includes(action);
      const cue=game.classCues().find(row=>row.owner===duelist.id&&row.kind===(cut?'assassin-duel-strike':'assassin-duel-focus'));
      if(cut){
        const passing=batch.some(row=>row.type==='sound'&&row.owner===duelist.id&&row.id==='assassin-duel-pass');
        assert(ownFrame.technique1,JSON.stringify({action,boss:game.boss.id,phase:game.phase,ownFrame}));
        if(!passing)assert(Math.hypot(ownFrame.moveX,ownFrame.moveY)<.001);
        if(cue?.at===game.combatTick){
          assert(!!cue.passing===passing);
          if(!passing)assert(distance(cue,before.pos)<.01,JSON.stringify({action,boss:game.boss.id,cue,before,ownFrame}));
        }
      }
      events.push({action,boss:game.boss.id,at:game.combatTick,eAt:duelist.eAt,before,current:point(duelist),cue,plan});
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(a=>[a.x,a.y,a.health,a.ammo,a.qAt,a.eAt,a.damageDealt,a.damageTaken])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  return { arena,difficulty,seed,policy,won:game.phase==='victory',clears:duelist.progress.clears,events,purchases,fights,navigationPlans,trace:trace.digest('hex') };
}
const chosen=sample?.split('/');
if(chosen)assert(chosen.length===2&&scenarios.some(row=>row[0]===chosen[0])&&policies.includes(chosen[1]));
const rows=[], controls=[];
for(const args of scenarios) {
  if(chosen&&args[0]!==chosen[0])continue;
  const sampled=(chosen?[chosen[1]]:policies).map(policy=>run(...args,policy));
  if(!chosen){
    assert.equal(sampled[0].trace,sampled[1].trace,args[0]);
    controls.push({arena:args[0],sameTrace:true});
  }
  rows.push(...sampled);
  for(const row of sampled)console.log(JSON.stringify({ arena:row.arena,policy:row.policy,won:row.won,clears:row.clears,
    marks:row.events.filter(e=>e.action==='focus').length,openings:row.events.filter(e=>e.action==='open').length,
    missed:row.events.filter(e=>e.action==='lost').length,contacts:row.events.filter(e=>e.action==='hit').length,
    guarded:row.events.filter(e=>e.action==='guard').length,
    fitted:row.events.filter(e=>e.action==='pass'||e.action==='turn').map(e=>e.action) }));
}
receipt(destination,{stageOnly:true,visiblePathNavigation:true,duelistFootworkStudy:true,contentRevision:CONTENT_REVISION,
  bundleSha256:verified.bundle,mode,cohort,rows,controls});
