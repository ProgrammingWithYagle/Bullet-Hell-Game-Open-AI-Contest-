import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL, idleInput, HZ } = await repoImport('src/shared/protocol.ts');
const { fieldSurgeryIds } = await repoImport('src/shared/medic-field-surgery.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect } = await repoImport('src/shared/geometry.ts');
const args = process.argv.slice(2);
const [transport, fitting, out, supplied, testAudience = 'public'] = args;
assert(PROTOCOL === 84 && ['worker', 'peer'].includes(transport) && ['tie', 'wrap'].includes(fitting) && out);
const setup = { mode: 'short', difficulty: 'baby', arenaSelection: 'fixed', openingArenaId: 'gatehouse' } as const;
const spending = p => p.skills.reduce((sum, id) => sum + [...data.specializationSkills, ...data.skills].find(node => node.id === id).cost, 0);
const point = p => ({ x: p.x, y: p.y });
const angle = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
const closeHealth = (view, id) => view?.players.find(player => player.id === id);

async function wait(truth, why, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, why);
    await sleep(8);
  }
}
function pilotState() {
  const events = [], observed = new Map(), cues = new Map();
  return { events, observed, cues };
}
function recordCues(cues, view) {
  for (const cue of view.classCues) if (cue.kind === 'medic-dressing' || cue.kind === 'medic-dressing-knot') cues.set(cue.id, cue);
}
function heading(view, from, goal, reach = 0) {
  if (distance(from, goal) <= reach) return {};
  const world = bulwarkTrialWorld(view), toward = angle(from, goal);
  const options = [0, 30, -30, 60, -60, 90, -90, 120, -120].map(value => toward + value * Math.PI / 180)
    .map(aim => {
      const x = Math.cos(aim), y = Math.sin(aim);
      const end = { x: from.x + x * 28, y: from.y + y * 28 };
      return { x, y, end, score: distance(end, goal) };
    }).filter(v => clearTrialWalk(world, from, v.end)).sort((a, b) => a.score - b.score);
  const best = options[0];
  return best ? { moveX: best.x, moveY: best.y } : {};
}

function ordinaryWoundDirection(view, patient, reach, observed) {
  const world = bulwarkTrialWorld(view);
  const opportunities = view.bossCues.filter(cue => cue.kind === 'stitch-seam' && !cue.disabled && cue.until > view.combatTick + 4)
    .flatMap(cue => {
      const dx = cue.x2 - cue.x1, dy = cue.y2 - cue.y1;
      const projection = Math.max(.08, Math.min(.92,
        ((patient.x - cue.x1) * dx + (patient.y - cue.y1) * dy) / (dx * dx + dy * dy)));
      if (!Number.isFinite(projection)) return [];
      return [projection, .25, .5, .75].map(u => ({ x: cue.x1 + dx * u, y: cue.y1 + dy * u }));
    }).filter(goal => clearTrialWalk(world, patient, goal)).sort((a, b) => distance(patient, a) - distance(patient, b));
  if (opportunities[0]) return heading(view, patient, opportunities[0], 4);
  for (const offset of [3, 6, 10, 14]) {
    const path = [...observed.values()].filter(shot => shot.owner === 'hostile' && shot.expires > view.combatTick + offset)
      .map(shot => {
        const seconds = (view.combatTick - shot.seenAt + offset) / HZ;
        return { x: shot.x + shot.vx * seconds, y: shot.y + shot.vy * seconds };
      }).filter(point => distance(patient, point) <= 8 + 4.5 * offset && clearTrialWalk(world, patient, point))
      .sort((a, b) => distance(patient, a) - distance(patient, b));
    if (path[0]) return heading(view, patient, path[0], 3);
  }
  return heading(view, patient, view.boss, reach);
}

async function earnedFlow(adapter) {
  const view = () => {
    const v = adapter.view();
    assert(v);
    return v;
  };
  const owner = () => {
    const p = closeHealth(view(), adapter.id);
    assert(p);
    return p;
  };
  const patient = () => {
    const p = closeHealth(view(), adapter.patientId ?? adapter.id);
    assert(p);
    return p;
  };
  const order = async (input, description) => {
    const seq = adapter.input(input);
    await wait(() => owner().ack >= seq, description);
    return seq;
  };
  const sounds = (kind, from = 0) => adapter.events.slice(from)
    .filter(e => e.type === 'sound' && e.id === 'medic-dressing-' + kind && e.owner === adapter.id);
  const fit = fieldSurgeryIds[fitting];
  const parent = fitting === 'tie' ? fieldSurgeryIds.step : fieldSurgeryIds.aside;
  const bought = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind: 'skill', item });
    assert(result.ok, JSON.stringify({ item, result }));
    bought.push({ item, earned: owner().sp + spending(owner()), clears: owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(w => w.classId === 'medic').sort((a, b) => b.tier - a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind: 'weapon', item: weapon.id })).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine'])
      await adapter.purchase({ kind: 'upgrade', item });
  }
  assert.equal(owner().sp, 3);
  await buy('medic-triage-1');
  await buy(fieldSurgeryIds.entry);
  if (fit) assert(!(await adapter.purchase({ kind: 'skill', item: fit })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat', 'Ordinary opening combat begins');

  for (const clears of [1, 2]) {
    const end = Date.now() + 125_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < end && !['victory', 'defeat'].includes(view().phase),
        'Earn the ordinary fitting shop after clear ' + clears);
      if (view().phase === 'combat') {
        const p = owner();
        const i = restRaidInput(view(), p, [...adapter.observed.values()]);
        adapter.input({ ...i, q: p.health < p.maxHealth - 20 && !!i.q, e: p.health < p.maxHealth - 17 && !!i.e });
        adapter.allyPressure?.();
      } else if (['mutationVote', 'contractVote', 'secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(25);
    }
    assert.equal(owner().progress.clears, clears);
    assert.equal(owner().sp + spending(owner()), clears === 1 ? 9 : 15);
    if (clears === 1) {
      await buy(parent);
      assert(!(await adapter.purchase({ kind: 'skill', item: fit })).ok);
    } else {
      await buy(fit);
      const other = fitting === 'tie' ? fieldSurgeryIds.wrap : fieldSurgeryIds.tie;
      assert(!(await adapter.purchase({ kind: 'skill', item: other })).ok);
    }
    await equip();
    await wait(() => view().phase === 'combat', 'Ordinary deployment after shop ' + clears, 90_000);
  }

  const opening = { boss: view().boss.id, tick: view().combatTick };
  const huntEnd = Date.now() + 45_000;
  const missing = () => patient().maxHealth - patient().health;
  // Baby raises the actual first dose above 17 HP. Keep enough missing health for a second positive dose.
  const wanted = 26;
  function reachable() {
    const p = owner(), t = patient();
    const world = bulwarkTrialWorld(view());
    return t.id === p.id || distance(p, t) <= 82 &&
      !world.obstacles.some(wall => segmentRect(p, t, wall, 2));
  }
  while (missing() < wanted || !reachable()) {
    assert(Date.now() < huntEnd && view().phase === 'combat' && ['active'].includes(patient().status),
      JSON.stringify({ reason: 'Ordinary hostile damage and a reachable patient', patient: patient().health, missing: missing(),
        owner: owner().health, distance: distance(owner(), patient()), boss: view().boss.id, reach: reachable() }));
    const p = owner(), t = patient(), boss = view().boss;
    if (t.id === p.id) {
      const direction = missing() < wanted ? ordinaryWoundDirection(view(), p, 75, adapter.observed) : {};
      adapter.input({ ...direction, aim: angle(p, boss) });
    } else {
      adapter.allyHunt?.(missing() < wanted ? ordinaryWoundDirection(view(), t, 75, adapter.allyObserved ?? adapter.observed) : {});
      adapter.input({ ...heading(view(), p, t, 57), aim: angle(p, t) });
    }
    await sleep(32);
  }
  // Retreat to a separate treatment position after the ordinary hostile hit.
  // Both bodies walk through the visible arena and then independently acknowledge a stop.
  const quietEnd = Date.now() + 4_000;
  while (Date.now() < quietEnd && distance(owner(), view().boss) < 230 && patient().health > 15) {
    const p = owner(), t = patient(), reset = bulwarkTrialWorld(view()).playerSpawn;
    if (t.id !== p.id) adapter.allyHunt?.(heading(view(), t, reset, 65));
    adapter.input({ ...heading(view(), p, t.id === p.id ? reset : t, 57), aim: angle(p, t.id === p.id ? view().boss : t) });
    await sleep(29);
  }
  await adapter.stopAlly?.();
  const getAim = () => patient().id === owner().id ? angle(owner(), view().boss) : angle(owner(), patient());
  let before, historical, preparationAttempts = 0;
  const settleEnd = Date.now() + 16_000;
  while (owner().kit.fieldDressing?.phase !== 'preparing') {
    const p = owner(), t = patient();
    assert(Date.now() < settleEnd && view().phase === 'combat',
      JSON.stringify({ reason: 'Stationary aimed Medic has a reachable patient', owner: point(p), patient: point(t),
        health: t.health, qAt: p.qAt, next: p.kit.fieldDressing, time: view().combatTick, preparationAttempts }));
    const approach = reachable() ? {} : heading(view(), p, t, 55);
    await order({ ...approach, aim: getAim() }, 'Medic aims and settles');
    const position = point(owner()), settledAt = view().combatTick;
    await wait(() => view().combatTick >= settledAt + 3, 'Observe stable ground');
    if (distance(position, owner()) > .2 || !owner().kit.fieldDressing?.ready ||
        owner().kit.fieldDressing?.patient !== t.id) continue;
    before = { health: patient().health, tick: view().combatTick, qAt: owner().qAt, x: owner().x, y: owner().y };
    historical = adapter.events.length;
    preparationAttempts++;
    await order({ technique1: true, aim: getAim() }, 'Dressing command acknowledged');
    await wait(() => owner().kit.fieldDressing?.phase === 'preparing' || sounds('stop', historical).length > 0 ||
      view().combatTick > before.tick + 5, 'Observe prepared or interrupted dressing');
  }
  await wait(() => sounds('prepare', historical).length === 1, 'Owner receives the private preparation sound');
  assert.equal(owner().kit.fieldDressing.patient, patient().id);
  assert.equal(owner().qAt, before.qAt);

  adapter.pause(true);
  await wait(() => adapter.paused(), 'Actual local or host pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ moveX: 1 });
  await sleep(65);
  assert.equal(view().combatTick, pausedAt);
  assert(owner().ack < ignored);
  assert.equal(owner().kit.fieldDressing.phase, 'preparing');
  adapter.pause(false);
  await wait(() => !adapter.paused(), 'Actual pause release');
  let manoeuvre;
  if (fitting === 'wrap') {
    await wait(() => owner().kit.fieldDressing?.phase === 'preparing' && owner().kit.fieldDressing.canWrap,
      'Observe the actual halfway wrap prompt');
    await order({ technique1: true, aim: getAim() }, 'Wrap request is acknowledged');
    await wait(() => owner().kit.fieldDressing?.phase === 'wrapped', 'The same preparation is wrapped');
    const wrapped = owner().kit.fieldDressing;
    assert.equal(wrapped.patient, patient().id);
    assert.equal(owner().qAt, before.qAt);
    assert.equal(sounds('dose', historical).length, 0);
    const ammo = owner().ammo;
    await order({ fire: true, aim: angle(owner(), view().boss) }, 'Ordinary shot while preparation is wrapped');
    await wait(() => owner().ammo < ammo, 'The ordinary shot spends ammunition');
    await order({ technique1: true, aim: getAim() }, 'Unwrap request is acknowledged');
    await wait(() => sounds('resume', historical).length === 1 && owner().kit.fieldDressing?.phase === 'preparing',
      'The original patient resumes remaining preparation');
    const resumed = owner().kit.fieldDressing;
    assert.equal(resumed.patient, patient().id);
    assert.equal(owner().qAt, before.qAt);
    manoeuvre = { heldUntil: wrapped.nextAt, resumedStart: resumed.startedAt, resumedFinish: resumed.nextAt,
      expectedPatient: wrapped.patient, ammunitionSpent: ammo - owner().ammo };
  }
  try {
    await wait(() => sounds('dose', historical).length >= 1 && owner().qAt > view().combatTick,
      'The first actual dose spends Q');
  } catch (error) {
    console.error(JSON.stringify({ area: 'first dose', opening, before, now: view().combatTick,
      p: { ...point(owner()), health: owner().health, qAt: owner().qAt, field: owner().kit.fieldDressing },
      wound: missing(), sounds: adapter.events.slice(historical).filter(event =>
        event.type === 'sound' && event.id.startsWith('medic-dressing-')).map(event => event.id) }));
    throw error;
  }
  const qAt = owner().qAt;
  assert(patient().health > before.health);
  const firstObservation = { tick: view().combatTick, owner: point(owner()), patient: point(patient()),
    remainingWound: missing(), status: owner().kit.fieldDressing, privateDoses: sounds('dose', historical).length };
  let knot;
  if (fitting === 'tie') {
    assert.equal(firstObservation.status?.phase, 'applying', JSON.stringify(firstObservation));
    const start = point(owner()), world = bulwarkTrialWorld(view());
    const direction = Array.from({ length: 8 }, (_, i) => getAim() + i * Math.PI / 4).find(aim => {
      const end = { x: start.x + 24 * Math.cos(aim), y: start.y + 24 * Math.sin(aim) };
      return clearTrialWalk(world, start, end) && (owner().id === patient().id || distance(end, patient()) < 98);
    });
    assert(direction !== undefined, 'Real map has a legal short walking lane');
    const walking = { moveX: Math.cos(direction), moveY: Math.sin(direction) };
    adapter.input({ ...walking, aim: getAim() });
    await wait(() => owner().kit.fieldDressing?.canTie, 'The actual steady step earns the tie prompt');
    const plannedAt = owner().kit.fieldDressing.nextAt;
    const tying = adapter.input({ ...walking, technique1: true, aim: getAim() });
    // The private sound is sent as soon as the authoritative command admits the knot.
    await wait(() => sounds('tie', historical).length === 1, 'The paid knot is admitted');
    const ammo = owner().ammo;
    const shotBegin = adapter.events.length;
    const firing = adapter.input({ fire: true, aim: angle(owner(), view().boss) });
    const ownedRound = () => adapter.events.slice(shotBegin).flatMap(event => event.type === 'shots' ? event.shots : [])
      .find(shot => shot.owner === adapter.id);
    await wait(() => owner().ack >= firing && owner().ammo < ammo && ownedRound(), 'The live primary round spends actual ammunition');
    assert(owner().ack >= tying);
    const observedShotTick = view().combatTick;
    adapter.input({ aim: getAim() });
    const anchor = () => [...adapter.cues.values()].find(row => row.kind === 'medic-dressing-knot' && row.owner === adapter.id && row.at >= before.tick);
    await wait(() => anchor(), 'A shared snapshot carries the anchored dose');
    knot = anchor();
    assert(knot?.patient === patient().id && knot.until === plannedAt);
    await wait(() => sounds('dose', historical).length === 2, 'Only the next original dose settles');
    const pulse = () => [...adapter.cues.values()].find(row => row.kind === 'medic-dressing' && row.owner === adapter.id && row.at === plannedAt);
    await wait(() => pulse(), 'A shared snapshot carries the dose on its original tick');
    const kept = pulse();
    assert(kept?.patient === patient().id);
    const weapon = data.weapons.find(weapon => weapon.id === owner().weapon);
    assert(weapon);
    const shot = ownedRound(), shotTick = shot.expires - Math.ceil(weapon.rangeSeconds * HZ);
    assert(shotTick > knot.at && shotTick <= kept.at, JSON.stringify({ shotTick, observedShotTick, knot, kept }));
    manoeuvre = { walked: distance(start, owner()), knot, kept, shotTick, observedShotTick, ammunitionSpent: ammo - owner().ammo };
  }
  await wait(() => sounds('dose', historical).length >= 2, 'At least two actual doses observed');
  assert.equal(owner().qAt, qAt);
  const physical = [...adapter.cues.values()].filter(c => c.kind === 'medic-dressing' && c.owner === adapter.id && c.patient === patient().id && c.at >= before.tick);
  assert(physical.length > 0);
  const witnessed = await adapter.peerWitness?.(physical.map(cue => cue.id), knot?.id);
  return { passed: true, protocol: PROTOCOL, contentRevision: CONTENT_REVISION, transport, fitting, bought,
    patient: patient().id === adapter.id ? 'self' : 'actual-teammate', opening, before, recoveryAt: qAt, preparationAttempts,
    doses: sounds('dose', historical).length, physical, manoeuvre, witnessed, firstObservation, pausedCommandsDiscarded: true,
    noCheckpointImports: true };
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Iona', classId: 'medic' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'surgery-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), medic = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], medic: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  medic.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, medic.id)?.kit.fieldDressing !== undefined) leaks++;
  };
  medic.onEvents = batch => remember(state.events, state.observed, batch, medic.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  medic.onPurchase = entry => replies.medic.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await medic.connect({ ...setup, name: 'Iona', classId: 'medic', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => medic.view?.players.length === 2 && host.view?.players.length === 2, 'Actual non-host Medic lobby');
    assert.equal(medic.view.owner, host.id);
    assert.notEqual(medic.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: medic.id, patientId: host.id, view: () => medic.view,
      input: props => { medic.input(inputFrame(medic.view, ++sequence, props)); return sequence; },
      purchase: request => reply(medic, replies.medic, request), start: () => host.start(),
      vote: i => { host.vote(i); medic.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => medic.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      allyObserved: peers.observed, allyHunt: i => hostInput(i), stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'Patient stops on the ordinary map');
      },
      peerWitness: async (ids, anchor) => {
        await wait(() => ids.some(id => peers.cues.has(id)), 'Host sees the same physical admitted dose');
        if (anchor !== undefined) await wait(() => peers.cues.has(anchor), 'Host sees the actual tied marker');
        assert.equal(leaks, 0);
        assert(!peers.events.some(e => e.type === 'sound' && e.owner === medic.id && e.id.startsWith('medic-dressing-')));
        assert(!host.room.state.players.get(medic.id).lineworkOwner);
        return { nonHost: true, sharedCue: ids.find(id => peers.cues.has(id)), tiedMarker: anchor, ownedStatePrivate: true, ownedSoundsPrivate: true };
      },
    });
    host.endMatch();
    await wait(() => [host, medic].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    medic.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, testedAudience: testAudience });
console.log(JSON.stringify({ ...result, physical: result.physical.map(cue => cue.id) }));
