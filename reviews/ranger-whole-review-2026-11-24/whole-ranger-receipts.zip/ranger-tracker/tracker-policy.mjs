import { standing } from '../formation/formation-policy.mjs';

const distance=(a,b)=>Math.hypot(b.x-a.x,b.y-a.y);
const heading=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
const offset=(point,aim,length)=>({x:point.x+Math.cos(aim)*length,y:point.y+Math.sin(aim)*length});
const travel=(from,to)=>{
  const aim=heading(from,to);
  return {moveX:Math.cos(aim),moveY:Math.sin(aim)};
};

export function trackerPolicy({ordinary,arenaFor,segmentRect,segmentCircle,rules}) {
  const visible=(world,from,to,pad=4)=>!world.obstacles.some(wall=>segmentRect(from,to,wall,pad)!==null);
  function legal(world,from,to) {
    const {x,y,width,height}=world.bounds;
    return to.x>=x+20 && to.y>=y+20 && to.x<=x+width-20 && to.y<=y+height-20 &&
      visible(world,from,to,19) && !world.lavaPits.some(pit=>segmentCircle(from,to,pit,pit.radius+19)!==null);
  }
  return (view,p,shots,enabled)=>{
    const base=ordinary(view,p,shots);
    if (!enabled || base.dodge || (base.supply??-1)>=0) return base;
    const track=p.kit.rangerTracker;
    if (!track) return base;
    const boss=view.boss;
    const world=arenaFor(view.arenaId,view.run.difficulty);
    const aim=heading(p,boss), quiet={...standing(base),aim};
    if (track.stage==='ready' && p.ammo>=2 && p.reloadAt<=view.combatTick &&
      track.footprints.some(point=>distance(point,boss)<=75) && visible(world,p,boss)) {
      return {...quiet,technique2:true};
    }
    const {stage,origin,bearing}=track;
    if (!origin || bearing===undefined || p.ammo<1) return base;
    if (track.fitting==='stakes') {
      const range=distance(p,boss);
      if (range>=78 && range<=154 && visible(world,p,boss) && p.eAt<=view.combatTick) return {...quiet,e:true};
      if (p.eAt<=view.combatTick && range>154 && range<=300) {
        const goal=offset(boss,heading(boss,p),111);
        if (legal(world,p,goal)) return {...quiet,...travel(p,goal)};
      }
    }
    if (stage==='follow' && visible(world,p,boss)) return {...quiet,fire:true};
    const lateral=[bearing+Math.PI/2,bearing-Math.PI/2];
    if (stage==='leave') lateral.push(bearing,bearing+Math.PI);
    const radius=stage==='leave'?rules.leaveDistance+14:rules.lateralDistance+14;
    const goal=stage==='return' ? origin :
      lateral.map(angle=>offset(origin,angle,radius)).filter(point=>legal(world,p,point))
        .sort((a,b)=>distance(p,a)-distance(p,b))[0];
    return goal && legal(world,p,goal)?{...quiet,...travel(p,goal)}:{...quiet,moveX:base.moveX,moveY:base.moveY};
  };
}
