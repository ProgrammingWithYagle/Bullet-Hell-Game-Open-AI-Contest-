import assert from 'node:assert/strict';
import { repoImport, receipt } from '../bonded/study-paths.mjs';
import { situationalInput } from '../summoner-whole/situational-input.mjs';
import { wholeRangerPolicy } from './whole-policy.mjs';
import { navigationPolicy } from './navigation-policy.mjs';

const { Game, data }=await repoImport('src/shared/game.ts');
const { viewOf }=await repoImport('src/shared/view.ts');
const { idleInput }=await repoImport('src/shared/protocol.ts');
const { segmentRect, segmentCircle, moveBody }=await repoImport('src/shared/geometry.ts');
const { runtimeArena }=await repoImport('src/shared/arena-layouts.ts');
const { restRaidInput }=await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { rangerSightRules }=await repoImport('src/shared/ranger-sight.ts');
const { trackerRules }=await repoImport('src/shared/ranger-tracker.ts');
const output=process.argv[2];
assert(output);
const ordinary=situationalInput({restRaidInput,runtimeArena,segmentRect,segmentCircle,moveBody});
const ordinaryPolicy=wholeRangerPolicy({ordinary,arenaFor:runtimeArena,segmentRect,segmentCircle,sightRules:rangerSightRules,trackerRules});
const navigated=process.argv[3]==='navigation';
const policy=navigated?navigationPolicy({ordinary:ordinaryPolicy,arenaFor:runtimeArena,segmentRect,segmentCircle,
  playerRadius:data.rules.playerRadius}):ordinaryPolicy;
const game=new Game({mode:'long',difficulty:'baby',seed:103,openingArenaId:'ossuary-works',arenaSelection:'fixed',maxPlayers:1});
const ranger=game.addPlayer('solo','Nela Venn','ranger');
let serial=0;
const purchase=(kind,item)=>game.transact(ranger.id,{kind,item,id:'opening-' + ++serial}).ok;
assert(purchase('skill','ranger-bowcraft-1') && purchase('skill','ranger-sight-draw-1'));
for (const bow of data.weapons.filter(row=>row.classId==='ranger').sort((a,b)=>b.tier-a.tier)) {
  if (ranger.weapon===bow.id || purchase('weapon',bow.id)) break;
}
for (const item of ['damage','health','fire-rate','reload','magazine']) purchase('upgrade',item);
purchase('supply','medkit');
assert(game.start());
const samples=[],hostile=new Map();
const spawn={x:ranger.x,y:ranger.y};
let blockedTicks=0, ticks=0, farthest=0;
while(game.phase==='combat' && ticks++<14000) {
  const view=viewOf(game,ranger.id),player=view.players.find(row=>row.id===ranger.id)!;
  const boss=view.boss,control=policy(view,player,[...hostile.values()],true);
  const blocked=game.obstacles.some(wall=>segmentRect(player,boss,wall,3)!==null);
  if(blocked) blockedTicks++;
  farthest=Math.max(farthest,Math.hypot(player.x-spawn.x,player.y-spawn.y));
  if(ticks===1 || ticks%120===0) samples.push({tick:view.combatTick,x:player.x,y:player.y,hp:player.health,bossX:boss.x,bossY:boss.y,bossHealth:boss.health,
    blocked,ammo:player.ammo,moveX:control.moveX,moveY:control.moveY});
  const input={...idleInput(),...control,sequence:ranger.ack+1,clientTick:game.combatTick};
  input.aim=Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
  assert(game.submitInput(ranger.id,input));
  game.step();
  for(const event of game.drainEvents()) {
    if(event.type==='shots') for(const shot of event.shots) if(shot.owner==='hostile') hostile.set(shot.id,{...shot,seenAt:game.combatTick});
    if(event.type==='remove') for(const id of event.ids) hostile.delete(id);
  }
}
const summary={scratchOnly:true,navigated,arena:game.arena.id,phase:game.phase,clears:ranger.progress.clears,
  ticks,blockedTicks,farthest,final:{x:ranger.x,y:ranger.y,hp:ranger.health,bossHealth:game.boss.health,damage:ranger.damageDealt}};
receipt(output,{...summary,samples});
console.log(JSON.stringify(summary));
