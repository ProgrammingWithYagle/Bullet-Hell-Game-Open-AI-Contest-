import assert from 'node:assert/strict';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
type InputFrame = ReturnType<typeof idleInput>;
const { viewOf } = await repoImport('src/shared/view.ts');
const { rangerSightIds } = await repoImport('src/shared/ranger-sight.ts');
const { rangerTrackerIds } = await repoImport('src/shared/ranger-tracker.ts');
const { rangerFieldIds } = await repoImport('src/shared/ranger-field.ts');
const [output, edition] = process.argv.slice(2);
assert(output && ['source', 'pilot'].includes(edition));
const pilot = edition === 'pilot';
assert.equal(PROTOCOL, pilot ? 103 : 104);

function simulate(window: 'sight' | 'tracker' | 'field') {
  const game = new Game({ mode: 'endless', difficulty: 'normal', seed: 44, openingArenaId: 'gatehouse', arenaSelection: 'fixed', maxPlayers: 2 });
  game.encounter = 9;
  const ranger = game.addPlayer('nela', 'Nela', 'ranger');
  const partner = game.addPlayer('mara', 'Mara', 'ranger');
  const skills = new Map([...data.skills, ...data.specializationSkills].map(node => [node.id, node]));
  const linked = data.skills.find(node => node.classId === 'ranger' && node.transform === 'linked-stakes');
  assert(linked);
  for (const actor of [ranger, partner]) {
    function buy(id: string) {
      if (actor.skills.includes(id)) return;
      const skill = skills.get(id);
      assert(skill);
      if (skill.prerequisite) buy(skill.prerequisite);
      assert(game.transact(actor.id, { kind: 'skill', item: id, id: actor.id + '-' + id }).ok);
    }
    assert.equal(actor.totalSp, 27);
    for (const id of [rangerSightIds.roll, rangerTrackerIds.stakes, rangerFieldIds.short, linked.id]) buy(id);
    assert(actor.skills.reduce((total, id) => total + game.skillCost(id), 0) <= actor.totalSp);
  }
  assert(game.start());
  const arena = { ...game.arena, obstacles: [], lavaPits: [] };
  Object.defineProperty(game, 'arena', { get: () => arena });
  Object.assign(game.boss, { x: 1355, y: 764, health: 100000, maxHealth: 100000, staggerUntil: 9999, deadline: 12000 });
  Object.assign(ranger, { x: 490, y: 500, oldX: 490, oldY: 500 });
  Object.assign(partner, { x: 490, y: 700, oldX: 490, oldY: 700 });
  const statuses = () => [game.kitStatus(ranger.id), game.kitStatus(partner.id)];
  const trap = (id: string) => game.classCues().find(cue => cue.kind === 'ranger-trap' && cue.owner === id);
  const press = (first: Partial<InputFrame> = {}, second: Partial<InputFrame> = {}) => {
    for (const [actor, input] of [[ranger, first], [partner, second]] as const) {
      if (!actor.connected) continue;
      assert(game.submitInput(actor.id, { ...idleInput(), aim: 0, ...input, clientTick: game.combatTick, sequence: actor.ack + 1 }));
    }
    game.step();
    return game.drainEvents();
  };
  const wait = (ready: () => boolean, second: Partial<InputFrame> = {}) => {
    for (let i = 0; i < 85 && !ready(); i++) press({}, second);
    assert(ready());
  };

  press({ e: true }, { e: true });
  const ground = trap(partner.id);
  assert(ground?.kind === 'ranger-trap' && ground.remaining === 3);
  const rangerArrows = ranger.ammo;
  if (window === 'sight') press({ technique1: true });
  if (window === 'tracker') {
    const target = game.minions.spawn(98123, { kind: 'ordinary', x: 572, y: 500, health: 900, speed: 0, radius: 16, damage: 1 }, game.combatTick);
    assert(target);
    press({ fire: true });
    wait(() => target.health < 900);
    press({ technique2: true });
  }
  if (window === 'field') press({ technique3: true });
  press({}, { technique3: true });
  const [before, partnerBefore] = statuses();
  const key = { sight: 'rangerSight', tracker: 'rangerTracker', field: 'rangerField' } as const;
  assert(before[key[window]]!.until > game.combatTick);
  assert.equal(ranger.ammo, rangerArrows - 1);
  assert(partnerBefore.rangerField!.until > game.combatTick);
  const partnerArrows = partner.ammo;
  const witness = viewOf(game, partner.id).players.find(player => player.id === ranger.id);
  assert(witness && !witness.kit.rangerSight && !witness.kit.rangerTracker && !witness.kit.rangerField);

  game.setConnected(ranger.id, false);
  assert(!game.classCues().some(cue => cue.owner === ranger.id && cue.kind.startsWith('ranger-')));
  assert(![...game.shots.values()].some(shot => shot.owner === ranger.id));
  assert.deepEqual(statuses()[1].rangerField, partnerBefore.rangerField);
  game.setConnected(ranger.id, true);
  assert.equal(ranger.ammo, rangerArrows - 1);
  assert.equal(statuses()[0][key[window]]!.until, 0);

  wait(() => partner.y >= 760, { moveY: 1 });
  const tick = game.combatTick;
  press({}, { technique3: true });
  const moved = trap(partner.id);
  assert(moved?.kind === 'ranger-trap' && moved.id === ground.id && moved.until === ground.until && moved.remaining === 3);
  assert(moved.at > tick && moved.y > ground.y + 45);
  const target = game.minions.spawn(98124, { kind: 'ordinary', x: (moved.x + moved.x2) / 2, y: (moved.y + moved.y2) / 2, health: 900, speed: 0, radius: 16, damage: 1 }, game.combatTick);
  assert(target);
  wait(() => target.health < 900);
  assert.equal(trap(partner.id)?.remaining, 2);
  assert.equal(partner.ammo, partnerArrows);
  assert.equal(ranger.ammo, rangerArrows - 1);
  return { window, originalCable: ground, movedCable: moved, damage: 900 - target.health, partnerArrows, departingArrows: ranger.ammo, retainedCharges: 2 };
}

const cases = (['sight', 'tracker', 'field'] as const).map(simulate);
const bindings = Object.fromEntries(['game', 'view', 'ranger-kit', 'ranger-sight', 'ranger-tracker', 'ranger-field'].map(id => {
  const path = `src/shared/${id}.ts`;
  return [path, pilot ? null : sha256(readFileSync(join(checkout, path)))];
}));
receipt(output, { passed: true, scratchOnly: pilot, protocol: PROTOCOL, contentRevision: CONTENT_REVISION,
  driverSha256: sha256(readFileSync(new URL(import.meta.url))), bindings, cases });
console.log(JSON.stringify(cases.map(({ window, damage, retainedCharges }) => ({ window, damage, retainedCharges }))));
