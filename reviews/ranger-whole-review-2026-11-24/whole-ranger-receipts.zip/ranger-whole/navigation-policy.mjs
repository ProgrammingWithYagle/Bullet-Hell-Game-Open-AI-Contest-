const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const spacing=64;

export function navigationPolicy({ordinary,arenaFor,segmentRect,segmentCircle,playerRadius}) {
  const graphs=new WeakMap();
  const pad=playerRadius+2;
  const clear=(arena,a,b,radius)=>!arena.obstacles.some(wall=>segmentRect(a,b,wall,radius)!==null) &&
    !arena.lavaPits.some(pit=>segmentCircle(a,b,pit,pit.radius+radius)!==null);
  function graph(arena) {
    const existing=graphs.get(arena);
    if (existing) return existing;
    const {x,y,width,height}=arena.bounds;
    const origins=new Map();
    const points=[];
    for(let col=0;x+pad+col*spacing<=x+width-pad;col++) {
      for(let row=0;y+pad+row*spacing<=y+height-pad;row++) {
        const p={x:x+pad+col*spacing,y:y+pad+row*spacing,col,row,index:points.length,edges:[]};
        if (!clear(arena,p,p,pad)) continue;
        origins.set(col+','+row,p);
        points.push(p);
      }
    }
    for (const p of points) for(let dc=-1;dc<=1;dc++) for(let dr=-1;dr<=1;dr++) {
      if (!dc && !dr) continue;
      const q=origins.get((p.col+dc)+','+(p.row+dr));
      if (q && clear(arena,p,q,pad)) p.edges.push({to:q.index,travel:distance(p,q)});
    }
    graphs.set(arena,points);
    return points;
  }
  function nextPoint(arena,p,target) {
    const points=graph(arena);
    const travel=new Float64Array(points.length).fill(Infinity);
    const first=new Int32Array(points.length).fill(-1);
    const scan=new Uint8Array(points.length);
    for (const point of points) {
      const range=distance(p,point);
      if (range<3 || range>spacing*2.5 || !clear(arena,p,point,playerRadius)) continue;
      travel[point.index]=range;
      first[point.index]=point.index;
    }
    let result, best=Infinity;
    for (let pass=0;pass<points.length;pass++) {
      let cursor=-1;
      for (const point of points) {
        const i=point.index;
        if (scan[i]===0 && Number.isFinite(travel[i]) && (cursor<0 || travel[i]<travel[cursor])) cursor=i;
      }
      if (cursor<0 || travel[cursor]>best) break;
      scan[cursor]=1;
      const point=points[cursor], direct=distance(point,target);
      const score=travel[cursor]+Math.abs(direct-235)*.19;
      if (direct>=95 && direct<=528 && score<best && clear(arena,point,target,3)) {
        best=score;
        result=points[first[cursor]];
      }
      for (const edge of point.edges) {
        const cost=travel[cursor]+edge.travel;
        if (travel[edge.to]>cost) {
          travel[edge.to]=cost;
          first[edge.to]=first[cursor];
        }
      }
    }
    return result;
  }

  let currentArena, waypoint, retryAt=0;
  return (view,p,shots,active)=>{
    const base=ordinary(view,p,shots,active);
    const arena=arenaFor(view.arenaId,view.run.difficulty);
    if (arena!==currentArena) {currentArena=arena;waypoint=undefined;retryAt=0;}
    if (clear(arena,p,view.boss,3) || base.dodge || (base.supply??-1)>=0) {
      waypoint=undefined;retryAt=0;return base;
    }
    if (view.combatTick>=retryAt || waypoint && distance(p,waypoint)<8) {
      waypoint=nextPoint(arena,p,view.boss);
      retryAt=view.combatTick+21;
    }
    if (!waypoint) return base;
    const angle=Math.atan2(waypoint.y-p.y,waypoint.x-p.x);
    return {...base,moveX:Math.cos(angle),moveY:Math.sin(angle),fire:false,q:false,e:false,ultimate:false,
      technique1:false,technique2:false,technique3:false};
  };
}
