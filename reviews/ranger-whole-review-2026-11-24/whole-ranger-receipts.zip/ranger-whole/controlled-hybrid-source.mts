import assert from 'node:assert/strict';
import { test } from 'node:test';
import { repoImport } from '../bonded/study-paths.mjs';
const { Game, data } = await repoImport('src/shared/game.ts');
const { fieldRules, rangerFieldIds } = await repoImport('src/shared/ranger-field.ts');
const { rangerSightIds } = await repoImport('src/shared/ranger-sight.ts');
const { rangerTrackerIds } = await repoImport('src/shared/ranger-tracker.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
assert.equal(PROTOCOL,104);
assert.equal(CONTENT_REVISION,process.argv[2]);
type InputFrame = ReturnType<typeof idleInput>;

test('one Ranger uses all three paid actions with Linked Stakes under the real 27-SP rules',()=>{
  const game=new Game({mode:'endless',difficulty:'normal',seed:44,openingArenaId:'gatehouse',arenaSelection:'fixed'});
  game.encounter=9;
  const actor=game.addPlayer('nela','Nela','ranger');
  assert.equal(actor.totalSp,27);
  const skills=new Map([...data.skills,...data.specializationSkills].map(node=>[node.id,node]));
  function buy(id:string) {
    if (actor.skills.includes(id)) return;
    const entry=skills.get(id)!;
    assert(entry);
    if (entry.prerequisite) buy(entry.prerequisite);
    assert(game.transact(actor.id,{kind:'skill',item:id,id:'hybrid-'+id}).ok,id);
  }
  const linked=data.skills.find(node=>node.classId==='ranger' && node.transform==='linked-stakes')!;
  for (const id of [rangerSightIds.bearing,rangerTrackerIds.stakes,rangerFieldIds.short,linked.id]) buy(id);
  assert(actor.skills.reduce((cost,id)=>cost+game.skillCost(id),0)<27);
  assert(game.start());
  const map={...game.arena,obstacles:[],lavaPits:[]};
  Object.defineProperty(game,'arena',{get:()=>map});
  Object.assign(game.boss,{x:1355,y:764,health:100000,maxHealth:100000,staggerUntil:9999,deadline:12000});
  Object.assign(actor,{x:490,y:500,oldX:490,oldY:500});
  const target=game.minions.spawn(98123,{kind:'ordinary',x:610,y:500,health:900,speed:0,radius:16,damage:1},game.combatTick)!;
  const kit=()=>game.kitStatus(actor.id);
  const trap=()=>game.classCues().find(cue=>cue.kind==='ranger-trap' && cue.owner===actor.id);
  function step(input:Partial<InputFrame>={}) {
    assert(game.submitInput(actor.id,{...idleInput(),sequence:actor.ack+1,clientTick:game.combatTick,aim:0,...input}));
    game.step();
    return game.drainEvents();
  }
  function wait(condition:()=>boolean,input:Partial<InputFrame>={},limit=90) {
    for (let i=0;i<limit && !condition();i++) step(input);
    assert(condition());
  }

  const start=actor.ammo;
  step({technique1:true,aim:Math.PI/3});
  assert.equal(actor.ammo,start-1);
  wait(()=>kit().rangerSight?.stage==='outside');
  assert(kit().rangerSight?.canAdjust);
  step({technique1:true});
  assert.equal(kit().rangerSight?.stage,'adjust');
  wait(()=>kit().rangerSight?.stage==='release');
  step({technique1:true});
  wait(()=>target.health<900);
  assert.equal(actor.ammo,start-1);
  assert.equal(kit().rangerTracker?.stage,'find');

  const shotHealth=target.health;
  step({fire:true});
  wait(()=>target.health<shotHealth);
  assert.equal(actor.ammo,start-2);
  assert.equal(kit().rangerTracker?.stage,'ready');
  step({technique2:true});
  step({e:true});
  const cable=trap()!;
  assert(cable.kind==='ranger-trap' && cable.remaining===3);
  const tripHealth=target.health;
  wait(()=>kit().rangerTracker?.stage==='recovering');
  assert(target.health<tripHealth);
  assert.equal(actor.ammo,start-1);
  const used=trap()!;
  assert(used.kind==='ranger-trap' && used.id===cable.id && used.remaining===2);

  step({technique3:true});
  assert.equal(actor.ammo,start-2);
  assert(!trap());
  assert.equal(kit().rangerTraps,1);
  wait(()=>actor.y>=600,{moveY:1});
  step({technique3:true});
  const moved=trap()!;
  assert(moved.kind==='ranger-trap');
  assert.equal(moved.id,cable.id);
  assert.equal(moved.until,cable.until);
  assert.equal(moved.remaining,2);
  assert.equal(moved.at-game.combatTick,fieldRules.shortArm);
  const newTarget=game.minions.spawn(98124,{kind:'ordinary',x:560,y:moved.y,health:900,speed:0,radius:16,damage:1},game.combatTick)!;
  wait(()=>newTarget.health<900);
  const spent=trap()!;
  assert(spent.kind==='ranger-trap' && spent.id===cable.id && spent.remaining===1);
  assert.equal(actor.ammo,start-2);
});
