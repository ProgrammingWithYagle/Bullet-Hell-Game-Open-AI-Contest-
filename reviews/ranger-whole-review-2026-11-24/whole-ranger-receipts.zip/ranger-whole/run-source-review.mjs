import assert from 'node:assert/strict';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

const root = fileURLToPath(new URL('./', import.meta.url));
const source = readJson(new URL('../ranger-field-controller/source-commit01.json', import.meta.url));
const gate = readJson(join(checkout, 'reviews/ranger-field-controller-2026-11-24/source-verification.json'));
assert(source.passed && source.protocol === 104 && gate.passed);
assert.equal(gate.runtimeSourceSha256, source.runtimeSourceSha256);
assert.equal(gate.sourceSnapshotSha256, source.sourceSnapshotSha256);
const hybrid = /import \{ Game, data \}[^\n]+\nimport \{ fieldRules[^\n]+\nimport \{ rangerSightIds[^\n]+\nimport \{ rangerTrackerIds[^\n]+\nimport \{ idleInput[^\n]+/;
const body = readFileSync(join(root, 'controlled-hybrid.mts'), 'utf8').replaceAll('\r\n', '\n');
assert(hybrid.test(body));
const focusedBody = body.replace(hybrid, [
  "import { repoImport } from '../bonded/study-paths.mjs';",
  "const { Game, data } = await repoImport('src/shared/game.ts');",
  "const { fieldRules, rangerFieldIds } = await repoImport('src/shared/ranger-field.ts');",
  "const { rangerSightIds } = await repoImport('src/shared/ranger-sight.ts');",
  "const { rangerTrackerIds } = await repoImport('src/shared/ranger-tracker.ts');",
  "const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');",
  'assert.equal(PROTOCOL,104);',
  'assert.equal(CONTENT_REVISION,process.argv[2]);',
  'type InputFrame = ReturnType<typeof idleInput>;',
].join('\n'));
const focused = join(root, 'controlled-hybrid-source.mts');
if (existsSync(focused)) assert.equal(readFileSync(focused, 'utf8'), focusedBody);
else writeFileSync(focused, focusedBody, { flag: 'wx' });

const lanes = [
  { name: 'Standard Normal', driver: 'run-observed-matrix.mjs', args: [join(root, 'standard01'), 'standard', 'source'], log: 'standard01.log', timeout: 1_800_000 },
  { name: 'Tactical Long', driver: 'run-observed-matrix.mjs', args: [join(root, 'tactical01'), 'tactical', 'source'], log: 'tactical01.log', timeout: 1_800_000 },
  { name: 'One Ranger with Linked Stakes', driver: 'controlled-hybrid-source.mts', args: [source.contentRevision], log: 'controlled-hybrid-source01.log', timeout: 120_000 },
  { name: 'Three two-Ranger cleanup cases', driver: 'controlled-owners.mts', args: [join(root, 'controlled-owners-source01.json'), 'source'], log: 'controlled-owners-source01.log', timeout: 120_000 },
  { name: 'Crosswind and Long Survey', driver: 'controlled-transforms.mts', args: [join(root, 'controlled-transforms-source01.json'), 'source'], log: 'controlled-transforms-source01.log', timeout: 120_000 },
];
assert(lanes.every(lane => !existsSync(join(root, lane.log))));
const outcomes = await Promise.all(lanes.map(async lane => {
  const driver = join(root, lane.driver), log = join(root, lane.log);
  const exitCode = await runChild([driver, ...lane.args], log, lane.timeout);
  const entry = { name: lane.name, passed: exitCode === 0, exitCode, log: lane.log, logSha256: digest(log), driver: lane.driver, driverSha256: digest(driver) };
  console.log(JSON.stringify(entry));
  return entry;
}));
const passed = outcomes.every(row => row.passed);
receipt(join(root, 'source-review01.json'), { passed, protocol: 104, source: source.sourceCommit, contentRevision: source.contentRevision, outcomes });
if (!passed) process.exitCode = 1;
