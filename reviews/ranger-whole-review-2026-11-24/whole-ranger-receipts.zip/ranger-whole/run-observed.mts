import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { situationalInput } from '../summoner-whole/situational-input.mjs';
import { wholeRangerPolicy } from './whole-policy.mjs';
import { navigationPolicy } from './navigation-policy.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { rangerSightIds, rangerSightRules } = await repoImport('src/shared/ranger-sight.ts');
const { rangerTrackerIds, trackerRules } = await repoImport('src/shared/ranger-tracker.ts');
const { rangerFieldIds } = await repoImport('src/shared/ranger-field.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle, moveBody } = await repoImport('src/shared/geometry.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [output,party,profile,edition,selected,reentry]=process.argv.slice(2);
assert(output && ['solo','pair'].includes(party) && ['standard','tactical'].includes(profile));
assert(['source','pilot'].includes(edition));
const pilot=edition==='pilot';
assert.equal(PROTOCOL,pilot?103:104);
assert(!reentry || reentry==='restore' && party==='solo' && selected);
const catalogueSha256=sha256(JSON.stringify(data));
if (!pilot) assert.equal(catalogueSha256,CONTENT_REVISION);

const tactical=profile==='tactical';
const ordinary=tactical?situationalInput({restRaidInput,runtimeArena,segmentRect,segmentCircle,moveBody}):restRaidInput;
const decision=wholeRangerPolicy({ordinary,arenaFor:runtimeArena,segmentRect,segmentCircle,sightRules:rangerSightRules,trackerRules});
const routeSettings={arenaFor:runtimeArena,segmentRect,segmentCircle,playerRadius:data.rules.playerRadius};
function activeRoute(policy) {
  const route=navigationPolicy({...routeSettings,ordinary:policy});
  return (view,p,shots,active)=>{
    const kit=p.kit;
    const holding=[kit.rangerSight,kit.rangerTracker,kit.rangerField].some(item=>item?.until>view.combatTick);
    return holding ? policy(view,p,shots,active) : route(view,p,shots,active);
  };
}
const worlds=[['gatehouse',73],['sunken-chapel',67],['ossuary-works',103]] as const;
const configurations=['roll','bearing'].flatMap(draw=>['stakes','backtrack'].flatMap(track=>['pivot','short'].map(field=>({draw,track,field}))));
const skillIndex=new Map(data.skills.map(node=>[node.id,node]));
const forms=['crosswind','linked-stakes','long-survey'] as const;
const key=(arena,fit,enabled)=>[arena,fit.draw,fit.track,fit.field,enabled?'active':'unused'].join(',');
const pathFor={
  'ranger-sight-release':'marksman',
  'ranger-track-recover':'tracker',
  'ranger-cable-set':'field controller',
};

function play(arena,seed,fitting,active,restore) {
  let game=new Game({mode:tactical?'long':'standard',difficulty:tactical?'baby':'normal',seed,
    openingArenaId:arena,arenaSelection:'fixed',maxPlayers:party==='solo'?1:2});
  let ranger=game.addPlayer('solo','Nela Venn','ranger');
  const partyMembers=party==='solo'?[ranger]:[ranger,game.addPlayer('ally','Mara','soldier')];
  const paths=[
    ['ranger-bowcraft-1',rangerSightIds.entry,rangerSightIds[fitting.draw]],
    ['ranger-trailkeeping-1',rangerTrackerIds.entry,rangerTrackerIds[fitting.track]],
    ['ranger-fieldcraft-1',rangerFieldIds.entry,rangerFieldIds[fitting.field]],
  ];
  const offset=(worlds.findIndex(row=>row[0]===arena)+configurations.indexOf(fitting))%paths.length;
  const ordered=[...paths.slice(offset),...paths.slice(0,offset)];
  const form=forms[(offset+configurations.indexOf(fitting))%forms.length];
  const formNode=data.skills.find(node=>node.classId==='ranger'&&node.transform===form);
  assert(formNode);
  const purchases=[], effects=[], encounters=[];
  const flightIds=new Set(), rawImpacts=[], moved=new Set(), contacts=[];
  function observeSightCollisions(subject) {
    const apply=subject.friendlyCollision.bind(subject);
    subject.friendlyCollision=(shot,...args)=>{
      const before=ranger.damageDealt;
      const outcome=apply(shot,...args);
      const amount=ranger.damageDealt-before;
      if (shot.owner===ranger.id && amount>0 && Math.abs(Math.hypot(shot.vx,shot.vy)-rangerSightRules.speed)<.001) {
        rawImpacts.push({id:shot.id,at:subject.combatTick,amount});
      }
      return outcome;
    };
  }
  observeSightCollisions(game);
  let rangerPolicy, allyPolicy;
  const hostile=new Map();
  const trace=createHash('sha256'), continuation=createHash('sha256');
  let serial=0, frames=0, latestShop=-1, boundary;
  const owns=id=>ranger.skills.includes(id);
  const unspent=()=>ranger.totalSp-ranger.skills.reduce((cost,id)=>cost+game.skillCost(id),0);
  const fitted=()=>paths.every(([, , fit])=>owns(fit));
  const buy=(actor,kind,item)=>game.transact(actor.id,{kind,item,id:'ranger-whole-'+ ++serial}).ok;
  function learn(id) {
    assert(buy(ranger,'skill',id),id);
    purchases.push({id,earned:ranger.totalSp,clears:ranger.progress.clears,left:unspent()});
  }
  function advanceSkills() {
    for (const [root,entry] of ordered) {
      if (!owns(entry) && unspent()>=2+Number(!owns(root))) {
        if (!owns(root)) learn(root);
        learn(entry);
      }
    }
    if (paths.every(([,entry])=>owns(entry))) {
      for (const [, , fit] of ordered) if (!owns(fit) && unspent()>=2) learn(fit);
    }
    if (fitted()) {
      const queue=[];
      for (let node=formNode;node && !owns(node.id);node=skillIndex.get(node.prerequisite)) queue.unshift(node);
      if (queue.reduce((cost,node)=>cost+node.cost,0)<=unspent()) for (const node of queue) learn(node.id);
    }
  }
  function outfit(actor) {
    for (const weapon of data.weapons.filter(row=>row.classId===actor.classId).sort((a,b)=>b.tier-a.tier)) {
      if (actor.weapon===weapon.id || buy(actor,'weapon',weapon.id)) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) buy(actor,'upgrade',item);
    buy(actor,'supply','medkit');
  }
  function markPractice() {
    const checkpoint=game.offlineCheckpoint();
    assert(checkpoint?.phase==='shop' && checkpoint.practiceOnly && checkpoint.contentRevision===CONTENT_REVISION);
    assert.deepEqual(checkpoint.player.skills,ranger.skills);
    const raw=JSON.stringify(checkpoint);
    boundary={digest:sha256(raw),earned:ranger.totalSp,clears:ranger.progress.clears,skills:[...ranger.skills],ammo:ranger.ammo};
    if (!restore) return;
    game=Game.restoreOffline(JSON.parse(raw));
    ranger=game.players.get('solo');
    observeSightCollisions(game);
    partyMembers[0]=ranger;
    assert.deepEqual(ranger.skills,boundary.skills);
    assert.equal(ranger.ammo,boundary.ammo);
    assert.equal(game.phase,'shop');
    assert(!game.classCues().some(cue=>cue.kind.startsWith('ranger-')));
    const kit=game.kitStatus(ranger.id);
    assert([kit.rangerSight,kit.rangerTracker,kit.rangerField].every(status=>status?.recoveryAt===0));
  }
  advanceSkills();
  assert.equal(purchases.length,2);
  partyMembers.forEach(outfit);
  assert(game.start());
  while (!['victory','defeat'].includes(game.phase) && frames++<125000) {
    if (game.phase!=='combat') {
      hostile.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) {
        for (const player of partyMembers) game.vote(player.id,game.phase==='contractVote'?1:0);
      }
      if (game.phase==='shop' && latestShop!==game.encounter) {
        latestShop=game.encounter;
        advanceSkills();
        partyMembers.forEach(outfit);
        if (!boundary && party==='solo' && fitted()) markPractice();
      }
      game.step();game.drainEvents();continue;
    }
    const view=viewOf(game,ranger.id), shots=[...hostile.values()];
    const encounter={index:view.encounter,arena:view.arenaId,boss:view.boss.id};
    if (encounters.at(-1)?.index!==encounter.index) {
      encounters.push(encounter);
      rangerPolicy=activeRoute(decision);
      allyPolicy=activeRoute(ordinary);
    }
    const fittedAt=fitted();
    for (const actor of partyMembers) {
      const p=view.players.find(player=>player.id===actor.id);
      assert(p);
      const control=actor.status!=='active'?{interact:true}:actor===ranger?rangerPolicy(view,p,shots,active):allyPolicy(view,p,shots,false);
      const input={...idleInput(),...control,clientTick:game.combatTick};
      input.aim=Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      if (boundary) continuation.update(JSON.stringify(input));
      assert(game.submitInput(actor.id,{...input,sequence:actor.ack+1}));
    }
    const cables=active?[...game.ranger.traps.values()].filter(trap=>trap.owner===ranger.id)
      .map(trap=>({trap,lifted:game.ranger.field.lifted(trap),contacts:trap.touched.size,placedAt:trap.placedAt,until:trap.until})):[];
    game.step();
    const batch=game.drainEvents();
    if (batch.some(event=>event.type==='sound' && event.owner===ranger.id && event.id==='ranger-cable-set')) {
      const planted=cables.find(row=>row.lifted && !game.ranger.field.lifted(row.trap));
      assert(planted && planted.trap.placedAt===planted.placedAt && planted.trap.until===planted.until);
      moved.add(planted.trap.id);
    }
    for (const row of cables) if (moved.has(row.trap.id) && row.trap.touched.size>row.contacts) {
      contacts.push({id:row.trap.id,at:game.combatTick,count:row.trap.touched.size-row.contacts,fitted:fittedAt});
    }
    const released=batch.some(event=>event.type==='sound' && event.owner===ranger.id && event.id==='ranger-sight-release');
    const causedByTripline=batch.some(event=>event.type==='sound'&&event.owner===ranger.id&&event.id==='ranger-trip');
    for (const event of batch) {
      if (event.type==='shots') for (const shot of event.shots) {
        if (shot.owner==='hostile') hostile.set(shot.id,{...shot,seenAt:game.combatTick});
        if (released && shot.owner===ranger.id && Math.abs(Math.hypot(shot.vx,shot.vy)-rangerSightRules.speed)<.001) flightIds.add(shot.id);
      }
      if (event.type==='remove') for (const id of event.ids) hostile.delete(id);
      if (event.type==='sound' && event.owner===ranger.id && /^ranger-(?:sight|track|cable)-/.test(event.id)) {
        assert(active);
        effects.push({id:event.id,boss:encounter.boss,at:game.combatTick,fitted:fittedAt,tripline:causedByTripline});
      }
    }
    trace.update(JSON.stringify([game.combatTick,game.boss.health,ranger.x,ranger.y,ranger.health,ranger.ammo,ranger.damageDealt]));
  }
  assert(['victory','defeat'].includes(game.phase));
  if (restore) assert(boundary);
  function exercised(rows) { return [...new Set(rows.map(row=>pathFor[row.id]).filter(Boolean))].sort(); }
  return {key:key(arena,fitting,active),arena,seed,fitting,active,won:game.phase==='victory',clears:ranger.progress.clears,
    unlocked:paths.filter(([,entry])=>owns(entry)).length,fullyFitted:fitted(),form:owns(formNode.id)?form:null,
    pathsUsed:exercised(effects),fittedUsed:exercised(effects.filter(event=>event.fitted)),
    purchases,effects,encounters,sightFlights:[...flightIds],sightHits:rawImpacts.filter(row=>flightIds.has(row.id)),movedContacts:contacts,boundary:boundary??null,trace:trace.digest('hex'),continuation:boundary?continuation.digest('hex'):null,
    finish:{health:ranger.health,bossHealth:game.boss.health,damageDealt:ranger.damageDealt,tick:game.combatTick}};
}

const rows=[];
for (const [arena,seed] of worlds) for (const fitting of configurations) for (const active of [false,true]) {
  if (selected && selected!==key(arena,fitting,active)) continue;
  const row=play(arena,seed,fitting,active,reentry==='restore');
  rows.push(row);
  console.log(JSON.stringify({key:row.key,clears:row.clears,won:row.won,paths:row.pathsUsed,fitted:row.fullyFitted}));
}
assert.equal(rows.length,selected?1:48);
const runtime=fileURLToPath(new URL('../ranger-field-controller/stage/',import.meta.url));
const tracker=fileURLToPath(new URL('../ranger-tracker/stage/',import.meta.url));
const roots=pilot?[runtime,tracker,checkout]:[checkout];
function paths(root,dir) {
  if (!existsSync(join(root,dir))) return [];
  return readdirSync(join(root,dir),{withFileTypes:true}).flatMap(entry=>{
    const file=dir+'/'+entry.name;
    return entry.isDirectory()?paths(root,file):[file];
  });
}
const fingerprint=createHash('sha256');
for (const path of [...new Set(roots.flatMap(root=>paths(root,'src')))].sort()) {
  const input=roots.map(root=>join(root,path)).find(existsSync);
  fingerprint.update(path+'\0').update(readFileSync(input));
}
receipt(output,{scratchOnly:pilot,routed:true,effectsObserved:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,catalogueSha256,
  runtimeSourceSha256:fingerprint.digest('hex'),profile,party,
  driverSha256:sha256(readFileSync(new URL(import.meta.url))),
  policyFiles:['./navigation-policy.mjs','./whole-policy.mjs','../ranger-marksman/sight-policy.mjs','../ranger-tracker/tracker-policy.mjs',
    '../summoner-whole/situational-input.mjs','../formation/formation-policy.mjs'].map(path=>({path,sha256:sha256(readFileSync(new URL(path,import.meta.url)))})),
  rows});
