import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { join } from 'node:path';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { rangerSightIds, rangerSightRules } = await repoImport('src/shared/ranger-sight.ts');
const { rangerTrackerIds } = await repoImport('src/shared/ranger-tracker.ts');
const { rangerFieldIds } = await repoImport('src/shared/ranger-field.ts');
const [output, edition] = process.argv.slice(2);
assert(output && ['source', 'staged'].includes(edition) && PROTOCOL === 104);
type Frame = ReturnType<typeof idleInput>;

function fixture(transform: 'crosswind' | 'long-survey') {
  const game = new Game({ mode: 'endless', difficulty: 'normal', seed: 44, openingArenaId: 'gatehouse', arenaSelection: 'fixed' });
  game.encounter = 9;
  const ranger = game.addPlayer('nela', 'Nela', 'ranger');
  const index = new Map([...data.skills, ...data.specializationSkills].map(skill => [skill.id, skill]));
  const choice = data.skills.find(skill => skill.classId === 'ranger' && skill.transform === transform);
  assert(choice && ranger.totalSp === 27);
  function buy(id: string) {
    if (ranger.skills.includes(id)) return;
    const entry = index.get(id);
    assert(entry);
    if (entry.prerequisite) buy(entry.prerequisite);
    assert(game.transact(ranger.id, { kind: 'skill', item: id, id: 'transform-' + id }).ok, id);
  }
  for (const id of [choice.id, rangerSightIds.entry, rangerTrackerIds.entry, rangerFieldIds.short]) buy(id);
  assert(game.start());
  const arena = { ...game.arena, obstacles: [], lavaPits: [] };
  Object.defineProperty(game, 'arena', { get: () => arena });
  Object.assign(game.boss, { x: 1355, y: 764, health: 100000, maxHealth: 100000, staggerUntil: 9999, deadline: 12000 });
  Object.assign(ranger, { x: 490, y: 500, oldX: 490, oldY: 500 });
  const arrows = [];
  function step(patch: Partial<Frame> = {}) {
    assert(game.submitInput(ranger.id, { ...idleInput(), aim: 0, ...patch, clientTick: game.combatTick, sequence: ranger.ack + 1 }));
    game.step();
    for (const event of game.drainEvents()) if (event.type === 'shots') {
      arrows.push(...event.shots.filter(shot => shot.owner === ranger.id));
    }
  }
  function wait(ready: () => boolean, input: Partial<Frame> = {}) {
    for (let i = 0; i < 100 && !ready(); i++) step(input);
    assert(ready());
  }
  const status = () => game.kitStatus(ranger.id);
  const trap = () => game.classCues().find(cue => cue.kind === 'ranger-trap' && cue.owner === ranger.id);
  function lift() {
    step({ e: true });
    const original = trap();
    assert(original);
    const ready = ranger.ammo;
    step({ technique3: true });
    assert.equal(ranger.ammo, ready - 1);
    assert(status().rangerField?.until > game.combatTick && !trap());
    return original;
  }
  function replant(original) {
    step({ technique3: true });
    const moved = trap();
    assert(moved && moved.id === original.id && moved.until === original.until && moved.remaining === original.remaining);
    assert(Math.hypot(moved.x2 - moved.x, moved.y2 - moved.y) < Math.hypot(original.x2 - original.x, original.y2 - original.y));
  }
  const enemy = () => {
    const target = game.minions.spawn(98127, { kind: 'ordinary', x: ranger.x + 154, y: ranger.y, health: 900, speed: 0, radius: 16, damage: 1 }, game.combatTick);
    assert(target);
    return target;
  };
  return { game, ranger, arrows, step, wait, status, lift, replant, enemy };
}

const f = fixture('crosswind');
const original = f.lift();
f.step({ q: true });
assert.equal(f.ranger.qAt, 0);
assert.equal(f.status().rangerDrawUntil, 0);
f.replant(original);
const target = f.enemy();
f.step({ q: true });
assert(f.ranger.qAt > f.game.combatTick);
f.wait(() => target.health < 900);
assert.equal(f.arrows.length, 3);
assert.equal(new Set(f.arrows.map(shot => Math.atan2(shot.vy, shot.vx))).size, 3);
assert.equal(f.status().rangerTracker?.stage, 'find');

const g = fixture('long-survey');
g.step({ ultimate: true });
const surveys = g.game.classCues().filter(cue => cue.kind === 'ranger-survey' && cue.owner === g.ranger.id);
assert.equal(surveys.length, 1);
const post = surveys[0];
const charges = g.status().rangerSurveyCharges;
assert(charges > 0);
g.wait(() => Math.hypot(g.ranger.x - post.x, g.ranger.y - post.y) < 30, { moveX: 1 });
const surveyCable = g.lift();
g.step({ fire: true });
assert.equal(g.status().rangerSurveyCharges, charges);
assert.equal(g.arrows.length, 0);
g.replant(surveyCable);
const surveyTarget = g.enemy();
g.step({ technique1: true });
g.wait(() => g.status().rangerSight?.stage === 'release');
g.step({ technique1: true });
g.wait(() => surveyTarget.health < 900);
assert.equal(g.status().rangerSurveyCharges, charges);
assert.equal(g.arrows.length, 1);
assert(Math.abs(Math.hypot(g.arrows[0].vx, g.arrows[0].vy) - rangerSightRules.speed) < .001);
const afterSight = surveyTarget.health;
g.step({ fire: true });
assert.equal(g.status().rangerSurveyCharges, charges - 1);
g.wait(() => surveyTarget.health < afterSight);
assert.equal(g.status().rangerSurveyUntil, post.until);

const cases = [
  { id: 'crosswind', issuedProjectiles: f.arrows.length, damage: 900 - target.health, readOpenedByCrosswind: false },
  { id: 'long-survey', points: surveys.length, expiry: post.until, chargesBefore: charges, chargesAfterSight: charges,
    chargesAfterPrimary: g.status().rangerSurveyCharges, sightDamage: 900 - afterSight, primaryDamage: afterSight - surveyTarget.health },
];
receipt(output, { passed: true, scratchOnly: edition === 'staged', protocol: PROTOCOL, contentRevision: CONTENT_REVISION, cases,
  driverSha256: sha256(readFileSync(new URL(import.meta.url))), gameSha256: edition === 'source' ? sha256(readFileSync(join(checkout, 'src/shared/game.ts'))) : null });
console.log(JSON.stringify(cases));
