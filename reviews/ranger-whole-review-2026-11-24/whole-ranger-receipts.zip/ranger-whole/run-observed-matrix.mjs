import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

const [folder,profile,edition]=process.argv.slice(2);
assert(folder && ['standard','tactical'].includes(profile) && ['pilot','source'].includes(edition));
const pilot=edition==='pilot';
const source=pilot?undefined:readJson(new URL('../ranger-field-controller/source-commit01.json',import.meta.url));
if (source) assert(source.passed && source.protocol===104);
const loader=pilot?['--import',new URL('../ranger-field-controller/overlay-loader.mjs',import.meta.url).href]:[];
const driver=fileURLToPath(new URL('run-observed.mts',import.meta.url));
const scriptHash=digest(driver);
const worlds=['gatehouse','sunken-chapel','ossuary-works'];
mkdirSync(folder);
const receipts=[];
let baseline;
async function collect(name,party,...args) {
  const raw=join(folder,name+'.json'),log=join(folder,name+'.log');
  assert.equal(await runChild([...loader,driver,raw,party,profile,edition,...args],log,1500000),0,log);
  const row=readJson(raw);
  assert.equal(row.scratchOnly,pilot);
  assert(row.routed && row.effectsObserved);
  assert.equal(row.protocol,pilot?103:104);
  assert.equal(row.driverSha256,scriptHash);
  assert(row.party===party && row.profile===profile);
  for (const file of row.policyFiles) assert.equal(digest(new URL(file.path,import.meta.url)),file.sha256);
  baseline??={runtime:row.runtimeSourceSha256,catalogue:row.catalogueSha256,content:row.contentRevision,policy:row.policyFiles};
  assert.deepEqual({runtime:row.runtimeSourceSha256,catalogue:row.catalogueSha256,content:row.contentRevision,policy:row.policyFiles},baseline);
  if (source) {
    assert.equal(row.contentRevision,source.contentRevision);
    assert.equal(row.runtimeSourceSha256,source.runtimeSourceSha256);
  }
  receipts.push({name,raw:name+'.json',rawSha256:digest(raw),log:name+'.log',logSha256:digest(log)});
  return row.rows;
}

async function lane(party) {
  const rows=await collect(party+'-all',party);
  assert.equal(rows.length,48);
  const lookup=new Map(rows.map(row=>[row.key,row]));
  assert.equal(lookup.size,48);
  for (const row of rows.filter(row=>!row.active)) {
    assert(row.effects.length===0 && row.sightFlights.length===0 && row.sightHits.length===0 && row.movedContacts.length===0);
    const counterpart=lookup.get(row.key.replace(/unused$/,'active'));
    assert(counterpart);
    const compatible=Math.min(row.purchases.length,counterpart.purchases.length);
    assert.deepEqual(counterpart.purchases.slice(0,compatible),row.purchases.slice(0,compatible));
  }
  const replayed=[];
  for (const [index,arena] of worlds.entries()) for (const active of [false,true]) {
    const row=rows.filter(row=>row.arena===arena && row.active===active)[index*2];
    const [replay]=await collect(party+'-replay-'+replayed.length,party,row.key);
    assert.deepEqual(replay,row);
    replayed.push(row.key);
  }
  const practice=[];
  if (party==='solo') for (const row of rows.filter(row=>row.active && row.boundary)) {
    const [replay]=await collect('solo-practice-'+practice.length,party,row.key,'restore');
    assert.deepEqual(replay,row);
    practice.push({key:replay.key,boundary:replay.boundary,continuation:replay.continuation,clears:replay.clears,won:replay.won});
  }
  const summaries=[];
  for (const active of [false,true]) for (const arena of worlds) {
    const cases=rows.filter(row=>row.active===active && row.arena===arena);
    const eventCounts={};
    for (const row of cases) for (const event of row.effects) eventCounts[event.id]=(eventCounts[event.id]??0)+1;
    const summary={party,arena,active,runs:cases.length,wins:cases.filter(row=>row.won).length,clears:cases.map(row=>row.clears),
      fitted:cases.filter(row=>row.fullyFitted).length,usedAll:cases.filter(row=>row.pathsUsed.length===3).length,
      usedAllFitted:cases.filter(row=>row.fittedUsed.length===3).length,
      sightHits:cases.flatMap(row=>row.sightHits).length,
      movedContacts:cases.flatMap(row=>row.movedContacts).reduce((sum,contact)=>sum+contact.count,0),eventCounts};
    summaries.push(summary);
    console.log(JSON.stringify(summary));
  }
  return {party,replayed,practice,summaries};
}

const outcomes=await Promise.allSettled(['solo','pair'].map(lane));
const passed=outcomes.every(row=>row.status==='fulfilled');
for (const row of outcomes) if (row.status==='rejected') console.error(row.reason);
receipt(join(folder,'whole-summary.json'),{passed,scratchOnly:pilot,routed:true,effectsObserved:true,profile,source:source?.sourceCommit??null,
  matches:96,pairedComparisons:48,exactReplays:passed?12:null,sourceBytes:baseline,
  outcomes:outcomes.map(row=>row.status==='fulfilled'?row.value:{error:String(row.reason)}),files:receipts});
if (!passed) process.exitCode=1;
