import { standing } from '../formation/formation-policy.mjs';
import { sightPolicy } from '../ranger-marksman/sight-policy.mjs';
import { trackerPolicy } from '../ranger-tracker/tracker-policy.mjs';

const distance=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const heading=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
const offset=(p,angle,length)=>({x:p.x+Math.cos(angle)*length,y:p.y+Math.sin(angle)*length});
const walk=(from,to)=>{
  const aim=heading(from,to);
  return {moveX:Math.cos(aim),moveY:Math.sin(aim)};
};
const normalAim=aim=>Math.atan2(Math.sin(aim),Math.cos(aim));

export function wholeRangerPolicy({ordinary,arenaFor,segmentRect,segmentCircle,sightRules,trackerRules}) {
  const context={ordinary,arenaFor,segmentRect,segmentCircle};
  const sight=sightPolicy({...context,rules:sightRules});
  const track=trackerPolicy({...context,rules:trackerRules});
  function clear(world,from,to,pad) {
    return !world.obstacles.some(wall=>segmentRect(from,to,wall,pad)!==null);
  }
  function legal(world,from,to) {
    const {x,y,width,height}=world.bounds;
    return to.x>=x+18 && to.x<=x+width-18 && to.y>=y+18 && to.y<=y+height-18 &&
      clear(world,from,to,18) && !world.lavaPits.some(pit=>segmentCircle(from,to,pit,pit.radius+18)!==null);
  }
  return (view,p,shots,active)=>{
    const ordinaryInput=ordinary(view,p,shots);
    if (!active) return ordinaryInput;
    const now=view.combatTick;
    const tracking=p.kit.rangerTracker;
    const drawing=p.kit.rangerSight;
    const field=p.kit.rangerField;
    const world=arenaFor(view.arenaId,view.run.difficulty);
    const boss=view.boss, range=distance(p,boss), aim=heading(p,boss);
    const quiet={...standing(ordinaryInput),aim};
    const danger=ordinaryInput.dodge || (ordinaryInput.supply??-1)>=0;
    const sightHeld=drawing?.until>now && drawing?.stage!=='recovery';
    if (sightHeld && !danger) return sight(view,p,shots,true);
    if (danger) return ordinaryInput;

    if (field?.until>now) {
      const candidate=field.placement;
      if (candidate && (segmentCircle(candidate.start,candidate.end,boss,25)!==null || field.until-now<=12)) {
        return {...quiet,technique3:true};
      }
      const pin=field.anchor;
      const desired=pin ? offset(pin,heading(pin,boss),Math.min(145,Math.max(48,distance(pin,boss)+8))) :
        offset(boss,heading(boss,p),field.fitting==='short'?96:132);
      if (legal(world,p,desired) && distance(p,desired)>5) return {...quiet,...walk(p,desired)};
      return {...quiet,moveX:ordinaryInput.moveX,moveY:ordinaryInput.moveY};
    }
    if (tracking?.until>now) return track(view,p,shots,true);
    if (tracking?.stage==='ready') {
      const action=track(view,p,shots,true);
      if (action.technique2) return action;
    }
    if (field?.stage==='ready' && range<=192 && range>=70 && p.ammo>=2 && clear(world,p,boss,4)) {
      return {...quiet,technique3:true};
    }
    if (field?.stage==='find' && p.eAt<=now && p.ammo>=2 && range<183 && range>=75 &&
      !view.classCues.some(cue=>cue.kind==='ranger-trap' && cue.owner===p.id)) {
      const angles=field.fitting==='pivot'?[aim,aim-.16,aim+.16]:[aim+Math.PI/2,aim-Math.PI/2,aim];
      const fittingAim=angles.find(angle=>legal(world,p,offset(p,angle,87)));
      if (fittingAim!==undefined) return {...quiet,aim:normalAim(fittingAim),e:true};
    }
    if (drawing?.stage==='ready') {
      const action=sight(view,p,shots,true);
      if (action.technique1) return action;
    }
    return ordinaryInput;
  };
}
