import { bondInput } from '../bonded/bond-policy.mjs';

export const normalizedAim = value => Math.atan2(Math.sin(value), Math.cos(value));
export const formationCue = (view, player) => view.classCues.find(cue => cue.kind === 'summoner-formation' && cue.owner === player.id);
export const standing = input => ({ ...input, fire: false, reload: false, q:false, e:false, ultimate:false, moveX:0, moveY:0, dodge:false, sprint:false, supply:-1 });

export function formationInput(view, player, observed, ordinary, active) {
  const input = bondInput(view, player, observed, ordinary, false);
  if (!active) return input;
  const status = player.kit.formation;
  const cue = formationCue(view, player);
  const activeFor = cue ? view.combatTick - cue.at : 0;
  if (cue) {
    const planted = { ...input, q: false, e: false, ultimate: false, moveX: 0, moveY: 0 };
    if (status.fitting === 'turn' && status.stage === 'set' && status.canCommand) {
      return { ...standing(input), aim: normalizedAim(cue.aim + Math.PI / 2), technique3: true };
    }
    if (status.fitting === 'walking' && activeFor >= 44 && activeFor <= 53) {
      return { ...planted, moveX: -Math.sin(cue.aim), moveY: Math.cos(cue.aim), dodge: false };
    }
    return planted;
  }
  const aim = normalizedAim(input.aim + (status?.fitting === 'turn' ? -Math.PI / 2 : 0));
  if (status?.stage === 'ready' && !input.dodge && (input.supply ?? -1) < 0) {
    return { ...standing(input), aim, technique3: true };
  }
  if (status?.stage === 'ground' && view.combatTick % 9 < 5) return { ...input, aim, fire: false };
  return input;
}
