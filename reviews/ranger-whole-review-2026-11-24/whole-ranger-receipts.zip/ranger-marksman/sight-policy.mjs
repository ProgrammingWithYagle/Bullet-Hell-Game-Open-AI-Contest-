import { normalizedAim, standing } from '../formation/formation-policy.mjs';

export function sightPolicy({ ordinary, arenaFor, segmentRect, segmentCircle, rules }) {
  return (view, player, shots, enabled) => {
    const base=ordinary(view,player,shots);
    if(!enabled) return base;
    const state=player.kit.rangerSight;
    const cue=view.classCues.find(row=>row.kind==='ranger-sight'&&row.owner===player.id);
    const world=arenaFor(view.arenaId,view.run.difficulty);
    const boss=view.boss;
    const bearing=Math.atan2(boss.y-player.y,boss.x-player.x);
    const distance=Math.hypot(boss.x-player.x,boss.y-player.y);
    const visible=distance<630 && !world.obstacles.some(wall=>segmentRect(player,boss,wall,4));
    const needsSupply=(base.supply??-1)>=0;
    if(!cue) {
      if(state?.stage!=='ready' || base.dodge || needsSupply || !visible || distance<94) return base;
      const aim=normalizedAim(bearing+(state.fitting==='bearing'?Math.PI/3:0));
      return {...standing(base),aim,technique1:true};
    }
    const quiet={...standing(base),aim:cue.aim};
    if(needsSupply) return {...quiet,supply:base.supply};
    if(state.stage!=='release' && state.stage!=='outside') return quiet;
    const difference=Math.abs(normalizedAim(bearing-cue.aim));
    if(state.fitting==='bearing' && state.canAdjust && difference>rules.halfArc) {
      return {...quiet,aim:bearing,technique1:true};
    }
    if(state.fitting==='roll' && state.rollAvailable && player.dodgeAt<=view.combatTick &&
      (player.stamina??100)>24 && view.combatTick+14<cue.until) {
      const angle=[bearing+Math.PI,bearing].find(angle=>{
        const target={x:player.x+Math.cos(angle)*150,y:player.y+Math.sin(angle)*150};
        const range=Math.hypot(target.x-boss.x,target.y-boss.y);
        const wall=world.obstacles.some(rect=>segmentRect(player,target,rect,18));
        const lava=world.lavaPits.some(pit=>segmentCircle(player,target,pit,pit.radius+18)!==null);
        return !wall&&!lava&&range>110&&range<600;
      });
      if(angle!==undefined) return {...quiet,dodge:true,moveX:Math.cos(angle),moveY:Math.sin(angle)};
    }
    if(visible&&difference<=rules.halfArc) return {...quiet,aim:bearing,technique1:true};
    return {...quiet,moveX:base.moveX,moveY:base.moveY};
  };
}
