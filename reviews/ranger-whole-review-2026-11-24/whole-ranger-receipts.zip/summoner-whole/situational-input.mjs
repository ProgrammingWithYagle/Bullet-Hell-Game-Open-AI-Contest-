const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const directions = Array.from({ length:16 }, (_, i) => ({ x:Math.cos(i * Math.PI / 8), y:Math.sin(i * Math.PI / 8) }));
const pointFrom = cue => ({ x:cue.x1, y:cue.y1 });
const pointTo = cue => ({ x:cue.x2, y:cue.y2 });

export function situationalInput({ restRaidInput, runtimeArena, segmentRect, segmentCircle, moveBody }) {
  return (view, player, shots) => {
    const ordinary = restRaidInput(view, player, shots);
    const arena = runtimeArena(view.arenaId, view.run.difficulty);
    const now = view.combatTick;
    const visible = (from, target) => !arena.obstacles.some(wall => segmentRect(from, target, wall, 3));
    const lenses = view.bossCues.filter(cue => cue.kind === 'service-prop' && cue.style === 'needle' && cue.health > 0 &&
      distance(player, cue) <= 430 && visible(player, cue));
    const threats = view.minions.filter(unit => unit.health > 0 && distance(unit, player) <= 126 && visible(player, unit));
    const target = threats.sort((a,b) => distance(player,a) - distance(player,b))[0] ??
      lenses.sort((a,b) => distance(player,a) - distance(player,b))[0] ?? view.boss;
    const aim = Math.atan2(target.y - player.y, target.x - player.x);
    const beams = view.bossCues.filter(cue => ['service-beam','early-lane','raid-lane'].includes(cue.kind) &&
      !cue.disabled && !cue.cancelled && cue.at - now <= 28 && cue.until > now && Number.isFinite(cue.width));
    const nearBeam = (point, pad) => beams.filter(cue => segmentCircle(pointFrom(cue), pointTo(cue), point, pad + cue.width / 2) !== null).length;
    if (!nearBeam(player, 76) && visible(player, target) && !threats.length) return { ...ordinary, aim, fire:true };
    const radius = 18;
    const bounds = arena.bounds;
    const baseMove = { x:ordinary.moveX ?? 0, y:ordinary.moveY ?? 0 };
    const scored = [baseMove, ...directions, { x:0, y:0 }].map(movement => {
      const step = { x:movement.x * player.speed * 0.48, y:movement.y * player.speed * 0.48 };
      const next = moveBody(player, step, radius, arena.obstacles);
      const legal = next.x >= bounds.x + radius && next.x <= bounds.x + bounds.width - radius &&
        next.y >= bounds.y + radius && next.y <= bounds.y + bounds.height - radius;
      const lava = arena.lavaPits.some(pit => segmentCircle(player, next, pit, radius + pit.radius) !== null);
      if (!legal || lava) return { movement, score:Infinity };
      let danger = 600 * nearBeam(next, 26);
      for (const shot of shots) {
        const remain = Math.min(14, shot.expires - now);
        if (remain < 0 || distance(shot, next) > 460) continue;
        const age = Math.max(0, now - shot.seenAt) / 30;
        const from = { x:shot.x + shot.vx * age, y:shot.y + shot.vy * age };
        const to = { x:from.x + shot.vx * remain / 30, y:from.y + shot.vy * remain / 30 };
        if (segmentCircle(from, to, next, radius + shot.radius + 3) !== null) danger += 70;
      }
      const range = Math.abs(distance(next, target) - (threats.length ? 195 : 205));
      return { movement, score:danger + range * 0.08 + (visible(next,target) ? 0 : 80) + distance(movement, baseMove) * 0.2 };
    }).sort((a, b) => a.score - b.score)[0];
    return { ...ordinary, aim, moveX:scored.movement.x, moveY:scored.movement.y, fire:visible(player,target),
      dodge:ordinary.dodge || nearBeam(player, 20) > 0 && player.dodgeAt <= now };
  };
}
