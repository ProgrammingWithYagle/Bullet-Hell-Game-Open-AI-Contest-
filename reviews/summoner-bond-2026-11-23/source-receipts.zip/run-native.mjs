import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { closeSync, existsSync, mkdirSync, openSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt, sha256 } from './study-paths.mjs';

export const currentDriver = fileURLToPath(new URL('./native-bond.mts', import.meta.url));
export const digest = path => sha256(readFileSync(path));
export const verifyNative = (row, options) => {
  const { transport, fitting, revision, driver, worker, difficulty } = options;
  assert(row.passed && row.protocol === 100 && row.contentRevision === revision);
  assert.equal(row.transport, transport);
  assert.equal(row.fitting, fitting);
  assert.equal(row.difficulty, difficulty);
  assert.equal(row.driverSha256, digest(driver));
  assert.equal(row.policySha256, digest(new URL('./bond-policy.mjs', import.meta.url)));
  assert.equal(row.result.focusCost, 2);
  assert(row.pauseRejected && row.bought[1].earned === 3);
  if (fitting !== 'entry') assert(row.firstClear === 1 && row.bought[2].earned === 5);
  assert(row.result.cue.radius > 0 && row.result.repaired > 0);
  assert.equal(row.result.cue.state, fitting === 'entry' ? 'watch' : fitting === 'close' ? 'close' : 'return');
  if (fitting === 'homeward') assert(row.result.maxTravel > 8);
  if (transport === 'worker') {
    assert(row.wholeOptimizedWorker && row.workerPatched === false);
    if (worker) assert.equal(row.workerSha256, worker);
  } else assert(row.peers === 2 && row.result.witness.joinedNonHost && row.result.witness.ownerStateStayedPrivate);
};

export function runChild(args, log, timeout) {
  const fd = openSync(log, 'wx');
  return new Promise((resolve, reject) => {
    const child = spawn(process.execPath, ['--import', 'tsx', ...args], { cwd: checkout, stdio: ['ignore', fd, fd], windowsHide: true });
    const timer = setTimeout(() => child.kill(), timeout);
    child.once('error', failure => { clearTimeout(timer); closeSync(fd); reject(failure); });
    child.once('exit', code => { clearTimeout(timer); closeSync(fd); resolve(code); });
  });
}

async function localAttempts(folder, difficulty, filter) {
  assert(!existsSync(folder));
  mkdirSync(folder);
  const catalog = readJson(join(checkout, 'content/revision.json'));
  const combos = ['worker', 'peer'].flatMap(transport => ['entry', 'close', 'homeward'].map(fitting => [transport, fitting]));
  const chosen = filter ? combos.filter(row => filter.split(',').includes(row.join('-'))) : combos;
  assert(chosen.length);
  const cases = await Promise.all(chosen.map(async ([transport, fitting]) => {
    const stem = transport + '-' + fitting;
    const raw = join(folder, stem + '.json'), log = join(folder, stem + '.log');
    const code = await runChild([currentDriver, transport, fitting, raw, '-', 'testing', difficulty], log, 290000);
    const result = existsSync(raw) ? readJson(raw) : undefined;
    if (code === 0) verifyNative(result, { transport, fitting, revision: catalog.sha256, driver: currentDriver, difficulty });
    const summary = { transport, fitting, code, passed: code === 0 && result?.passed === true,
      logSha256: digest(log), rawSha256: result && digest(raw), repair: result?.result.repaired };
    console.log(JSON.stringify(summary));
    return summary;
  }));
  const passed = cases.every(row => row.passed);
  receipt(join(folder, 'checks.json'), { passed, difficulty, driver: digest(currentDriver), cases });
  if (!passed) process.exitCode = 1;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) await localAttempts(...process.argv.slice(2));
