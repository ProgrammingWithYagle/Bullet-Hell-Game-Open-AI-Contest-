import assert from 'node:assert/strict';
import { join } from 'node:path';
import { checkout, readJson, receipt, repoImport } from './study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION } = await repoImport('src/shared/protocol.ts');
const { conflictingSkill } = await repoImport('src/shared/skill-conflicts.ts');
const { bondIds } = await repoImport('src/shared/summoner-bond.ts');
const { cohortIds } = await repoImport('src/shared/summoner-cohort.ts');
const output = process.argv[2];
assert(output && PROTOCOL === 100);
const prior = readJson(join(checkout, 'reviews/summoner-cohort-2026-11-23/build-census.json'));
assert.equal(prior.totalSets, 24114);
const skills = new Map([...data.skills, ...data.generalSkills, ...data.specializationSkills].map(node => [node.id, node]));
const transforms = data.skills.filter(node => node.classId === 'summoner' && node.transform).map(node => node.id);
assert.equal(transforms.length, 3);
const techniques = data.specializationSkills.filter(node => node.classId === 'summoner').map(node => node.id);
const significant = new Set([...techniques, ...data.generalSkills.map(node => node.id), ...transforms]);
const prerequisiteFirst = new Set<string>();
function include(id: string) {
  if (prerequisiteFirst.has(id)) return;
  const node = skills.get(id);
  assert(node, id);
  if (node.prerequisite) include(node.prerequisite);
  prerequisiteFirst.add(id);
}
for (const id of significant) include(id);
const choices = [...prerequisiteFirst];
const candidates = new Map();
const owned: string[] = [];
function walk(index: number, spent: number, capstones: number) {
  if (index === choices.length) {
    if (!owned.some(id => techniques.includes(id))) return;
    const signature = owned.filter(id => significant.has(id)).sort().join('|');
    if (!candidates.has(signature) || candidates.get(signature).spent > spent) {
      candidates.set(signature, { skills: [...owned], spent, remaining: 27 - spent, capstones, operationAndSharedSignature: signature });
    }
    return;
  }
  walk(index + 1, spent, capstones);
  const id = choices[index], node = skills.get(id)!;
  if (spent + node.cost > 27 || Number(node.freePlaySpRequired ?? 0) > 27 || node.capstone && capstones ||
      node.prerequisite && !owned.includes(node.prerequisite) || conflictingSkill(owned, id)) return;
  owned.push(id);
  walk(index + 1, spent + node.cost, capstones + Number(node.capstone));
  owned.pop();
}
walk(0, 0, 0);

const count = (builds, ...ids) => builds.filter(build => ids.every(id => build.skills.includes(id))).length;
const reports = prior.reports.map(report => {
  const builds = report.classId === 'summoner' ? [...candidates.values()] : report.builds;
  if (report.classId === 'summoner') {
    for (const row of report.builds) assert(candidates.has(row.operationAndSharedSignature));
  }
  let purchases = 0, exclusionChecks = 0;
  for (const build of builds) {
    const game = new Game({ mode: 'endless', seed: 41, maxPlayers: 1 });
    game.encounter = 9;
    const player = game.addPlayer('solo', 'Build census', report.classId);
    assert.equal(player.totalSp, 27);
    for (const item of build.skills) assert(game.transact(player.id, { id: 'build-' + ++purchases, kind: 'skill', item }).ok, item);
    assert.deepEqual(player.skills, build.skills);
    assert.equal(player.skills.reduce((sum, item) => sum + game.skillCost(item), 0), build.spent);
    assert(build.capstones <= 1);
    if (report.classId === 'summoner') {
      const hasBond = player.skills.includes(bondIds.entry);
      const capacity = game.kitStatus(player.id).retinueCapacity;
      assert(capacity >= (hasBond ? 2 : 4) && capacity <= (hasBond ? 4 : 6));
      const alternative = player.skills.includes(bondIds.close) ? bondIds.homeward :
        player.skills.includes(bondIds.homeward) ? bondIds.close : undefined;
      if (alternative) {
        assert.equal(game.transact(player.id, { id: 'alt', kind: 'skill', item: alternative }).reason, 'incompatibleItem');
        assert(!player.skills.includes(alternative));
        exclusionChecks++;
      }
    }
  }
  const fitting = report.classId === 'summoner' ? {
    cohort: count(builds, cohortIds.entry), cross: count(builds, cohortIds.cross), relay: count(builds, cohortIds.relay),
    bond: count(builds, bondIds.entry), close: count(builds, bondIds.close), homeward: count(builds, bondIds.homeward),
    withCohort: count(builds, cohortIds.entry, bondIds.entry),
    withRunningPack: count(builds, bondIds.entry, transforms.find(id => skills.get(id).transform === 'running-pack')),
    withClosedRanks: count(builds, bondIds.entry, transforms.find(id => skills.get(id).transform === 'closed-ranks')),
    withPatientCompany: count(builds, bondIds.entry, transforms.find(id => skills.get(id).transform === 'patient-company')),
    withIssuedTransformation: builds.filter(row => transforms.some(id => row.skills.includes(id))).length,
    exclusionChecks,
  } : report.fitting;
  return { ...report, techniques: report.classId === 'summoner' ? techniques.length : report.techniques,
    distinctSets: builds.length, purchases, priorSetsPreserved: report.distinctSets, fitting, builds };
});
const total = reports.reduce((sum, row) => sum + row.distinctSets, 0);
assert(reports.reduce((sum, row) => sum + row.priorSetsPreserved, 0) === prior.totalSets);
const summoner = reports.find(row => row.classId === 'summoner');
assert(summoner.fitting.bond > 0 && summoner.fitting.withCohort > 0 && summoner.fitting.close === summoner.fitting.homeward);
receipt(output, { stage: false, protocol: PROTOCOL, contentRevision: CONTENT_REVISION, priorSetCount: prior.totalSets,
  totalSets: total, reports, scope: 'Canonical 27-SP purchases. The prior tracked sets, Summoner transformations, and Bonded Companion plus Cohort Commander hybrids.' });
const { builds, ...summary } = summoner;
console.log(JSON.stringify({ priorSets: prior.totalSets, total, summoner: summary }));
