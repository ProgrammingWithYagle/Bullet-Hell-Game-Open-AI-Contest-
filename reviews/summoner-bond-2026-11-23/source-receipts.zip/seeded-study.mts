import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { bondInput } from './bond-policy.mjs';
import { checkout, receipt, repoImport, sha256 } from './study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { bondIds } = await repoImport('src/shared/summoner-bond.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [mode, party, output, replay] = process.argv.slice(2);
assert(PROTOCOL === 100 && ['short', 'standard'].includes(mode) && ['solo', 'pair'].includes(party) && output);
const seeds = [['gatehouse', 41], ['sunken-chapel', 67], ['ossuary-works', 103]] as const;
const styles = ['entry', 'close', 'homeward'] as const;
const sourceFiles = (dir: string): string[] => readdirSync(join(checkout, dir), { withFileTypes: true }).flatMap(row => {
  const path = dir + '/' + row.name;
  return row.isDirectory() ? sourceFiles(path) : [path];
});
const runtime = createHash('sha256');
for (const path of sourceFiles('src').sort()) runtime.update(path + '\0').update(readFileSync(join(checkout, path)));

function run(arena, seed, fitting, active) {
  const game = new Game({ mode, difficulty: 'normal', seed, openingArenaId: arena, arenaSelection: 'fixed', maxPlayers: party === 'solo' ? 1 : 2 });
  const owner = game.addPlayer('joss', 'Joss', 'summoner');
  const players = party === 'solo' ? [owner] : [owner, game.addPlayer('mara', 'Mara', 'soldier')];
  const observed = new Map();
  const purchases = [], casts = [], mends = [];
  let serial = 0, frames = 0, shop = -1;
  const trace = createHash('sha256');

  function buy(player, kind, item) {
    const result = game.transact(player.id, { id: 'bond-study-' + ++serial, kind, item });
    if (result.ok) purchases.push({ who: player.id, kind, item, earned: player.totalSp, clears: player.progress.clears });
    return result.ok;
  }
  function equip(player) {
    const weapons = data.weapons.filter(w => w.classId === player.classId).sort((a, b) => b.tier - a.tier);
    for (const weapon of weapons) if (player.weapon === weapon.id || buy(player, 'weapon', weapon.id)) break;
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy(player, 'upgrade', item);
    buy(player, 'supply', 'medkit');
  }
  assert.equal(owner.totalSp, 3);
  assert(buy(owner, 'skill', 'summoner-bonds-1') && buy(owner, 'skill', bondIds.entry));
  if (fitting !== 'entry') assert(!buy(owner, 'skill', bondIds[fitting]));
  players.forEach(equip);
  assert(game.start());

  while (game.phase !== 'victory' && game.phase !== 'defeat' && frames++ < 90000) {
    if (game.phase !== 'combat') {
      observed.clear();
      if (['mutationVote', 'contractVote', 'secretOffer'].includes(game.phase)) for (const player of players) game.vote(player.id, 0);
      if (game.phase === 'shop' && game.encounter !== shop) {
        shop = game.encounter;
        if (fitting !== 'entry' && owner.totalSp >= 5 && !owner.skills.includes(bondIds[fitting])) {
          assert(buy(owner, 'skill', bondIds[fitting]));
          assert(owner.progress.clears >= 1);
        }
      }
      game.step();
      game.drainEvents();
      continue;
    }
    const view = viewOf(game, owner.id);
    const hostile = [...observed.values()];
    const enabled = active && (fitting === 'entry' || owner.skills.includes(bondIds[fitting]));
    for (const player of players) {
      const seen = view.players.find(candidate => candidate.id === player.id);
      assert(seen);
      const control = player.status !== 'active' ? { interact: true } : player === owner ?
        bondInput(view, seen, hostile, restRaidInput, enabled) : restRaidInput(view, seen, hostile);
      const input = { ...idleInput(), ...control, sequence: player.ack + 1, clientTick: game.combatTick };
      input.aim = Math.atan2(Math.sin(input.aim), Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      assert(game.submitInput(player.id, input));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') observed.set(shot.id, { ...shot, seenAt: game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) observed.delete(id);
      if (event.type === 'sound' && event.owner === owner.id && event.id.startsWith('summoner-bond-')) {
        assert(enabled);
        const row = { tick: game.combatTick, boss: view.boss.id, clears: owner.progress.clears };
        if (event.id === 'summoner-bond-cast') casts.push(row);
        if (event.id === 'summoner-bond-mend') mends.push(row);
      }
    }
    trace.update(JSON.stringify([game.combatTick, game.boss.health, owner.x, owner.y, owner.health, owner.ammo,
      owner.damageDealt, game.kitStatus(owner.id).bond, ...game.retinue.owned(owner.id).map(u=>[u.id, u.x, u.y, u.health, u.attackAt])]));
  }
  assert(['defeat', 'victory'].includes(game.phase));
  return { arena, seed, fitting, active, won: game.phase === 'victory', clears: owner.progress.clears,
    acquired: owner.skills.includes(bondIds[fitting]), purchases, casts, mends, trace: trace.digest('hex') };
}

const rows = [];
for (const [arena, seed] of seeds) for (const fitting of styles) for (const active of [false, true]) {
  if (replay && (!active || fitting === 'entry' && arena !== 'gatehouse' || fitting === 'close' && arena !== 'sunken-chapel' || fitting === 'homeward' && arena !== 'ossuary-works')) continue;
  const result = run(arena, seed, fitting, active);
  rows.push(result);
  console.log(JSON.stringify({ ...result, purchases: result.purchases.length, casts: result.casts.length, mends: result.mends.length }));
}
assert.equal(rows.length, replay ? 3 : 18);
receipt(output, { protocol: PROTOCOL, revision: CONTENT_REVISION, runtimeSourceSha256: runtime.digest('hex'), mode, party, replay: !!replay,
  driverSha256: sha256(readFileSync(new URL(import.meta.url))), policySha256: sha256(readFileSync(new URL('./bond-policy.mjs', import.meta.url))), rows });
