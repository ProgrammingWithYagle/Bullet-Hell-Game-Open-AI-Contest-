import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { Worker } from 'node:worker_threads';
import { bondInput, ownedBodies } from './bond-policy.mjs';
import { checkout, receipt, repoImport, sha256 } from './study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION } = await repoImport('src/shared/protocol.ts');
const { bondIds, bondRules } = await repoImport('src/shared/summoner-bond.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');

const [transport, fitting, outcome, supplied, audience = 'public', difficulty = 'normal'] = process.argv.slice(2);
assert(PROTOCOL === 100 && ['worker', 'peer'].includes(transport) && ['entry', 'close', 'homeward'].includes(fitting) && outcome);
assert(['testing', 'public'].includes(audience) && ['normal', 'baby'].includes(difficulty));
const setup = { mode: fitting === 'entry' ? 'short' : 'standard', difficulty, arenaSelection: 'route', openingArenaId: 'gatehouse',
  freePlay: { openingBossId: 'constable', variant: 'normal', seed: 73 } };
const playerIn = (view, id) => view?.players.find(player => player.id === id);
const cueFor = (view, id) => view?.classCues.find(cue => cue.kind === 'summoner-bond' && cue.owner === id);
const state = () => ({ events: [], observed: new Map(), cues: new Map() });

function observeCues(receiver, view) {
  for (const cue of view.classCues) if (cue.kind === 'summoner-bond' && !receiver.has(cue.id)) receiver.set(cue.id, cue);
}
async function until(check, detail, limit = 6000) {
  const end = Date.now() + limit;
  while (!check()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(12);
  }
}

async function play(adapter) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const current = playerIn(view(), adapter.id); assert(current); return current; };
  const owned = () => ownedBodies(view(), owner());
  const status = () => owner().kit.bond;
  const spent = () => owner().skills.reduce((sum, id) => sum + [...data.skills, ...data.specializationSkills].find(node => node.id === id).cost, 0);
  const bought = [];
  const probes = [];
  async function purchase(item) {
    assert((await adapter.purchase({ kind: 'skill', item })).ok, item);
    bought.push({ item, earned: spent() + owner().sp, clears: owner().progress.clears });
  }
  async function outfit() {
    for (const weapon of data.weapons.filter(row => row.classId === 'summoner').sort((a, b) => b.tier - a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind: 'weapon', item: weapon.id })).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) await adapter.purchase({ kind: 'upgrade', item });
    await adapter.purchase({ kind: 'supply', item: 'medkit' });
  }
  const ordinary = () => bondInput(view(), owner(), [...adapter.observed.values()], restRaidInput, false, false);
  const quiet = () => ({ ...ordinary(), q: false, e: false, ultimate: false, fire: false, reload: false, supply: -1 });
  const details = () => JSON.stringify({ fitting, boss: view().boss.id, phase: view().phase, tick: view().combatTick,
    owner: { health: owner().health, ammo: owner().ammo, bond: status(), mark: owner().kit.retinueMarkKey, clears: owner().progress.clears },
    units: owned().map(unit => [unit.kind, unit.health, unit.maxHealth, Math.round(Math.hypot(unit.x - owner().x, unit.y - owner().y))]), probes });
  assert.equal(owner().sp, 3);
  await purchase('summoner-bonds-1');
  await purchase(bondIds.entry);
  await until(() => !!status(), 'private owner action');
  assert.equal(owner().kit.retinueCapacity, 2);
  if (fitting !== 'entry') assert(!(await adapter.purchase({ kind: 'skill', item: bondIds[fitting] })).ok);
  await outfit();
  adapter.start();
  await until(() => view().phase === 'combat', 'opening fight');
  if (fitting !== 'entry') {
    const end = Date.now() + 135000;
    while (view().phase !== 'shop') {
      assert(Date.now() < end && !['victory', 'defeat'].includes(view().phase), details());
      if (view().phase === 'combat') { adapter.input(ordinary()); adapter.ally?.(true); }
      else if (['mutationVote', 'contractVote', 'secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears, 1);
    assert.equal(owner().sp + spent(), 5);
    await purchase(bondIds[fitting]);
    assert.equal((await adapter.purchase({ kind: 'skill', item: fitting === 'close' ? bondIds.homeward : bondIds.close })).reason, 'incompatibleItem');
    await outfit();
    await until(() => view().phase === 'combat', 'next encounter after earned fitting', 95000);
  }
  const firstClear = owner().progress.clears;
  console.log(JSON.stringify({ type: 'earned purchase', fitting, firstClear, boss: view().boss.id, bought }));

  adapter.pause(true);
  await until(() => adapter.paused(), 'pause acknowledged');
  const frozen = view().combatTick, pauseAmmo = owner().ammo;
  adapter.input({ technique2: true });
  await sleep(120);
  assert.equal(view().combatTick, frozen);
  assert.equal(owner().ammo, pauseAmmo);
  assert(!cueFor(view(), adapter.id));
  adapter.input({});
  adapter.pause(false);
  await until(() => !adapter.paused() && view().combatTick > frozen, 'resume acknowledged');

  const deadline = Date.now() + 90000;
  while (Date.now() < deadline && view().phase === 'combat') {
    const bond = status();
    const unit = bond?.stage === 'ready' ? owned().find(body => body.id === bond.unit) : undefined;
    const distance = unit && Math.hypot(unit.x - owner().x, unit.y - owner().y);
    if (!unit || (fitting === 'homeward' && distance < 65)) {
      adapter.input({ ...ordinary(), e: false });
      adapter.ally?.(true);
      await sleep(24);
      continue;
    }

    const before = { ammo: owner().ammo, health: unit.health, t: view().combatTick, x: unit.x, y: unit.y, mark: owner().kit.retinueMarkKey };
    const healthSamples = new Map(owned().map(body => [body.id, body.health]));
    const priorCues = new Set(adapter.cues.keys());
    const eventIndex = adapter.events.length;
    const seq = adapter.input({ ...quiet(), dodge: false, sprint: false, technique2: true });
    await until(() => owner().ack >= seq || view().phase !== 'combat', details);
    adapter.input(quiet());
    const accepted = status()?.recoveryAt > before.t;
    if (!accepted) continue;
    assert.equal(owner().ammo, before.ammo - bondRules.focus);
    let cue, mended = false, after, maxTravel = 0;
    const castDeadline = Date.now() + 5200;
    while (Date.now() < castDeadline && view().phase === 'combat') {
      cue ??= [...adapter.cues.values()].find(row => !priorCues.has(row.id) && row.owner === adapter.id);
      const current = cue && owned().find(body => body.id === cue.unit);
      if (current && cue.unit === unit.id) maxTravel = Math.max(maxTravel, Math.hypot(current.x - before.x, current.y - before.y));
      mended ||= adapter.events.slice(eventIndex).some(event => event.type === 'sound' && event.owner === adapter.id && event.id === 'summoner-bond-mend');
      if (current && mended && current.health > healthSamples.get(cue.unit)) { after = current.health; break; }
      if (status()?.stage === 'recovering' && view().combatTick > before.t + 7) break;
      const control = bondInput(view(), owner(), [...adapter.observed.values()], restRaidInput, false, true);
      adapter.input({ ...control, dodge: false, sprint: false, q: false, e: false, ultimate: false, supply: -1,
        fire: fitting === 'close' });
      adapter.ally?.(false);
      await sleep(24);
    }
    if (cue && after !== undefined && (fitting !== 'homeward' || maxTravel > 8)) {
      assert.equal(cue.until - cue.at, bondRules.duration);
      assert(cue.radius > 0 && cue.unit === unit.id);
      const witness = await adapter.witness?.(cue);
      return { passed: true, firstClear, boss: view().boss.id, fitting, bought, pauseRejected: true, attempts: probes,
        result: { cue, focusCost: bondRules.focus, before, after, repaired: after - healthSamples.get(cue.unit), maxTravel, witness } };
    }
    probes.push({ before, chosen: unit.id, cue, mended, after: after ?? null, maxTravel });
    console.log(JSON.stringify({ type: 'paid attempt', boss: view().boss.id, probe: probes.at(-1) }));
  }
  throw Error('No complete real-contact repair: ' + details());
}

async function runWorker() {
  let code = supplied && supplied !== '-' ? readFileSync(supplied, 'utf8') : undefined;
  if (code === undefined) {
    const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
    const output = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'],
      bundle: true, minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(audience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = output.outputFiles[0].text;
  }
  const wrapper = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" + code +
    "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(wrapper).toString('base64')), { execArgv: [] });
  const captured = state(), purchases = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', failure => { error = failure; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    if (message.type === 'error') error = Error(JSON.stringify(message));
    if (message.type === 'view') { view = message.view; observeCues(captured.cues, view); }
    if (message.type === 'events') remember(captured.events, captured.observed, message.events, view?.combatTick ?? 0);
    if (message.type === 'purchaseResult') purchases.set(message.id, message);
    if (message.type === 'pauseState') paused = message.value;
  });
  const send = message => worker.postMessage(message);
  try {
    await until(() => ready || error, 'whole worker ready');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: setup.freePlay.seed, maxPlayers: 1 }, name: 'Joss', classId: 'summoner' });
    await until(() => !!view || error, 'worker lobby');
    if (error) throw error;
    const result = await play({ ...captured, id: 'solo', view: () => { if (error) throw error; return view; },
      input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
      purchase: async request => {
        const id = 'bond-' + ++serial;
        send({ type: 'purchase', request: { ...request, id } });
        await until(() => confirmedPurchase(view, 'solo', request, purchases.get(id)), 'worker purchase response');
        return purchases.get(id);
      }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
      pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeer() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const transient = supplied && supplied !== '-' ? undefined : createGameServer({ audience });
  if (transient) await transient.server.listen(0, '127.0.0.1');
  const endpoint = transient ? 'http://127.0.0.1:' + transient.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), joss = new Session(endpoint);
  const ownerState = state(), hostState = state(), ownerReplies = [], hostReplies = [];
  let seq = 0, hostSeq = 0, leaks = 0;
  host.onView = view => {
    observeCues(hostState.cues, view);
    const raw = host.room?.state.players.get(joss.id)?.lineworkOwner;
    if (playerIn(view, joss.id)?.kit.bond !== undefined || raw && JSON.parse(raw).bond !== undefined) leaks++;
  };
  joss.onView = view => observeCues(ownerState.cues, view);
  joss.onEvents = batch => remember(ownerState.events, ownerState.observed, batch, joss.view?.combatTick ?? 0);
  host.onEvents = batch => remember(hostState.events, hostState.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = response => hostReplies.push(response);
  joss.onPurchase = response => ownerReplies.push(response);
  async function purchase(client, replies, request) {
    const i = replies.length;
    client.purchase(request);
    await until(() => confirmedPurchase(client.view, client.id, request, replies[i]), 'room purchase response');
    return replies[i];
  }
  try {
    await host.connect({ ...setup, name: 'Natural host', classId: 'soldier', maxPlayers: 2 });
    await joss.connect({ ...setup, name: 'Bonded Joss', classId: 'summoner', maxPlayers: 2 }, { roomId: host.room.roomId });
    await until(() => joss.view?.players.length === 2 && host.view?.players.length === 2, 'two real peers');
    assert.equal(joss.view.owner, host.id);
    assert.notEqual(joss.id, host.id);
    const hostPlayer = () => playerIn(host.view, host.id);
    for (const weapon of data.weapons.filter(row => row.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (hostPlayer().weapon === weapon.id || (await purchase(host, hostReplies, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const result = await play({ ...ownerState, id: joss.id, view: () => joss.view,
      input: props => { joss.input(inputFrame(joss.view, ++seq, props)); return seq; },
      purchase: request => purchase(joss, ownerReplies, request), start: () => host.start(),
      vote: index => { host.vote(index); joss.vote(index); }, pause: value => host.setMatchPaused(value), paused: () => joss.view?.matchPaused === true,
      ally: pressure => {
        const control = restRaidInput(host.view, hostPlayer(), [...hostState.observed.values()]);
        host.input(inputFrame(host.view, ++hostSeq, pressure ? control : { ...control, q: false, e: false, ultimate: false, fire: false }));
      },
      witness: async cue => {
        await until(() => hostState.cues.has(cue.id), 'peer sees the public tether');
        const seen = hostState.cues.get(cue.id);
        for (const key of ['id', 'owner', 'unit', 'radius', 'at', 'until', 'state']) assert.equal(seen[key], cue[key]);
        const raw = joss.room.state.players.get(joss.id)?.lineworkOwner;
        assert(raw && JSON.parse(raw).bond);
        assert.equal(leaks, 0);
        return { joinedNonHost: true, sharedCue: seen, ownerStateStayedPrivate: true };
      },
    });
    host.endMatch();
    await until(() => [host, joss].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'close joined proof room');
    return { ...result, endpoint, peers: 2 };
  } finally {
    await joss.close();
    await host.close();
    if (transient) await transient.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeer());
receipt(outcome, { ...result, protocol: PROTOCOL, contentRevision: CONTENT_REVISION, transport, audience, difficulty,
  driverSha256: sha256(readFileSync(new URL(import.meta.url))), policySha256: sha256(readFileSync(new URL('./bond-policy.mjs', import.meta.url))) });
console.log(JSON.stringify({ passed: true, transport, fitting, firstClear: result.firstClear, boss: result.boss, repair: result.result.repaired }));
