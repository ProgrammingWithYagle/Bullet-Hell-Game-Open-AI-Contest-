export const ownedBodies = (view, player) => (view.retinue ?? [])
  .filter(unit => unit.owner === player.id && unit.health > 0 && !unit.temporary);

export function bondInput(view, player, observed, restRaidInput, active, holdGather = false) {
  const input = restRaidInput(view, player, observed);
  const { bond, retinueCapacity, retinuePermanent } = player.kit;
  const bodies = ownedBodies(view, player);
  const summoning = player.qAt <= view.combatTick && retinuePermanent < retinueCapacity;
  const held = bond?.stage === 'linked' || bond?.stage === 'returning';
  const recalling = !holdGather && !held && player.eAt <= view.combatTick &&
    bodies.some(unit => unit.health < unit.maxHealth * 0.48);
  if (active && bond?.stage === 'ready' && !input.dodge && (input.supply ?? -1) < 0) {
    return { ...input, technique2: true, fire: false, q: false, e: false, ultimate: false, reload: false };
  }
  const linked = held && bodies.find(unit => unit.id === bond.unit);
  const range = bond?.fitting === 'close' ? 108 : bond?.fitting === 'homeward' ? 240 : 190;
  if (linked) {
    const dx = linked.x - player.x, dy = linked.y - player.y;
    const distance = Math.hypot(dx, dy);
    if (!input.dodge && distance > range * 0.68) {
      input.moveX = dx / distance;
      input.moveY = dy / distance;
    }
  }
  return { ...input, q: summoning, e: recalling };
}
