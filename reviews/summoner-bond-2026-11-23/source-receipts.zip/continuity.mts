import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { checkout, receipt, repoImport, sha256 } from './study-paths.mjs';
import { join } from 'node:path';

const { Game } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { bondIds, bondRules } = await repoImport('src/shared/summoner-bond.ts');
assert(PROTOCOL === 100 && process.argv[2]);

function match(fitting?: 'homeward') {
  const game = new Game({ mode: fitting ? 'raid' : 'short', seed: 41, openingArenaId: 'gatehouse', arenaSelection: 'fixed', maxPlayers: 2 });
  const player = game.addPlayer('joss', 'Joss', 'summoner');
  game.addPlayer('host', 'Mara', 'soldier');
  for (const item of ['summoner-bonds-1', bondIds.entry, ...(fitting ? [bondIds[fitting]] : [])]) {
    assert(game.transact(player.id, { id: item, kind: 'skill', item }).ok);
  }
  assert(game.start());
  const arena = structuredClone(game.arena);
  arena.obstacles = [];
  arena.lavaPits = [];
  Object.defineProperty(game, 'arena', { get: () => arena });
  Object.assign(game.boss, { x: 1400, y: 770, health: 100000, maxHealth: 100000, staggerUntil: 10000, deadline: 10000 });
  Object.assign(player, { x: 480, y: 500, oldX: 480, oldY: 500 });
  const tick = (control = {}) => {
    assert(game.submitInput(player.id, { ...idleInput(), sequence: player.ack + 1, clientTick: game.combatTick, aim: 0, ...control }));
    game.step(); return game.drainEvents();
  };
  const cue = () => game.classCues().find(item => item.kind === 'summoner-bond' && item.owner === player.id);
  const status = () => game.kitStatus(player.id).bond!;
  tick({ q: true });
  const bodies = game.retinue.owned(player.id);
  for (const unit of bodies) unit.attackAt = 10000;
  const patient = bodies[0];
  const wound = () => assert.equal(game.retinue.hit(patient.id, 28, game.combatTick), 28);
  return { game, player, arena, tick, cue, status, patient, wound };
}

function returning() {
  const f = match('homeward');
  Object.assign(f.patient, { x: 650, y: 500 });
  f.wound();
  f.tick({ technique2: true });
  const cue = f.cue();
  assert(cue && cue.unit === f.patient.id && cue.state === 'return');
  return f;
}

const reconnect = returning();
const recovery = reconnect.status().recoveryAt;
reconnect.game.setConnected(reconnect.player.id, false);
assert(!reconnect.cue() && reconnect.game.retinue.owned(reconnect.player.id).length === 0);
reconnect.game.setConnected(reconnect.player.id, true);
reconnect.player.qAt = 0;
reconnect.tick({ q: true });
const replacements = reconnect.game.retinue.owned(reconnect.player.id);
assert.equal(replacements.length, 2);
assert(replacements.every(unit => unit.id !== reconnect.patient.id && unit.health === unit.maxHealth));
assert.equal(reconnect.status().stage, 'recovering');
assert.equal(reconnect.status().recoveryAt, recovery);
assert(!reconnect.cue());

const phase = returning();
phase.game.boss.health = 0;
phase.tick();
assert.equal(phase.player.progress.clears, 1);
assert(!phase.cue() && phase.game.retinue.owned(phase.player.id).length === 0);
assert.equal(phase.status().recoveryAt, 0);

const wall = match('homeward');
Object.assign(wall.patient, { x: 635, y: 500 });
wall.arena.obstacles = [{ x: 537, y: wall.arena.bounds.y - 30, width: 30, height: wall.arena.bounds.height + 60 }];
wall.wound();
const health = wall.patient.health;
wall.tick({ technique2: true });
assert(wall.cue());
for (let i = 0; i <= bondRules.duration; i++) {
  assert(!wall.tick().some(event => event.type === 'sound' && event.id === 'summoner-bond-mend'));
  assert(wall.patient.x > 567);
}
assert(!wall.cue());
assert.equal(wall.patient.health, health);

const stale = match();
const enemy = stale.game.minions.spawn(899003, { kind: 'ordinary', x: 594, y: 500, health: 2000, speed: 0, radius: 16, damage: 1 }, stale.game.combatTick);
assert(enemy);
stale.tick({ fire: true });
while (!stale.game.kitStatus(stale.player.id).retinueMarkUntil && stale.game.combatTick < 50) stale.tick();
const until = stale.game.kitStatus(stale.player.id).retinueMarkUntil!;
assert(until > stale.game.combatTick);
while (stale.game.combatTick < until - 5) stale.tick();
Object.assign(stale.patient, { x: 535, y: 500 });
stale.wound();
const scratched = stale.patient.health;
stale.tick({ technique2: true });
assert(stale.cue());
while (stale.game.combatTick <= until + 1) stale.tick();
assert(!stale.cue());
assert.equal(stale.patient.health, scratched);

receipt(process.argv[2], { passed: true, protocol: PROTOCOL, contentRevision: CONTENT_REVISION,
  driverSha256: sha256(readFileSync(new URL(import.meta.url))),
  gameSha256: sha256(readFileSync(join(checkout, 'src/shared/game.ts'))),
  bondSha256: sha256(readFileSync(join(checkout, 'src/shared/summoner-bond.ts'))),
  cases: ['same-player reconnect keeps recovery and clears old entity and cue', 'encounter clear drops link, summoned bodies and recovery',
    'sealed route expires without crossing wall or repairing', 'actual issued beacon mark expires and ends the paid bond'] });
console.log('Four Bonded Companion continuity boundaries passed.');
