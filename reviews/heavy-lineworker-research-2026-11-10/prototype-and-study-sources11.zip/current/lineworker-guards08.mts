import fs from 'node:fs';import assert from 'node:assert/strict';import {pathToFileURL} from 'node:url';
import {root,stage,scope,read,write,sha,fingerprints,runtime} from './common.mjs';
process.chdir(root);assert(read(scope+'/frozen-verification.json').passed);
const research=stage,binding=read(research+'/game-study03-binding.json');
assert.equal(sha(fs.readFileSync(research+'/game-study03.mjs')),binding.bundleSha256);assert.equal(fingerprints().runtimeSourceSha256,runtime);
const before=fingerprints(),{Game}=await import(pathToFileURL(research+'/game-study03.mjs').href),{idleInput}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href),geometry=read('C:/Users/yigal/Documents/Codex/2026-11-05/continue-grave-accord-in-the-same/work/heavy-tethered-traverse-stage/linework-geometry27.json').rows.find((r:any)=>r.arena==='gatehouse'&&r.difficulty==='normal');
function fixture(mode='bare'){
 const g:any=new Game({mode:'short',difficulty:'normal',seed:41,maxPlayers:1,arenaSelection:'fixed',openingArenaId:'gatehouse'}),p=g.addPlayer('solo','Unregistered Lineworker guard study','heavy');p.totalSp=9;assert(g.transact(p.id,{id:'foundation',kind:'skill',item:'heavy-ordnance-1'}).ok);p.skills.push('heavy-linework-1');if(mode!=='bare')p.skills.push('heavy-linework-'+mode+'-1');assert(g.start());g.boss.staggerUntil=1e9;g.boss.deadline=1e9;
 const aim=Math.atan2(geometry.example.anchor.y-p.y,geometry.example.anchor.x-p.x);let sequence=0;const emitted:any[]=[];
 const status=()=>g.linework.status(p,g.combatTick),step=(input:any={})=>{assert(g.submitInput(p.id,{...idleInput(),sequence:++sequence,clientTick:g.combatTick,aim,...input}));g.step();for(const e of g.drainEvents())if(e.type==='shots')emitted.push(...e.shots.filter((s:any)=>s.owner===p.id).map((s:any)=>({...s,at:g.combatTick})));};
 const ammo=p.ammo;step({technique1:true});for(let i=0;i<20&&!status().lineworkUntil;i++)step();assert(status().lineworkUntil>g.combatTick,'actual physical attachment');assert.equal(p.ammo,ammo-1);return{g,p,aim,step,status,emitted,ammo};
}
const results:any[]=[];
const run=(label:string,fn:()=>unknown)=>{try{const details=fn();results.push({label,passed:true,details});}catch(e){results.push({label,passed:false,error:String(e),stack:(e as Error).stack});}};
for(const mode of ['bare','yoke','sheave'])run(mode+' actual primary-versus-lateral handling',()=>{
 const f=fixture(mode),original=f.status(),from={x:f.p.x,y:f.p.y},tangent={x:-Math.sin(f.aim),y:Math.cos(f.aim)};f.step({technique2:true});const anchorShots=f.emitted.length;
 for(let i=0;i<8;i++)f.step({aim:f.aim+Math.PI/2,moveX:tangent.x,moveY:tangent.y,fire:true});
 const after=f.status(),lateral=(f.p.x-from.x)*tangent.x+(f.p.y-from.y)*tangent.y,primary=f.emitted.length-anchorShots;
 assert(after.lineworkActive);assert.equal(after.lineworkUntil,original.lineworkUntil);assert.equal(after.lineworkRecovery,original.lineworkRecovery);
 if(mode==='yoke'){assert(primary>0);assert(Math.abs(lateral)<1);}else{assert.equal(primary,0);assert(lateral>5);}
 return{mode,primaryProjectiles:primary,actualLateralMovement:lateral,originalUntil:original.lineworkUntil,afterUntil:after.lineworkUntil,ammoBefore:f.ammo,ammoAfter:f.p.ammo,rawProposedOwnership:true};
});
for(const mode of ['bare','sheave'])run(mode+' payout and fitting dependency',()=>{
 const f=fixture(mode),original=f.status(),away={x:-Math.cos(f.aim),y:-Math.sin(f.aim)};for(let i=0;i<3;i++)f.step({moveX:away.x,moveY:away.y});const paidOut=f.status();
 if(mode==='bare')assert.equal(paidOut.lineworkUntil,0);else{assert.equal(paidOut.lineworkUntil,original.lineworkUntil);f.step({technique2:true});assert(f.status().lineworkActive);assert.equal(f.status().lineworkUntil,original.lineworkUntil);f.p.skills=f.p.skills.filter((id:string)=>id!=='heavy-linework-sheave-1');f.step();assert.equal(f.status().lineworkUntil,0);}
 assert.equal(f.status().lineworkRecovery,original.lineworkRecovery);assert.equal(f.p.ammo,f.ammo-1);return{mode,original,paidOut,after:f.status(),noRoundRefund:true,noClockReset:true};
});
for(const action of ['dodge','reload','ultimate'])for(const admitted of [false,true])run((admitted?'admitted ':'blocked ')+action+' retains issued admission authority',()=>{
 const f=fixture(),original=f.status();f.step({technique2:true});assert(f.status().lineworkActive);
 // Explicit controlled admission states. These are not earned-play observations.
 if(!admitted){if(action==='dodge'){f.p.dodgeAt=f.g.combatTick+1000;f.p.dodgeCharges=0;}if(action==='reload')f.p.ammo=f.g.stats(f.p).magazine;if(action==='ultimate')f.p.ultimateAt=f.g.combatTick+1000;}
 f.step({[action]:true});const actual=f.status();
 if(admitted)assert.equal(actual.lineworkUntil,0,'admitted interruption must release unpaid line');else assert.equal(actual.lineworkUntil,original.lineworkUntil,'rejected issued action must preserve the existing line');
 assert.equal(actual.lineworkRecovery,original.lineworkRecovery);return{action,admitted,originalUntil:original.lineworkUntil,actualUntil:actual.lineworkUntil,controlledAdmissionFixture:true};
});
run('separate C releases unpaid work and retains actual cartridge/recovery',()=>{const f=fixture(),original=f.status();f.step({technique1:true});assert.equal(f.status().lineworkUntil,0);assert.equal(f.status().lineworkRecovery,original.lineworkRecovery);assert.equal(f.p.ammo,f.ammo-1);return{originalRecovery:original.lineworkRecovery,ammoAfter:f.p.ammo};});
assert.deepEqual(fingerprints(),before);const report={studiedAt:new Date().toISOString(),registered:false,canonicalFilesChanged:false,onlineProof:false,countsAs2211Tests:false,prototypeSourceBase:binding.sourceBase,copiedGameBundleSha256:binding.bundleSha256,candidate03Sha256:binding.candidateSha256,runnerSha256:sha(fs.readFileSync(new URL(import.meta.url))),cases:results.length,pass:results.filter(r=>r.passed).length,fail:results.filter(r=>!r.passed).length,results,limits:['Unregistered copied-Game raw-ownership controlled fixtures. Actual paid physical attachment/motor/primary/body movement run against current real Gatehouse cover; boss attacks are explicitly held. No canonical card/purchase/earned progression/online checkpoint/acceptance exists.','Blocked-action fixtures explicitly set ordinary recovery or magazine to make admission unavailable. Failures are preserved and block any admission decision; no gameplay deadline/content/source is changed.','Human/rendered/device/language/listening/motion/final-balance and live-pressure assessment remain open.']};write(stage+'/lineworker-guards08.json',report);console.log(JSON.stringify({studied:true,registered:false,cases:report.cases,pass:report.pass,fail:report.fail,results:results.map(r=>({label:r.label,passed:r.passed,error:r.error}))}));
