import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {root,sha,write,fingerprints} from './common.mjs';
const stage=path.dirname(fileURLToPath(import.meta.url)),require=createRequire(root+'/package.json'),{build}=require('esbuild');
process.chdir(root);const before=fingerprints(),raw=fs.readFileSync('src/shared/game.ts');
assert.equal(before.runtimeSourceSha256,'c213467e0877fce574552b98139e4171a71ad4430069102a880db46c65f86de8');
let text=raw.toString('utf8');const patches=[];
function one(a,b){assert.equal(text.split(a).length,2,a.slice(0,120));text=text.replace(a,b);patches.push(a.slice(0,110));}
text=`import{HeavyLineworkCandidate,lineworkIds,type LineworkContext}from ${JSON.stringify(stage+'/linework-candidate03.mts')};\n`+text;
one('  readonly traverse = new HeavyTraverse();','  readonly traverse = new HeavyTraverse();\n  readonly linework = new HeavyLineworkCandidate();');
one('const sk = skillFor(id,p.classId)!;',"const sk = (skillFor(id,p.classId)??(p.classId==='heavy'&&Object.values(lineworkIds).includes(id as any)?{effects:{}}:undefined))!;");
one('kitStatus(id:string){return {...this.classKits.status(id,this.combatTick),',"kitStatus(id:string){return {...this.classKits.status(id,this.combatTick),...(this.players.get(id)?.classId==='heavy'&&this.players.get(id)?.skills.includes(lineworkIds.entry)?this.linework.status(this.players.get(id)!,this.combatTick):{}),");
one('    this.traverse.reconcile(this.traverseAuthority());','    this.traverse.reconcile(this.traverseAuthority());\n    this.linework.reconcile(this.roster(),this.lineworkContext());');
one('    this.traverse.beforeMove(p,this.traverseContext());','    this.traverse.beforeMove(p,this.traverseContext());\n    this.linework.beforeMove(p,this.lineworkContext());');
one("    const footwork=p.classId==='soldier'",`    const haul=this.linework.force(p,this.lineworkContext(),dash?0:speed/(p.sprinting?mobilityRules.sprintMultiplier:1));
    const haulLength=Math.hypot(haul.x,haul.y);if(haul.yoke&&haulLength>1e-9){const projection=(mx*haul.x+my*haul.y)/haulLength;mx=haul.x/haulLength*projection;my=haul.y/haulLength*projection;}
    const footwork=p.classId==='soldier'`);
one('traverseRecoil.x + environment.x','traverseRecoil.x + haul.x + environment.x');
one('traverseRecoil.y + environment.y','traverseRecoil.y + haul.y + environment.y');
one('    p.y = next.y;\n    if(p.classId', '    p.y = next.y;\n    this.linework.afterMove(p,this.lineworkContext());\n    if(p.classId');
one("if(p.classId==='heavy'&&i.technique1){if(p.skills.includes(traverseIds.entry))", "if(p.classId==='heavy'&&i.technique1){if(p.skills.includes(lineworkIds.entry))this.linework.cast(p,this.lineworkContext());else if(p.skills.includes(traverseIds.entry))");
assert.equal(text.split('!this.traverse.blocksPrimary(p.id,now)').length,3);text=text.replaceAll('!this.traverse.blocksPrimary(p.id,now)','!this.traverse.blocksPrimary(p.id,now) && !this.linework.blocksPrimary(p.id,now)');
one("if(p.classId==='heavy')this.traverse.beforeAbility(p,slot,this.traverseContext());","if(p.classId==='heavy'){this.traverse.beforeAbility(p,slot,this.traverseContext());this.linework.beforeAbility(p,slot);}");
one('    this.traverse.forget(s.id);','    this.traverse.forget(s.id);\n    this.linework.forget(s.id);');
one('      if(this.flak.has(s.id)){',"      if(this.linework.has(s.id)){const alive=this.linework.advance(s,{tick:this.combatTick,scope:this.lineworkContext().scope,owner:this.players.get(s.owner),bounds:this.arena.bounds,obstacles:fixedObstacles,masonry:this.arena.obstacles,body:(from,to,window)=>this.grenadierBody(from,to,s.radius,window)});if(!alive)this.removeShot(s);continue;}\n      if(this.flak.has(s.id)){");
const clearCount=text.split('this.traverse.clear();').length-1;assert(clearCount>=2);text=text.replaceAll('this.traverse.clear();','this.traverse.clear();this.linework.clear();');
one('  private traverseContext():TraverseContext',`  private lineworkContext():LineworkContext{return{tick:this.combatTick,scope:this.settings.runId+':'+this.encounter+':'+this.currentArenaId,stats:p=>this.stats(p),canEmit:()=>this.canEmitShots('friendly',1),shoot:(p,speed,radius,seconds)=>this.emitShot(p.id,p.x,p.y,p.aim,speed,0,radius,0,seconds),shot:id=>this.shots.get(id),remove:s=>this.removeShot(s),obstacles:this.obstacles,masonry:this.arena.obstacles,sound:(p,id,point=p)=>this.events.push({type:'sound',id,owner:p.id,x:point.x,y:point.y})};}
  private traverseContext():TraverseContext`);
one('      p.dodgeControlUntil=p.dashUntil;','      p.dodgeControlUntil=p.dashUntil;\n      if(p.classId==='heavy')this.linework.interrupt(p.id);');
one('  private reload(p: Player) {','  private reload(p: Player) {\n    if(p.classId==='heavy')this.linework.interrupt(p.id);');
const output=stage+'/game-study03.mjs';assert(!fs.existsSync(output));
await build({stdin:{contents:text,resolveDir:root+'/src/shared',sourcefile:'game-linework-study03.ts',loader:'ts'},bundle:true,platform:'node',format:'esm',target:'node24',outfile:output,logLevel:'silent'});
assert.deepEqual(fingerprints(),before);
write(stage+'/game-study03-binding.json',{builtAt:new Date().toISOString(),sourceBase:'dd2ae752279d3b2f31b6b4c8961a3b5682a8e1d2',runtimeOriginSource:'30fbfefaa66faabd93416dc31e27310149df5fed',originalPrototype02BundleSha256:'7ea14bd9ca65daa519b067650d2c1aea384e9f4748b2072d18c83d53b7de990a',...before,
  canonicalGameSha256:sha(raw),derivedGameSha256:sha(text),candidateSha256:sha(fs.readFileSync(stage+'/linework-candidate03.mts')),bundleSha256:sha(fs.readFileSync(output)),
  registered:false,canonicalFilesWritten:false,onlineProof:false,countsAs2211Tests:false,controlledProposedRawOwnershipOnly:true,virtualCatalogUnchanged:true,
  proposedIdsAreNotCanonicalPurchases:true,proposedCheckpointsMustNeverBeImportedIntoCurrentOrOnlineSource:true,patches,phaseCleanupCalls:clearCount,
  valueAcceptancePending:true});
console.log(JSON.stringify({built:true,registered:false,canonicalSourceAndTestsUnchanged:true,controlledProposedOwnershipOnly:true,patches:patches.length}));
