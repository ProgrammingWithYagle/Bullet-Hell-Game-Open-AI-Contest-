import fs from 'node:fs';import assert from 'node:assert/strict';
import {stage,write,sha} from './common.mjs';
const original=fs.readFileSync(stage+'/build-study03.mjs','utf8');let lines=original.split('\n'),changes=0;
for(let i=0;i<lines.length;i++){
 if(lines[i].startsWith("one('      p.dodgeControlUntil=p.dashUntil;'")){lines[i]='one('+JSON.stringify('      p.dodgeControlUntil=p.dashUntil;')+','+JSON.stringify("      p.dodgeControlUntil=p.dashUntil;\n      if(p.classId==='heavy')this.linework.interrupt(p.id);")+');';changes++;}
 if(lines[i].startsWith("one('  private reload(p: Player) {'")){lines[i]='one('+JSON.stringify('  private reload(p: Player) {')+','+JSON.stringify("  private reload(p: Player) {\n    if(p.classId==='heavy')this.linework.interrupt(p.id);")+');';changes++;}
}assert.equal(changes,2);const text=lines.join('\n');fs.writeFileSync(stage+'/build-study04.mjs',text,{flag:'wx'});write(stage+'/prototype-builder-syntax08.json',{preparedAt:new Date().toISOString(),originalFile:'build-study03.mjs',originalSha256:sha(original),originalSyntaxFailurePreserved:true,originalGameplayCasesExecuted:0,correctedFile:'build-study04.mjs',correctedSha256:sha(text),change:'Use proper JavaScript string literal quoting for the two admitted-action hooks; no prototype/rules change.'});console.log('Corrected builder quoting in a separate file; failed source preserved.');
