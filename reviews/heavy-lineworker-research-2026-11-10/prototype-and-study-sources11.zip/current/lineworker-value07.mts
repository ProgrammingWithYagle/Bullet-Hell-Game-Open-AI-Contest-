import {gzipSync} from 'node:zlib';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {root,stage,scope,read,sha,write,fingerprints,runtime} from './common.mjs';
process.chdir(root);
// This research cannot execute until the requested current proof is closed.
const closed=read(scope+'/frozen-verification.json');assert(closed.passed);
const research='C:/Users/yigal/Documents/Codex/2026-11-05/continue-grave-accord-in-the-same/work/heavy-lineworker-stage';
const binding=read(research+'/game-study02-binding.json');
assert.equal(binding.runtimeSourceSha256,runtime);assert.equal(sha(fs.readFileSync(research+'/game-study02.mjs')),binding.bundleSha256);assert.equal(sha(fs.readFileSync(research+'/linework-candidate02.mts')),binding.candidateSha256);
assert.equal(sha(fs.readFileSync('src/shared/game.ts')),binding.canonicalGameSha256);
const arrivalRadius=9;
const before=fingerprints(),{Game,data}=await import(pathToFileURL(research+'/game-study02.mjs').href),{idleInput}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href);
const geometry=read('C:/Users/yigal/Documents/Codex/2026-11-05/continue-grave-accord-in-the-same/work/heavy-tethered-traverse-stage/linework-geometry27.json');
const policies=['walk','sprint','dodge','haul-bare','haul-yoke','haul-sheave'];
const rows:any[]=[];
for(const sample of geometry.rows)for(const policy of policies){
 const game:any=new Game({mode:'short',difficulty:sample.difficulty,seed:41,maxPlayers:1,openingArenaId:sample.arena,arenaSelection:'fixed'}),p=game.addPlayer('solo','Controlled unregistered hauling study','heavy');
 // Equal labelled controlled shop budget for actual issued Sprint in every arm.
 // Proposed entry/fitting ownership is raw research, never a canonical purchase.
 p.totalSp=9;
 for(const item of ['heavy-ordnance-1','general-sprint'])assert(game.transact(p.id,{id:'study-'+item,kind:'skill',item}).ok);
 const hauling=policy.startsWith('haul-');if(hauling)p.skills.push('heavy-linework-1');if(policy==='haul-yoke')p.skills.push('heavy-linework-yoke-1');if(policy==='haul-sheave')p.skills.push('heavy-linework-sheave-1');
 assert(game.start());
 const spawn={x:p.x,y:p.y};assert(Math.hypot(spawn.x-sample.spawn.x,spawn.y-sample.spawn.y)<1e-6);
 // The comparison isolates actual Game movement/time/cost. The ordinary boss
 // stays at its real location/body but its attack director is explicitly held.
 game.boss.staggerUntil=1e9;game.boss.deadline=1e9;
 const target=sample.example.target,aim=Math.atan2(sample.example.anchor.y-p.y,sample.example.anchor.x-p.x),initialAmmo=p.ammo,initialStamina=p.sprintStamina;
 let sequence=0,reached:number|null=null,tightReached:number|null=null,attachedAt:number|null=null,engagedAt:number|null=null,primaryShots=0,anchorShotId:number|null=null;
 const trace:any[]=[];
 for(let tick=1;tick<=150;tick++){
  const status=game.linework.status(p,game.combatTick),distance=Math.hypot(target.x-p.x,target.y-p.y),move=distance>1?{moveX:(target.x-p.x)/distance,moveY:(target.y-p.y)/distance}:{};
  const input:any={...idleInput(),sequence:++sequence,clientTick:game.combatTick,aim,...move};
  if(hauling&&tick===1){input.technique1=true;input.moveX=input.moveY=0;}
  if(hauling&&status.lineworkUntil>game.combatTick&&!attachedAt)attachedAt=game.combatTick;
  if(hauling&&attachedAt!==null&&engagedAt===null){input.technique2=true;engagedAt=game.combatTick+1;}
  if(policy==='sprint')input.sprint=true;
  if(policy==='dodge'&&tick===1)input.dodge=true;
  assert(game.submitInput(p.id,input));game.step();
  for(const e of game.drainEvents())if(e.type==='shots')for(const s of e.shots)if(s.owner===p.id){if(hauling&&anchorShotId===null)anchorShotId=s.id;else primaryShots++;}
  const after=game.linework.status(p,game.combatTick),d=Math.hypot(target.x-p.x,target.y-p.y);
  if(tightReached===null&&d<=2)tightReached=game.combatTick;
  if(reached===null&&d<=arrivalRadius)reached=game.combatTick;
  trace.push({tick:game.combatTick,x:p.x,y:p.y,distance:d,ammo:p.ammo,health:p.health,sprintStamina:p.sprintStamina,dodgeCharges:p.dodgeCharges,active:after.lineworkActive,until:after.lineworkUntil,paidLength:after.lineworkPaidLength});
 }
 const final=game.linework.status(p,game.combatTick);
 rows.push({arena:sample.arena,difficulty:sample.difficulty,policy,registered:false,controlledBudget:9,actualIssuedPurchases:['heavy-ordnance-1','general-sprint'],proposedRawOwnership:hauling?p.skills.filter((s:string)=>s.startsWith('heavy-linework')):[],spawn,target,actualCurrentSolids:game.obstacles.length,quietBossAttackDirector:true,bossBodyRetained:true,initialAmmo,finalAmmo:p.ammo,actualRoundCost:initialAmmo-p.ammo,initialStamina,finalStamina:p.sprintStamina,targetReachedTick:reached,originalTwoPixelArrivalTick:tightReached,arrivalRadius,attachedAt,engagedAt,anchorShotId,primaryShots,finalRecovery:final.lineworkRecovery,finalLineUntil:final.lineworkUntil,finalHealth:p.health,trace});
}
assert.deepEqual(fingerprints(),before);
const comparisons=geometry.rows.map((s:any)=>{const group=rows.filter(r=>r.arena===s.arena&&r.difficulty===s.difficulty),get=(p:string)=>group.find(r=>r.policy===p);return{arena:s.arena,difficulty:s.difficulty,walkTicks:get('walk').targetReachedTick,sprintTicks:get('sprint').targetReachedTick,dodgeThenWalkTicks:get('dodge').targetReachedTick,bareHaulTicks:get('haul-bare').targetReachedTick,yokeHaulTicks:get('haul-yoke').targetReachedTick,sheaveHaulTicks:get('haul-sheave').targetReachedTick,bareAnchorAdmitted:get('haul-bare').anchorShotId!==null,bareAttached:get('haul-bare').attachedAt!==null,bareRoundCost:get('haul-bare').actualRoundCost};});
const archive=stage+'/lineworker-value07-traces.json.gz',raw=Buffer.from(JSON.stringify({rows}));fs.writeFileSync(archive,gzipSync(raw),{flag:'wx'});
const result={fullTraceArchive:{file:'lineworker-value07-traces.json.gz',sha256:sha(fs.readFileSync(archive)),uncompressedSha256:sha(raw),ticksPerPolicy:150,all216PerTickTrajectoriesRetained:true},arrivalRadius:9,originalStudy03Preserved:true,analysisCorrection:'A two-pixel point test aliased discrete movement: Sprint and hauling could oscillate near the intended point without entering that tiny target. This new separate run retains every tick and measures first entry into a fixed actual-body-radius9px approach disk, while preserving original2px observations, identical150tick clocks and original input policy. It does not change gameplay.',studiedAt:new Date().toISOString(),registered:false,onlineProof:false,canonicalFilesChanged:false,countsAs2211Tests:false,sourceRuntimeSha256:runtime,currentTestSnapshotSha256:before.sourceSnapshotSha256,prototypeSourceBase:binding.sourceBase,prototypeOriginalTestSnapshotSha256:binding.sourceSnapshotSha256,copiedGameBundleSha256:binding.bundleSha256,candidate02Sha256:binding.candidateSha256,runnerSha256:sha(fs.readFileSync(new URL(import.meta.url))),cases:rows.length,comparisons,rows:rows.map(({trace,...r})=>r),limits:['Controlled actual copied-Game movement/cost comparison only. The216arms span36real runtime arenas/difficulties and compare walking, actually purchased issued Sprint, actual dodge and three proposed raw-owned hauling modes.','Equal controlled9SP budgets buy the issued foundation/Sprint. Proposed Lineworker ids are unregistered raw study ownership, not catalog cards, real purchases, normal earned progression or online proof. No proposed checkpoint is created or imported.','The real boss body/location and actual cover/lava remain; the boss attack director/deadline is explicitly held for a movement comparison. This is not live safety, combat advantage, final balance, human enjoyment or class completion.','Further actual firing-versus-steering, Sheave payout, interruptions, owner/weapon/cover loss, pool reuse, phase cleanup and live-pressure trials are required before deciding on any canonical admission.']};
assert.equal(result.cases,216);write(stage+'/lineworker-value07.json',result);console.log(JSON.stringify({studied:true,registered:false,cases:result.cases,comparisons}));
