import {DT,HZ,type Shot,type Vec} from '../../../../../../OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)/src/shared/protocol.ts';
import {segmentRect,type Rect} from '../../../../../../OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)/src/shared/geometry.ts';
import type {Player,Stats} from '../../../../../../OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)/src/shared/game.ts';
import type {MotionWindow} from '../../../../../../OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)/src/shared/motion-window.ts';

// UNREGISTERED study ids/rules. No current catalog ownership or online authority is created.
export const lineworkIds={entry:'heavy-linework-1',yoke:'heavy-linework-yoke-1',sheave:'heavy-linework-sheave-1'} as const;
export const proposedLineworkRules={speed:900,radius:3,flightTicks:20,lineTicks:150,cooldown:8,maximumLength:600,bodyStop:10,slack:2} as const;
type Mode='bare'|'yoke'|'sheave';
type Flight={id:number;owner:string;weapon:string;scope:string;born:number;sequence:number;until:number;lineUntil:number;cancelled:boolean};
type Connection={owner:string;weapon:string;scope:string;origin:Vec;normal:Vec;wall:Rect;at:number;until:number;initialLength:number;paidLength:number;active:boolean;mode:Mode;commandAt:number;commandSequence:number;requiresFitting?:string};
export type LineworkContext={tick:number;scope:string;stats(p:Player):Stats;canEmit():boolean;shoot(p:Player,speed:number,radius:number,seconds:number):Shot|undefined;shot(id:number):Shot|undefined;remove(s:Shot):void;obstacles:readonly Rect[];masonry:readonly Rect[];sound(p:Player,id:string,point?:Vec):void};
type FlightContext={tick:number;scope:string;owner:Player|undefined;bounds:Rect;obstacles:readonly Rect[];masonry:readonly Rect[];body(from:Vec,to:Vec,window:MotionWindow):number|null};
const owned=(p:Player|undefined):p is Player=>!!p&&p.classId==='heavy'&&p.skills.includes(lineworkIds.entry);
const live=(p:Player|undefined):p is Player=>owned(p)&&p.connected&&!p.expired&&p.status==='active'&&p.health>0;
const mode=(p:Player):Mode=>p.skills.includes(lineworkIds.yoke)?'yoke':p.skills.includes(lineworkIds.sheave)?'sheave':'bare';
const sameRect=(a:Rect,b:Rect)=>a.x===b.x&&a.y===b.y&&a.width===b.width&&a.height===b.height;
export class HeavyLineworkCandidate {
  readonly recovery=new Map<string,number>();
  private flights=new Map<number,Flight>();
  private lines=new Map<string,Connection>();
  private casts=new Map<string,{at:number;sequence:number}>();
  clear(){this.recovery.clear();this.flights.clear();this.lines.clear();this.casts.clear();}
  has(id:number){return this.flights.has(id);}
  forget(id:number){this.flights.delete(id);}
  private valid(p:Player|undefined,f:Pick<Flight,'owner'|'weapon'>){return live(p)&&p.id===f.owner&&p.weapon===f.weapon;}
  private busy(p:Player,now:number){return !live(p)||p.reloadAt>now||p.dashUntil>now||p.overdriveUntil>now||p.channelUntil>now;}
  private cancelWork(owner:string){this.lines.delete(owner);for(const f of this.flights.values())if(f.owner===owner)f.cancelled=true;}
  private pointClear(p:Player,line:Connection,c:Pick<LineworkContext,'obstacles'|'masonry'|'scope'|'tick'>){
    if(c.scope!==line.scope||c.tick>=line.until||!this.valid(p,line)||line.requiresFitting&&!p.skills.includes(line.requiresFitting)||!c.masonry.some(w=>sameRect(w,line.wall)))return false;
    const length=Math.hypot(p.x-line.origin.x,p.y-line.origin.y),limit=line.mode==='sheave'&&!line.active?proposedLineworkRules.maximumLength:line.paidLength+proposedLineworkRules.slack;
    if(length>limit)return false;
    const end={x:line.origin.x+line.normal.x*1.25,y:line.origin.y+line.normal.y*1.25};
    return !c.obstacles.some(w=>segmentRect(p,end,w,1)!==null);
  }
  reconcile(players:readonly Player[],c:LineworkContext){
    for(const[id,f]of this.flights){const p=players.find(p=>p.id===f.owner);if(!this.valid(p,f)||f.scope!==c.scope){const shot=c.shot(id);if(shot)c.remove(shot);else this.flights.delete(id);}else if(p&&this.busy(p,c.tick))f.cancelled=true;}
    for(const[owner,line]of this.lines){const p=players.find(p=>p.id===owner);if(!p||this.busy(p,c.tick)||!this.pointClear(p,line,c))this.lines.delete(owner);}
  }
  cast(p:Player,c:LineworkContext){
    if(!owned(p))return false;
    const active=this.lines.has(p.id)||[...this.flights.values()].some(f=>f.owner===p.id&&!f.cancelled),last=this.casts.get(p.id);
    if(active){if(!last||c.tick<=last.at||p.input.sequence<=last.sequence||this.busy(p,c.tick))return false;this.cancelWork(p.id);c.sound(p,'linework-release');return true;}
    if(this.busy(p,c.tick)||p.input.reload||p.input.dodge||p.input.ultimate||p.ammo<1||c.tick<(this.recovery.get(p.id)??0)||!c.canEmit())return false;
    const shot=c.shoot(p,proposedLineworkRules.speed,proposedLineworkRules.radius,proposedLineworkRules.flightTicks/HZ);if(!shot)return false;
    p.ammo--;this.recovery.set(p.id,c.tick+Math.ceil(proposedLineworkRules.cooldown*c.stats(p).cooldown*HZ));this.casts.set(p.id,{at:c.tick,sequence:p.input.sequence});
    this.flights.set(shot.id,{id:shot.id,owner:p.id,weapon:p.weapon,scope:c.scope,born:c.tick,sequence:p.input.sequence,until:shot.expires,lineUntil:c.tick+proposedLineworkRules.lineTicks,cancelled:false});c.sound(p,'linework-shot');return true;
  }
  beforeMove(p:Player,c:LineworkContext){
    if(!owned(p))return;
    if(this.busy(p,c.tick)||p.input.reload||p.input.dodge||p.input.ultimate){this.cancelWork(p.id);return;}
    const line=this.lines.get(p.id);if(!line)return;if(!this.pointClear(p,line,c)){this.lines.delete(p.id);return;}
    if(!p.input.technique2||p.input.technique1||c.tick<=line.at||c.tick<=line.commandAt||p.input.sequence<=line.commandSequence)return;
    line.commandAt=c.tick;line.commandSequence=p.input.sequence;
    if(line.active){line.active=false;c.sound(p,'linework-brake');return;}
    if(line.mode==='sheave'&&Math.hypot(p.x-line.origin.x,p.y-line.origin.y)>line.initialLength+proposedLineworkRules.slack)line.requiresFitting=lineworkIds.sheave;
    line.paidLength=Math.hypot(p.x-line.origin.x,p.y-line.origin.y);line.active=true;
    if(line.mode==='yoke')line.requiresFitting=lineworkIds.yoke;c.sound(p,'linework-engage');
  }
  force(p:Player,c:LineworkContext,currentOrdinarySpeed:number){
    const line=this.lines.get(p.id);if(!line?.active||this.busy(p,c.tick)||!this.pointClear(p,line,c))return{x:0,y:0,yoke:false};
    const dx=line.origin.x+line.normal.x*proposedLineworkRules.bodyStop-p.x,dy=line.origin.y+line.normal.y*proposedLineworkRules.bodyStop-p.y,d=Math.hypot(dx,dy);
    if(d<=1){line.active=false;return{x:0,y:0,yoke:false};}
    const speed=Math.min(Math.max(0,currentOrdinarySpeed),d/DT);
    return{x:dx/d*speed,y:dy/d*speed,yoke:line.mode==='yoke'};
  }
  afterMove(p:Player,c:LineworkContext){const line=this.lines.get(p.id);if(!line)return;if(!this.pointClear(p,line,c)){this.lines.delete(p.id);return;}if(Math.hypot(p.x-line.origin.x,p.y-line.origin.y)<=proposedLineworkRules.bodyStop+1)line.active=false;}
  blocksPrimary(owner:string,now:number){return this.casts.get(owner)?.at===now||!!(this.lines.get(owner)?.active&&this.lines.get(owner)?.mode!=='yoke');}
  beforeAbility(p:Player,slot:string){if(!owned(p))return;if(slot==='ultimate')this.cancelWork(p.id);else if(slot==='q'){const line=this.lines.get(p.id);if(line)line.active=false;}}
  advance(s:Shot,c:FlightContext){
    const f=this.flights.get(s.id);if(!f||!this.valid(c.owner,f)||f.scope!==c.scope||c.tick>=f.until){this.flights.delete(s.id);return false;}
    const from={x:s.x,y:s.y},to={x:s.x+s.vx*DT,y:s.y+s.vy*DT},b=c.bounds,pad=s.radius;
    if(from.x<b.x+pad||from.y<b.y+pad||from.x>b.x+b.width-pad||from.y>b.y+b.height-pad)return false;
    let wall:{t:number;normal:Vec;rect:Rect}|undefined,bound=Infinity;
    for(const rect of c.obstacles){const hit=segmentRect(from,to,rect,pad);if(hit&&(!wall||hit.t<wall.t))wall={...hit,rect};}
    for(const[axis,lo,hi]of[['x',b.x+pad,b.x+b.width-pad],['y',b.y+pad,b.y+b.height-pad]] as const){const delta=to[axis]-from[axis];if(delta>0)bound=Math.min(bound,(hi-from[axis])/delta);else if(delta<0)bound=Math.min(bound,(lo-from[axis])/delta);}
    const body=c.body(from,to,{from:0,to:1})??Infinity,t=Math.min(wall?.t??Infinity,bound,body);
    if(t>1){s.x=to.x;s.y=to.y;return true;}
    const at={x:from.x+(to.x-from.x)*Math.max(0,t),y:from.y+(to.y-from.y)*Math.max(0,t)};s.x=at.x;s.y=at.y;
    if(!f.cancelled&&wall&&wall.t<=bound&&wall.t<body&&c.masonry.some(r=>sameRect(r,wall!.rect))&&c.owner&&!this.busy(c.owner,c.tick)){
      const origin={x:at.x-wall.normal.x*pad,y:at.y-wall.normal.y*pad},length=Math.hypot(c.owner.x-origin.x,c.owner.y-origin.y);
      if(length<=proposedLineworkRules.maximumLength){const line:Connection={owner:f.owner,weapon:f.weapon,scope:f.scope,origin,normal:{...wall.normal},wall:{...wall.rect},at:c.tick,until:f.lineUntil,initialLength:length,paidLength:length,active:false,mode:mode(c.owner),commandAt:c.tick,commandSequence:Math.max(f.sequence,c.owner.input.sequence)};
        if(this.pointClear(c.owner,line,c))this.lines.set(f.owner,line);}
    }
    this.flights.delete(s.id);return false;
  }
  status(p:Player,now:number){const line=this.lines.get(p.id),flight=[...this.flights.values()].find(f=>f.owner===p.id&&!f.cancelled);return{lineworkRecovery:this.recovery.get(p.id)??0,lineworkFlight:flight?.id??0,lineworkUntil:line?.until??0,lineworkAnchor:line?{...line.origin}:undefined,lineworkActive:line?.active??false,lineworkMode:line?.mode??mode(p),lineworkPaidLength:line?.paidLength??0,lineworkAt:line?.at??0,lineworkCommandSequence:line?.commandSequence??0,lineworkNow:now};}
}
