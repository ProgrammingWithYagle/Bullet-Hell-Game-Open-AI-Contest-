import fs from 'node:fs';import assert from 'node:assert/strict';import {stage,write} from './common.mjs';
const shared={classId:'heavy',branchId:'heavy-pathways',branchName:'Specializations',subbranchId:'heavy-linework-1',subbranchName:'Lineworker',subbranchNameKey:'pathway.heavy-linework-1.name',capstone:false,effects:{}};
const proposed=[
 {...shared,id:'heavy-linework-1',name:'Anchor Cartridge',nameKey:'skill.heavy-linework-1.name',sourceSkillId:'heavy-linework-1',grade:'D-',depth:1,cost:2,freePlaySpRequired:3,prerequisite:'heavy-ordnance-1',role:'active',description:'Spend one actual magazine round on a finite physical masonry anchor. A separate Action2 engages or brakes the hauling motor; Action1 releases the line. Cover, bodies and bounds stop its flight; living bodies and temporary constructs cannot become attachments. Hauling commits primary fire, preserves ordinary lateral walking and respects collision, slows and the original finite line/recovery. Choose Lineworker instead of Flak or Siege Gunner.'},
 {...shared,id:'heavy-linework-yoke-1',name:'Straight Yoke',nameKey:'skill.heavy-linework-yoke-1.name',sourceSkillId:'heavy-linework-yoke-1',grade:'D',depth:2,cost:2,freePlaySpRequired:5,prerequisite:'heavy-linework-1',role:'evolution',description:'Permit ordinary paid primary while hauling, but restrict ordinary walking to the current anchor approach axis. Manual aim remains your responsibility. A separate brake releases that steering commitment without refunding the anchor or resetting its original clocks. Choose this fitting instead of Open Sheave.'},
 {...shared,id:'heavy-linework-sheave-1',name:'Open Sheave',nameKey:'skill.heavy-linework-sheave-1.name',sourceSkillId:'heavy-linework-sheave-1',grade:'D',depth:2,cost:2,freePlaySpRequired:5,prerequisite:'heavy-linework-1',role:'evolution',description:'While braked, allow actual clear line to pay out up to its original600px maximum, then re-engage from that new approach. Keep lateral walking while hauling and keep primary committed. The same original deadline, one paid cartridge and recovery remain; losing a fitting after using its payout releases dependent work. Choose this fitting instead of Straight Yoke.'},
];
write(stage+'/linework-proposed-catalog27.json',{createdAt:new Date().toISOString(),registered:false,canonicalCatalogUnchanged:true,initialEntryAndFittingStudyOnly:true,noFixedPathwayMaximum:true,proposed});
let builder=fs.readFileSync(stage+'/build-study06.mjs','utf8');
builder=builder.replaceAll('game-study05','game-study06').replaceAll('game-linework-study05','game-linework-study06');
const insertion="const output=stage+'/game-study06.mjs';assert(!fs.existsSync(output));";
assert.equal(builder.split(insertion).length,2);
const shadow=`
one("import { conflictingSkill } from './skill-conflicts.ts';","import { conflictingSkill as issuedConflictingSkill } from './skill-conflicts.ts';");
const proposal=JSON.parse(fs.readFileSync(stage+'/linework-proposed-catalog27.json','utf8')).proposed;
text+='\\nexport function registerResearchCatalog(){const proposed='+JSON.stringify(proposal)+';for(const node of proposed){if(data.specializationSkills.some(s=>s.id===node.id))throw Error("Already research-registered");data.specializationSkills.push(node as any);allSkills.push(node as any);}return proposed;}\\n'+
 'function conflictingSkill(owned:readonly string[],candidate:string){const entries=["heavy-linework-1","heavy-flak-1","heavy-traverse-1"],fittings=["heavy-linework-yoke-1","heavy-linework-sheave-1"];return owned.find(id=>id!==candidate&&((entries.includes(candidate)&&entries.includes(id))||(fittings.includes(candidate)&&fittings.includes(id))))??issuedConflictingSkill(owned,candidate);}' ;
`;
builder=builder.replace(insertion,shadow+'\n'+insertion);
builder=builder.replace('controlledProposedRawOwnershipOnly:true,virtualCatalogUnchanged:true','controlledProposedRawOwnershipOnly:false,virtualCatalogUnchanged:false,researchRegistryOnly:true');
fs.writeFileSync(stage+'/build-study07.mjs',builder,{flag:'wx'});
console.log(JSON.stringify({prepared:true,canonicalCatalogWritten:false,researchRegistryOnly:true,cards:proposed.length}));
