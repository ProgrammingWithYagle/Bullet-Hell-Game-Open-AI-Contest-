import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {root,stage,scope,read,write,sha,fingerprints} from './common.mjs';
process.chdir(root);assert(read(scope+'/frozen-verification.json').passed);
const before=fingerprints(),binding=read(stage+'/game-study05-binding.json');
assert.equal(sha(fs.readFileSync(stage+'/game-study05.mjs')),binding.bundleSha256);
const {Game}=await import(pathToFileURL(stage+'/game-study05.mjs').href),{idleInput}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href);
const geometry=read('C:/Users/yigal/Documents/Codex/2026-11-05/continue-grave-accord-in-the-same/work/heavy-tethered-traverse-stage/linework-geometry27.json').rows.find((r:any)=>r.arena==='gatehouse'&&r.difficulty==='normal');
const results:any[]=[],traces:any[]=[];
function fixture(mode:string){
 const g:any=new Game({mode:'short',seed:41,difficulty:'normal',maxPlayers:1,arenaSelection:'fixed',openingArenaId:'gatehouse'}),p=g.addPlayer('solo','Controlled finite-line boundaries','heavy');
 p.totalSp=9;assert(g.transact(p.id,{id:'foundation',kind:'skill',item:'heavy-ordnance-1'}).ok);p.skills.push('heavy-linework-1');if(mode!=='bare')p.skills.push('heavy-linework-'+mode+'-1');assert(g.start());g.boss.staggerUntil=g.boss.deadline=1e9;
 const aim=Math.atan2(geometry.example.anchor.y-p.y,geometry.example.anchor.x-p.x),away={moveX:-Math.cos(aim),moveY:-Math.sin(aim)};let seq=0;
 const status=()=>g.linework.status(p,g.combatTick),trace:any[]=[];traces.push({mode,trace});
 const step=(input:any={})=>{assert(g.submitInput(p.id,{...idleInput(),sequence:++seq,clientTick:g.combatTick,aim,...input}));g.step();const s=status();trace.push({tick:g.combatTick,x:p.x,y:p.y,ammo:p.ammo,...s,actualDistance:s.lineworkAnchor?Math.hypot(p.x-s.lineworkAnchor.x,p.y-s.lineworkAnchor.y):null});};
 step({technique1:true});for(let n=0;n<20&&!status().lineworkUntil;n++)step();assert(status().lineworkUntil>g.combatTick);return{g,p,step,status,away,trace};
}
function run(label:string,fn:()=>unknown){try{results.push({label,passed:true,details:fn()});}catch(e){results.push({label,passed:false,error:String(e),stack:(e as Error).stack});}}
for(const mode of ['bare','yoke'])run(mode+' braking cannot ratchet the original finite cable into free payout',()=>{
 const f=fixture(mode),original=f.status(),anchor=original.lineworkAnchor;
 const smallAway={moveX:f.away.moveX*.25,moveY:f.away.moveY*.25};
 f.step(smallAway);
 for(let n=0;n<16&&f.status().lineworkUntil;n++){
  // Opposing ordinary walking cancels the motor displacement during engagement;
  // a later separate brake permits a small ordinary backstep within slack.
  f.step({technique2:true,...f.away});
  f.step({technique2:true,...smallAway});
 }
 const maxDistance=Math.max(...f.trace.map((t:any)=>t.actualDistance??0)),after=f.status();
 assert(maxDistance<=original.lineworkPaidLength+2+1e-6,'no Sheave purchase: brake/reengage must not manufacture payout beyond original slack; observed '+maxDistance+' from '+original.lineworkPaidLength);
 assert.equal(after.lineworkRecovery,original.lineworkRecovery);assert.equal(f.p.ammo,44);
 return{original,after,maxDistance,anchor,controlledOpposingInput:true};
});
run('Sheave finite maximum cannot grow through active brake/reengage slack',()=>{
 const f=fixture('sheave'),original=f.status(),smallAway={moveX:f.away.moveX*.25,moveY:f.away.moveY*.25};
 while(f.status().lineworkUntil&&Math.hypot(f.p.x-original.lineworkAnchor.x,f.p.y-original.lineworkAnchor.y)<598)f.step(smallAway);
 for(let n=0;n<5&&f.status().lineworkUntil;n++){f.step({technique2:true,...f.away});f.step({technique2:true,...smallAway});}
 const maxDistance=Math.max(...f.trace.map((t:any)=>t.actualDistance??0));
 assert(maxDistance<=600+1e-6,'the actual surviving line may never exceed its finite600px maximum; observed '+maxDistance);
 assert.equal(f.status().lineworkRecovery,original.lineworkRecovery);assert.equal(f.p.ammo,44);
 return{original,after:f.status(),maxDistance};
});
assert.deepEqual(fingerprints(),before);
const report={createdAt:new Date().toISOString(),registered:false,canonicalFilesChanged:false,onlineProof:false,countsAs2211Tests:false,prototype:'05',bundleSha256:binding.bundleSha256,runnerSha256:sha(fs.readFileSync(new URL(import.meta.url))),cases:results.length,pass:results.filter(r=>r.passed).length,fail:results.filter(r=>!r.passed).length,results,traces,limits:['Actual copied-Game input/movement/shot attachment with held boss attacks, raw proposed ownership and a controlled issued foundation purchase. No canonical or online checkpoint exists.','Opposing movement is submitted through actual normalized input. Intermediate frames and failures are retained; no input/position/clock is edited after the physical shot.']};
write(stage+'/lineworker-boundaries23.json',report);console.log(JSON.stringify({cases:report.cases,pass:report.pass,fail:report.fail,results:results.map(r=>({label:r.label,passed:r.passed,error:r.error}))}));
