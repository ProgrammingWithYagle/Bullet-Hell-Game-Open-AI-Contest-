import fs from 'node:fs';
import assert from 'node:assert/strict';
import {stage,sha,write} from './common.mjs';
const put=(name,text)=>fs.writeFileSync(stage+'/'+name,text,{flag:'wx'});
let candidate=fs.readFileSync(stage+'/linework-candidate04.mts','utf8');
function one(from,to){assert.equal(candidate.split(from).length,2,from);candidate=candidate.replace(from,to);}
one('if(length>limit)return false;','if(length>proposedLineworkRules.maximumLength||length>limit)return false;');
one('line.paidLength=Math.hypot(p.x-line.origin.x,p.y-line.origin.y);line.active=true;',"const length=Math.hypot(p.x-line.origin.x,p.y-line.origin.y);line.paidLength=line.mode==='sheave'?length:Math.min(line.paidLength,length);line.active=true;");
put('linework-candidate05.mts',candidate);
let builder=fs.readFileSync(stage+'/build-study05.mjs','utf8');
builder=builder.replaceAll('linework-candidate04.mts','linework-candidate05.mts').replaceAll('game-study04','game-study05').replaceAll('game-linework-study04','game-linework-study05');
assert(!builder.includes('candidate04')&&!builder.includes('game-study04'));
put('build-study06.mjs',builder);
for(const [input,output]of [['lineworker-boundaries22.mts','lineworker-boundaries23.mts'],['lineworker-guards19.mts','lineworker-guards24.mts'],['lineworker-lifecycle18.mts','lineworker-lifecycle25.mts'],['lineworker-value20.mts','lineworker-value26.mts']]){
 let text=fs.readFileSync(stage+'/'+input,'utf8').replaceAll('game-study04','game-study05').replaceAll('candidate04','candidate05').replaceAll("prototype:'04'","prototype:'05'").replaceAll(input.replace('.mts',''),output.replace('.mts',''));
 if(input==='lineworker-value20.mts')text=text.replaceAll('candidate04','candidate05');
 put(output,text);
}
write(stage+'/boundary23-preparation.json',{createdAt:new Date().toISOString(),registered:false,originalFailedResult:'lineworker-boundaries22.json',originalFailedResultSha256:sha(fs.readFileSync(stage+'/lineworker-boundaries22.json')),originalPrototype04Sha256:sha(fs.readFileSync(stage+'/linework-candidate04.mts')),candidate05Sha256:sha(Buffer.from(candidate)),change:'A bare/Yoke engagement can shorten its captured paid length but cannot enlarge it with repeated brake/slack. Every retained line also obeys the600px absolute maximum. Sheave alone may explicitly pay out within that same finite maximum and original deadline.',canonicalFilesWritten:false,proposedCheckpointCreated:false});
console.log(JSON.stringify({prepared:true,prototype:'05',canonicalFilesWritten:false}));
