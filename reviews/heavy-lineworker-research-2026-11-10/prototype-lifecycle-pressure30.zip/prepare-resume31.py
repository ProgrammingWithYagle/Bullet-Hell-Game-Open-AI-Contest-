from pathlib import Path
stage=Path(__file__).parent
text=(stage/'publish-research30.py').read_text(encoding='utf-8')
start=text.index("archive=scope/'prototype-lifecycle-pressure30.zip'")
end=text.index("cards=read('linework-proposed-catalog27.json')")
resume="""archive=scope/'prototype-lifecycle-pressure30.zip';members=[]
with zipfile.ZipFile(archive) as z:
    assert z.namelist()==names
    for name in names:assert z.read(name)==(stage/name).read_bytes()
for name in ['lineworker-lifecycle16.json','lineworker-lifecycle18.json','lineworker-boundaries22.json','lineworker-boundaries23.json','lineworker-guards24.json','lineworker-lifecycle25.json','lineworker-shop28.json','lineworker-value26.json','lineworker-pressure29.json']:
    assert (scope/name).read_bytes()==(stage/name).read_bytes()
assert (scope/trace['file']).read_bytes()==raw
with zipfile.ZipFile(archive,'a',compression=zipfile.ZIP_DEFLATED) as z:
    for name in ['prepare-resume31.py','resume-publish31.py']:
        assert name not in z.namelist();z.writestr(name,(stage/name).read_bytes())
with zipfile.ZipFile(archive) as z:
    for name in z.namelist():
        b=z.read(name);assert b==(stage/name).read_bytes();members.append({'member':name,'bytes':len(b),'sha256':sha(b)})
pressure=read('lineworker-pressure29.json');aggregates=[]
for policy in sorted({r['policy'] for r in pressure['rows']}):
    rows=[r for r in pressure['rows'] if r['policy']==policy]
    aggregates.append({'policy':policy,'arms':len(rows),'arrivedWithin9px':sum(r['targetReachedTick'] is not None for r in rows),'survivedToObservationEnd':sum(r['finalStatus']=='active' and r['finalHealth']>0 for r in rows),'actualRoundCost':sum(r['actualRoundCost'] for r in rows),'actualDamageDealt':sum(r['damageDealt'] for r in rows),'losses':[{'arena':r['arena'],'difficulty':r['difficulty'],'combatTicks':r['combatTicksObserved'],'phase':r['finalPhase'],'initialHealth':r['initialHealth'],'finalHealth':r['finalHealth']} for r in rows if r['finalHealth']<=0]})
"""
text=text[:start]+resume+text[end:]
text=text.replace("(root/'content/catalog.json').read_text()","(root/'content/catalog.json').read_text(encoding='utf-8')")
text=text.replace("'allRawMemberBytesVerified':True}","'allRawMemberBytesVerified':True,'publication30PartialWriteVerifiedBeforeResume':True,'publication30Error':'Default Windows cp1252 catalog decoding failed after archive and result copies; resume31 reads UTF-8. Original publisher source remains exact in this archive.'}")
(stage/'resume-publish31.py').open('x',encoding='utf-8',newline='\n').write(text)
print('Prepared checked UTF-8 resume; original publisher retained.')
