import{gzipSync}from'node:zlib';
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {root,stage,scope,read,sha,write,fingerprints,runtime} from './common.mjs';
process.chdir(root);
// This research cannot execute until the requested current proof is closed.
const closed=read(scope+'/frozen-verification.json');assert(closed.passed);
const research=stage;
const binding=read(research+'/game-study05-binding.json');
assert.equal(binding.runtimeSourceSha256,runtime);assert.equal(sha(fs.readFileSync(research+'/game-study05.mjs')),binding.bundleSha256);assert.equal(sha(fs.readFileSync(research+'/linework-candidate05.mts')),binding.candidateSha256);
assert.equal(sha(fs.readFileSync('src/shared/game.ts')),binding.canonicalGameSha256);
const before=fingerprints(),{Game,data}=await import(pathToFileURL(research+'/game-study05.mjs').href),{idleInput}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href);
const geometry=read('C:/Users/yigal/Documents/Codex/2026-11-05/continue-grave-accord-in-the-same/work/heavy-tethered-traverse-stage/linework-geometry27.json');
const policies=['walk','sprint','dodge','haul-bare','haul-yoke','haul-sheave','haul-yoke-fire'];
const rows:any[]=[];
for(const sample of geometry.rows)for(const policy of policies){
 const game:any=new Game({mode:'short',difficulty:sample.difficulty,seed:41,maxPlayers:1,openingArenaId:sample.arena,arenaSelection:'fixed'}),p=game.addPlayer('solo','Controlled unregistered hauling study','heavy');
 // Equal labelled controlled shop budget for actual issued Sprint in every arm.
 // Proposed entry/fitting ownership is raw research, never a canonical purchase.
 p.totalSp=9;
 for(const item of ['heavy-ordnance-1','general-sprint'])assert(game.transact(p.id,{id:'study-'+item,kind:'skill',item}).ok);
 const hauling=policy.startsWith('haul-');if(hauling)p.skills.push('heavy-linework-1');if(policy==='haul-yoke'||policy==='haul-yoke-fire')p.skills.push('heavy-linework-yoke-1');if(policy==='haul-sheave')p.skills.push('heavy-linework-sheave-1');
 assert(game.start());
 const spawn={x:p.x,y:p.y};assert(Math.hypot(spawn.x-sample.spawn.x,spawn.y-sample.spawn.y)<1e-6);
 // Actual ordinary boss movement, body, attacks and hazards remain enabled.
 // This short controlled route does not establish whole-run safety or balance.
 const initialBoss={id:game.boss.id,variant:game.boss.variant};const initialHealth=p.health;
 const target=sample.example.target,aim=Math.atan2(sample.example.anchor.y-p.y,sample.example.anchor.x-p.x),initialAmmo=p.ammo,initialStamina=p.sprintStamina;
 let sequence=0,reached:number|null=null,attachedAt:number|null=null,engagedAt:number|null=null,healthAtArrival:number|null=null,primaryShots=0,anchorShotId:number|null=null;
 const trace:any[]=[];
 for(let tick=1;tick<=150;tick++){
  if(game.phase!=="combat"||p.status!=="active")break;
  const status=game.linework.status(p,game.combatTick),distance=Math.hypot(target.x-p.x,target.y-p.y),move=distance>1?{moveX:(target.x-p.x)/distance,moveY:(target.y-p.y)/distance}:{};
  const input:any={...idleInput(),sequence:++sequence,clientTick:game.combatTick,aim,...move};
  if(hauling&&tick===1){input.technique1=true;input.moveX=input.moveY=0;}
  if(hauling&&status.lineworkUntil>game.combatTick&&!attachedAt)attachedAt=game.combatTick;
  if(hauling&&attachedAt!==null&&engagedAt===null){input.technique2=true;engagedAt=game.combatTick+1;}
  if(policy==='sprint')input.sprint=true;
  if(policy==='haul-yoke-fire'&&tick>1){input.fire=true;input.aim=Math.atan2(game.boss.y-p.y,game.boss.x-p.x);}
  if(policy==='dodge'&&tick===1)input.dodge=true;
  assert(game.submitInput(p.id,input));game.step();
  for(const e of game.drainEvents())if(e.type==='shots')for(const s of e.shots)if(s.owner===p.id){if(hauling&&anchorShotId===null)anchorShotId=s.id;else primaryShots++;}
  const after=game.linework.status(p,game.combatTick),d=Math.hypot(target.x-p.x,target.y-p.y);
  if(reached===null&&d<=9&&p.status==="active"&&p.health>0){reached=game.combatTick;healthAtArrival=p.health;}
  trace.push({tick:game.combatTick,x:p.x,y:p.y,distance:d,ammo:p.ammo,health:p.health,sprintStamina:p.sprintStamina,dodgeCharges:p.dodgeCharges,active:after.lineworkActive,until:after.lineworkUntil,paidLength:after.lineworkPaidLength});
 }
 const final=game.linework.status(p,game.combatTick);
 rows.push({arena:sample.arena,difficulty:sample.difficulty,policy,registered:false,controlledBudget:9,actualIssuedPurchases:['heavy-ordnance-1','general-sprint'],proposedRawOwnership:hauling?p.skills.filter((s:string)=>s.startsWith('heavy-linework')):[],spawn,target,actualCurrentSolids:game.obstacles.length,quietBossAttackDirector:false,bossBodyRetained:true,initialBoss,initialHealth,healthAtArrival,finalStatus:p.status,finalPhase:game.phase,damageDealt:p.damageDealt,combatTicksObserved:game.combatTick,initialAmmo,finalAmmo:p.ammo,actualRoundCost:initialAmmo-p.ammo,initialStamina,finalStamina:p.sprintStamina,targetReachedTick:reached,attachedAt,engagedAt,anchorShotId,primaryShots,finalRecovery:final.lineworkRecovery,finalLineUntil:final.lineworkUntil,finalHealth:p.health,trace});
}
assert.deepEqual(fingerprints(),before);
const comparisons=geometry.rows.map((s:any)=>{const group=rows.filter(r=>r.arena===s.arena&&r.difficulty===s.difficulty),get=(p:string)=>group.find(r=>r.policy===p);return{arena:s.arena,difficulty:s.difficulty,walkTicks:get('walk').targetReachedTick,sprintTicks:get('sprint').targetReachedTick,dodgeThenWalkTicks:get('dodge').targetReachedTick,bareHaulTicks:get('haul-bare').targetReachedTick,yokeHaulTicks:get('haul-yoke').targetReachedTick,sheaveHaulTicks:get('haul-sheave').targetReachedTick,bareAnchorAdmitted:get('haul-bare').anchorShotId!==null,bareAttached:get('haul-bare').attachedAt!==null,bareRoundCost:get('haul-bare').actualRoundCost};});
const archive=stage+'/lineworker-pressure21-traces.json.gz',raw=Buffer.from(JSON.stringify({rows})),prior=read(stage+'/lineworker-pressure21.json');assert.equal(sha(raw),prior.fullTraceArchive.uncompressedSha256,'All new prototype05 raw live-pressure rows/frames must match04');assert.equal(sha(fs.readFileSync(archive)),prior.fullTraceArchive.sha256);
const result={fullTraceArchive:{file:'lineworker-pressure21-traces.json.gz',sha256:sha(fs.readFileSync(archive)),uncompressedSha256:sha(raw),newPrototype05AllRawFramesMatch04:true,originalArchiveReusedAfterExactNewExecutionComparison:true},arrivalRadius:9,liveBossAttacksAndBodiesUnmodified:true,studiedAt:new Date().toISOString(),registered:false,onlineProof:false,canonicalFilesChanged:false,countsAs2211Tests:false,sourceRuntimeSha256:runtime,currentTestSnapshotSha256:before.sourceSnapshotSha256,prototypeSourceBase:binding.sourceBase,prototypeOriginalTestSnapshotSha256:binding.sourceSnapshotSha256,copiedGameBundleSha256:binding.bundleSha256,candidate05Sha256:binding.candidateSha256,runnerSha256:sha(fs.readFileSync(new URL(import.meta.url))),cases:rows.length,comparisons,rows:rows.map(({trace,...r})=>r),limits:['Controlled copied-Game live-pressure traversal only: seven input policies across36actual map/difficulty starts, at most150combat steps. Actual boss AI, bodies, hazards, cover and movement run without attack holds or health/position/hazard injection.','Equal9SPcontrolled shop budgets buy issued foundation/Sprint; proposed Lineworker ownership remains raw unregistered research, not canonical purchase/earned progression/online proof. No proposed checkpoint is created or imported.','One geometry-selected route and one seed/policy family do not rank builds or isolate outcomes. The extra Yoke/fire policy supplies manual aim toward the observed boss and pays actual primary rounds; the candidate itself has no target-selection/auto-aim behavior.','Survival, arrival, actual health loss, damage and ammunition are observations from short controlled traversals, not natural completed runs, equal power, human enjoyment or final balance. No class/game completion.']};
assert.equal(result.cases,252);write(stage+'/lineworker-pressure29.json',result);console.log(JSON.stringify({studied:true,registered:false,cases:result.cases,comparisons}));
