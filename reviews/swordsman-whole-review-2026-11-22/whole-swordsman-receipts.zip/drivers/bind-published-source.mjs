import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, relative } from 'node:path';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const here = path => new URL('./' + path, import.meta.url);
const [name, action] = process.argv.slice(2);
assert(/^checkout\d\d$/.test(name) && ['rebuild', 'record'].includes(action));
const expected = readJson(here('../swordsman-pursuit/game03.json'));
const source = readJson(here('../swordsman-pursuit/source-commit01.json'));
const summary = readJson(here('whole-summary01.json'));
assert(summary.passed && summary.protocol === 98 && summary.cases === 96 && summary.replays === 12);
assert(source.passed && source.protocol === 98 && source.checks === 7 && source.tests === 2912);
assert.equal(summary.revision, source.contentRevision);
assert.equal(sha256(readFileSync(here('../swordsman-pursuit/game03.mjs'))), expected.bundle);
assert.equal(summary.bundle, expected.bundle);

const fileBytes = path => readFileSync(join(checkout, path));
const tree = directory => readdirSync(join(checkout, directory), { withFileTypes: true })
  .flatMap(entry => {
    assert(!entry.isSymbolicLink());
    const path = directory + '/' + entry.name;
    return entry.isDirectory() ? tree(path) : [path];
  });
function fingerprint(paths) {
  const digest = createHash('sha256');
  for (const path of paths.sort()) digest.update(path + '\0').update(fileBytes(path));
  return digest.digest('hex');
}
const runtime = tree('src');
assert.equal(fingerprint([...runtime]), source.runtimeSourceSha256);
assert.equal(fingerprint([...runtime, ...tree('tests'), 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml',
  'tsconfig.json', 'vite.config.ts', 'index.html']), source.sourceSnapshotSha256);
for (const [path, expectedHash] of Object.entries(expected.inputs)) assert.equal(sha256(fileBytes(path)), expectedHash, path);

if (action === 'rebuild') {
  const entries = [
    "export { Game, data } from './src/shared/game.ts';",
    "export { pursuitIds, pursuitRules } from './src/shared/swordsman-pursuit.ts';",
    "export { counterstrokeIds, counterstrokeRules } from './src/shared/swordsman-counterstroke.ts';",
    "export { measuredIds, measuredRules } from './src/shared/swordsman-measured.ts';",
    "export { HZ, idleInput, PROTOCOL, CONTENT_REVISION } from './src/shared/protocol.ts';",
    "export { viewOf } from './src/shared/view.ts';",
    "export { swordCircleContact } from './src/shared/sword-geometry.ts';",
    "export { distance, segmentRect, segmentCircle } from './src/shared/geometry.ts';",
    "export { restRaidInput } from './tests/helpers/sniper-rest-raid-policy.ts';",
    "export { clearTrialWalk } from './tests/helpers/tank-bulwark-staging.ts';",
  ];
  const inputs = new Map();
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  const result = await build({
    absWorkingDir: checkout,
    stdin: { contents: entries.join('\n'), loader: 'ts', resolveDir: checkout },
    bundle: true, write: false, format: 'esm', platform: 'node', target: 'node24', logLevel: 'silent',
    plugins: [{ name: 'exact-whole-swordsman', setup(builder) {
      builder.onLoad({ filter: /\.(?:ts|json)$/ }, ({path}) => {
        const member = relative(checkout, path).replaceAll('\\','/');
        if (!Object.hasOwn(expected.inputs, member)) return;
        const contents = fileBytes(member).toString('utf8');
        inputs.set(member, sha256(contents));
        return { contents, loader: member.endsWith('.json') ? 'json' : 'ts', resolveDir: dirname(path) };
      });
    } }],
  });
  const bytes = result.outputFiles[0].contents;
  const bundle = sha256(bytes);
  assert.deepEqual(Object.fromEntries(inputs), expected.inputs);
  assert.equal(bundle, expected.bundle);
  writeFileSync(here(name+'.mjs'), bytes, {flag:'wx'});
  receipt(here(name+'.json'), {passed:true, checkoutExact:true, sourceCommit:source.sourceCommit,
    sourceSnapshotSha256:source.sourceSnapshotSha256, bundle, inputs:Object.fromEntries(inputs)});
  console.log(JSON.stringify({passed:true, action, source:source.sourceCommit, bundle, inputs:inputs.size}));
  process.exit(0);
}

const rebuilt = readJson(here(name+'.json'));
assert(rebuilt.passed && rebuilt.checkoutExact && rebuilt.sourceCommit === source.sourceCommit);
assert.equal(rebuilt.sourceSnapshotSha256, source.sourceSnapshotSha256);
assert.deepEqual(rebuilt.inputs, expected.inputs);
const bundle = sha256(readFileSync(here(name+'.mjs')));
assert.equal(bundle, rebuilt.bundle);
assert.equal(bundle, expected.bundle);
const workflowPath = here('../swordsman-pursuit/source-ci01/feature-ci.json');
const workflows = readJson(workflowPath);
assert(workflows.passed && workflows.phase === 'source' && workflows.draft);
assert.equal(workflows.head, source.sourceCommit);
assert.equal(workflows.commit, source.sourceCommit);
assert.deepEqual(workflows.outcomes.map(run => run.event).sort(), ['pull_request', 'push']);
assert(workflows.outcomes.every(run => run.counts.tests === source.tests && run.counts.pass === source.tests &&
  run.counts.fail === 0 && run.steps === 11 && /^[0-9a-f]{64}$/.test(run.reportSha256)));
receipt(here('whole-runtime01.json'), {passed:true, sourceCommit:source.sourceCommit, protocol:source.protocol,
  contentRevision:source.contentRevision, runtimeSourceSha256:source.runtimeSourceSha256, sourceSnapshotSha256:source.sourceSnapshotSha256,
  studyBundleSha256:expected.bundle, rebuiltBundleSha256:bundle, inputPaths:Object.keys(expected.inputs),
  sourceWorkflowIds:workflows.outcomes.map(run => run.id), sourceWorkflowsSha256:sha256(readFileSync(workflowPath)),
  previousRuntimeBinding:sha256(readFileSync(here('../swordsman-pursuit/game03.json'))), rebuiltRuntimeBinding:sha256(readFileSync(here(name+'.json'))),
  rebuilt:name+'.json', comparisonCases:summary.cases, exactReplays:summary.replays});
console.log(JSON.stringify({passed:true, action, source:source.sourceCommit, bundle, inputs:Object.keys(rebuilt.inputs).length}));
