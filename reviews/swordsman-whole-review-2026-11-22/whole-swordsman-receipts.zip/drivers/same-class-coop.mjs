import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';

const [output, rebuiltName] = process.argv.slice(2);
assert(output);
const root = new URL('../swordsman-pursuit/', import.meta.url);
const binary = readJson(new URL('game03.json', root));
let bundlePath = new URL('game03.mjs', root);
let rebuilt;
if (rebuiltName) {
  assert(/^checkout\d\d$/.test(rebuiltName));
  rebuilt = readJson(new URL('./' + rebuiltName + '.json', import.meta.url));
  assert(rebuilt.checkoutExact && rebuilt.passed && rebuilt.sourceCommit);
  assert.equal(rebuilt.bundle, binary.bundle);
  bundlePath = new URL('./' + rebuiltName + '.mjs', import.meta.url);
}
const { Game, viewOf, idleInput, measuredIds, counterstrokeIds, pursuitIds, pursuitRules, CONTENT_REVISION } =
  await verifiedBundle(fileURLToPath(bundlePath), binary.bundle);

const sound = (events, player, id) => events.some(event => event.type === 'sound' && event.owner === player.id && event.id === id);
const sameClassFields = ['measuredStance', 'counterstroke', 'pursuit'];
const resources = player => ({ ammo: player.ammo, qAt: player.qAt, eAt: player.eAt });
const walkInput = heading => ({ aim: heading, moveX: Math.cos(heading), moveY: Math.sin(heading) });

function fixture(disconnectIndex) {
  const game = new Game({ mode: 'endless', seed: 41, difficulty: 'normal', arenaSelection: 'fixed', openingArenaId: 'gatehouse', maxPlayers: 2 });
  game.encounter = 9;
  const players = [game.addPlayer('dara', 'Dara', 'swordsman'), game.addPlayer('lane', 'Lane', 'swordsman')];
  const fitting = { dara: { hold: 'turn', reply: 'needle', pursuit: 'through' }, lane: { hold: 'follow', reply: 'back', pursuit: 'cross' } };
  const purchases = players.map(player => {
    assert.equal(player.totalSp, 27);
    const fit = fitting[player.id];
    const skills = ['swordsman-measure-1', measuredIds.entry, measuredIds[fit.hold],
      'swordsman-edgework-1', counterstrokeIds.entry, counterstrokeIds[fit.reply],
      'swordsman-footwork-1', pursuitIds.entry, pursuitIds[fit.pursuit]];
    for (const item of skills) assert(game.transact(player.id, { id: player.id + '-' + item, item, kind: 'skill' }).ok, item);
    const spent = player.skills.reduce((sum, id) => sum + game.skillCost(id), 0);
    assert.equal(spent, 15);
    return { id: player.id, earned: player.totalSp, spent, skills };
  });
  assert(game.start());
  const arena = structuredClone(game.arena);
  arena.obstacles = [];
  arena.lavaPits = [];
  Object.defineProperty(game, 'arena', { get: () => arena });
  Object.assign(players[0], { x: 430, oldX: 430, y: 285, oldY: 285 });
  Object.assign(players[1], { x: 430, oldX: 430, y: 555, oldY: 555 });
  Object.assign(game.boss, { x: 1300, y: 720, staggerUntil: 10000, deadline: 10000 });
  const disconnected = players[disconnectIndex];
  const survivor = players[1 - disconnectIndex];

  function step(input = () => ({})) {
    for (const player of players.filter(player => player.connected)) {
      assert(game.submitInput(player.id, { ...idleInput(), aim: 0, sequence: player.ack + 1, clientTick: game.combatTick, ...input(player) }));
    }
    game.step();
    return game.drainEvents();
  }

  let nextId = 86000;
  function target(player, heading, distance) {
    const actor = game.minions.spawn(++nextId, { x: player.x + Math.cos(heading) * distance,
      y: player.y + Math.sin(heading) * distance, kind: 'ordinary', health: 500, speed: 0, radius: 14, damage: 1 }, game.combatTick);
    assert(actor);
    return actor;
  }

  function wait(ready, input, steps = 32) {
    for (let count = 0; count < steps && !ready(); count++) step(input);
    assert(ready(), 'Both commanded players must reach the expected combat window');
  }

  function publicCues(kind) {
    const one = viewOf(game, players[0].id);
    const two = viewOf(game, players[1].id);
    assert.deepEqual(one.classCues, two.classCues);
    for (const [index, view] of [one, two].entries()) {
      const own = view.players.find(player => player.id === players[index].id);
      const other = view.players.find(player => player.id === players[1 - index].id);
      for (const field of sameClassFields) {
        assert(own.kit[field]);
        assert.equal(other.kit[field], undefined);
      }
    }
    const cues = one.classCues.filter(cue => cue.kind === kind);
    assert.equal(new Set(cues.map(cue => cue.id)).size, cues.length);
    return cues;
  }

  function disconnect(kind) {
    const before = publicCues(kind);
    assert(players.every(player => before.some(cue => cue.owner === player.id)));
    game.setConnected(disconnected.id, false);
    const after = publicCues(kind);
    assert.deepEqual(after, before.filter(cue => cue.owner === survivor.id));
    return { before: before.map(cue => ({ id: cue.id, owner: cue.owner, state: cue.state })), remaining: after.map(cue => cue.id) };
  }

  function reconnect(technique, prefix, expected) {
    game.setConnected(disconnected.id, true);
    const events = step(player => player === disconnected ? { [technique]: true } : {});
    assert(!events.some(event => event.type === 'sound' && event.owner === disconnected.id && event.id.startsWith(prefix)));
    assert.deepEqual(resources(disconnected), expected);
  }

  return { game, players, fitting, purchases, disconnected, survivor, step, target, wait, disconnect, reconnect,
    kit: player => game.kitStatus(player.id) };
}

function passingCut(disconnectIndex) {
  const f = fixture(disconnectIndex);
  const targets = f.players.map(player => f.target(player, 0, 145));
  const initial = f.players.map(resources);
  f.wait(() => f.players.every(player => f.kit(player).pursuit.stride === pursuitRules.stride), () => walkInput(0));
  const first = f.step(() => ({ technique3: true }));
  for (const [index, player] of f.players.entries()) {
    assert(sound(first, player, 'sword-pursuit-passing') && targets[index].health < 500);
    assert.deepEqual(resources(player), { ...initial[index], ammo: initial[index].ammo - 1 });
  }
  const heading = player => f.fitting[player.id].pursuit === 'through' ? 0 : Math.PI / 2;
  const follow = f.target(f.survivor, heading(f.survivor), 121);
  f.wait(() => f.players.every(player => f.kit(player).pursuit.followStride === pursuitRules.followStride), player => walkInput(heading(player)));
  const paid = resources(f.disconnected);
  const recovery = f.kit(f.disconnected).pursuit.recoveryAt;
  const followedUntil = f.kit(f.survivor).pursuit.followUntil;
  const cues = f.disconnect('sword-passing-cut');
  assert.equal(f.kit(f.disconnected).pursuit.followUntil, 0);
  assert.equal(f.kit(f.survivor).pursuit.followUntil, followedUntil);
  const survivorBefore = resources(f.survivor);
  const release = f.step(() => ({ technique3: true, aim: heading(f.survivor) }));
  const fitting = f.fitting[f.survivor.id].pursuit;
  assert(sound(release, f.survivor, 'sword-pursuit-' + fitting) && follow.health < 500);
  assert.deepEqual(resources(f.survivor), { ...survivorBefore, ammo: survivorBefore.ammo - 1 });
  f.reconnect('technique3', 'sword-pursuit-', paid);
  assert.equal(f.kit(f.disconnected).pursuit.recoveryAt, recovery);
  return { action: 'passing cut', fitting, targetDamage: 500 - follow.health, cues, disconnected: f.disconnected.id, survivor: f.survivor.id, purchases: f.purchases };
}

function heldEdge(disconnectIndex) {
  const f = fixture(disconnectIndex);
  const target = f.target(f.survivor, 0, 118);
  const start = f.step(() => ({ technique1: true }));
  assert(f.players.every(player => sound(start, player, 'sword-held-edge-set') && player.qAt > f.game.combatTick));
  f.wait(() => f.players.every(player => f.game.combatTick >= f.kit(player).measuredStance.readyAt));
  const paid = resources(f.disconnected);
  const followedUntil = f.kit(f.survivor).measuredStance.until;
  const cues = f.disconnect('sword-measured-stance');
  assert.equal(f.kit(f.disconnected).measuredStance.until, 0);
  assert.equal(f.kit(f.survivor).measuredStance.until, followedUntil);
  const release = f.step(() => ({ technique1: true }));
  assert(sound(release, f.survivor, 'sword-held-edge-cut') && target.health < 500);
  f.reconnect('technique1', 'sword-held-edge-', paid);
  return { action: 'held edge', targetDamage: 500 - target.health, cues, disconnected: f.disconnected.id, survivor: f.survivor.id, purchases: f.purchases };
}

function drawnReply(disconnectIndex) {
  const f = fixture(disconnectIndex);
  const threats = f.players.map(player => f.game.emitShot('hostile', player.x + 48, player.y, Math.PI, 900, 16, 3));
  assert(threats.every(Boolean));
  const start = f.step(() => ({ technique2: true }));
  assert(f.players.every(player => sound(start, player, 'sword-drawn-reply-guard') && player.eAt > f.game.combatTick));
  f.wait(() => f.players.every(player => f.kit(player).counterstroke.responseUntil > f.game.combatTick));
  assert(threats.every(shot => !f.game.shots.has(shot.id)));
  const paid = resources(f.disconnected);
  const followedUntil = f.kit(f.survivor).counterstroke.responseUntil;
  const cues = f.disconnect('sword-drawn-reply');
  assert.equal(f.kit(f.disconnected).counterstroke.responseUntil, 0);
  assert.equal(f.kit(f.survivor).counterstroke.responseUntil, followedUntil);
  const fitting = f.fitting[f.survivor.id].reply;
  const aim = fitting === 'needle' ? 0 : Math.PI / 2;
  const target = f.target(f.survivor, aim, 100);
  const release = f.step(() => ({ technique2: true, aim }));
  assert(sound(release, f.survivor, 'sword-drawn-reply-' + fitting));
  f.wait(() => target.health < 500);
  f.reconnect('technique2', 'sword-drawn-reply-', paid);
  return { action: 'drawn reply', fitting, targetDamage: 500 - target.health, cues, disconnected: f.disconnected.id, survivor: f.survivor.id,
    stopped: threats.map(shot => shot.id), purchases: f.purchases };
}

const cases = [heldEdge, drawnReply, passingCut].flatMap(run => [run(0), run(1)]);
receipt(output, { passed: true, stageOnly: !rebuilt, controlledFight: true, bundle: binary.bundle, revision: CONTENT_REVISION, cases,
  ...(rebuilt ? { sourceCommit: rebuilt.sourceCommit, sourceSnapshotSha256: rebuilt.sourceSnapshotSha256 } : {}) });
console.log(JSON.stringify({ passed: true, cases: cases.map(({ action, fitting, targetDamage, disconnected, survivor }) => ({ action, fitting, targetDamage, disconnected, survivor })) }));
