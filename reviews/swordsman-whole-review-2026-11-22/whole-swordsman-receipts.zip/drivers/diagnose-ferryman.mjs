import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { combinePathways } from './combine-pathways.mjs';

const [output, cohort, sample] = process.argv.slice(2);
assert(output && ['solo','party'].includes(cohort));
const root = new URL('../swordsman-pursuit/',import.meta.url);
const compiled = readJson(new URL('game03.json',root));
const api = await verifiedBundle(fileURLToPath(new URL('game03.mjs',root)),compiled.bundle);
const { Game,data,viewOf,HZ,idleInput,CONTENT_REVISION,measuredIds,counterstrokeIds,pursuitIds,
  distance,segmentRect,segmentCircle,restRaidInput } = api;
const worlds = [['gatehouse','baby',41],['sunken-chapel','normal',73],['crown-crypt','baby',61]];
const builds = ['turn','follow'].flatMap(held => ['needle','back'].flatMap(reply => ['through','cross'].map(pursuit => ({ held, reply, pursuit }))));
const fitNames = build => [build.held,build.reply,build.pursuit].join('/');
const filter = sample?.split(',');
if (filter) assert(filter.length === 3 && worlds.some(world=>world[0]===filter[0]) &&
  builds.some(build => fitNames(build) === filter[1]) && ['active','unused'].includes(filter[2]));
const performed = {
  held:['sword-held-edge-cut','sword-held-edge-second'],
  reply:['sword-drawn-reply-cut','sword-drawn-reply-needle','sword-drawn-reply-back'],
  pursuit:['sword-pursuit-passing','sword-pursuit-through','sword-pursuit-cross'],
};

function conduct(arena,difficulty,seed,build,active) {
  const game = new Game({ mode:'standard', difficulty, seed, openingArenaId:arena, arenaSelection:'route', maxPlayers:cohort === 'solo' ? 1 : 2 });
  const sword = game.addPlayer('solo','Dara','swordsman');
  const ally = cohort === 'party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [sword,ally] : [sword];
  const trace = createHash('sha256'), shots = new Map(), effects = [], purchases = [], ferryman = [];
  const paths = [
    ['swordsman-measure-1',measuredIds.entry,measuredIds[build.held]],
    ['swordsman-edgework-1',counterstrokeIds.entry,counterstrokeIds[build.reply]],
    ['swordsman-footwork-1',pursuitIds.entry,pursuitIds[build.pursuit]],
  ];
  const offset = (worlds.findIndex(world => world[0] === arena) + builds.indexOf(build)) % paths.length;
  const order = [...paths.slice(offset),...paths.slice(0,offset)];
  let serial=0, frames=0,lastShop=-1;
  const buy = (player,kind,item) => game.transact(player.id,{ kind,item,id:'sword-whole-' + ++serial });
  const missing = item => !sword.skills.includes(item);
  const remaining = () => sword.totalSp - sword.skills.reduce((sum,id) => sum + game.skillCost(id),0);
  function acquire(item) {
    assert(buy(sword,'skill',item).ok,item);
    purchases.push({ item, earned:sword.totalSp, clears:sword.progress.clears, left:remaining() });
  }
  function acquirePaths() {
    for (const [prerequisite,entry] of order) {
      if (missing(entry) && remaining() >= 3) {
        if (missing(prerequisite)) acquire(prerequisite);
        acquire(entry);
      }
    }
    if (order.every(([,entry])=>!missing(entry))) {
      for (const [,,fitting] of order) if (missing(fitting) && remaining() >= 2) acquire(fitting);
    }
  }
  function outfit(player) {
    for (const weapon of data.weapons.filter(item => item.classId === player.classId).sort((a,b)=>b.tier-a.tier)) {
      if (player.weapon === weapon.id || buy(player,'weapon',weapon.id).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) buy(player,'upgrade',item);
    buy(player,'supply','medkit');
  }
  acquirePaths();
  assert.equal(purchases.length,2);
  actors.forEach(outfit);
  assert(game.start());
  function danger(view,point,horizon) {
    if (view.minions.some(target => target.health > 0 && distance(target,point) < 26 + horizon * 2)) return true;
    if (view.fields.some(field => field.kind === 'zone' && distance(field,point) < field.radius + 12)) return true;
    for (const shot of shots.values()) {
      const left = Math.min(horizon,shot.expires - view.combatTick);
      if (left <= 0 || distance(point,shot) > 410) continue;
      const travelled = (view.combatTick - shot.seenAt)/HZ;
      const from = { x:shot.x + shot.vx * travelled, y:shot.y + shot.vy * travelled };
      const to = { x:from.x + shot.vx * left/HZ, y:from.y + shot.vy * left/HZ };
      const contact = segmentCircle(from,to,point,shot.radius + data.rules.playerRadius + 2);
      if (contact !== null && !game.obstacles.some(wall => (segmentRect(from,to,wall,shot.radius)?.t ?? Infinity) <= contact)) return true;
    }
    return false;
  }
  const context = { ...api, game,danger,observed:shots,build };
  const navigate = explicitNavigation(context), play = combinePathways(context);
  while (!['victory','defeat'].includes(game.phase) && frames++ < 90_000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of actors) game.vote(actor.id,0);
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        acquirePaths();
        actors.forEach(outfit);
      }
      game.step(); game.drainEvents(); continue;
    }
    const seen = viewOf(game,sword.id), allFitted = order.every(([, ,fitting])=>!missing(fitting));
    const before = sword.damageDealt;
    for (const actor of actors) {
      const body = seen.players.find(row=>row.id === actor.id);
      const base = actor.status === 'active' ? restRaidInput(seen,body,[...shots.values()]) :
        actor.status === 'downed' ? { interact:true } : {};
      const choice = actor.status !== 'active' ? base : actor === sword ? play(active,seen,body,base,navigate) : navigate(seen,body,base);
      const input = { ...idleInput(),...choice,sequence:actor.ack+1,clientTick:game.combatTick };
      input.aim = Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      if (actor === sword && seen.boss.id === 'bridge-ferryman' && (!ferryman.length || seen.combatTick % 15 === 0)) {
        const cues = seen.bossCues.filter(cue=>/district/.test(cue.kind));
        ferryman.push({ tick:seen.combatTick, before:{x:body.x,y:body.y,health:body.health}, boss:{x:seen.boss.x,y:seen.boss.y,health:seen.boss.health},
          move:[input.moveX,input.moveY], aim:input.aim, fire:input.fire, q:input.q, e:input.e, dodge:input.dodge,
          distance:distance(body,seen.boss), cues });
      }
      assert(game.submitInput(actor.id,input));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id,{ ...shot,seenAt:game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== sword.id || !/^sword-(held-edge|drawn-reply|pursuit)-/.test(event.id)) continue;
      assert(active);
      effects.push({ id:event.id, at:game.combatTick, boss:game.boss.id, clears:sword.progress.clears, allFitted, damage:sword.damageDealt-before });
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(p=>[p.x,p.y,p.health,p.qAt,p.eAt,p.ammo,p.damageDealt])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  const did = (events,names) => events.some(event=>names.includes(event.id));
  const pathsUsed = Object.entries(performed).filter(([,names])=>did(effects,names)).map(([path])=>path);
  const fittedUsed = Object.entries(performed).filter(([,names])=>did(effects.filter(event=>event.allFitted),names)).map(([path])=>path);
  return { arena,difficulty,seed,build,first:purchases[1].item,active,won:game.phase === 'victory',clears:sword.progress.clears,
    fullyFitted:order.every(([, ,id])=>!missing(id)),pathsUsed,fittedUsed,purchases,effects,trace:trace.digest('hex'), ferryman };
}

const rows=[];
for (const world of worlds) {
  if (filter && world[0] !== filter[0]) continue;
  for (const build of builds) {
    if (filter && fitNames(build) !== filter[1]) continue;
    for (const active of filter ? [filter[2] === 'active'] : [false,true]) {
      const row = conduct(...world,build,active);
      rows.push(row);
      console.log(JSON.stringify({ arena:row.arena, build:fitNames(build), active, won:row.won, clears:row.clears,
        pathsUsed:row.pathsUsed, fittedUsed:row.fittedUsed, events:row.effects.length }));
    }
  }
}
receipt(output,{ stageOnly:true, protocol:98, revision:CONTENT_REVISION,bundle:compiled.bundle,cohort,rows });
