import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { combinePathways } from './combine-pathways.mjs';
import { ferrymanBypass } from './ferryman-bypass.mjs';

const [output] = process.argv.slice(2);
assert(output);
const cohort = 'solo';
const root = new URL('../swordsman-pursuit/',import.meta.url);
const compiled = readJson(new URL('game03.json',root));
const api = await verifiedBundle(fileURLToPath(new URL('game03.mjs',root)),compiled.bundle);
const { Game,data,viewOf,HZ,idleInput,CONTENT_REVISION,measuredIds,counterstrokeIds,pursuitIds,
  distance,segmentRect,segmentCircle,restRaidInput } = api;
const worlds = [['gatehouse','baby',41],['sunken-chapel','normal',73],['crown-crypt','baby',61]];
const builds = ['turn','follow'].flatMap(held => ['needle','back'].flatMap(reply => ['through','cross'].map(pursuit => ({ held, reply, pursuit }))));
const fitNames = build => [build.held,build.reply,build.pursuit].join('/');
const performed = {
  held:['sword-held-edge-cut','sword-held-edge-second'],
  reply:['sword-drawn-reply-cut','sword-drawn-reply-needle','sword-drawn-reply-back'],
  pursuit:['sword-pursuit-passing','sword-pursuit-through','sword-pursuit-cross'],
};

function conduct(arena,difficulty,seed,build,active,restore) {
  let game = new Game({ mode:'standard', difficulty, seed, openingArenaId:arena, arenaSelection:'route', maxPlayers:cohort === 'solo' ? 1 : 2 });
  let sword = game.addPlayer('solo','Dara','swordsman');
  const ally = cohort === 'party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [sword,ally] : [sword];
  const trace = createHash('sha256'), continuation = createHash('sha256'), shots = new Map(), effects = [], purchases = [];
  const continuations = [];
  let boundary, combatResume;
  const paths = [
    ['swordsman-measure-1',measuredIds.entry,measuredIds[build.held]],
    ['swordsman-edgework-1',counterstrokeIds.entry,counterstrokeIds[build.reply]],
    ['swordsman-footwork-1',pursuitIds.entry,pursuitIds[build.pursuit]],
  ];
  const offset = (worlds.findIndex(world => world[0] === arena) + builds.indexOf(build)) % paths.length;
  const order = [...paths.slice(offset),...paths.slice(0,offset)];
  let serial=0, frames=0,lastShop=-1;
  const buy = (player,kind,item) => game.transact(player.id,{ kind,item,id:'sword-whole-' + ++serial });
  const missing = item => !sword.skills.includes(item);
  const remaining = () => sword.totalSp - sword.skills.reduce((sum,id) => sum + game.skillCost(id),0);
  function acquire(item) {
    assert(buy(sword,'skill',item).ok,item);
    purchases.push({ item, earned:sword.totalSp, clears:sword.progress.clears, left:remaining() });
  }
  function acquirePaths() {
    for (const [prerequisite,entry] of order) {
      if (missing(entry) && remaining() >= 3) {
        if (missing(prerequisite)) acquire(prerequisite);
        acquire(entry);
      }
    }
    if (order.every(([,entry])=>!missing(entry))) {
      for (const [,,fitting] of order) if (missing(fitting) && remaining() >= 2) acquire(fitting);
    }
  }
  function outfit(player) {
    for (const weapon of data.weapons.filter(item => item.classId === player.classId).sort((a,b)=>b.tier-a.tier)) {
      if (player.weapon === weapon.id || buy(player,'weapon',weapon.id).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) buy(player,'upgrade',item);
    buy(player,'supply','medkit');
  }
  acquirePaths();
  assert.equal(purchases.length,2);
  actors.forEach(outfit);
  assert(game.start());
  function danger(view,point,horizon) {
    if (view.minions.some(target => target.health > 0 && distance(target,point) < 26 + horizon * 2)) return true;
    if (view.fields.some(field => field.kind === 'zone' && distance(field,point) < field.radius + 12)) return true;
    for (const shot of shots.values()) {
      const left = Math.min(horizon,shot.expires - view.combatTick);
      if (left <= 0 || distance(point,shot) > 410) continue;
      const travelled = (view.combatTick - shot.seenAt)/HZ;
      const from = { x:shot.x + shot.vx * travelled, y:shot.y + shot.vy * travelled };
      const to = { x:from.x + shot.vx * left/HZ, y:from.y + shot.vy * left/HZ };
      const contact = segmentCircle(from,to,point,shot.radius + data.rules.playerRadius + 2);
      if (contact !== null && !game.obstacles.some(wall => (segmentRect(from,to,wall,shot.radius)?.t ?? Infinity) <= contact)) return true;
    }
    return false;
  }
  const context = { ...api, game,danger,observed:shots,build };
  let navigate = explicitNavigation(context), play = combinePathways(context), cross = ferrymanBypass(context);
  function confirmBoundary() {
    const copy = game.offlineCheckpoint();
    assert(copy?.phase === 'shop' && copy.practiceOnly && copy.contentRevision === CONTENT_REVISION);
    assert.deepEqual(copy.player.skills, sword.skills);
    assert.equal(copy.player.totalSp,16);
    assert.equal(copy.player.progress.clears,5);
    assert.equal(remaining(),1);
    const raw = JSON.stringify(copy);
    boundary = { hash:createHash('sha256').update(raw).digest('hex'), phase:copy.phase, tick:copy.tick,
      combatTick:copy.combatTick, encounter:copy.encounter, skills:[...copy.player.skills],
      earned:copy.player.totalSp, ammo:sword.ammo, q:sword.qAt, e:sword.eAt, ultimate:sword.ultimateAt };
    if (!restore) return;
    game = Game.restoreOffline(JSON.parse(raw));
    assert.equal(game.phase,'shop');
    sword = game.players.get(copy.player.id);
    assert(sword);
    assert.deepEqual(sword.skills,copy.player.skills);
    assert.deepEqual([sword.ammo,sword.qAt,sword.eAt,sword.ultimateAt],[boundary.ammo,boundary.q,boundary.e,boundary.ultimate]);
    const privateState = game.kitStatus(sword.id);
    assert(privateState.measuredStance && privateState.counterstroke && privateState.pursuit);
    assert(privateState.measuredStance.until === 0 && privateState.counterstroke.guardUntil === 0 &&
      privateState.pursuit.followUntil === 0 && privateState.pursuit.stride === 0);
    assert(game.shots.size === 0);
    actors[0] = sword;
    context.game = game;
    navigate = explicitNavigation(context);
    play = combinePathways(context);
    cross = ferrymanBypass(context);
  }
  while (!['victory','defeat'].includes(game.phase) && frames++ < 90_000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of actors) game.vote(actor.id,0);
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        acquirePaths();
        actors.forEach(outfit);
        if (!boundary && order.every(([, ,id])=>!missing(id))) confirmBoundary();
      }
      game.step(); game.drainEvents(); continue;
    }
    const seen = viewOf(game,sword.id), allFitted = order.every(([, ,fitting])=>!missing(fitting));
    const before = sword.damageDealt;
    if (boundary && !combatResume) combatResume = { tick:game.combatTick, arena:seen.arenaId, boss:seen.boss.id, ammo:sword.ammo };
    if (boundary && continuations.at(-1)?.encounter !== seen.encounter) continuations.push({ encounter:seen.encounter, arena:seen.arenaId, boss:seen.boss.id, actions:0 });
    for (const actor of actors) {
      const body = seen.players.find(row=>row.id === actor.id);
      const base = actor.status === 'active' ? restRaidInput(seen,body,[...shots.values()]) :
        actor.status === 'downed' ? { interact:true } : {};
      const ordinary = actor.status !== 'active' ? base : actor === sword ? play(active,seen,body,base,navigate) : navigate(seen,body,base);
      const choice = actor === sword && actor.status === 'active' && seen.boss.id === 'bridge-ferryman'
        ? cross(seen,body,ordinary) : ordinary;
      const input = { ...idleInput(),...choice,sequence:actor.ack+1,clientTick:game.combatTick };
      input.aim = Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      if (boundary) {
        const { sequence, ...recorded } = input;
        continuation.update(JSON.stringify(recorded));
        if (input.technique1 || input.technique2 || input.technique3) continuations.at(-1).actions++;
      }
      assert(game.submitInput(actor.id,input));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id,{ ...shot,seenAt:game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== sword.id || !/^sword-(held-edge|drawn-reply|pursuit)-/.test(event.id)) continue;
      assert(active);
      effects.push({ id:event.id, at:game.combatTick, boss:game.boss.id, clears:sword.progress.clears, allFitted, damage:sword.damageDealt-before });
    }
    const frameState = JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(p=>[p.x,p.y,p.health,p.qAt,p.eAt,p.ammo,p.damageDealt])]);
    trace.update(frameState);
    if (boundary) continuation.update(frameState);
  }
  assert(['victory','defeat'].includes(game.phase));
  const did = (events,names) => events.some(event=>names.includes(event.id));
  const pathsUsed = Object.entries(performed).filter(([,names])=>did(effects,names)).map(([path])=>path);
  const fittedUsed = Object.entries(performed).filter(([,names])=>did(effects.filter(event=>event.allFitted),names)).map(([path])=>path);
  return { arena,difficulty,seed,build,first:purchases[1].item,active,won:game.phase === 'victory',clears:sword.progress.clears,
    fullyFitted:order.every(([, ,id])=>!missing(id)),pathsUsed,fittedUsed,purchases,effects,trace:trace.digest('hex'),
    boundary, combatResume, stepsAfterBoundary:continuations, continuation:continuation.digest('hex'),
    final:{ phase:game.phase, clears:sword.progress.clears, damageTaken:sword.damageTaken, damageDealt:sword.damageDealt,
      ammo:sword.ammo, skills:[...sword.skills] } };
}

const evidence = readJson(new URL('./ferryman-summary01.json',import.meta.url));
assert(evidence.passed && evidence.protocol === 98 && evidence.revision === CONTENT_REVISION && evidence.bundle === compiled.bundle);
assert.equal(evidence.cases.length,6);
const cases = [];
for (const tested of evidence.cases) {
  const row = readJson(new URL('./' + tested.path,import.meta.url)).rows[0];
  const build = builds.find(candidate=>fitNames(candidate)===fitNames(row.build));
  assert(build);
  const normal = conduct(row.arena,row.difficulty,row.seed,build,true,false);
  const resumed = conduct(row.arena,row.difficulty,row.seed,build,true,true);
  assert.equal(normal.trace,row.trace);
  assert.deepEqual(normal.boundary,resumed.boundary);
  assert.deepEqual(normal.combatResume,resumed.combatResume);
  const differing = ['purchases','effects','stepsAfterBoundary','continuation','final'].filter(key =>
    JSON.stringify(normal[key]) !== JSON.stringify(resumed[key]));
  const evidence = { arena:row.arena, seed:row.seed, build, boundary:normal.boundary, firstFight:normal.combatResume,
    uninterrupted:{ continuation:normal.continuation, steps:normal.stepsAfterBoundary, final:normal.final },
    restored:{ continuation:resumed.continuation, steps:resumed.stepsAfterBoundary, final:resumed.final },
    differing, exactAfterShop:differing.length===0 };
  cases.push(evidence);
  console.log(JSON.stringify({ build:fitNames(build), clearedBefore:evidence.boundary.encounter, finalClears:normal.final.clears,
    phase:normal.final.phase, same:evidence.exactAfterShop, differing }));
}
const passed = cases.every(row=>row.exactAfterShop);
const won = cases.filter(row=>row.restored.final.phase==='victory' && row.restored.final.clears===10).length;
assert.equal(won,evidence.wins);
receipt(output,{ passed, stageOnly:true, protocol:98, revision:CONTENT_REVISION, bundle:compiled.bundle, observedWins:won, cases });
if (!passed) process.exitCode = 1;
