import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, receipt, sha256 } from '../bastion/study-paths.mjs';

const [name, mode = 'tests'] = process.argv.slice(2);
assert(/^[a-z]+\d\d$/.test(name) && ['tests','game'].includes(mode));
const here = file => new URL('./' + file, import.meta.url);
const roots = ['./stage/','../swordsman-counterstroke/stage/','../swordsman-measured/stage/','../bard-misdirection/stage/','../bard-lament/stage/','../bard-conductor/stage/'].map(path=>fileURLToPath(here(path)));
const { build } = createRequire(join(checkout,'package.json'))('esbuild');
const inputs = new Map();
function source(path) {
  if(path.startsWith('..'))return;
  return roots.map(root=>join(root,path)).find(path=>existsSync(path));
}
const files = mode === 'tests' ? ['tests/swordsman-pursuit.test.ts','tests/swordsman-counterstroke.test.ts','tests/swordsman-measured.test.ts','tests/swordsman.test.ts','tests/swordsman-presentation.test.ts'].map(path=>`import './${path}'`) : [
  "export { Game, data } from './src/shared/game.ts';",
  "export { pursuitIds, pursuitRules } from './src/shared/swordsman-pursuit.ts';",
  "export { counterstrokeIds, counterstrokeRules } from './src/shared/swordsman-counterstroke.ts';",
  "export { measuredIds, measuredRules } from './src/shared/swordsman-measured.ts';",
  "export { HZ, idleInput, PROTOCOL, CONTENT_REVISION } from './src/shared/protocol.ts';",
  "export { viewOf } from './src/shared/view.ts';",
  "export { swordCircleContact } from './src/shared/sword-geometry.ts';",
  "export { distance, segmentRect, segmentCircle } from './src/shared/geometry.ts';",
  "export { restRaidInput } from './tests/helpers/sniper-rest-raid-policy.ts';",
  "export { clearTrialWalk } from './tests/helpers/tank-bulwark-staging.ts';",
];
const result = await build({ absWorkingDir:checkout, stdin:{ contents:files.join('\n'),loader:'ts',resolveDir:checkout }, bundle:true,
  write:false,format:'esm',platform:'node',target:'node24',logLevel:'silent',plugins:[{ name:'staged-swordsman-pursuit',setup(builder){
    builder.onResolve({filter:/^\./},({path,resolveDir})=>{
      const destination=resolve(resolveDir,path);
      if(source(relative(checkout,destination)))return { path:destination };
    });
    builder.onLoad({filter:/\.(?:ts|json)$/},({path})=>{
      const file=relative(checkout,path).replaceAll('\\','/'), overlay=source(file);
      if(!overlay)return;
      const contents=readFileSync(overlay,'utf8');
      inputs.set(file,sha256(contents));
      return {contents,loader:file.endsWith('.json')?'json':'ts',resolveDir:dirname(path)};
    });
  }}] });
for (const file of ['src/shared/swordsman-pursuit.ts','src/shared/swordsman-counterstroke.ts','src/shared/swordsman-measured.ts','src/shared/swordsman-kit.ts','src/shared/game.ts','src/shared/view.ts','content/catalog.json'])assert(inputs.has(file),file);
const bytes=result.outputFiles[0].contents;
writeFileSync(here(name+'.mjs'),bytes,{flag:'wx'});
receipt(here(name+'.json'),{stageOnly:true,mode,bundle:sha256(bytes),inputs:Object.fromEntries(inputs)});
console.log(JSON.stringify({stageOnly:true,mode,inputs:inputs.size,bundle:sha256(bytes)}));
