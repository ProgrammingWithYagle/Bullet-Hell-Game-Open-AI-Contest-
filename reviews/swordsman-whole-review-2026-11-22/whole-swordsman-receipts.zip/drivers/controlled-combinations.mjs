import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';

const output = process.argv[2];
assert(output);
const root = new URL('../swordsman-pursuit/',import.meta.url);
const binary = readJson(new URL('game03.json',root));
const { Game,viewOf,idleInput,measuredIds,measuredRules,counterstrokeIds,counterstrokeRules,pursuitIds,pursuitRules,CONTENT_REVISION } =
  await verifiedBundle(fileURLToPath(new URL('game03.mjs',root)),binary.bundle);
const relative = (body,heading,length) => ({ x:body.x + Math.cos(heading)*length, y:body.y + Math.sin(heading)*length });

function exercise({ party,held,reply,pursuit }) {
  const game = new Game({ mode:'endless', seed:41, difficulty:'normal', arenaSelection:'fixed', openingArenaId:'gatehouse',maxPlayers:party ? 2 : 1 });
  game.encounter = 9;
  const blade = game.addPlayer('dara','Dara','swordsman');
  const ally = party ? game.addPlayer('lane','Lane','soldier') : undefined;
  assert.equal(blade.totalSp,27);
  const skills = ['swordsman-measure-1',measuredIds.entry,measuredIds[held],
    'swordsman-edgework-1',counterstrokeIds.entry,counterstrokeIds[reply],
    'swordsman-footwork-1',pursuitIds.entry,pursuitIds[pursuit]];
  for (const item of skills) assert(game.transact(blade.id,{ id:item, item,kind:'skill' }).ok,item);
  const spent = blade.skills.reduce((sum,id) => sum + game.skillCost(id),0);
  assert.equal(spent,15);
  assert(game.start());
  const arena = structuredClone(game.arena);
  arena.obstacles = []; arena.lavaPits = [];
  Object.defineProperty(game,'arena',{ get:() => arena });
  Object.assign(blade,{ x:500,y:500,oldX:500,oldY:500 });
  Object.assign(game.boss,{ x:1300,y:720,staggerUntil:10000,deadline:10000 });
  if (ally) Object.assign(ally,{ x:1220,y:640 });
  const sounds = [], events = [];
  const kit = () => game.kitStatus(blade.id);
  function tick(props = {}) {
    assert(game.submitInput(blade.id,{ ...idleInput(),aim:0,sequence:blade.ack+1,clientTick:game.combatTick,...props }));
    game.step();
    const owned = game.drainEvents().filter(event => event.type === 'sound' && event.owner === blade.id);
    sounds.push(...owned.map(event=>({ id:event.id, tick:game.combatTick })));
    if (ally) {
      const own = viewOf(game,blade.id), peer = viewOf(game,ally.id);
      assert.deepEqual(own.classCues,peer.classCues);
      const other = peer.players.find(player => player.id === blade.id).kit;
      for (const field of ['pursuit','measuredStance','counterstroke']) assert.equal(other[field],undefined);
    }
    return owned.map(event=>event.id);
  }
  let id = 85000;
  function target(heading,length) {
    const point = relative(blade,heading,length);
    const actor = game.minions.spawn(++id,{ ...point,kind:'ordinary',health:500,speed:0,radius:14,damage:1 },game.combatTick);
    assert(actor);
    return actor;
  }
  function walk(heading,distance,following) {
    const before = { x:blade.x,y:blade.y };
    for (let i=0; i<30 && kit().pursuit[following ? 'followStride' : 'stride'] < distance; i++) {
      tick({ aim:heading,moveX:Math.cos(heading),moveY:Math.sin(heading) });
    }
    assert.equal(kit().pursuit[following ? 'followStride' : 'stride'],distance);
    events.push({ operation:following ? 'follow footwork' : 'approach', distance:Math.hypot(blade.x-before.x,blade.y-before.y) });
  }
  function waitUntil(ready) {
    for(let n=0; n<60 && !ready(); n++) tick();
    assert(ready());
  }

  const ammo = blade.ammo;
  tick({ ultimate:true });
  assert.equal(kit().swordCuts,3);
  const ultimate = blade.ultimateAt;
  const start = target(0,145);
  walk(0,pursuitRules.stride,false);
  assert(tick({ technique3:true }).includes('sword-pursuit-passing'));
  assert(start.health < 500 && blade.ammo === ammo - 1 && kit().pursuit.followUntil > game.combatTick);
  const route = pursuit === 'through' ? 0 : Math.PI/2;
  const finish = target(route,121);
  walk(route,pursuitRules.followStride,true);
  assert(tick({ technique3:true,aim:route }).includes('sword-pursuit-'+pursuit));
  assert(finish.health < 500 && blade.ammo === ammo - 2 && kit().pursuit.followUntil === 0);
  events.push({ operation:'passing and fitted cut', first:start.id, second:finish.id, ammo:blade.ammo });

  const axis = held === 'turn' ? Math.PI/3 : 0;
  const stance = target(axis,110);
  assert(tick({ technique1:true }).includes('sword-held-edge-set'));
  const q = blade.qAt;
  waitUntil(()=>game.combatTick >= kit().measuredStance.readyAt);
  if (held === 'turn') {
    assert(tick({ technique1:true,aim:axis }).includes('sword-held-edge-turn'));
    waitUntil(()=>game.combatTick >= kit().measuredStance.readyAt);
  }
  assert(tick({ technique1:true,aim:axis }).includes('sword-held-edge-cut'));
  assert(stance.health < 500 && blade.qAt === q);
  if (held === 'follow') {
    const other = target(Math.PI/3,91);
    assert(tick({ technique1:true,aim:Math.PI/3 }).includes('sword-held-edge-second'));
    assert(other.health < 500);
  }
  assert(!kit().measuredStance.until && blade.ammo === ammo - 2 && kit().swordCuts === 3);
  events.push({ operation:'held cut', target:stance.id, paidQ:q, ammo:blade.ammo });

  const incoming = relative(blade,0,48);
  const threat = game.emitShot('hostile',incoming.x,incoming.y,Math.PI,900,16,3);
  assert(threat);
  assert(tick({ technique2:true }).includes('sword-drawn-reply-guard'));
  const e = blade.eAt;
  waitUntil(()=>kit().counterstroke.responseUntil > game.combatTick);
  assert(!game.shots.has(threat.id));
  const siding = reply === 'needle' ? 0 : Math.PI/2;
  const answer = target(siding,100);
  const frontActors = [...game.minions.actors.values()].filter(actor => actor.health > 0 && actor.x > blade.x &&
    Math.abs(actor.y - blade.y) < actor.radius + counterstrokeRules.needleRadius);
  const previously = new Map(frontActors.map(actor=>[actor.id,actor.health]));
  assert(tick({ technique2:true,aim:siding }).includes('sword-drawn-reply-'+reply));
  if (reply === 'needle') waitUntil(()=>frontActors.some(actor=>actor.health < previously.get(actor.id)));
  else assert(answer.health < 500);
  assert(blade.eAt === e && blade.qAt === q && blade.ammo === ammo - 2);
  assert(!kit().counterstroke.responseUntil && !kit().counterUntil && kit().swordCuts === 3);
  assert.equal(blade.ultimateAt,ultimate);
  events.push({ operation:'captured and answered one shot', stopped:threat.id, paidE:e, ammo:blade.ammo });
  tick({ fire:true,aim:0 });
  assert.equal(blade.ammo,ammo - 3);
  assert.equal(kit().swordCuts,2);
  return { party,held,reply,pursuit,earned:blade.totalSp,spent,skills,events,sounds,retainedOrdinaryUltimate:ultimate,finalAmmo:blade.ammo };
}

const cases = [exercise({ party:false,held:'turn',reply:'needle',pursuit:'through' }),
  exercise({ party:true,held:'follow',reply:'back',pursuit:'cross' })];
receipt(output,{ passed:true, stageOnly:true, syntheticFight:true, revision:CONTENT_REVISION, bundle:binary.bundle, cases });
console.log(JSON.stringify({ passed:true, cases:cases.map(row=>({ party:row.party, cuts:row.events.length, spent:row.spent })) }));
