import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const here = path => new URL('./'+path,import.meta.url);
const digest = path => sha256(readFileSync(here(path)));
const runFile = promisify(execFile);
const bundle = readJson(here('../swordsman-pursuit/game03.json'));
const content = readJson(here('../swordsman-pursuit/content01.json'));
assert.equal(digest('../swordsman-pursuit/game03.mjs'),bundle.bundle);
const controlled = readJson(here('controlled01.json'));
assert(controlled.passed && controlled.syntheticFight && controlled.bundle === bundle.bundle && controlled.revision === content.revision);
assert(controlled.cases.length === 2 && controlled.cases.every(row => row.earned === 27 && row.spent === 15 && row.events.length === 5));
mkdirSync(here('replays01/'));
const studies = [], replays = [];
const arenaIds = ['gatehouse','sunken-chapel','crown-crypt'];
const fit = row => [row.build.held,row.build.reply,row.build.pursuit].join('/');
function counts(rows) {
  const events = Object.create(null);
  for (const effect of rows.flatMap(row=>row.effects)) events[effect.id] = (events[effect.id] ?? 0) + 1;
  return { runs:rows.length, wins:rows.filter(row=>row.won).length, fitted:rows.filter(row=>row.fullyFitted).length,
    allThree:rows.filter(row=>row.pathsUsed.length===3).length, afterFitting:rows.filter(row=>row.fittedUsed.length===3).length, events };
}
for (const cohort of ['solo','party']) {
  const path = `standard-${cohort}01.json`, data = readJson(here(path));
  assert(data.stageOnly && data.protocol === 98 && data.revision === content.revision && data.bundle === bundle.bundle && data.cohort === cohort);
  assert.equal(data.rows.length,48);
  const active = data.rows.filter(row=>row.active), unused = data.rows.filter(row=>!row.active);
  assert.equal(new Set(active.map(row=>row.arena + '/' + fit(row))).size,24);
  assert.equal(new Set(unused.map(row=>row.arena + '/' + fit(row))).size,24);
  const matches = active.map(row => {
    const other = unused.find(candidate=>candidate.arena===row.arena && fit(candidate)===fit(row));
    assert(other && other.seed === row.seed && other.first === row.first);
    const len = Math.min(row.purchases.length,other.purchases.length);
    assert.deepEqual(row.purchases.slice(0,len),other.purchases.slice(0,len));
    assert.deepEqual(other.effects,[]);
    for (const trial of [row,other]) {
      assert(trial.purchases.every(purchase=>purchase.left>=0 && purchase.earned<=27));
      if (trial.fullyFitted) assert.deepEqual(trial.purchases.at(-1),{ ...trial.purchases.at(-1), earned:16, clears:5, left:1 });
    }
    return { arena:row.arena, fit:fit(row), start:row.first, commonPurchases:len };
  });
  for (const arena of arenaIds) {
    const focus = active.filter(row=>row.arena===arena).sort((a,b)=>b.fittedUsed.length-a.fittedUsed.length || b.pathsUsed.length-a.pathsUsed.length ||
      b.effects.length-a.effects.length)[0];
    assert(focus);
    const baseline = unused.find(row=>row.arena===arena && fit(row)===fit(focus));
    replays.push(...await Promise.all([focus,baseline].map(async row => {
      const policy = row.active ? 'active' : 'unused';
      const tag = `replays01/${cohort}-${arena}-${policy}`;
      const casePath = tag+'.json', log = tag+'.log';
      const result = await runFile(process.execPath,[fileURLToPath(here('standard-runs.mjs')),fileURLToPath(here(casePath)),cohort,
        [arena,fit(row),policy].join(',')],{ cwd:fileURLToPath(here('')), windowsHide:true, timeout:210_000, maxBuffer:1024*1024 });
      writeFileSync(here(log),result.stdout,{ flag:'wx' });
      assert.deepEqual(readJson(here(casePath)).rows,[row]);
      return { path:casePath, sha256:digest(casePath), logSha256:digest(log), cohort, arena, fitting:fit(row), policy, trace:row.trace };
    })));
  }
  studies.push({ path, sha256:digest(path), cohort, matches, active:counts(active), unused:counts(unused) });
}
assert.equal(replays.length,12);
receipt(here('replays01/summary.json'),{ passed:true,revision:content.revision,bundle:bundle.bundle,replays });
const paired = studies.flatMap(study=>study.matches).length;
const combined = Object.fromEntries(['active','unused'].map(policy => [policy,
  Object.fromEntries(['runs','wins','fitted','allThree','afterFitting'].map(key=>[key,studies.reduce((total,row)=>total+row[policy][key],0)]))]));
assert.equal(paired,48);
receipt(here('whole-summary01.json'),{ passed:true,stageOnly:true,protocol:98,revision:content.revision,bundle:bundle.bundle,
  cases:96, paired, replays:replays.length, replaySha256:digest('replays01/summary.json'),
  controls:{ path:'controlled01.json',sha256:digest('controlled01.json'),cases:controlled.cases.length }, studies, combined });
console.log(JSON.stringify({ passed:true, cases:96, paired, replays:replays.length, combined }));
