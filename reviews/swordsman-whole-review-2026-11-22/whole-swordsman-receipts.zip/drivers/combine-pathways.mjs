import { measuredPilot } from '../swordsman-measured/measured-pilot.mjs';
import { counterstrokePilot } from '../swordsman-counterstroke/counterstroke-targeted-pilot.mjs';
import { pursuitPilot } from '../swordsman-pursuit/pursuit-pilot.mjs';

export function combinePathways({ measuredRules, counterstrokeRules, pursuitRules, build, ...context }) {
  const ordinary = measuredPilot({ ...context, rules:measuredRules, policy:'unused' });
  const held = measuredPilot({ ...context, rules:measuredRules, policy:build.held });
  const reply = counterstrokePilot({ ...context, rules:counterstrokeRules, component:measuredRules, policy:build.reply });
  const pursue = pursuitPilot({ ...context, rules:pursuitRules, component:measuredRules, policy:build.pursuit });

  return (active, seen, body, input, navigate) => {
    if (!active) return ordinary(seen,body,input,navigate);
    const now = seen.combatTick;
    const { measuredStance, counterstroke, pursuit } = body.kit;
    if (measuredStance?.until > now) return held(seen,body,input,navigate);
    if (counterstroke?.guardUntil > now || counterstroke?.responseUntil > now) return reply(seen,body,input,navigate);
    if (pursuit?.followUntil > now) return pursue(seen,body,input,navigate);

    if (counterstroke?.canGuard) {
      const attempt = reply(seen,body,input,navigate);
      if (attempt.technique2) return attempt;
    }
    const mobile = pursuit ? pursue(seen,body,input,navigate) : undefined;
    if (mobile?.technique3) return mobile;
    if (measuredStance?.canPlant) {
      const attempt = held(seen,body,input,navigate);
      if (attempt.technique1) return attempt;
    }
    return mobile ?? ordinary(seen,body,input,navigate);
  };
}
