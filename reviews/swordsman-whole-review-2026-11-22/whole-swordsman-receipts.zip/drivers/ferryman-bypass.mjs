const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);
const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);

export function ferrymanBypass({ game,data,HZ,segmentRect,segmentCircle,clearTrialWalk }) {
  const radius = data.rules.playerRadius;
  let route;

  function plan(player,boss,world) {
    const { bounds } = world;
    const definition = data.bosses.find(item=>item.id==='bridge-ferryman');
    const flank = definition.mechanics.outerBypassWidthPx;
    const dry = { x:bounds.x+flank, y:bounds.y+bounds.height/2-95, width:bounds.width-2*flank, height:190 };
    const obstacles = [...world.obstacles,dry];
    const padding = radius+3;
    const far = { x:bounds.x+bounds.width-padding, y:bounds.y+bounds.height-padding };
    const within = p => p.x>=bounds.x+padding && p.y>=bounds.y+padding && p.x<=far.x && p.y<=far.y;
    const clear = (a,b) => within(b) && !obstacles.some(wall=>segmentRect(a,b,wall,padding)) &&
      !world.lavaPits.some(pit=>segmentCircle(a,b,pit,pit.radius+padding)!==null);
    const gap = padding+10;
    const corners = obstacles.flatMap(wall=>[
      { x:wall.x-gap,y:wall.y-gap }, { x:wall.x+wall.width+gap,y:wall.y-gap },
      { x:wall.x-gap,y:wall.y+wall.height+gap }, { x:wall.x+wall.width+gap,y:wall.y+wall.height+gap },
    ]).filter(p=>clear(p,p));
    const goals = Array.from({length:20},(_,index)=>{
      const angle = index*Math.PI/10;
      return { x:boss.x+Math.cos(angle)*117,y:boss.y+Math.sin(angle)*117 };
    }).filter(p=>clear(p,p) && !world.obstacles.some(wall=>segmentRect(p,boss,wall,3)));
    const points = [{x:player.x,y:player.y},...corners,...goals];
    const costs = points.map((_,i)=>i===0?0:Infinity), via = points.map(()=>-1), visited = new Set();
    for (;;) {
      const candidates = costs.map((cost,index)=>({ cost,index })).filter(row=>!visited.has(row.index)&&Number.isFinite(row.cost));
      const next = candidates.sort((a,b)=>a.cost-b.cost)[0];
      if (!next) return [];
      if (next.index>corners.length) {
        const path = [];
        for (let i=next.index; i>0; i=via[i]) path.unshift(points[i]);
        return path;
      }
      visited.add(next.index);
      for (let i=1; i<points.length; i++) {
        const cost = next.cost+distance(points[next.index],points[i]);
        if (visited.has(i) || cost>=costs[i] || !clear(points[next.index],points[i])) continue;
        costs[i]=cost;
        via[i]=next.index;
      }
    }
  }

  return (seen,body,base) => {
    const world = { ...game.arena, obstacles:game.obstacles,tick:seen.combatTick,playerRadius:radius };
    const boss = seen.boss;
    if (distance(body,boss)<160 && !world.obstacles.some(wall=>segmentRect(body,boss,wall,3))) return base;
    if ((base.supply ?? -1)>=0 || base.dodge) return base;
    const now=seen.combatTick;
    if (!route || route.encounter!==seen.encounter || now>=route.at+68) {
      route={ at:now,encounter:seen.encounter,points:plan(body,boss,world) };
    }
    while (route.points.length && distance(body,route.points[0])<4) route.points.shift();
    const step=route.points[0];
    if (!step || !clearTrialWalk(world,body,step)) return base;
    const div=Math.max(distance(body,step),body.speed/HZ);
    return { ...base,moveX:(step.x-body.x)/div,moveY:(step.y-body.y)/div,aim:bearing(body,boss),
      q:false,technique1:false,technique2:false,technique3:false,fire:false,ultimate:false };
  };
}
