import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdirSync,readFileSync,writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { readJson,receipt,sha256 } from '../bastion/study-paths.mjs';

const here=path=>new URL('./'+path,import.meta.url);
const digest=path=>sha256(readFileSync(here(path)));
const run=promisify(execFile);
const comparison=readJson(here('standard-solo01.json'));
const original=readJson(here('ferryman-observed01.json'));
const first=readJson(here('ferryman-bypass01.json'));
const pilot=readJson(here('../swordsman-pursuit/game03.json'));
assert([comparison,original,first].every(row=>row.protocol===98 && row.stageOnly && row.bundle===pilot.bundle && row.revision===comparison.revision));
assert.equal(original.rows[0].trace,comparison.rows.find(row=>row.trace===original.rows[0].trace).trace);
const blocked=original.rows[0].ferryman;
assert(blocked.length && blocked.every(time=>!time.fire && !time.q && time.boss.health===blocked[0].boss.health));
assert(Math.min(...blocked.map(row=>row.distance))>230);
const prior=comparison.rows.filter(row=>row.active && row.fullyFitted);
assert(prior.length===6 && prior.every(row=>row.arena==='sunken-chapel' && row.clears===6 && !row.won));
mkdirSync(here('ferryman-cases01/'));
const cases=[];
for (const baseline of prior) {
  const {held,reply,pursuit}=baseline.build;
  const tag=`ferryman-cases01/${held}-${reply}-${pursuit}`;
  const pathname=tag+'.json', logfile=tag+'.log';
  const result=await run(process.execPath,[fileURLToPath(here('ferryman-bypass-study.mjs')),fileURLToPath(here(pathname)),'solo',
    [baseline.arena,[held,reply,pursuit].join('/'),'active'].join(',')],
  { cwd:fileURLToPath(here('')),windowsHide:true,timeout:180_000,maxBuffer:1024*1024 });
  writeFileSync(here(logfile),result.stdout,{flag:'wx'});
  const proof=readJson(here(pathname));
  assert.equal(proof.bundle,pilot.bundle);
  const [actual]=proof.rows;
  assert(actual && actual.ferryStart.clears===6 && actual.ferryStart.earned===19 && actual.arena===baseline.arena);
  assert.deepEqual(actual.build,baseline.build);
  assert.deepEqual(actual.effects.filter(event=>event.at<=actual.ferryStart.tick),baseline.effects);
  assert.deepEqual(actual.purchases.slice(0,baseline.purchases.length),baseline.purchases);
  if (held==='turn' && reply==='needle' && pursuit==='through') assert.deepEqual(actual,first.rows[0]);
  cases.push({ path:pathname,sha256:digest(pathname),log:logfile,logSha256:digest(logfile),build:actual.build,
    start:actual.ferryStart,end:actual.ferryFinish,usedBypass:actual.ferryman.some(row=>row.planned),
    closest:Math.min(...actual.ferryman.map(row=>row.distance)),clears:actual.clears,won:actual.won,lastEncounter:actual.lastEncounter });
}
const ferrymanClears=cases.filter(row=>row.usedBypass && row.end.hp===0 && row.end.clears===7).length;
const wins=cases.filter(row=>row.won && row.clears===10).length;
assert(ferrymanClears && wins);
const binding={ passed:true,stageOnly:true,protocol:98,revision:comparison.revision,bundle:pilot.bundle,cases,
  ordinaryEarlierTrace:{ path:'ferryman-observed01.json',sha256:digest('ferryman-observed01.json'),matches:original.rows[0].trace },
  originalRetested:{ path:'ferryman-bypass01.json',sha256:digest('ferryman-bypass01.json'),exactReplay:true },ferrymanClears,wins };
receipt(here('ferryman-summary01.json'),binding);
console.log(JSON.stringify({passed:true,cases:cases.length,ferrymanClears,wins,finalClears:cases.map(row=>row.clears)}));
