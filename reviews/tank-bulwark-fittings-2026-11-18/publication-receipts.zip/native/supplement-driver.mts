import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { closeSync, existsSync, openSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const [mode, commit, scope, out, ...args] = process.argv.slice(2);
assert(/^[a-f\d]{40}$/.test(commit) && /^reviews\/[a-z0-9-]+$/.test(scope) && out);
const script = fileURLToPath(import.meta.url);
const audiences = ['testing', 'public'] as const;
const choices = ['none', 'pivot', 'port', 'folded', 'side'] as const;
const transports = ['worker', 'peer'] as const;
const icons = ['tank-bulwark-carry-1', 'tank-bulwark-pivot-1', 'tank-bulwark-port-1',
  'tank-bulwark-folded-setdown-1', 'tank-bulwark-side-port-1'];
const revision = readJson(join(checkout, 'content/revision.json')).sha256;
const digest = file => sha256(readFileSync(file));
const check = async (url: string) => {
  const response = await fetch(url, { signal: AbortSignal.timeout(10000) });
  assert.equal(response.status, 200, url);
  return response;
};
const imports = await import('./native-helper02/tank-bulwark-transport.ts');

function frozen(audience: string) {
  const preview = readJson(join(checkout, scope, 'preview-' + audience + '.json'));
  assert.equal(preview.contentRevision, revision);
  assert.equal(preview.protocol, 81);
  assert.equal(preview.sourceCommit, commit);
  assert.equal(digest(preview.manifestPath), preview.manifestSha256);
  assert.equal(digest(preview.backend.path), preview.backend.sha256);
  const manifest = readJson(preview.manifestPath);
  assert.equal(manifest.members.length, preview.files);
  return { preview, manifest };
}

async function health(audience, preview) {
  const value = await (await check(preview.endpoint + '/api/health')).json();
  assert.equal(value.audience, audience);
  assert.equal(value.sourceCommit, commit);
  assert.equal(value.protocolVersion, 81);
  assert.equal(value.contentRevision, revision);
  return value;
}

async function served(preview, member) {
  const bytes = Buffer.from(await (await check(new URL(member.path, preview.url).href)).arrayBuffer());
  assert.equal(sha256(bytes), member.sha256);
  return bytes;
}

function logChild(nodeArgs: string[], log: string, limit: number) {
  const fd = openSync(log, 'wx');
  return new Promise<number | null>((resolve, reject) => {
    const child = spawn(process.execPath, nodeArgs, { cwd: checkout, stdio: ['ignore', fd, fd], windowsHide: true });
    const timeout = setTimeout(() => child.kill(), limit);
    child.once('error', error => { clearTimeout(timeout); closeSync(fd); reject(error); });
    child.once('exit', code => { clearTimeout(timeout); closeSync(fd); resolve(code); });
  });
}

if (mode === 'case') {
  const [audience, transport, choice] = args;
  assert(audiences.includes(audience) && transports.includes(transport) && choices.includes(choice));
  const destination = join(out, audience + '-' + transport + '-' + choice + '.json');
  const { preview, manifest } = frozen(audience), current = await health(audience, preview);
  const worker = manifest.members.find(file => /offline\.worker-.*\.js$/.test(file.path));
  assert(worker);
  const bytes = await served(preview, worker);
  const result = transport === 'worker'
    ? await imports.runBulwarkWorker(bytes.toString('utf8'), choice)
    : await imports.runBulwarkPeers(preview.endpoint, choice);
  assert(result.passed && result.pausedCommandsDiscarded);
  const late = choice === 'folded' || choice === 'side';
  assert.deepEqual(result.actualEarnedSequence, late ? [3, 9, 15, 21] : [3, 9]);
  assert.equal(result.spent, late ? 8 : choice === 'none' ? 3 : 5);
  assert.equal(result.originalLifetimeTicks, 150);
  if (choice === 'pivot') assert(Math.abs(result.turned) > .5);
  if (choice === 'port') assert.equal(result.paidPortRounds, 1);
  if (choice === 'folded') assert.equal(result.paidAfterFold, 1);
  if (choice === 'side') {
    assert.equal(result.paidPortRounds, 2);
    assert(Math.abs(result.shiftedOffset) > 14);
  }
  receipt(destination, { ...result, audience, transport, sourceCommit: commit, contentRevision: revision,
    protocol: 81, backendStartedAt: current.startedAt, backendSha256: preview.backend.sha256, servedWorker: worker });
  console.log(JSON.stringify(result));
} else {
  assert.equal(mode, 'matrix');
  async function review(audience) {
    const { preview, manifest } = frozen(audience), current = await health(audience, preview);
    const smoke = join(out, audience + '-http.log');
    const code = await logChild(['--import', 'tsx', 'tools/smoke-client-review.mts', audience, scope], smoke, 95_000);
    assert.equal(code, 0, 'See ' + smoke);
    const httpPath = scope + '/smoke-' + audience + '.json';
    const http = readJson(join(checkout, httpPath));
    assert(http.passed && http.probeRoomsClosed);
    assert.equal(http.sourceCommit, commit);
    assert.equal(http.health.startedAt, current.startedAt);
    const emblems = [];
    for (const id of icons) {
      const member = manifest.members.find(file => file.path.startsWith('assets/' + id + '-') && file.path.endsWith('.png'));
      assert(member, id);
      const folder = id.includes('folded-setdown') || id.includes('side-port') ? 'tank-bulwark-late-2026-11-18' : 'tank-tree-2026-11-13';
      const authored = join(checkout, 'assets/production/ui', folder, id + '.png');
      assert.equal(digest(authored), member.sha256);
      await served(preview, member);
      emblems.push(member);
    }
    const groups = await Promise.all(transports.map(async transport => {
      const results = [];
      for (const choice of choices) {
        const name = audience + '-' + transport + '-' + choice;
        const log = join(out, name + '.log'), file = join(out, name + '.json');
        const status = await logChild(['--import', 'tsx', script, 'case', commit, scope, out, audience, transport, choice], log, 455_000);
        const result = existsSync(file) ? readJson(file) : undefined;
        const passed = status === 0 && result?.passed === true && result.backendStartedAt === current.startedAt;
        results.push({ choice, transport, passed, status, log: name + '.log', logSha256: digest(log),
          result: result && name + '.json', resultSha256: result && digest(file) });
        console.log(JSON.stringify({ audience, transport, choice, passed }));
      }
      return results;
    }));
    const cases = groups.flat();
    const until = Date.now() + 12000;
    let metrics;
    do {
      metrics = await (await check(preview.endpoint + '/api/metrics')).json();
      if (metrics.rooms === 0 && metrics.connections === 0) break;
      await sleep(100);
    } while (Date.now() < until);
    assert.equal((await health(audience, preview)).startedAt, current.startedAt);
    const report = { passed: cases.length === choices.length * transports.length && cases.every(row => row.passed) && metrics.rooms === 0 && metrics.connections === 0,
      audience, sourceCommit: commit, protocol: 81, contentRevision: revision, url: preview.url, endpoint: preview.endpoint,
      backendStartedAt: current.startedAt, files: preview.files, manifestSha256: preview.manifestSha256,
      backendSha256: preview.backend.sha256, httpPath, httpSha256: digest(join(checkout, httpPath)), emblems,
      caseCount: cases.length + 1, cases, remainingProbeRooms: metrics.rooms, remainingProbeConnections: metrics.connections };
    receipt(join(out, 'result-' + audience + '.json'), report);
    return report;
  }
  const outcomes = await Promise.allSettled(audiences.map(review));
  const passed = outcomes.every(row => row.status === 'fulfilled' && row.value.passed);
  receipt(join(out, 'frozen-verification.json'), { passed, sourceCommit: commit, protocol: 81, contentRevision: revision,
    checkedAt: new Date().toISOString(), driverSha256: digest(script),
    audiences: outcomes.map(row => row.status === 'fulfilled' ? row.value : { passed: false, error: String(row.reason) }) });
  if (!passed) process.exitCode = 1;
}
