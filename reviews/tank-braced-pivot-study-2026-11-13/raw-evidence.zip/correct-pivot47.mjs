import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {one,write,sha} from '../heavy-corner-guide-stage/common.mjs';

const stage=path.dirname(fileURLToPath(import.meta.url));
const original=fs.readFileSync(stage+'/tank-pivot42.ts','utf8');
let code=one(original,'  beginPivot(player, walls, world) {','  beginPivot(player, walls, world, next = player) {');
code=one(code,'        player.input.technique1 || player.input.moveX || player.input.moveY ||',`        player.input.technique1 || player.input.moveX || player.input.moveY ||
        distance(player, next) > .01 ||
        distance(player, { x: player.oldX ?? player.x, y: player.oldY ?? player.y }) > .01 ||`);
code=one(code,`    if (held.pivot) {
      if (player.input.technique1 || player.input.moveX || player.input.moveY || distance(player, next) > .01) held.pivot = undefined;
      else {
        this.advancePivot(player, held, walls, world);
        return player;
      }
    }
    const current = this.frames`, '    const current = this.frames');
code=one(code,'    const target = this.frames(held, lead(next, held.normal), true, walls);',`    if (held.pivot) {
      const ejected = distance(player, { x: player.oldX ?? player.x, y: player.oldY ?? player.y }) > .01;
      if (player.input.technique1 || player.input.moveX || player.input.moveY ||
          distance(player, next) > .01 || ejected) held.pivot = undefined;
      else {
        this.advancePivot(player, held, walls, world);
        return player;
      }
    }
    const target = this.frames(held, lead(next, held.normal), true, walls);`);

let builder=fs.readFileSync(stage+'/build-pivot43.mjs','utf8');
builder=builder.replaceAll('tank-pivot42.ts','tank-pivot47.ts').replaceAll('tank-game43.mjs','tank-game48.mjs').replaceAll('tank-pivot-build43.json','tank-pivot-build48.json');
builder=one(builder,'commandTankPivot(p: Player, world) { return this.tankCarry.beginPivot(p,this.towers,world); }',
  'commandTankPivot(p: Player, world, next: Vec) { return this.tankCarry.beginPivot(p,this.towers,world,next); }');
builder=one(builder,'this.classKits.commandTankPivot(p,tankWorld))','this.classKits.commandTankPivot(p,tankWorld,next))');
let driver=fs.readFileSync(stage+'/pivot46.mts','utf8');
driver=driver.replaceAll('tank-pivot-build43.json','tank-pivot-build48.json').replaceAll('tank-game43.mjs','tank-game48.mjs').replaceAll('tank-pivot-controlled46.json','tank-pivot-controlled49.json');
for(const file of ['tank-pivot47.ts','build-pivot48.mjs','pivot49.mts'])assert(!fs.existsSync(stage+'/'+file));
fs.writeFileSync(stage+'/tank-pivot47.ts',code,{flag:'wx'});
fs.writeFileSync(stage+'/build-pivot48.mjs',builder,{flag:'wx'});
fs.writeFileSync(stage+'/pivot49.mts',driver,{flag:'wx'});
write(stage+'/pivot-correction47.json',{at:new Date().toISOString(),originalControllerSha256:sha(original),controllerSha256:sha(code),
  builderSha256:sha(builder),driverSha256:sha(driver),originalFailures:['tank-pivot-controlled44.json','tank-pivot-controlled45.json','tank-pivot-controlled46.json'],
  corrections:['Reject initial service-force or closing-gate displacement before spending pivot recovery.',
    'Cancel an active pivot on pre-walk closing-gate ejection and preserve actual displacement.',
    'Validate current held footprint before any active-turn path.'],canonicalSourceEdited:false});
