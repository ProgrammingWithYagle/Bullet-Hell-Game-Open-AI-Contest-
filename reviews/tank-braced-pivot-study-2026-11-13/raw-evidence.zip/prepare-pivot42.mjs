import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { one, write, sha } from '../heavy-corner-guide-stage/common.mjs';

const stage=path.dirname(fileURLToPath(import.meta.url));
let code=fs.readFileSync(stage+'/tank-carry32.ts','utf8');
code=one(code,'export { tankCarryId, wallFootprintClear };',`export { tankCarryId, wallFootprintClear };
export const pivotId = 'tank-bulwark-pivot-1';
export const pivotRules = { windTicks: 12, recoveryTicks: 60 };
const rotate = (point, angle) => ({
  x: point.x * Math.cos(angle) - point.y * Math.sin(angle),
  y: point.x * Math.sin(angle) + point.y * Math.cos(angle),
});`);
code=one(code,'type HeldWall = { weapon: string; normal: { x: number; y: number }; members: Member[] };',`type Pivot = {
  at: number;
  until: number;
  angle: number;
  fromNormal: { x: number; y: number };
  startMembers: { id: number; aim: number; offset: { x: number; y: number } }[];
};
type HeldWall = {
  weapon: string;
  normal: { x: number; y: number };
  members: Member[];
  pivot?: Pivot;
  pivotUsed?: boolean;
};`);
code=one(code,'  private commands = new Map<string, number>();','  private commands = new Map<string, number>();\n  private pivotRecovery = new Map<string, number>();');
code=one(code,'    this.commands.clear();','    this.commands.clear();\n    this.pivotRecovery.clear();');
code=one(code,'  private frames(held, center, folded, walls) {',`  pivotStatus(id) {
    return { active: !!this.held.get(id)?.pivot, readyAt: this.pivotRecovery.get(id) ?? 0 };
  }

  beginPivot(player, walls, world) {
    if (!player.skills.includes(pivotId) || !this.active(player.id, walls, world.tick) ||
        player.input.technique1 || player.input.moveX || player.input.moveY ||
        player.input.reload || player.input.dodge || player.input.q || player.input.e || player.input.ultimate ||
        world.tick < (this.pivotRecovery.get(player.id) ?? 0) ||
        player.input.sequence <= (this.commands.get(player.id) ?? -1)) return false;
    const held = this.held.get(player.id)!;
    if (held.pivot) return false;
    const members = held.members.map(member => ({ ...member, wall: walls.get(member.id) }));
    if (members.some(member => member.wall.until <= world.tick + pivotRules.windTicks)) return false;
    const from = Math.atan2(held.normal.y, held.normal.x);
    const angle = Math.atan2(Math.sin(player.input.aim - from), Math.cos(player.input.aim - from));
    if (Math.abs(angle) < .02) return false;
    this.commands.set(player.id, player.input.sequence);
    this.pivotRecovery.set(player.id, world.tick + pivotRules.recoveryTicks);
    held.pivotUsed = true;
    held.pivot = {
      at: world.tick, until: world.tick + pivotRules.windTicks, angle,
      fromNormal: { ...held.normal },
      startMembers: members.map(member => ({ id: member.id, aim: member.wall.aim, offset: { ...member.offset } })),
    };
    return true;
  }

  private advancePivot(player, held, walls, world) {
    const pivot = held.pivot!;
    const fraction = Math.min(1, (world.tick - pivot.at) / pivotRules.windTicks);
    const targetAngle = pivot.angle * fraction;
    const currentAngle = Math.atan2(
      pivot.fromNormal.x * held.normal.y - pivot.fromNormal.y * held.normal.x,
      pivot.fromNormal.x * held.normal.x + pivot.fromNormal.y * held.normal.y,
    );
    const steps = Math.max(1, Math.ceil(Math.abs(targetAngle - currentAngle) / (Math.PI / 72)));
    for (let step = 1; step <= steps; step++) {
      const angle = currentAngle + (targetAngle - currentAngle) * step / steps;
      const normal = rotate(pivot.fromNormal, angle);
      const center = lead(player, normal);
      const frames = held.members.map(member => {
        const original = pivot.startMembers.find(original => original.id === member.id)!;
        const offset = rotate(original.offset, angle);
        return { member, wall: walls.get(member.id), offset,
          point: { x: center.x + offset.x / 2, y: center.y + offset.y / 2 },
          aim: original.aim + angle };
      });
      if (frames.some(frame => !wallFootprintClear(world, frame.point,
          { x: Math.cos(frame.aim), y: Math.sin(frame.aim) }, (frame.member.halfSpan ?? 110) / 2))) {
        held.pivot = undefined;
        return;
      }
      held.normal = normal;
      for (const frame of frames) {
        frame.member.offset = frame.offset;
        Object.assign(frame.wall, frame.point, { aim: frame.aim });
      }
    }
    if (world.tick >= pivot.until) held.pivot = undefined;
  }

  private frames(held, center, folded, walls) {`);
code=one(code,'    const held = this.held.get(player.id)!;\n    const current = this.frames',`    const held = this.held.get(player.id)!;
    if (held.pivotUsed && !player.skills.includes(pivotId)) {
      this.remove(player.id, walls);
      return next;
    }
    if (held.pivot) {
      if (player.input.technique1 || player.input.moveX || player.input.moveY || distance(player, next) > .01) held.pivot = undefined;
      else {
        this.advancePivot(player, held, walls, world);
        return player;
      }
    }
    const current = this.frames`);

let builder=fs.readFileSync(stage+'/build33.mjs','utf8');
builder=builder.replaceAll('tank-carry32.ts','tank-pivot42.ts').replaceAll('tank-game33.mjs','tank-game43.mjs').replaceAll('tank-carry-build33.json','tank-pivot-build43.json');
builder=one(builder,'catalog.specializationSkills.push(definition);',`catalog.specializationSkills.push(definition);
const pivotDefinition = { ...definition, id: 'tank-bulwark-pivot-1', name: 'Braced Pivot',
  nameKey: 'skill.tank-bulwark-pivot-1.name', sourceSkillId: 'tank-bulwark-pivot-1',
  prerequisite: definition.id, grade: 'D', depth: 2, cost: 2, freePlaySpRequired: 5, role: 'handling',
  description: 'While carrying and standing still, Action 2 commits the shield toward the aimed bearing over 12 combat ticks. Walking or forced movement interrupts the turn. The shield keeps its original health and expiry. Recovery lasts 60 combat ticks.' };
catalog.specializationSkills.push(pivotDefinition);`);
builder=one(builder,'  private tankCarry = new TankCarryStudy();', `  private tankCarry = new TankCarryStudy();
  commandTankPivot(p: Player, world) { return this.tankCarry.beginPivot(p,this.towers,world); }
  tankPivotStatus(id: string) { return this.tankCarry.pivotStatus(id); }`);
builder=one(builder,'    const final = tankWorld ? this.classKits.moveTankWall(p, next, tankWorld) : next;', `    if (tankWorld && i.technique2 && this.classKits.commandTankPivot(p,tankWorld))
      this.events.push({type:'sound',id:'tank-wall-pivot',owner:p.id,x:p.x,y:p.y});
    const final = tankWorld ? this.classKits.moveTankWall(p, next, tankWorld) : next;`);
builder=one(builder,'bundleSha256: sha(fs.readFileSync(bundle)), definition, canonicalSourceEdited:', 'bundleSha256: sha(fs.readFileSync(bundle)), definition, pivotDefinition, canonicalSourceEdited:');
assert(!fs.existsSync(stage+'/tank-pivot42.ts')&&!fs.existsSync(stage+'/build-pivot43.mjs'));
fs.writeFileSync(stage+'/tank-pivot42.ts',code,{flag:'wx'});
fs.writeFileSync(stage+'/build-pivot43.mjs',builder,{flag:'wx'});
write(stage+'/pivot-preparation42.json',{controllerSha256:sha(code),builderSha256:sha(builder),
  purpose:'A stationary committed shield turn after the affordable entry. Movement interrupts and all original wall state persists.',canonicalSourceEdited:false});
