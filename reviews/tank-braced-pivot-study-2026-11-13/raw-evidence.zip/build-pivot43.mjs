import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';
import { root, read, one, sha, write, git, fingerprints } from '../heavy-corner-guide-stage/common.mjs';

const stage = path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const before = fingerprints();
const catalog = read('content/catalog.json');
const definition = {
  ...catalog.specializationSkills.find(node => node.id === 'heavy-linework-1'),
  id: 'tank-bulwark-carry-1', name: 'Shoulder Wall', nameKey: 'skill.tank-bulwark-carry-1.name', classId: 'tank',
  sourceSkillId: 'tank-bulwark-carry-1', prerequisite: 'tank-protection-1',
  description: 'Approach the rear of your Protective Wall. Action 1 folds it into a narrow shield and carries it at the original heading. Walk it across the line of fire. A separate Action 1 sets it down at full width on clear ground. It keeps the same remaining health and expiry. Both hands are occupied until set down.',
};
assert.equal(definition.cost, 2);
assert(catalog.skills.some(node => node.id === definition.prerequisite && node.cost === 1));
catalog.specializationSkills.push(definition);
const pivotDefinition = { ...definition, id: 'tank-bulwark-pivot-1', name: 'Braced Pivot',
  nameKey: 'skill.tank-bulwark-pivot-1.name', sourceSkillId: 'tank-bulwark-pivot-1',
  prerequisite: definition.id, grade: 'D', depth: 2, cost: 2, freePlaySpRequired: 5, role: 'handling',
  description: 'While carrying and standing still, Action 2 commits the shield toward the aimed bearing over 12 combat ticks. Walking or forced movement interrupts the turn. The shield keeps its original health and expiry. Recovery lasts 60 combat ticks.' };
catalog.specializationSkills.push(pivotDefinition);

const gameFile = 'src/shared/game.ts', kitFile = 'src/shared/class-kits.ts';
let game = fs.readFileSync(gameFile, 'utf8'), kit = fs.readFileSync(kitFile, 'utf8');
kit = "import { TankCarryStudy } from 'tank-carry-study';\n" + kit;
kit = one(kit, '  private towers = new Map<number, Tower>();', `  private towers = new Map<number, Tower>();
  private tankCarry = new TankCarryStudy();
  commandTankPivot(p: Player, world) { return this.tankCarry.beginPivot(p,this.towers,world); }
  tankPivotStatus(id: string) { return this.tankCarry.pivotStatus(id); }
  tankWallCarried(id: string, tick: number) { return !!this.tankCarry.active(id, this.towers, tick); }
  moveTankWall(p: Player, next: Vec, world) { return this.tankCarry.move(p, next, this.towers, world); }
  commandTankWall(p: Player, world) { return this.tankCarry.command(p, this.towers, world); }`);
kit = one(kit, '    this.combatClock=c.tick;', '    this.tankCarry.step(c.players,this.towers,c.tick);\n    this.combatClock=c.tick;');
kit = one(kit, '  tankWallCarried(id:', '  dropTankWall(id: string) { this.tankCarry.remove(id,this.towers); }\n  tankWallCarried(id:');
kit = one(kit, '    this.towers.clear();', '    this.towers.clear();\n    this.tankCarry.clear();');
game = one(game, '      stats = this.stats(p),\n      i = p.input;', `      stats = this.stats(p),
      carried = p.classId === 'tank' && this.classKits.tankWallCarried(p.id, now),
      i = carried ? { ...p.input, q: false, e: false, ultimate: false, reload: false, dodge: false, fire: false } : p.input;`);
game = one(game, '    p.x = next.x;\n    p.y = next.y;\n    if (lineworkContext)', `    const tankWorld = p.classId === 'tank' ? { tick: now, bounds: this.arena.bounds, obstacles: this.obstacles, lavaPits: this.arena.lavaPits } : undefined;
    if (tankWorld && i.technique2 && this.classKits.commandTankPivot(p,tankWorld))
      this.events.push({type:'sound',id:'tank-wall-pivot',owner:p.id,x:p.x,y:p.y});
    const final = tankWorld ? this.classKits.moveTankWall(p, next, tankWorld) : next;
    p.x = final.x;
    p.y = final.y;
    if (tankWorld && i.technique1) {
      const command = this.classKits.commandTankWall(p, tankWorld);
      if (command) this.events.push({ type: 'sound', id: 'tank-wall-' + command, x: p.x, y: p.y, owner: p.id });
    }
    const handsBusy = carried || (p.classId === 'tank' && this.classKits.tankWallCarried(p.id, now));
    if (lineworkContext)`);
game = one(game, '    if(!connected)this.skirmisher.remove(id);', '    if(!connected)this.classKits.dropTankWall(id);\n    if(!connected)this.skirmisher.remove(id);');
game = one(game, "      if(p.classId==='heavy')this.traverse.cancelOwner(p.id,this.traverseAuthority());", "      if(p.classId==='tank')this.classKits.dropTankWall(p.id);\n      if(p.classId==='heavy')this.traverse.cancelOwner(p.id,this.traverseAuthority());");
game = one(game, '    if (i.fire && !sniperReloadHandled', '    if (i.fire && !handsBusy && !sniperReloadHandled');
game = one(game, '    p.wasFiring = i.fire && !sniperReloadHandled', '    p.wasFiring = i.fire && !handsBusy && !sniperReloadHandled');

const require = createRequire(root + '/package.json');
const { build } = require('esbuild');
const overrides = new Map([[gameFile, [game, 'ts']], [kitFile, [kit, 'ts']], ['content/catalog.json', [JSON.stringify(catalog), 'json']]]);
const loaded = new Set();
const bundle = stage + '/tank-game43.mjs';
assert(!fs.existsSync(bundle));
await build({ entryPoints: [gameFile], outfile: bundle, format: 'esm', platform: 'node', bundle: true, logLevel: 'silent', plugins: [{
  name: 'tank-wall-copy',
  setup(plugin) {
    plugin.onResolve({ filter: /^tank-carry-study$/ }, () => ({ path: stage + '/tank-pivot42.ts' }));
    plugin.onLoad({ filter: /(?:game\.ts|class-kits\.ts|catalog\.json)$/ }, ({ path: file }) => {
      const relative = path.relative(root, file).split(path.sep).join('/');
      const override = overrides.get(relative);
      if (!override) return;
      loaded.add(relative);
      return { contents: override[0], loader: override[1], resolveDir: path.dirname(file) };
    });
  },
}] });
assert.deepEqual([...loaded].sort(), [...overrides.keys()].sort());
assert.deepEqual(fingerprints(), before);
write(stage + '/tank-pivot-build43.json', { measuredAt: new Date().toISOString(), base: git('rev-parse','HEAD'), contentRevision: read('content/revision.json').sha256,
  runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256,
  copiedRegistrySha256: sha(JSON.stringify(catalog)), bundleSha256: sha(fs.readFileSync(bundle)), definition, pivotDefinition, canonicalSourceEdited: false, gameplayCasesRun: 0 });
console.log(JSON.stringify({ copiedGameBuild: true, replacements: loaded.size, card: definition.id, gameplayCasesRun: 0 }));
