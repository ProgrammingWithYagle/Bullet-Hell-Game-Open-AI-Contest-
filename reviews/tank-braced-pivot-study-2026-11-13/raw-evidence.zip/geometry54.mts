import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {root,read,write,sha,fingerprints} from '../heavy-corner-guide-stage/common.mjs';
const stage=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const before=fingerprints(),build=read(stage+'/tank-pivot-build48.json');
assert.equal(before.sourceSnapshotSha256,build.sourceSnapshotSha256);
assert.equal(sha(fs.readFileSync(stage+'/tank-game48.mjs')),build.bundleSha256);
const {Game}=await import(pathToFileURL(stage+'/tank-game48.mjs').href);
const {idleInput,HZ}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href);
const {distance,segmentRect}=await import(pathToFileURL(root+'/src/shared/geometry.ts').href);
const {constructHit}=await import(pathToFileURL(root+'/src/shared/class-kits.ts').href);
const {wallFootprintClear}=await import(pathToFileURL(stage+'/tank-carry25.ts').href);
const survey=read(stage+'/survey17.json');
const wrap=angle=>Math.atan2(Math.sin(angle),Math.cos(angle));
const point=({x,y})=>({x,y});

function trial(row,shape,route,angle,pivot){
  const g=new Game({mode:'endless',difficulty:row.difficulty,seed:41,openingArenaId:row.arena,arenaSelection:'fixed'});
  g.encounter=9;
  const p=g.addPlayer('solo','Controlled braced shield interception','tank');
  assert.equal(p.totalSp,27);
  for(const id of ['tank-protection-1',build.definition.id,build.pivotDefinition.id])
    assert(g.transact(p.id,{kind:'skill',id,item:id}).ok);
  assert(g.start());g.boss.staggerUntil=500;
  const aim=shape.aim,goal=wrap(aim+angle);
  const normal={x:Math.cos(aim),y:Math.sin(aim)},nextNormal={x:Math.cos(goal),y:Math.sin(goal)};
  const side={x:-normal.y*route.sign,y:normal.x*route.sign};
  let sequence=0;
  const wall=()=>g.classKits.cues().find(cue=>cue.kind==='wall'&&cue.owner===p.id);
  function step(input={}){
    assert(g.submitInput(p.id,{...idleInput(),sequence:++sequence,clientTick:g.combatTick,aim,...input}));
    g.step();return g.drainEvents();
  }
  step({q:true});const original=wall(),qAt=p.qAt;assert(original);
  const take={x:original.x-32*normal.x,y:original.y-32*normal.y};
  for(let n=0;n<40&&distance(p,take)>.5;n++){
    const length=Math.max(distance(p,take),g.movementSpeed(p)/HZ);
    step({moveX:(take.x-p.x)/length,moveY:(take.y-p.y)/length});
  }
  assert(distance(p,take)<=.5);step({technique1:true});
  assert(g.classKits.tankWallCarried(p.id,g.combatTick));const start=point(p);
  const stride=4*HZ/g.movementSpeed(p);
  for(let n=0;n<route.clearSteps;n++)step({moveX:side.x*stride,moveY:side.y*stride});
  assert(distance(start,p)>112);
  const body=point(p),world={...g.arena,obstacles:g.obstacles};
  const from={x:p.x+47.2*nextNormal.x,y:p.y+47.2*nextNormal.y};
  assert(!g.obstacles.some(rect=>segmentRect(from,p,rect,3)),'controlled launch needs a clear masonry ray');
  assert.equal(constructHit(from,p,wall(),3),null,'unturned shield already covers proposed threat');
  const frames=Math.ceil(Math.abs(angle)/(Math.PI/72));
  for(let n=0;n<=frames;n++){
    const a=aim+angle*n/frames,normal={x:Math.cos(a),y:Math.sin(a)};
    assert(wallFootprintClear(world,{x:p.x+normal.x*32,y:p.y+normal.y*32},normal,55),'proposed pivot arc is blocked');
  }
  assert(wallFootprintClear(world,{x:p.x+nextNormal.x*32,y:p.y+nextNormal.y*32},nextNormal,110),'proposed full setdown is blocked');
  const command=step({technique2:pivot,aim:goal});
  assert.equal(command.some(e=>e.type==='sound'&&e.id==='tank-wall-pivot'),pivot);
  for(let n=0;n<12;n++)step({aim:goal});
  assert(!g.classKits.tankPivotStatus(p.id).active);assert.deepEqual(point(p),body);
  const beforeShot=wall();assert(beforeShot);
  assert.equal(constructHit(from,p,beforeShot,3)!==null,pivot);
  assert(Math.abs(wrap(beforeShot.aim-aim)-(pivot?angle:0))<1e-7);
  const health=p.health,shield=p.shield,ammo=p.ammo;
  const shot=g.emitShot('hostile',from.x,from.y,Math.atan2(p.y-from.y,p.x-from.x),720,25,3);assert(shot);
  for(let n=0;n<5&&g.shots.has(shot.id);n++)step();
  assert(!g.shots.has(shot.id));const afterShot=wall();assert(afterShot);
  const wallDamage=beforeShot.health-afterShot.health,actorDamage=health-p.health,shieldDamage=shield-p.shield;
  assert.equal(wallDamage,pivot?25:0);
  if(pivot)assert.equal(actorDamage+shieldDamage,0);else assert(actorDamage+shieldDamage>0);
  step({technique1:true});assert(!g.classKits.tankWallCarried(p.id,g.combatTick));
  const set=wall();assert(set);assert.equal(set.id,original.id);assert.equal(set.until,original.until);
  assert.equal(set.halfSpan,original.halfSpan);assert.equal(set.health,original.health-wallDamage);
  assert.equal(p.qAt,qAt);assert.equal(p.ammo,ammo);
  return {pivot,body,moved:distance(start,body),angle,originalAim:aim,setAim:set.aim,
    wallDamage,actorDamage,shieldDamage,originalId:original.id,originalUntil:original.until,
    originalHealth:original.health,remainingHealth:set.health,qAt,setAt:g.combatTick,paidSP:5,projectileId:shot.id};
}

const rows=[];
for(const row of survey.rows){
  const attempts=[];
  const routes=row.surveyed.flatMap(shape=>shape.routes.filter(route=>route.halfSpan===55&&route.canSetFullWidth&&route.traveled>116&&route.remainingAtEnd>30)
    .map(route=>({shape,route})));
  outer:for(const {shape,route} of routes)for(const angle of [Math.PI/2,-Math.PI/2,Math.PI*2/3,-Math.PI*2/3]){
    try{
      const pivot=trial(row,shape,route,angle,true),fixed=trial(row,shape,route,angle,false);
      assert.deepEqual(pivot.body,fixed.body);assert.equal(pivot.originalUntil,fixed.originalUntil);
      assert.equal(pivot.qAt,fixed.qAt);assert.equal(pivot.paidSP,fixed.paidSP);
      attempts.push({passed:true,aim:shape.aim,side:route.sign,angle,pivot,fixed});break outer;
    }catch(error){attempts.push({passed:false,aim:shape.aim,side:route.sign,angle,error:error.message});}
  }
  const result={arena:row.arena,difficulty:row.difficulty,passed:attempts.some(attempt=>attempt.passed),attempts};rows.push(result);
  console.log(JSON.stringify({arena:row.arena,difficulty:row.difficulty,passed:result.passed,attempts:attempts.length}));
}
assert.deepEqual(fingerprints(),before);
const passed=rows.filter(row=>row.passed).length;
write(stage+'/tank-pivot-geometry54.json',{at:new Date().toISOString(),passed,total:rows.length,rows,bundleSha256:build.bundleSha256,
  runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,
  driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),
  scope:'Controlled copied-Game comparisons with the same actual 5-SP research purchases in a labelled 27-SP Endless lobby. Each pair walks the same legal route, waits the same 13 combat ticks and meets one injected hostile projectile from a newly exposed bearing. Boss stagger isolates the interception. Original health, first expiry, Q recovery and panel identity remain. Candidate route failures remain. No natural, canonical, online or balance claim.'});
console.log(JSON.stringify({passed,total:rows.length,failures:rows.filter(row=>!row.passed)}));
if(passed!==rows.length)process.exitCode=1;
