import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {root,read,write,sha,fingerprints,git} from '../heavy-corner-guide-stage/common.mjs';
const stage=path.dirname(fileURLToPath(import.meta.url));
process.chdir(root);
const before=fingerprints(),build=read(stage+'/tank-pivot-build48.json');
const source=read('reviews/heavy-corner-guide-r2-2026-11-12/frozen-verification.json');
assert(source.passed&&source.sourceCommit==='21f490af74c2a05c59fa94e1bf3ce6f8614c9279');
assert.equal(before.runtimeSourceSha256,source.runtimeSourceSha256);
assert.equal(before.sourceSnapshotSha256,source.sourceSnapshotSha256);
assert.equal(sha(fs.readFileSync(stage+'/tank-game48.mjs')),build.bundleSha256);
const controlled=read(stage+'/tank-pivot-controlled61.json'),geometry=read(stage+'/tank-pivot-geometry58.json');
assert(controlled.passed===controlled.total&&controlled.total===26);
assert(geometry.passed===geometry.total&&geometry.total===36);
for(const row of geometry.rows){
  const pass=row.attempts.find(attempt=>attempt.passed);assert(pass);
  assert.equal(pass.pivot.wallDamage,25);assert.equal(pass.pivot.actorDamage+pass.pivot.shieldDamage,0);
  assert.equal(pass.fixed.wallDamage,0);assert(pass.fixed.actorDamage+pass.fixed.shieldDamage>0);
  for(const arm of [pass.pivot,pass.fixed])assert(arm.setAt<arm.originalUntil&&arm.paidSP===5);
  if(!pass.pivot.canSetTurned)assert(pass.pivot.refusedWideSet&&pass.pivot.returnedToOriginalHeading);
}
const matrix=read(stage+'/tank-pivot-earned53-matrix.json');assert.equal(matrix.rows.length,48);
const old=read(stage+'/tank-carry-earned34-matrix.json');
const key=row=>[row.arena,row.difficulty,row.seed].join('/');
const original=new Map(old.rows.filter(row=>row.useCarry).map(row=>[key(row),row]));
let exact=0;
for(const row of matrix.rows.filter(row=>!row.usePivot)){
  const {usePivot,...comparable}=row;
  assert.deepEqual(comparable,original.get(key(row)),key(row));exact++;
}
assert.equal(exact,24);
const wrap=angle=>Math.atan2(Math.sin(angle),Math.cos(angle));
const turns=[];
for(const row of matrix.rows){
  const purchase=row.purchases.find(purchase=>purchase.item===build.pivotDefinition.id);
  if(purchase){assert(row.usePivot);assert.equal(purchase.earned,9);}
  for(const start of row.operations.filter(op=>op.kind==='pivot-started')){
    assert(purchase,'unowned natural turn');
    const end=row.operations.find(op=>op.kind==='pivot-ended'&&op.wall===start.wall&&op.tick>=start.tick);
    const completed=!!end&&end.tick-start.tick===12&&end.stillCarried&&Math.abs(wrap(end.aim-start.aim))<1e-7;
    const retainedHits=completed?row.operations.filter(op=>op.kind==='actual-carried-interception'&&op.wall===end.wall&&op.tick>=end.tick):[];
    turns.push({arena:row.arena,difficulty:row.difficulty,seed:row.seed,wall:start.wall,startTick:start.tick,endTick:end?.tick,
      goal:start.aim,endAim:end?.aim,completed,originalUntil:start.originalUntil,
      retainedHitsAfterCompletedTurn:retainedHits.length,retainedWallHealthLossAfterCompletedTurn:retainedHits.reduce((sum,hit)=>sum+hit.wallDamage,0)});
  }
}
const byPolicy=[false,true].map(usePivot=>{
  const rows=matrix.rows.filter(row=>row.usePivot===usePivot);
  return {usePivot,runs:rows.length,victories:rows.filter(row=>row.outcome==='victory').length,defeats:rows.filter(row=>row.outcome==='defeat').length,
    acquiredAtEarned9:rows.filter(row=>row.purchases.some(p=>p.item===build.pivotDefinition.id)).length,
    lifts:rows.flatMap(row=>row.operations.filter(op=>op.kind==='tank-wall-lift')).length,
    runsWithActualCarriedInterception:rows.filter(row=>row.actualCarriedWallDamage>0).length,
    actualCarriedWallHealthLoss:rows.reduce((sum,row)=>sum+row.actualCarriedWallDamage,0),
    triggerHeldDuringCarryTicks:rows.reduce((sum,row)=>sum+row.triggerHeldWhileCarriedTicks,0)};
});
assert.deepEqual(fingerprints(),before);
const summary={passed:true,at:new Date().toISOString(),verificationSourceCommit:source.sourceCommit,metadataBase:git('rev-parse','HEAD'),
  runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,
  copiedRegistrySha256:build.copiedRegistrySha256,copiedGameBundleSha256:build.bundleSha256,
  canonicalCardRegistered:false,canonicalTankSpecializations:0,canonicalSpecializations:69,canonicalLegalBuildCensus:2298,
  operation:{id:build.pivotDefinition.id,name:build.pivotDefinition.name,cost:2,freePlaySpRequired:5,actualNaturalAcquisitionSp:9,
    prerequisite:build.pivotDefinition.prerequisite,windCombatTicks:12,recoveryCombatTicks:60,originalWallHealthAndExpiryPreserved:true},
  controlledCases:{passed:controlled.passed,total:controlled.total},geometryPairs:{passed:geometry.passed,total:geometry.total,
    pairsRequiringReturnBeforeWideSet:geometry.rows.filter(row=>!row.attempts.find(a=>a.passed).pivot.canSetTurned).length},
  naturalTrials:matrix.rows.length,previousCarryRowsExactlyEqual:exact,byPolicy,
  naturalTurnStarts:turns.length,naturalCompletedCapturedTurns:turns.filter(turn=>turn.completed).length,
  naturalInterruptedOrObstructedTurns:turns.filter(turn=>!turn.completed).length,
  naturalRetainedHitsAfterCompletedTurn:turns.reduce((sum,turn)=>sum+turn.retainedHitsAfterCompletedTurn,0),
  naturalRetainedWallHealthLossAfterCompletedTurn:turns.reduce((sum,turn)=>sum+turn.retainedWallHealthLossAfterCompletedTurn,0),turns,
  originalEvidencePreserved:['tank-pivot-controlled44.json','tank-pivot-controlled45.json','tank-pivot-controlled46.json','tank-pivot-controlled60.json',
    'tank-pivot-geometry54.json','tank-pivot-geometry55.json','tank-pivot-geometry56.json','tank-pivot-diagnostic57.json'],
  pending:['Authored Tank branch metadata and alternative handling','Canonical source cards and UI','Owned controls, remaps and both saved HUD layouts',
    'Art and sound','Exact edition76 before75 admission across ownership and all twelve profile/history rosters',
    'Optimized worker and actual non-host earned acquisition','Source/full gate/exact CI/frozen proof for an actual content edition',
    'Human, rendered, device, native-language, listening, motion and final balance acceptance'],
  interpretation:'All natural outcomes and opportunity-cost spending remain. Original carry rows compare exactly only for the 24 omitted-fitting rows. The earlier Tethered 126 comparison is separate and remains allMeasuredFieldsMatch=false. Research imports and these copied bundles never establish online or canonical proof.'};
write(stage+'/tank-pivot-summary62.json',summary);
console.log(JSON.stringify({...summary,turns:undefined,pending:undefined,originalEvidencePreserved:undefined}));
