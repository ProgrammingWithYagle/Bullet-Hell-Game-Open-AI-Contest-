import { tankCarryId, wallFootprintClear } from './tank-carry25.ts';
export { tankCarryId, wallFootprintClear };
export const pivotId = 'tank-bulwark-pivot-1';
export const pivotRules = { windTicks: 12, recoveryTicks: 60 };
const rotate = (point, angle) => ({
  x: point.x * Math.cos(angle) - point.y * Math.sin(angle),
  y: point.x * Math.sin(angle) + point.y * Math.cos(angle),
});

const leadDistance = 32;
const pickupRange = 37;
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const normalOf = wall => ({ x: Math.cos(wall.aim), y: Math.sin(wall.aim) });
const lead = (body, normal) => ({
  x: body.x + normal.x * leadDistance,
  y: body.y + normal.y * leadDistance,
});
type Member = { id: number; halfSpan?: number; offset: { x: number; y: number } };
type Pivot = {
  at: number;
  until: number;
  angle: number;
  fromNormal: { x: number; y: number };
  startMembers: { id: number; aim: number; offset: { x: number; y: number } }[];
};
type HeldWall = {
  weapon: string;
  normal: { x: number; y: number };
  members: Member[];
  pivot?: Pivot;
  pivotUsed?: boolean;
};

export class TankCarryStudy {
  private held = new Map<string, HeldWall>();
  private commands = new Map<string, number>();
  private pivotRecovery = new Map<string, number>();

  clear() {
    this.held.clear();
    this.commands.clear();
    this.pivotRecovery.clear();
  }

  remove(id, walls) {
    for (const member of this.held.get(id)?.members ?? []) walls.delete(member.id);
    this.held.delete(id);
    this.commands.delete(id);
  }

  active(id, walls, tick) {
    const held = this.held.get(id);
    if (!held) return;
    held.members = held.members.filter(member => {
      const wall = walls.get(member.id);
      return wall?.owner === id && wall.until > tick && wall.health > 0;
    });
    if (held.members.length) return walls.get(held.members[0].id);
    this.held.delete(id);
  }

  step(players, walls, tick) {
    for (const [id, held] of this.held) {
      if (!this.active(id, walls, tick)) continue;
      const player = players.find(player => player.id === id);
      if (!player?.connected || player.status !== 'active' || player.weapon !== held.weapon ||
          !player.skills.includes(tankCarryId)) this.remove(id, walls);
    }
  }

  pivotStatus(id) {
    return { active: !!this.held.get(id)?.pivot, readyAt: this.pivotRecovery.get(id) ?? 0 };
  }

  beginPivot(player, walls, world, next = player) {
    if (!player.skills.includes(pivotId) || !this.active(player.id, walls, world.tick) ||
        player.input.technique1 || player.input.moveX || player.input.moveY ||
        distance(player, next) > .01 ||
        distance(player, { x: player.oldX ?? player.x, y: player.oldY ?? player.y }) > .01 ||
        player.input.reload || player.input.dodge || player.input.q || player.input.e || player.input.ultimate ||
        world.tick < (this.pivotRecovery.get(player.id) ?? 0) ||
        player.input.sequence <= (this.commands.get(player.id) ?? -1)) return false;
    const held = this.held.get(player.id)!;
    if (held.pivot) return false;
    const members = held.members.map(member => ({ ...member, wall: walls.get(member.id) }));
    if (members.some(member => member.wall.until <= world.tick + pivotRules.windTicks)) return false;
    const from = Math.atan2(held.normal.y, held.normal.x);
    const angle = Math.atan2(Math.sin(player.input.aim - from), Math.cos(player.input.aim - from));
    if (Math.abs(angle) < .02) return false;
    this.commands.set(player.id, player.input.sequence);
    this.pivotRecovery.set(player.id, world.tick + pivotRules.recoveryTicks);
    held.pivotUsed = true;
    held.pivot = {
      at: world.tick, until: world.tick + pivotRules.windTicks, angle,
      fromNormal: { ...held.normal },
      startMembers: members.map(member => ({ id: member.id, aim: member.wall.aim, offset: { ...member.offset } })),
    };
    return true;
  }

  private advancePivot(player, held, walls, world) {
    const pivot = held.pivot!;
    const fraction = Math.min(1, (world.tick - pivot.at) / pivotRules.windTicks);
    const targetAngle = pivot.angle * fraction;
    const currentAngle = Math.atan2(
      pivot.fromNormal.x * held.normal.y - pivot.fromNormal.y * held.normal.x,
      pivot.fromNormal.x * held.normal.x + pivot.fromNormal.y * held.normal.y,
    );
    const steps = Math.max(1, Math.ceil(Math.abs(targetAngle - currentAngle) / (Math.PI / 72)));
    for (let step = 1; step <= steps; step++) {
      const angle = currentAngle + (targetAngle - currentAngle) * step / steps;
      const normal = rotate(pivot.fromNormal, angle);
      const center = lead(player, normal);
      const frames = held.members.map(member => {
        const original = pivot.startMembers.find(original => original.id === member.id)!;
        const offset = rotate(original.offset, angle);
        return { member, wall: walls.get(member.id), offset,
          point: { x: center.x + offset.x / 2, y: center.y + offset.y / 2 },
          aim: original.aim + angle };
      });
      if (frames.some(frame => !wallFootprintClear(world, frame.point,
          { x: Math.cos(frame.aim), y: Math.sin(frame.aim) }, (frame.member.halfSpan ?? 110) / 2))) {
        held.pivot = undefined;
        return;
      }
      held.normal = normal;
      for (const frame of frames) {
        frame.member.offset = frame.offset;
        Object.assign(frame.wall, frame.point, { aim: frame.aim });
      }
    }
    if (world.tick >= pivot.until) held.pivot = undefined;
  }

  private frames(held, center, folded, walls) {
    const fraction = folded ? 0.5 : 1;
    return held.members.map(member => ({
      wall: walls.get(member.id),
      center: {
        x: center.x + member.offset.x * fraction,
        y: center.y + member.offset.y * fraction,
      },
      halfSpan: (member.halfSpan ?? 110) * fraction,
      originalSpan: member.halfSpan,
    }));
  }

  command(player, walls, world) {
    if (!player.skills.includes(tankCarryId) || player.dashUntil > world.tick ||
        player.reloadAt > world.tick || player.input.q || player.input.dodge) return;
    if (player.input.sequence <= (this.commands.get(player.id) ?? -1)) return;
    this.commands.set(player.id, player.input.sequence);
    if (this.active(player.id, walls, world.tick)) {
      const held = this.held.get(player.id)!;
      const frames = this.frames(held, lead(player, held.normal), false, walls);
      if (frames.some(frame => !wallFootprintClear(world, frame.center, normalOf(frame.wall), frame.halfSpan))) return;
      for (const frame of frames) Object.assign(frame.wall, frame.center, { halfSpan: frame.originalSpan });
      this.held.delete(player.id);
      return 'set';
    }

    const available = [...walls.values()]
      .filter(wall => wall.owner === player.id && wall.kind === 'wall' &&
        (!wall.source || wall.source.startsWith('corner-')) && wall.until > world.tick && wall.health > 0)
      .sort((a, b) => b.at - a.at || a.id - b.id);
    const first = available[0];
    if (!first) return;
    const group = first.source
      ? available.filter(wall => wall.source?.startsWith('corner-') && wall.at === first.at)
      : [first];
    const center = {
      x: group.reduce((sum, wall) => sum + wall.x, 0) / group.length,
      y: group.reduce((sum, wall) => sum + wall.y, 0) / group.length,
    };
    const heading = {
      x: group.reduce((sum, wall) => sum + Math.cos(wall.aim), 0),
      y: group.reduce((sum, wall) => sum + Math.sin(wall.aim), 0),
    };
    const length = Math.hypot(heading.x, heading.y);
    if (length < 1e-6) return;
    const normal = group.length === 1 ? normalOf(first) : { x: heading.x / length, y: heading.y / length };
    const carriedCenter = lead(player, normal);
    const rear = (center.x - player.x) * normal.x + (center.y - player.y) * normal.y;
    if (distance(player, center) > pickupRange || rear < 23 || distance(center, carriedCenter) > 12) return;
    const held = {
      weapon: player.weapon,
      normal,
      members: group.map(wall => ({
        id: wall.id, halfSpan: wall.halfSpan,
        offset: { x: wall.x - center.x, y: wall.y - center.y },
      })),
    };
    const frames = this.frames(held, carriedCenter, true, walls);
    if (frames.some(frame => !wallFootprintClear(world, frame.center, normalOf(frame.wall), frame.halfSpan))) return;
    this.held.set(player.id, held);
    for (const frame of frames) Object.assign(frame.wall, frame.center, { halfSpan: frame.halfSpan });
    return 'lift';
  }

  move(player, next, walls, world) {
    if (!this.active(player.id, walls, world.tick)) return next;
    const held = this.held.get(player.id)!;
    if (held.pivotUsed && !player.skills.includes(pivotId)) {
      this.remove(player.id, walls);
      return next;
    }
    const current = this.frames(held, lead(player, held.normal), true, walls);
    if (player.weapon !== held.weapon || !player.skills.includes(tankCarryId) ||
        current.some(frame => !wallFootprintClear(world, frame.center, normalOf(frame.wall), frame.halfSpan))) {
      this.remove(player.id, walls);
      return next;
    }
    if (held.pivot) {
      const ejected = distance(player, { x: player.oldX ?? player.x, y: player.oldY ?? player.y }) > .01;
      if (player.input.technique1 || player.input.moveX || player.input.moveY ||
          distance(player, next) > .01 || ejected) held.pivot = undefined;
      else {
        this.advancePivot(player, held, walls, world);
        return player;
      }
    }
    const target = this.frames(held, lead(next, held.normal), true, walls);
    const steps = Math.max(1, ...target.map(frame => Math.ceil(distance(frame.wall, frame.center) / 3)));
    for (let n = 1; n <= steps; n++) for (const frame of target) {
      const portion = n / steps;
      const center = {
        x: frame.wall.x + (frame.center.x - frame.wall.x) * portion,
        y: frame.wall.y + (frame.center.y - frame.wall.y) * portion,
      };
      if (!wallFootprintClear(world, center, normalOf(frame.wall), frame.halfSpan)) return player;
    }
    for (const frame of target) Object.assign(frame.wall, frame.center);
    return next;
  }
}
