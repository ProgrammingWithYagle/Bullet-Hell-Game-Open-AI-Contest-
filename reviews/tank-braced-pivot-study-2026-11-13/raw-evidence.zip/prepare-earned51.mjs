import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {one,write,sha} from '../heavy-corner-guide-stage/common.mjs';
const stage=path.dirname(fileURLToPath(import.meta.url));
let code=fs.readFileSync(stage+'/earned34.mts','utf8');
code=code.replaceAll('tank-carry-build33.json','tank-pivot-build48.json').replaceAll('tank-game33.mjs','tank-game48.mjs');
code=one(code,'function trial(arena,difficulty,seed,useCarry){','function trial(arena,difficulty,seed,usePivot){\n  const useCarry=true;');
code=one(code,"    if(g.encounter>0)for(const id of ['general-sprint','general-brake-step','general-double-dash'])",`    if(usePivot&&g.encounter>0&&!p.skills.includes(build.pivotDefinition.id))assert(buy('skill',build.pivotDefinition.id));
    if(g.encounter>0)for(const id of ['general-sprint','general-brake-step','general-double-dash'])`);
code=one(code,"        }else{\n          note('set-command'",`          if(usePivot&&p.skills.includes(build.pivotDefinition.id)&&!work.pivotAttempted&&
              distance(p,work.target)<=.7&&g.combatTick-work.at>=20&&g.combatTick<work.until-15){
            work.pivotAttempted=true;
            input={...input,moveX:0,moveY:0,technique2:true,aim:ordinary.aim};
            note('pivot-command',{aim:ordinary.aim,wall:current.id,originalUntil:work.until});
          }
          if(g.classKits.tankPivotStatus(p.id).active)input={...input,moveX:0,moveY:0};
        }else{
          note('set-command'`);
code=one(code,'      const encounter=g.encounter;\n      assert(g.submitInput',`      const encounter=g.encounter;
      const pivotBefore=g.classKits.tankPivotStatus(p.id).active;
      assert(g.submitInput`);
code=one(code,'      const after=wall();\n      if(carrying',`      const after=wall();
      const pivotAfter=g.classKits.tankPivotStatus(p.id);
      if(!pivotBefore&&pivotAfter.active)note('pivot-started',{wall:after?.id,aim:input.aim,readyAt:pivotAfter.readyAt,originalUntil:after?.until});
      if(pivotBefore&&!pivotAfter.active)note('pivot-ended',{wall:after?.id,aim:after?.aim,originalUntil:after?.until,stillCarried:g.classKits.tankWallCarried(p.id,g.combatTick)});
      if(carrying`);
code=one(code,'return {arena,difficulty,seed,useCarry,outcome:', 'return {arena,difficulty,seed,useCarry,usePivot,outcome:');
code=one(code,'for(const arena of arenas)for(const difficulty of difficulties)for(const seed of [41,73])for(const useCarry of [false,true]){',
  'for(const arena of arenas)for(const difficulty of difficulties)for(const seed of [41,73])for(const usePivot of [false,true]){');
code=one(code,'const row=trial(arena,difficulty,seed,useCarry);','const row=trial(arena,difficulty,seed,usePivot);');
code=one(code,'{arena,difficulty,seed,useCarry,outcome:row.outcome,', '{arena,difficulty,seed,usePivot,outcome:row.outcome,pivots:row.operations.filter(op=>op.kind===\'pivot-started\').length,');
code=code.replaceAll('tank-carry-earned34-','tank-pivot-earned52-');
code=one(code,"  scope:'Isolated research registry with actual starting3SP purchases", "  scope:'Braced Pivot is bought at actual earned9SP after the first ordinary Short clear. Both arms own Shoulder Wall at the ordinary3SP start. The pivot arm attempts one stationary committed turn toward its live target after arrival per later encounter. The original wall expiry and health remain. Different later purchases are retained as opportunity costs. No canonical, online, human or balance-ranking claim. Isolated research registry with actual starting3SP purchases");
assert(!fs.existsSync(stage+'/earned52.mts'));
fs.writeFileSync(stage+'/earned52.mts',code,{flag:'wx'});
write(stage+'/earned-preparation51.json',{at:new Date().toISOString(),driverSha256:sha(code),baseDriver:'earned34.mts',
  sourceChanged:false,policy:'Base carry and optional stationary Pivot. Buy at earned9 before other new spending. One attempt after a clear route reaches its ordinary destination. All natural failures remain.'});
