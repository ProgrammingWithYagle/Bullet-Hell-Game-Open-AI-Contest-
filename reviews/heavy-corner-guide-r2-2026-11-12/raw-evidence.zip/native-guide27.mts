import assert from 'node:assert/strict';
import fs from 'node:fs';
import { spawn } from 'node:child_process';
import { setTimeout as sleep } from 'node:timers/promises';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { root, stage, read, write, sha, git } from './common.mjs';
import { digestFile, protocol, revision, scope, source } from './publication.mjs';
import { checkGuideAcquisition } from './guide-proof.mjs';

process.chdir(root);
const audiences = ['testing', 'public'] as const;
const fittings = ['bare', 'yoke', 'sheave'] as const;
const commit = source();
assert.equal(git('rev-parse', 'HEAD'), commit);
const driver = fileURLToPath(import.meta.url);
const driverSha256 = digestFile(driver);
const input = process.argv.slice(2);
type Audience = (typeof audiences)[number];
type Fitting = (typeof fittings)[number];
type Transport = 'worker' | 'peer';

function frozen(audience: Audience) {
  const preview = read(scope + '/preview-' + audience + '.json');
  assert.equal(preview.sourceCommit, commit);
  assert.equal(preview.protocol, protocol);
  assert.equal(preview.contentRevision, revision);
  assert.equal(digestFile(preview.manifestPath), preview.manifestSha256);
  return { preview, manifest: read(preview.manifestPath) };
}

async function served(url: string, checksum: string) {
  const response = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  assert.equal(response.status, 200, url);
  const bytes = Buffer.from(await response.arrayBuffer());
  assert.equal(sha(bytes), checksum, url);
  return bytes;
}

async function checkHealth(endpoint: string, audience: Audience) {
  const response = await fetch(endpoint + '/api/health', { signal: AbortSignal.timeout(10_000) });
  assert.equal(response.status, 200);
  const health = await response.json();
  assert.equal(health.sourceCommit, commit);
  assert.equal(health.protocolVersion, protocol);
  assert.equal(health.contentRevision, revision);
  assert.equal(health.audience, audience);
  return health;
}

async function runCase(audience: Audience, transport: Transport, fitting: Fitting, destination: string) {
  const { preview, manifest } = frozen(audience);
  const health = await checkHealth(preview.endpoint, audience);
  const { runLineworkWorker, runLineworkPeers } = await import(pathToFileURL(root + '/tests/helpers/heavy-linework-transport.ts').href);
  const worker = manifest.members.find((file: {path: string}) => /offline\.worker-.*\.js$/.test(file.path));
  assert(worker);
  const bytes = await served(new URL(worker.path, preview.url).href, worker.sha256);
  assert.equal(digestFile(preview.backend.path), preview.backend.sha256);
  const result = transport === 'worker'
    ? await runLineworkWorker(bytes.toString('utf8'), fitting, 'guide')
    : await runLineworkPeers(preview.endpoint, fitting, 'guide');
  checkGuideAcquisition(result, transport, fitting);
  const receipt = { ...result, checkedAt: new Date().toISOString(), sourceCommit: commit, protocol, contentRevision: revision,
    audience, endpoint: preview.endpoint, url: preview.url, servedWorker: worker, backendBundleSha256: preview.backend.sha256,
    backendStartedAt: health.startedAt, driverSha256, noCheckpointImport: true };
  write(destination, receipt);
  console.log(JSON.stringify(receipt));
}

function runLogged(args: string[], log: string, deadlineMs: number) {
  const fd = fs.openSync(log, 'wx');
  return new Promise<{code: number | null, signal: string | null}>((resolve, reject) => {
    const child = spawn(process.execPath, args, { stdio: ['ignore', fd, fd], windowsHide: true });
    const timeout = setTimeout(() => child.kill(), deadlineMs);
    child.once('error', error => { clearTimeout(timeout); fs.closeSync(fd); reject(error); });
    child.once('exit', (code, signal) => { clearTimeout(timeout); fs.closeSync(fd); resolve({code, signal}); });
  });
}

async function audienceCheck(audience: Audience, attempt: string) {
  const { preview, manifest } = frozen(audience);
  await checkHealth(preview.endpoint, audience);
  const prefix = stage + '/' + attempt + '-' + audience;
  const httpReport = scope + '/smoke-' + audience + '.json';
  assert(!fs.existsSync(httpReport), 'Inspect existing HTTP execution evidence before retry');
  const httpLog = prefix + '-http.log';
  const http = await runLogged(['--import', 'tsx', 'tools/smoke-client-review.mts', audience, scope], httpLog, 90_000);
  assert.equal(http.code, 0, httpLog);
  const httpProof = read(httpReport);
  assert(httpProof.passed && httpProof.probeRoomsClosed);
  assert.equal(httpProof.sourceCommit, commit);
  assert.equal(httpProof.backendBundleSha256, preview.backend.sha256);

  const emittedEmblems = [];
  for (const filename of ['heavy-linework-1', 'heavy-linework-yoke-1', 'heavy-linework-sheave-1', 'heavy-linework-reserve-1', 'heavy-linework-guide-1']) {
    const member = manifest.members.find((file: {path: string}) => file.path.startsWith('assets/' + filename + '-') && file.path.endsWith('.png'));
    assert(member, filename);
    assert.equal(digestFile('assets/production/ui/heavy-tree-2026-11-06/' + filename + '.png'), member.sha256);
    await served(new URL(member.path, preview.url).href, member.sha256);
    emittedEmblems.push(member);
  }
  const runTransport = async (transport: Transport) => {
    const cases = [];
    for (const fitting of fittings) {
      const startedAt = new Date().toISOString();
      const log = prefix + '-' + transport + '-' + fitting + '.log';
      const destination = prefix + '-' + transport + '-' + fitting + '.json';
      const result = await runLogged(['--import', 'tsx', driver, 'case', audience, transport, fitting, destination], log, 300_000);
      const receipt = fs.existsSync(destination) ? read(destination) : undefined;
      const passed = result.code === 0 && receipt?.passed === true;
      cases.push({ transport, fitting, passed, ...result, startedAt, finishedAt: new Date().toISOString(),
        log, logSha256: digestFile(log), receipt: receipt && destination, receiptSha256: receipt && digestFile(destination) });
      console.log(JSON.stringify({ audience, transport, fitting, passed, walked: receipt?.walked,
        payout: receipt?.payout, paidPrimaryProjectiles: receipt?.paidPrimaryProjectiles, guideFirstHaul: receipt?.guide?.firstHaul, guideSecondHaul: receipt?.guide?.towardOriginal }));
    }
    return cases;
  };
  const [worker, peer] = await Promise.all([runTransport('worker'), runTransport('peer')]);
  const cases = [...worker, ...peer];
  const cleanupUntil = Date.now() + 10_000;
  let metrics;
  do {
    const response = await fetch(preview.endpoint + '/api/metrics', { signal: AbortSignal.timeout(5_000) });
    assert.equal(response.status, 200);
    metrics = await response.json();
    if (metrics.rooms === 0 && metrics.connections === 0) break;
    await sleep(100);
  } while (Date.now() < cleanupUntil);
  const report = { passed: cases.every(test => test.passed) && metrics.rooms === 0 && metrics.connections === 0,
    checkedAt: new Date().toISOString(), sourceCommit: commit, protocol, contentRevision: revision, audience, driverSha256,
    url: preview.url, endpoint: preview.endpoint, caseCount: cases.length + 1, httpReport, httpReportSha256: digestFile(httpReport),
    httpLog, httpLogSha256: digestFile(httpLog), emittedEmblems, cases, remainingProbeRooms: metrics.rooms, remainingProbeConnections: metrics.connections };
  write(prefix + '-result.json', report);
  assert(report.passed, 'Inspect preserved original native outputs');
}

if (input[0] === 'case') {
  const [, audience, transport, fitting, destination] = input;
  assert(audiences.includes(audience as Audience) && fittings.includes(fitting as Fitting));
  assert(transport === 'peer' || transport === 'worker');
  assert(destination.startsWith(stage + '/') && !fs.existsSync(destination));
  await runCase(audience as Audience, transport, fitting as Fitting, destination);
} else {
  const attempt = input[0] ?? 'native27';
  assert(/^native\d+$/.test(attempt));
  const settled = await Promise.allSettled(audiences.map(audience => audienceCheck(audience, attempt)));
  for (const outcome of settled) if (outcome.status === 'rejected') console.error(outcome.reason);
  assert(settled.every(outcome => outcome.status === 'fulfilled'));
}
