import assert from 'node:assert/strict';
import fs from 'node:fs';
import { root, stage, baseline, issuedRevision, read, write, sha, git, gitBytes, fingerprints } from './common.mjs';

process.chdir(root);
assert.equal(git('rev-parse', 'HEAD'), baseline);
const exact = fingerprints();
const change = read(stage + '/traffic-correction29.json');
assert.equal(exact.sourceSnapshotSha256, change.sourceSnapshotSha256);
const catalog = read('content/catalog.json');
const priorCatalog = JSON.parse(gitBytes('show', 'b82cd6f07cb3db0e40fa8fc774d28c104f7ea57a:content/catalog.json').toString('utf8'));
const contentRevision = read('content/revision.json').sha256;
assert.equal(sha(JSON.stringify(catalog)), contentRevision);
assert.equal(sha(JSON.stringify(priorCatalog)), issuedRevision);
const specializations = catalog.specializationSkills.filter(skill => skill.id !== 'heavy-linework-guide-1');
assert.equal(specializations.length + 1, catalog.specializationSkills.length);
const { heavyLineworkGuide, ...rules } = catalog.rules;
assert.deepEqual({ ...catalog, specializationSkills: specializations, rules }, priorCatalog);
assert.deepEqual(Object.keys(heavyLineworkGuide).sort(), ['cornerHalfAngle', 'redirectReach', 'setReach']);
assert.equal(catalog.skills.length, 648);
assert.equal(catalog.generalSkills.length, 4);
assert.equal(catalog.classes.length, 12);

const issued = read('tests/fixtures/heavy-linework-issued75.json');
const newKey = key => key.startsWith('ui.heavy.guide') || key.startsWith('skill.heavy-linework-guide-1.');
const messages = catalog.locales.map(({ id }) => {
  const file = 'locales/' + id + '.json';
  const { messages } = read(file);
  const retained = Object.fromEntries(Object.entries(messages).filter(([key]) => !newKey(key)));
  assert.equal(sha(JSON.stringify(retained)), issued.localeHashes[id]);
  const added = Object.fromEntries(Object.entries(messages).filter(([key]) => newKey(key)));
  assert(Object.values(added).every(value => typeof value === 'string' && value.trim().length > 0));
  assert.deepEqual(added, Object.fromEntries(Object.entries(read('locales/en.json').messages).filter(([key]) => newKey(key))));
  return { locale: id, retainedMessages: Object.keys(retained).length, addedEnglishPilotMessages: Object.keys(added).length };
});
const artwork = 'assets/production/ui/heavy-tree-2026-11-06/provenance.json';
const priorArt = JSON.parse(gitBytes('show', 'b82cd6f07cb3db0e40fa8fc774d28c104f7ea57a:' + artwork).toString('utf8'));
const currentArt = read(artwork);
assert.deepEqual(currentArt.assets.slice(0, -1), priorArt.assets);
for (const asset of currentArt.assets) assert.equal(sha(fs.readFileSync(asset.file)), asset.sha256);
const guide = currentArt.assets.at(-1);
assert.equal(guide.id, 'heavy-linework-guide-1');
assert.equal(guide.sha256, 'e6ffdf83f0ad7bf848eb40f2726d24c403b69e8c83896b5423c2bf2c5aee80fb');
const runs = ['corner', 'face'].map(layout => {
  const canonical = read(stage + '/canonical-guide-short29-' + layout + '.json');
  const research = read('C:/Users/yigal/Documents/Codex/2026-11-10/continue-grave-accord-in-the-same/work/heavy-corner-guide-stage/earned-guide07-' + layout + '.json');
  assert.equal(canonical.sourceSnapshotSha256, exact.sourceSnapshotSha256);
  assert.equal(canonical.runtimeSourceSha256, exact.runtimeSourceSha256);
  assert.equal(canonical.contentRevision, contentRevision);
  const changes = [];
  assert.equal(canonical.rows.length, research.rows.length);
  for (let i = 0; i < canonical.rows.length; i++) {
    const actual = canonical.rows[i], previous = research.rows[i];
    for (const key of ['arena', 'seed', 'useGuide', 'outcome', 'clears', 'purchases', 'operations', 'phaseStates', 'finalSpent', 'finalEarned', 'damageTaken', 'endingHealth']) {
      if (JSON.stringify(actual[key]) !== JSON.stringify(previous[key])) changes.push({ arena: actual.arena, seed: actual.seed, useGuide: actual.useGuide, key });
    }
  }
  return { layout, pairs: canonical.rows.length / 2, changedFields: changes, allMeasuredFieldsMatch: changes.length === 0 };
});
assert.deepEqual(fingerprints(), exact);
write(stage + '/catalog-preservation30.json', { passed: true, checkedAt: new Date().toISOString(), contentRevision, priorContentRevision: issuedRevision,
  runtimeSourceSha256: exact.runtimeSourceSha256, sourceSnapshotSha256: exact.sourceSnapshotSha256, sourceBaseline: baseline,
  everyIssuedCatalogValueExact: true, generalNodes: catalog.skills.length, sharedTechniques: catalog.generalSkills.length, classes: catalog.classes.length,
  oldArtworkExact: priorArt.assets.length, newGuideArtwork: guide.sha256, messages, runs });
console.log(JSON.stringify({ passed: true, priorCatalogValuesExact: true, locales: messages.length, oldArtworkExact: priorArt.assets.length, runs }));
