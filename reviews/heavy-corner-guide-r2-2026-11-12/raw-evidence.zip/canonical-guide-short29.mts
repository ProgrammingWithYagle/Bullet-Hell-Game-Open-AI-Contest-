import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { root, stage, baseline, read, write, sha, fingerprints } from './common.mjs';

process.chdir(root);
const before = fingerprints();
const contentRevision = read('content/revision.json').sha256;
const layout = process.argv[2] ?? 'corner';
assert(layout === 'corner' || layout === 'face');
const { Game, data } = await import(pathToFileURL(root + '/src/shared/game.ts').href);
assert.equal(sha(JSON.stringify(data)), contentRevision);
const { idleInput, HZ } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { viewOf } = await import(pathToFileURL(root + '/src/shared/view.ts').href);
const { segmentRect } = await import(pathToFileURL(root + '/src/shared/geometry.ts').href);
const { restRaidInput } = await import(pathToFileURL(root + '/tests/helpers/sniper-rest-raid-policy.ts').href);
const geometry = layout === 'corner'
  ? read(stage + '/../heavy-lineworker-admission-stage/linework-guide45.json')
  : read('C:/Users/yigal/Documents/Codex/2026-11-10/continue-grave-accord-in-the-same/work/heavy-corner-guide-stage/wall-face-baby07.json');
const id = 'heavy-linework-guide-1';
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const point = p => ({ x: p.x, y: p.y });
const angle = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);

function approachRoute(g, start, goal) {
  const clearance = data.rules.playerRadius;
  const b = g.arena.bounds;
  const walls = g.obstacles;
  const inside = p => p.x > b.x + clearance && p.y > b.y + clearance &&
    p.x < b.x + b.width - clearance && p.y < b.y + b.height - clearance;
  const clear = (a, b) => !walls.some(wall => segmentRect(a, b, wall, clearance + 0.2));
  const nodes = [start, goal];
  for (const wall of walls) for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
    const p = { x: wall.x + (sx > 0 ? wall.width : 0) + sx * (clearance + 4),
      y: wall.y + (sy > 0 ? wall.height : 0) + sy * (clearance + 4) };
    if (inside(p) && clear(p, p)) nodes.push(p);
  }
  const costs = nodes.map(() => Infinity), predecessor = nodes.map(() => -1), visited = new Set();
  costs[0] = 0;
  for (;;) {
    let next = -1;
    for (let n = 0; n < nodes.length; n++) if (!visited.has(n) && (next < 0 || costs[n] < costs[next])) next = n;
    if (next < 0 || !Number.isFinite(costs[next])) return [];
    if (next === 1) break;
    visited.add(next);
    for (let n = 1; n < nodes.length; n++) {
      const cost = costs[next] + distance(nodes[next], nodes[n]);
      if (cost < costs[n] && clear(nodes[next], nodes[n])) {
        costs[n] = cost;
        predecessor[n] = next;
      }
    }
  }
  const route = [];
  for (let n = 1; n > 0; n = predecessor[n]) route.unshift(nodes[n]);
  return route;
}

function trial(arena, seed, useGuide) {
  const g = new Game({ mode: 'short', difficulty: 'baby', seed, maxPlayers: 1, openingArenaId: arena, arenaSelection: 'fixed' });
  const p = g.addPlayer('solo', 'Earned guide study', 'heavy');
  const observed = new Map(), operations = [], clears = [], purchases = [], states = [];
  let serial = 0, sequence = 0, phase = '', cleared = 0, attempted = false, probe;
  let operation, stageAt = 0, route = [], plan, castOrigin, motorStart, directEnd, firstOrigin, secondStart;
  const note = (kind, fields = {}) => operations.push({ kind, tick: g.combatTick, position: point(p), health: p.health, ammo: p.ammo, ...fields });
  const buy = (kind, item) => {
    const result = g.transact(p.id, { id: 'guide-study-' + ++serial, kind, item });
    if (result.ok) purchases.push({ kind, item, encounter: g.encounter, earned: p.totalSp });
    return result;
  };
  function shop() {
    if (!p.skills.includes('heavy-ordnance-1')) assert(buy('skill', 'heavy-ordnance-1').ok);
    if (!p.skills.includes('heavy-linework-1')) assert(buy('skill', 'heavy-linework-1').ok);
    if (g.encounter === 1 && useGuide) {
      const before = { total: p.totalSp, skills: [...p.skills], coins: p.coins };
      probe = buy('skill', id);
      assert(!probe.ok);
      assert.deepEqual({ total: p.totalSp, skills: [...p.skills], coins: p.coins }, before);
    }
    if (g.encounter === 2 && useGuide) {
      assert.equal(p.totalSp, 15);
      assert(buy('skill', id).ok);
    }
    if (g.encounter > 0 && !p.skills.includes('general-sprint')) buy('skill', 'general-sprint');
    if (g.encounter > 1 && !p.skills.includes('general-double-dash')) buy('skill', 'general-double-dash');
    for (const weapon of data.weapons.filter(w => w.classId === 'heavy').sort((a, b) => b.tier - a.tier)) {
      if (p.weapon === weapon.id || buy('weapon', weapon.id).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy('upgrade', item);
    buy('supply', 'medkit');
  }
  assert.equal(p.totalSp, 3);
  shop();
  assert(g.start());

  function switchTo(value) { operation = value; stageAt = g.combatTick; }
  const walk = to => {
    const length = Math.max(distance(p, to), g.movementSpeed(p) / HZ);
    return { aim: angle(p, to), moveX: (to.x - p.x) / length, moveY: (to.y - p.y) / length };
  };
  function guideControl(kit) {
    const line = kit.lineworkConnection;
    if (!operation) return;
    if (g.combatTick - stageAt > (operation === 'approach' ? 150 : 45)) {
      note('approach-or-command-bound', { operation }); switchTo(undefined); return;
    }
    if (operation === 'approach') {
      while (route.length && distance(p, route[0]) <= 0.8) route.shift();
      if (route.length) return walk(route[0]);
      castOrigin = point(p); switchTo('flight'); note('manual-cast');
      return { aim: Math.atan2(plan.approach.y, plan.approach.x), technique1: true };
    }
    if (operation === 'flight' && !line) {
      if (g.combatTick - stageAt < 20) return {};
      note('paid-flight-without-anchor'); switchTo(undefined); return;
    }
    if (operation === 'flight') {
      if (distance(line.origin, plan.anchor) > 3) {
        note('different-live-contact', { anchor: line.origin }); switchTo(undefined); return { technique1: true };
      }
      directEnd = {x: line.origin.x + line.normal.x * 1.25, y: line.origin.y + line.normal.y * 1.25};
      firstOrigin = { ...line.origin };
      note('attached', { from: castOrigin, originalUntil: line.until }); switchTo('walk-to-corner');
    }
    if (operation === 'walk-to-corner') {
      if (!line) { note('direct-line-broke-before-corner'); switchTo(undefined); return; }
      if (distance(p, plan.setFrom) > 0.8) return walk(plan.setFrom);
      if (useGuide) { switchTo('verify-install'); return { aim: angle(p, plan.guide), technique3: true }; }
      switchTo('detour');
    }
    if (operation === 'verify-install') {
      if (!line?.guide) { note('guide-command-rejected'); switchTo(undefined); return; }
      note('paid-guide', { guide: line.guide.point, until: line.until }); switchTo('detour');
    }
    if (operation === 'detour') {
      if (distance(p, plan.detour) > 0.8) return walk(plan.detour);
      note('detour', { paidLineSurvived: !!line, guideSurvived: !!line?.guide, directCableBlocked: g.obstacles.some(rect => segmentRect(p, directEnd, rect, 1)) });
      if (!line) { switchTo(undefined); return; }
      motorStart = point(p);
      switchTo(line.guide ? 'return' : 'direct-haul');
      return { technique2: true };
    }
    if (operation === 'return') {
      if (!line?.guide) { note('line-lost-during-return'); switchTo(undefined); return; }
      if (line.active) return {};
      if (distance(p, line.guide.point) > 5.01) { note('haul-stopped-short'); switchTo(undefined); return; }
      if (g.obstacles.some(rect => segmentRect(p, directEnd, rect, 1)) && distance(p, line.guide.point) > 0.65)
        return walk(line.guide.point);
      note('motor-return', { distance: distance(p, motorStart), originalUntil: line.until });
      switchTo('redirect'); return { technique3: true };
    }
    if (operation === 'redirect') {
      if (!line?.guideUsed || line.guide || line.active) {
        note('redirect-unavailable'); switchTo(undefined); return line ? { technique1: true } : undefined;
      }
      note('redirected', { originalUntil: line.until });
      secondStart = point(p); switchTo('second-haul'); return { technique2: true };
    }
    if (operation === 'second-haul' || operation === 'direct-haul') {
      if (line && line.active && g.combatTick - stageAt < 8) return {};
      const from = operation === 'second-haul' ? secondStart : motorStart;
      note(operation, { moved: distance(p, from), towardOriginal: distance(from, firstOrigin) - distance(p, firstOrigin), originalUntil: line?.until });
      switchTo(undefined); return line ? { technique1: true } : undefined;
    }
  }

  while (g.tick < 50_000 && !['victory', 'defeat'].includes(g.phase)) {
    if (phase !== g.phase) {
      phase = g.phase;
      states.push({ phase, encounter: g.encounter, tick: g.tick, earned: p.totalSp });
      if (phase === 'shop') shop();
      if (phase === 'combat') {
        observed.clear();
        switchTo(undefined);
        if (g.encounter === 2 && !attempted) {
          attempted = true;
          const selected = geometry.rows.find(row => row.arena === g.currentArenaId && row.difficulty === 'baby');
          const candidates = selected?.supportExamples ?? (selected?.example ? [selected.example] : []);
          const start = point(p);
          const ranked = candidates.flatMap(example => {
            const approach = approachRoute(g, start, example.castFrom);
            if (!approach.length) return [];
            const length = approach.reduce((sum, next, index) => sum + distance(next, approach[index - 1] ?? start), 0);
            if (length > g.movementSpeed(p) * 150 / HZ) return [];
            return [{ example, approach, length }];
          }).sort((a, b) => a.length - b.length);
          if (ranked.length) {
            plan = ranked[0].example;
            route = ranked[0].approach;
            note('route-start', { route: structuredClone(route), length: ranked[0].length, candidates: ranked.length });
            switchTo('approach');
          } else note('no-current-route');
        }
      }
    }
    if (['mutationVote', 'contractVote', 'secretOffer'].includes(phase)) g.vote(p.id, 0);
    if (phase === 'combat') {
      const view = viewOf(g, p.id), actor = view.players.find(player => player.id === p.id);
      const input = guideControl(actor.kit) ?? restRaidInput(view, actor, [...observed.values()]);
      assert(g.submitInput(p.id, { ...idleInput(), ...input, sequence: ++sequence, clientTick: g.combatTick }));
    }
    g.step();
    for (const event of g.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) observed.set(shot.id, { ...shot, seenAt: g.combatTick });
      if (event.type === 'remove') for (const shot of event.ids) observed.delete(shot);
    }
    if (p.progress.clears > cleared) {
      cleared = p.progress.clears;
      clears.push({ actualClears: cleared, earned: p.totalSp, tick: g.combatTick });
    }
  }
  assert(['victory', 'defeat'].includes(g.phase));
  return { arena, seed, useGuide, outcome: g.phase, clears, purchases, operations, phaseStates: states,
    earlyProbe: probe, finalSpent: p.skills.reduce((sum, skill) => sum + g.skillCost(skill), 0), finalEarned: p.totalSp,
    damageTaken: p.damageTaken, endingHealth: p.health };
}

const rows = [];
for (const arena of layout === 'corner' ? ['gatehouse', 'triage-yard', 'ossuary-works'] : ['gatehouse', 'triage-yard', 'crown-crypt']) for (const seed of [41, 73]) for (const useGuide of [false, true]) {
  const row = trial(arena, seed, useGuide);
  rows.push(row);
  console.log(JSON.stringify({ arena, seed, useGuide, outcome: row.outcome, clears: row.clears.length,
    purchased: row.purchases.some(purchase => purchase.item === id), operations: row.operations.map(operation => operation.kind) }));
}
assert.deepEqual(fingerprints(), before);
write(stage + '/canonical-guide-short29-' + layout + '.json', { measuredAt: new Date().toISOString(), candidateBase: baseline, contentRevision,
  runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256,
  layout, geometrySha256: sha(JSON.stringify(geometry)), driverSha256: sha(fs.readFileSync(new URL(import.meta.url))), rows,
  scope: 'Canonical local Short runs from ordinary starting positions with original clocks, enemies, money and earned SP. Matched guide and direct arms use the same planned route and shop actions. Paid guide acquisition is a canonical transaction at 15 actual SP. No testing injection, checkpoint import or online proof.' });
