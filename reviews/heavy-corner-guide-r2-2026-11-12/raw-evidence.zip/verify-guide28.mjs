import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { root, stage, originalStage, originalScope, retiredScope, baseline, oldStage, issuedReview, issuedSource, git, read, write, walk, sha } from './common.mjs';
import { checkedGate, digestFile, protocol, revision, scope, source } from './publication.mjs';
import { checkGuideAcquisition } from './guide-proof.mjs';

process.chdir(root);
const commit = source();
assert.equal(git('rev-parse', 'HEAD'), commit);
const { proof, result } = checkedGate();
const ci = read(scope + '/source-ci.json'), binding = read(scope + '/source-binding.json');
assert(binding.passed && binding.sourceCommit === commit && binding.allWorkingAndCommittedCoreBytesExact);
assert(ci.passed && ci.head === commit && ci.draftPR14);
assert.deepEqual(ci.events.map(event => event.event).sort(), ['pull_request', 'push']);
for (const event of ci.events) {
  assert(event.headSha === commit && event.conclusion === 'success' && event.jobs.length > 0);
  for (const job of event.jobs) {
    assert(job.verified && job.conclusion === 'success' && job.runtimeEvidence.verified);
    assert(job.steps.length && job.steps.every(step => step.status === 'completed' && step.conclusion === 'success'));
    for (const key of ['tests', 'pass', 'fail', 'cancelled', 'skipped']) assert.equal(job[key], result.counts[key]);
    assert.equal(digestFile(job.log), job.decodedLogSha256);
    for (const key of ['runtimeSourceSha256', 'sourceSnapshotSha256', 'contentRevision', 'verificationDriverSha256'])
      assert.equal(job.runtimeEvidence[key], proof[key]);
  }
}

const correction = read(stage + '/traffic-correction29.json');
assert(correction.passed && correction.preservesTestAndGameDeadlines);
assert.equal(correction.sourceSnapshotSha256, proof.sourceSnapshotSha256);
assert.equal(correction.runtimeSourceSha256, proof.runtimeSourceSha256);
assert.equal(digestFile(correction.originalFailedCI), correction.originalFailedCISha256);
assert.equal(digestFile(correction.originalWalkFailureLog), correction.originalWalkFailureLogSha256);
const initialCI = read(correction.originalFailedCI);
assert(initialCI.head === baseline && !initialCI.passed);
assert(initialCI.events.find(event => event.event === 'pull_request').jobs.every(job => job.verified));
const initialNative = ['testing', 'public'].map(audience => read(originalStage + '/native13-' + audience + '-result.json'));
assert(initialNative[0].passed && !initialNative[1].passed && initialNative.every(report => report.caseCount === 7));
assert.equal(initialNative.flatMap(report => report.cases.filter(test => !test.passed)).length, 1);
const retirement = read(retiredScope + '/retention-result.json');
assert(retirement.passed && retirement.removedDirectoryCount === 2);
const originalStop = fs.readFileSync(stage + '/pending-stop28.jsonl', 'utf8').trim().split('\n').map(JSON.parse);
assert.equal(originalStop.length, 4);
assert.equal(git('diff', baseline, '--', 'src/shared/game.ts', 'src/shared/heavy-linework.ts', 'src/shared/heavy-linework-guide.ts', 'content', 'assets', 'locales'), '');
const previous = read(issuedReview + '/frozen-verification.json');
const previousRetention = read('output/review-retention.json');
assert(previous.passed && previous.sourceCommit === issuedSource && previousRetention.currentScope === issuedReview);
assert.equal(previousRetention.currentSourceCommit, issuedSource);
const archiveHash = createHash('sha256');
for await (const bytes of fs.createReadStream(previousRetention.rollbackArchive)) archiveHash.update(bytes);
assert.equal(archiveHash.digest('hex'), previousRetention.rollbackArchiveSha256);
assert.equal(git('diff', baseline, '--', issuedReview, 'reviews/heavy-tethered-menu21-2026-11-10', 'reviews/heavy-tethered-traverse-2026-11-10', 'handoff/wip', 'docs/SERVICE_YARD_WORKING.md'), '');
const serviceYard = read('handoff/wip/service-yard-2026-11-02.json');
assert.deepEqual(serviceYard.focusedTests, { passed: 4, failed: 1, total: 5 });
assert.equal(digestFile(serviceYard.patchPath), serviceYard.patchSha256);
assert.equal(digestFile(serviceYard.logPath), serviceYard.logSha256);
const privateBaseline = read(oldStage + '/private-preserved-before01.json');
assert(privateBaseline.localOnly && privateBaseline.neverUploadThisManifestOrDatabaseContents);
assert.equal(privateBaseline.files.length, 213);
for (const file of privateBaseline.files) {
  assert.equal(fs.statSync(file.path).size, file.bytes);
  assert(digestFile(file.path) === file.sha256, 'Private baseline byte mismatch');
}

const census = read(stage + '/build-census29.json');
const geometry = read(stage + '/canonical-guide-geometry29.json');
const trials = ['corner', 'face'].map(layout => read(stage + '/canonical-guide-short29-' + layout + '.json'));
for (const evidence of [census, geometry, ...trials]) {
  for (const key of ['contentRevision', 'runtimeSourceSha256', 'sourceSnapshotSha256']) assert.equal(evidence[key], proof[key]);
}
assert.equal(census.priorSetCount, 2262);
assert.equal(census.totalSets, 2298);
assert.equal(census.reports.find(row => row.classId === 'heavy').newGuideSets, 36);
assert(geometry.total === 43 && geometry.passed === 43 && geometry.rows.every(row => row.passed));
const runs = trials.flatMap(report => report.rows);
assert(trials.every(report => report.rows.length === 12) && runs.every(row => ['victory', 'defeat'].includes(row.outcome)));
const paired = runs.filter(row => row.purchases.some(purchase => purchase.item === 'heavy-linework-guide-1'));
assert.equal(paired.length, 10);
for (const row of paired) {
  assert(row.useGuide && row.purchases.find(purchase => purchase.item === 'heavy-linework-guide-1').earned === 15);
  assert(row.operations.some(operation => operation.kind === 'second-haul' && operation.towardOriginal > 8));
}

const processProof = read(scope + '/process-identities.json');
assert.equal(processProof.sourceCommit, commit);
assert.equal(processProof.currentExactLiveCount, 4);
assert.equal(processProof.olderRecordedIdentities.length, 4);
assert(processProof.identities.every(identity => identity.exactIdentityAndListenerVerified));
assert(!processProof.cleanupPerformed);
const freeze = read(scope + '/frozen-build-binding.json');
assert(freeze.passed && freeze.sourceCommit === commit);
const nativeAttempt = process.argv[2] ?? 'native27';
assert(/^native\d+$/.test(nativeAttempt));
const rows = [];
for (const audience of ['testing', 'public']) {
  const preview = read(scope + '/preview-' + audience + '.json');
  const manifest = read(preview.manifestPath);
  const frozen = freeze.rows.find(row => row.audience === audience);
  assert.equal(preview.sourceCommit, commit);
  assert.equal(preview.protocol, protocol);
  assert.equal(preview.contentRevision, revision);
  assert.equal(preview.runtimeSourceSha256, proof.runtimeSourceSha256);
  assert.equal(preview.sourceSnapshotSha256, proof.sourceSnapshotSha256);
  assert.equal(digestFile(preview.manifestPath), preview.manifestSha256);
  assert.equal(preview.manifestSha256, frozen.manifestSha256);
  assert.equal(digestFile(preview.backend.path), frozen.backendSha256);
  assert.equal(manifest.members.length, preview.files);
  assert.deepEqual(walk(preview.root).map(file => path.relative(preview.root, file).split(path.sep).join('/')).sort(), manifest.members.map(file => file.path).sort());
  for (const member of manifest.members) {
    assert(!path.isAbsolute(member.path) && !member.path.split('/').includes('..'));
    const absolute = path.resolve(preview.root, member.path);
    assert(absolute.startsWith(path.resolve(preview.root) + path.sep));
    assert.equal(fs.statSync(absolute).size, member.bytes);
    assert.equal(digestFile(absolute), member.sha256, member.path);
  }
  const native = read(stage + '/' + nativeAttempt + '-' + audience + '-result.json');
  assert(native.passed && native.sourceCommit === commit && native.caseCount === 7);
  assert.equal(native.endpoint, preview.endpoint);
  assert.equal(native.url, preview.url);
  assert.equal(digestFile(native.httpReport), native.httpReportSha256);
  assert.equal(digestFile(native.httpLog), native.httpLogSha256);
  assert.equal(native.emittedEmblems.length, 5);
  assert.equal(native.cases.length, 6);
  assert.equal(native.remainingProbeRooms + native.remainingProbeConnections, 0);
  const cases = [];
  for (const transport of ['worker', 'peer']) for (const fitting of ['bare', 'yoke', 'sheave']) {
    const matched = native.cases.filter(test => test.transport === transport && test.fitting === fitting);
    assert.equal(matched.length, 1);
    const test = matched[0];
    assert(test.passed && test.code === 0);
    assert.equal(digestFile(test.log), test.logSha256);
    assert.equal(digestFile(test.receipt), test.receiptSha256);
    const receipt = read(test.receipt);
    assert(receipt.noCheckpointImport);
    assert.equal(receipt.sourceCommit, commit);
    assert.equal(receipt.servedWorker.sha256, frozen.worker.sha256);
    assert.equal(receipt.backendBundleSha256, frozen.backendSha256);
    checkGuideAcquisition(receipt, transport, fitting);
    cases.push({ transport, fitting, actualEarnedSequence: receipt.actualEarnedSequence, spent: receipt.spent,
      walked: receipt.walked, paidPrimaryProjectiles: receipt.paidPrimaryProjectiles, guide: receipt.guide,
      logSha256: test.logSha256, receiptSha256: test.receiptSha256 });
  }
  const health = await fetch(preview.endpoint + '/api/health', { signal: AbortSignal.timeout(10_000) }).then(response => response.json());
  assert(health.sourceCommit === commit && health.protocolVersion === protocol && health.contentRevision === revision && health.audience === audience);
  const served = await fetch(new URL(frozen.worker.path, preview.url), { signal: AbortSignal.timeout(10_000) });
  assert.equal(served.status, 200);
  assert.equal(sha(Buffer.from(await served.arrayBuffer())), frozen.worker.sha256);
  rows.push({ audience, url: preview.url, endpoint: preview.endpoint, filesHashed: manifest.members.length, nativeCases: native.caseCount,
    httpChecks: read(native.httpReport).httpChecks, manifestSha256: preview.manifestSha256, servedWorkerSha256: frozen.worker.sha256,
    backendSha256: frozen.backendSha256, emittedEmblems: native.emittedEmblems, cases });
}
const report = { passed: true, checkedAt: new Date().toISOString(), sourceCommit: commit, protocol,
  contentRevision: revision, runtimeSourceSha256: proof.runtimeSourceSha256, sourceSnapshotSha256: proof.sourceSnapshotSha256,
  tests: result.counts, sourceChecks: proof.checks, exactSourcePushAndPRJobsStepsLogsAndOwnArtifacts: true,
  originalAttempt: { sourceCommit: baseline, scope: originalScope, sourceCI: correction.originalFailedCI,
    originalLocalTests: 2330, originalTestingNativePassed: true, originalPublicNativePassed: false,
    quantizationReproduction: 'quantization-reproduction26.json', inputPacingCorrection: 'traffic-correction29.json',
    retiredScope, originalFailuresPreserved: true },
  sourceByteBinding: scope + '/source-binding.json', ci: scope + '/source-ci.json', rows,
  previousVerifiedReview: issuedReview + '/frozen-verification.json', previousSourceCommit: previous.sourceCommit,
  previousRollbackArchiveSha256: previousRetention.rollbackArchiveSha256, nativeAttempt,
  controlledBuildSets: census.totalSets, controlledGeometryCases: geometry.total,
  seededShortTrials: runs.length, actualSeededGuidePurchasesAndBothLegs: paired.length,
  preexistingPrivateSQLiteRelatedFilesVerified: privateBaseline.files.length, privateHashesRemainLocalOnly: true,
  serviceYardWipExact: true, processIdentities: scope + '/process-identities.json', retentionPromotionPending: true,
  scope: 'Fresh native HTTP plus three whole served worker and three real non-host peer Short acquisitions per audience. Each guide purchase follows two clears and both paid hauls are observed. Human, rendered, device, language, listening, motion and final balance acceptance remain open.' };
write(scope + '/frozen-verification.json', report);
console.log(JSON.stringify({ passed: true, sourceCommit: commit, tests: result.counts.pass, checks: proof.checks.length,
  rows: rows.map(({ audience, url, filesHashed, nativeCases }) => ({ audience, url, filesHashed, nativeCases })), privateFilesVerified: privateBaseline.files.length }));
