import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {root,stage,read,write,sha,fingerprints} from './common.mjs';

process.chdir(root);
const before=fingerprints();
const previous=read('reviews/heavy-reserve-anchor-ci-2026-11-12/build-census.json');
const {Game,data}=await import(pathToFileURL(root+'/src/shared/game.ts').href);
const {conflictingSkill}=await import(pathToFileURL(root+'/src/shared/skill-conflicts.ts').href);
const all=[...data.skills,...data.generalSkills,...data.specializationSkills];
const byId=new Map(all.map(skill=>[skill.id,skill]));
const sharedIds=new Set(data.generalSkills.map(skill=>skill.id));
type Build={skills:string[];spent:number;remaining:number;capstones:number;operationAndSharedSignature:string};
const reports=[];
for(const classId of ['engineer','soldier','heavy'] as const){
  const techniques=data.specializationSkills.filter(skill=>skill.classId===classId);
  const techniqueIds=new Set(techniques.map(skill=>skill.id));
  const candidate=new Set<string>();
  function addWithParents(id:string){
    if(candidate.has(id))return;
    const node=byId.get(id);
    assert(node);
    if(node.prerequisite)addWithParents(node.prerequisite);
    candidate.add(id);
  }
  for(const id of [...techniqueIds,...sharedIds])addWithParents(id);
  const ordered=[...candidate].map(id=>byId.get(id)!);
  const owned:string[]=[],builds:Build[]=[];
  function enumerate(index:number,spent:number,capstones:number){
    if(index===ordered.length){
      if(owned.some(id=>techniqueIds.has(id)))builds.push({skills:[...owned],spent,remaining:27-spent,capstones,operationAndSharedSignature:owned.filter(id=>techniqueIds.has(id)||sharedIds.has(id)).sort().join('|')});
      return;
    }
    enumerate(index+1,spent,capstones);
    const node=ordered[index];
    if((node.prerequisite&&!owned.includes(node.prerequisite))||('freePlaySpRequired' in node&&Number(node.freePlaySpRequired)>27)||spent+node.cost>27||(node.capstone&&capstones)||conflictingSkill(owned,node.id))return;
    owned.push(node.id);
    enumerate(index+1,spent+node.cost,capstones+Number(node.capstone));
    owned.pop();
  }
  enumerate(0,0,0);
  assert.equal(new Set(builds.map(build=>build.operationAndSharedSignature)).size,builds.length);
  let purchases=0;
  for(const build of builds){
    const game=new Game({mode:'endless',seed:41,maxPlayers:1});
    game.encounter=9;
    const player=game.addPlayer('solo','Controlled build legality',classId);
    assert.equal(player.totalSp,27);
    for(const item of build.skills)assert(game.transact(player.id,{id:'canonical-'+ ++purchases,kind:'skill',item}).ok,item);
    assert.deepEqual(player.skills,build.skills);
    assert.equal(player.skills.reduce((spent,id)=>spent+game.skillCost(id),0),build.spent);
  }
  const old=previous.reports.find((entry:any)=>entry.classId===classId);
  const oldBuilds=builds.filter(build=>!build.skills.includes('heavy-linework-guide-1'));
  assert.deepEqual(new Set(oldBuilds.map(build=>build.operationAndSharedSignature)),new Set(old.builds.map((build:Build)=>build.operationAndSharedSignature)));
  const linework=builds.filter(build=>build.skills.includes('heavy-linework-guide-1'));
  reports.push({classId,techniques:techniques.length,distinctSets:builds.length,purchases,issuedSetsPreserved:oldBuilds.length,newGuideSets:linework.length,guideByFitting:Object.fromEntries(['bare','yoke','sheave'].map(fitting=>[fitting,linework.filter(build=>(build.skills.includes('heavy-linework-yoke-1')?'yoke':build.skills.includes('heavy-linework-sheave-1')?'sheave':'bare')===fitting).length])),builds});
}
assert.deepEqual(fingerprints(),before);
const report={measuredAt:new Date().toISOString(),contentRevision:read('content/revision.json').sha256,runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,runnerSha256:sha(fs.readFileSync(new URL(import.meta.url))),totalSets:reports.reduce((sum,row)=>sum+row.distinctSets,0),priorSetCount:previous.totalSets,reports,scope:'Every set uses actual canonical purchases in a controlled 27SP Endless lobby. Distinct signatures include one or more specialization operations and optional shared mobility. The census excludes legacy numerical variations and does not measure natural acquisition or balance.'};
write(stage+'/build-census29.json',report);
console.log(JSON.stringify({totalSets:report.totalSets,priorSets:report.priorSetCount,classes:reports.map(({builds,...row})=>row)}));
