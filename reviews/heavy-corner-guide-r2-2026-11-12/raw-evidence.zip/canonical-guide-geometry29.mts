import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { root, stage, baseline, guideHistory, read, write, sha, fingerprints, git } from './common.mjs';
import { guideId, guideRules } from '../heavy-corner-guide-stage/corner-guide-content.mjs';

process.chdir(root);
assert.equal(git('rev-parse', 'HEAD'), baseline);
const before = fingerprints();
const contentRevision = read('content/revision.json').sha256;
const { Game, data } = await import(pathToFileURL(root + '/src/shared/game.ts').href);
assert.equal(sha(JSON.stringify(data)), contentRevision);
const { HZ, idleInput } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { segmentRect, distance } = await import(pathToFileURL(root + '/src/shared/geometry.ts').href);
const { lineworkIds, heavyLineworkRules: rules } = await import(pathToFileURL(root + '/src/shared/heavy-linework.ts').href);
const corners = read(guideHistory + '/guide-perimeter.json').rows.filter(row => row.example).map(row => ({ ...row, kind: 'corner' }));
const faces = read('C:/Users/yigal/Documents/Codex/2026-11-10/continue-grave-accord-in-the-same/work/heavy-corner-guide-stage/wall-face-geometry02.json').rows.filter(row => row.example).map(row => ({ ...row, kind: 'face' }));
assert.equal(corners.length, 26);
assert.equal(faces.length, 10);
const point = (body) => ({ x: body.x, y: body.y });
const angle = (from, to) => Math.atan2(to.y - from.y, to.x - from.x);
const eye = (line) => ({ x: line.origin.x + line.normal.x * 1.25, y: line.origin.y + line.normal.y * 1.25 });

function fixture(row, fitting = 'bare', purchaseGuide = true) {
  const plan = row.example;
  const game = new Game({ mode: 'short', difficulty: row.difficulty, seed: 41, maxPlayers: 1,
    openingArenaId: row.arena, arenaSelection: 'fixed' });
  const player = game.addPlayer('solo', 'Controlled Corner Guide', 'heavy');
  assert.equal(player.totalSp, 3);
  const buy = (item) => game.transact(player.id, { id: 'guide-study-' + item, kind: 'skill', item });
  assert(buy('heavy-ordnance-1').ok && buy(lineworkIds.entry).ok);
  player.totalSp = 15;
  if (fitting !== 'bare') assert(buy(lineworkIds[fitting]).ok);
  if (purchaseGuide) assert(buy(guideId).ok);
  assert(game.start());
  game.boss.staggerUntil = 400;
  const castAim = Math.atan2(plan.approach.y, plan.approach.x), ammo = player.ammo;
  let sequence = 0;
  const line = () => game.kitStatus(player.id).lineworkConnection;
  const recovery = () => game.kitStatus(player.id).lineworkRecovery;
  const step = (input = {}) => {
    assert(game.submitInput(player.id, { ...idleInput(), clientTick: game.combatTick, sequence: ++sequence, aim: castAim, ...input }));
    game.step();
    return game.drainEvents();
  };
  function walk(target, maxTicks) {
    const limit = game.combatTick + maxTicks;
    while (distance(player, target) > 0.45 && game.combatTick < limit) {
      const length = Math.max(distance(player, target), game.movementSpeed(player) / HZ);
      step({ moveX: (target.x - player.x) / length, moveY: (target.y - player.y) / length });
    }
    assert(distance(player, target) <= 0.45, `Real body never reached the selected point (${distance(player, target).toFixed(2)} px away)`);
  }
  const spawn = point(player);
  if (row.kind === 'face') {
    assert(plan.straightWalkFromSpawn);
    walk(plan.castFrom, 120);
  } else Object.assign(player, plan.castFrom);
  const actualCast = point(player);
  const events = [...step({ technique1: true })];
  for (let tick = 0; !line() && tick < rules.flightTicks; tick++) events.push(...step());
  const first = line();
  assert(first, 'The paid flight must attach to real current masonry');
  const actualFlight = events.flatMap(event => event.type === 'shots' ? event.shots : []).find(shot => shot.visual === 'heavy-anchor');
  assert(actualFlight);
  assert.equal(first.until, actualFlight.expires - rules.flightTicks + rules.lineTicks);
  assert.equal(player.ammo, ammo - 1);
  assert(distance(first.origin, plan.anchor) <= 1.5);
  const originalRecovery = recovery();
  walk(plan.setFrom, 65);
  assert(line() && !line().active);
  const install = (input = {}) => step({ aim: angle(player, plan.guide), technique3: true, ...input });
  return { game, player, plan, line, recovery, first, originalRecovery, ammo, spawn, actualCast, step, walk, install };
}

function guided(row, fitting = 'bare') {
  const f = fixture(row, fitting);
  const events = f.install({ technique2: true, fire: true });
  const support = f.line()?.guide;
  assert(support && distance(support.point, f.plan.guide) < 1.5, 'The aimed actual guide must attach at the planned support');
  assert.equal(f.line().active, false);
  assert(events.some(event => event.type === 'sound' && event.id === 'linework-guide-set'));
  assert.equal(f.player.ammo, f.ammo - 2);
  assert.equal(f.line().paidLength, f.first.paidLength);
  f.walk(f.plan.detour, 45);
  assert(f.line()?.guide && !f.line().active);
  const detour = point(f.player);
  const directObstructed = f.game.obstacles.some(rect => segmentRect(detour, eye(f.first), rect, 1) !== null);
  assert.equal(directObstructed, row.kind === 'corner');
  const begin = f.game.combatTick;
  f.step({ technique2: true });
  assert(f.line()?.active);
  const firstHeading = angle(detour, f.player);
  while (f.line()?.active && f.game.combatTick < begin + 32) f.step();
  assert(f.line()?.guide && !f.line().active);
  const firstLegTicks = f.game.combatTick - begin, towardGuide = distance(detour, f.player);
  assert(towardGuide > 60 && distance(f.player, support.point) <= guideRules.redirectReach);
  if (f.game.obstacles.some(rect => segmentRect(f.player, eye(f.first), rect, 1))) f.walk(support.point, 4);
  const redirect = f.step({ technique3: true, technique2: true });
  assert(f.line()?.guideUsed && !f.line().guide && !f.line().active);
  assert(redirect.some(event => event.type === 'sound' && event.id === 'linework-guide-redirect'));
  assert.deepEqual(f.line().origin, f.first.origin);
  const atGuide = point(f.player), towardBefore = distance(atGuide, f.first.origin);
  f.step({ technique2: true });
  assert(f.line()?.active);
  for (let tick = 0; f.line()?.active && tick < 100; tick++) f.step();
  assert(f.line() && !f.line().active, 'The original anchor is reached within its original clock');
  const towardAnchor = towardBefore - distance(f.player, f.first.origin);
  assert(towardAnchor > 16);
  assert(distance(f.player, f.first.origin) <= rules.bodyStop + 1);
  assert.equal(f.line().until, f.first.until);
  assert.equal(f.recovery(), f.originalRecovery);
  assert.equal(f.player.ammo, f.ammo - 2);
  const result = { fitting, spawn: f.spawn, cast: f.actualCast, support: support.foot, guide: support.point, firstAnchor: f.first.origin,
    detour, atGuide, reachedAnchor: point(f.player), firstHeading, firstLegTicks, towardGuide, towardAnchor,
    actualDirectObstructed: directObstructed, spentRounds: 2, reachedAt: f.game.combatTick, originalUntil: f.first.until, originalRecovery: f.originalRecovery };
  f.step({ technique1: true });
  assert(!f.line());
  assert.equal(f.player.ammo, f.ammo - 2);
  return result;
}

function direct(row, ticks) {
  const f = fixture(row, 'bare', false);
  f.walk(f.plan.detour, 45);
  const survived = !!f.line(), start = point(f.player);
  if (!survived) return { survived, start };
  f.step({ technique2: true });
  const heading = angle(start, f.player);
  for (let tick = 1; tick < ticks; tick++) f.step();
  assert(f.line() && !f.line().guide);
  return { survived, heading, start, reached: point(f.player), distanceFromGuide: distance(f.player, f.plan.guide), spentRounds: f.ammo - f.player.ammo };
}

const rows = [];
function run(label, execute) {
  try { rows.push({ label, passed: true, result: execute() }); }
  catch (error) { rows.push({ label, passed: false, error: error.stack ?? String(error) }); }
}
for (const row of [...corners, ...faces]) run(`${row.arena}/${row.difficulty}/${row.kind}`, () => {
  const guide = guided(row), stock = direct(row, guide.firstLegTicks);
  if (row.kind === 'face') {
    assert(stock.survived && stock.distanceFromGuide > 40);
    const separation = Math.abs(Math.atan2(Math.sin(stock.heading - guide.firstHeading), Math.cos(stock.heading - guide.firstHeading))) * 180 / Math.PI;
    assert(separation > 40);
    return { guide, stock, actualTurnDegrees: separation };
  }
  assert(!stock.survived);
  return { guide, stock };
});
for (const fitting of ['yoke', 'sheave']) for (const row of [corners[0], faces[0]]) run(row.kind + '/' + fitting, () => guided(row, fitting));
run('empty magazine keeps the first anchor', () => {
  const f = fixture(corners[0]);
  f.player.ammo = 0;
  f.install();
  assert(f.line() && !f.line().guide && !f.line().guideUsed && !f.line().active);
  assert.equal(f.line().until, f.first.until);
  assert.equal(f.recovery(), f.originalRecovery);
});
run('release outranks a simultaneous guide set', () => {
  const f = fixture(corners[0]);
  f.install({ technique1: true });
  assert(!f.line());
  assert.equal(f.player.ammo, f.ammo - 1);
  assert.equal(f.recovery(), f.originalRecovery);
});
run('guide and reserve reject each other through the actual transaction', () => {
  for (const [first, second] of [[guideId, lineworkIds.reserve], [lineworkIds.reserve, guideId]]) {
    const game = new Game({ mode: 'raid', difficulty: 'normal' });
    const player = game.addPlayer('solo', 'Two Lineworker routes', 'heavy');
    assert.equal(player.totalSp, 12);
    const buy = item => game.transact(player.id, { id: item, kind: 'skill', item });
    for (const item of ['heavy-ordnance-1', lineworkIds.entry, first]) assert(buy(item).ok);
    const skills = [...player.skills];
    assert(!buy(second).ok);
    assert.deepEqual(player.skills, skills);
  }
});

assert.deepEqual(fingerprints(), before);
const passed = rows.filter(row => row.passed).length;
write(stage + '/canonical-guide-geometry29.json', { measuredAt: new Date().toISOString(), candidateBase: baseline, contentRevision,
  runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256, driverSha256: sha(fs.readFileSync(new URL(import.meta.url))),
  passed, total: rows.length, rows,
  scope: 'Controlled local runs using the canonical Game and catalog. Boss attacks are held to isolate geometry. Corner setups use controlled cast positions. Face trials walk from ordinary spawn and compare equal motor ticks. No checkpoint or online authority.' });
console.log(JSON.stringify({ passed, total: rows.length, failures: rows.filter(row => !row.passed).map(row => ({ label: row.label, error: row.error.split('\n')[0] })),
  faces: rows.filter(row => row.passed && row.result?.actualTurnDegrees).map(row => [row.label, Math.round(row.result.actualTurnDegrees)]) }));
