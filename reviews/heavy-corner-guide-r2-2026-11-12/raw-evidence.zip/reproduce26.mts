import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { root, stage, baseline, read, write, sha, git, fingerprints } from './common.mjs';

process.chdir(root);
assert.equal(git('rev-parse', 'HEAD'), baseline);
const before = fingerprints();
const { Game } = await import(pathToFileURL(root + '/src/shared/game.ts').href);
const { idleInput, HZ } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { lineworkIds, heavyLineworkRules } = await import(pathToFileURL(root + '/src/shared/heavy-linework.ts').href);
const { viewOf } = await import(pathToFileURL(root + '/src/shared/view.ts').href);
const { lineworkMenu } = await import(pathToFileURL(root + '/tests/helpers/heavy-linework-menu-flow.ts').href);
const { face: route } = read('tests/fixtures/heavy-corner-guide-routes.json');
const g = new Game({ mode: 'short', difficulty: 'baby', seed: 41, openingArenaId: 'gatehouse', arenaSelection: 'fixed' });
const p = g.addPlayer('solo', 'Controlled quantized guide arrival', 'heavy');
const buy = item => g.transact(p.id, { kind: 'skill', id: item, item });
assert(buy('heavy-ordnance-1').ok && buy(lineworkIds.entry).ok);
p.totalSp = 15;
assert(buy(lineworkIds.guide).ok && g.start());
g.boss.staggerUntil = 400;
let sequence = 0;
function step(input = {}) {
  assert(g.submitInput(p.id, { ...idleInput(), sequence: ++sequence, clientTick: g.combatTick, ...input }));
  g.step();g.drainEvents();
}
const distance = (a,b) => Math.hypot(a.x-b.x,a.y-b.y);
function walk(target) {
  for (let tick = 0; distance(p,target) > 0.4 && tick < 100; tick++) {
    const length = Math.max(distance(p,target),g.movementSpeed(p)/HZ);
    step({ moveX: (target.x-p.x)/length,moveY:(target.y-p.y)/length });
  }
  assert(distance(p,target)<=0.4);
}
walk(route.castFrom);
step({ aim: Math.atan2(route.approach.y,route.approach.x), technique1:true });
for(let tick=0;!g.kitStatus(p.id).lineworkConnection && tick<heavyLineworkRules.flightTicks;tick++)step();
assert(g.kitStatus(p.id).lineworkConnection);
walk(route.setFrom);
step({ aim: Math.atan2(route.guide.y-p.y,route.guide.x-p.x),technique3:true });
const guide = g.kitStatus(p.id).lineworkConnection.guide;
assert(guide);
// Select the replicated boundary observed in the failed real room.
p.x = guide.point.x;p.y = guide.point.y-4.99;
step();
const owner = viewOf(g,p.id).players[0];
const replicated = { ...owner,x:Math.round(owner.x*4)/4,y:Math.round(owner.y*4)/4 };
assert(owner.kit.lineworkGuideBlocked===false && owner.kit.lineworkCommandBlocked);
assert(distance(owner,guide.point)<5 && distance(replicated,guide.point)>5);
const menu=await lineworkMenu(()=>replicated);
let b,m;
try {
  b=menu.guide.heavyHudLabel(replicated,'technique2',g.combatTick);
  m=menu.guide.heavyHudLabel(replicated,'technique3',g.combatTick);
  assert.equal(b,read('locales/en.json').messages['ui.heavy.lineworkEngage']);
  assert.equal(m,'Redirect to anchor');
} finally {await menu.close();}
assert.deepEqual(fingerprints(),before);
write(stage+'/quantization-reproduction26.json',{reproduced:true,sourceCommit:baseline,contentRevision:read('content/revision.json').sha256,
  runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,
  driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),guide:guide.point,physical:{x:owner.x,y:owner.y,distance:distance(owner,guide.point)},
  replicated:{x:replicated.x,y:replicated.y,distance:distance(replicated,guide.point)},
  authoritativeGuideBlocked:owner.kit.lineworkGuideBlocked,authoritativeHaulBlocked:owner.kit.lineworkCommandBlocked,
  originalHelperReady:false,originalBLabel:b,originalSelectorLabel:m,controlledPosition:true,privateRecordsRead:false});
console.log(JSON.stringify({reproduced:true,physicalDistance:distance(owner,guide.point),replicatedDistance:distance(replicated,guide.point),guideBlocked:owner.kit.lineworkGuideBlocked,b,m}));
