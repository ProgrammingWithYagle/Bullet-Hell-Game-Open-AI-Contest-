import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL } = await repoImport('src/shared/protocol.ts');
const { mageSpatialIds, waymarkRules: rules } = await repoImport('src/shared/mage-waymark-return.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance } = await repoImport('src/shared/geometry.ts');

const [transport, fitting, out, supplied, testAudience = 'public'] = process.argv.slice(2);
assert(PROTOCOL === 88 && ['worker','peer'].includes(transport) && ['entry','hold','side'].includes(fitting) && out);
const setup = { mode:'short', difficulty:'baby', arenaSelection:'fixed', openingArenaId:'gatehouse' } as const;
const point = ({ x,y }) => ({ x,y });
const bearing = (from,to) => Math.atan2(to.y-from.y,to.x-from.x);
const heading = angle => Math.atan2(Math.sin(angle),Math.cos(angle));
const step = (p,angle,reach) => ({ x:p.x+Math.cos(angle)*reach,y:p.y+Math.sin(angle)*reach });
const closeHealth = (view,id) => view?.players.find(player => player.id === id);
const spending = p => p.skills.reduce((sum,id) => sum+[...data.specializationSkills,...data.skills].find(row => row.id === id).cost,0);

async function wait(truth, detail, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(8);
  }
}
function pilotState() {
  return { events: [], observed: new Map(), cues: new Map() };
}
function recordCues(cues,view) {
  for(const cue of view.classCues){
    if(cue.kind!=='mage-waymark')continue;
    const history=cues.get(cue.id)??{};
    history[cue.resting?'resting':cue.exit?'exit':cue.returning?'return':'mark']=cue;
    cues.set(cue.id,history);
  }
}

function chooseLane(world, view, start) {
  const axis = bearing(start,view.boss);
  for (const offset of [.65,-.65,1.2,-1.2,1.65,-1.65,.3,-.3,0,Math.PI]) {
    const angle = axis+offset, goal = step(start,angle,144);
    if (clearTrialWalk(world,start,goal)) return goal;
  }
}

async function traceOperation(adapter, view, owner, status, submit, next) {
  const cue = () => view().classCues.find(cue=>cue.kind==='mage-waymark'&&cue.owner===adapter.id);
  const notes = (from,event) => adapter.events.slice(from).filter(e=>e.type==='sound'&&e.id==='mage-waymark-'+event&&e.owner===adapter.id);
  const observations = [];
  const limit = Date.now()+84_000;
  let accepted;
  while (!accepted) {
    const v=view(), p=owner(), now=v.combatTick;
    assert(Date.now()<limit && v.phase==='combat' && p.status==='active',
      JSON.stringify({ fitting,transport,next,tick:now,position:point(p),health:p.health,phase:v.phase,observations }));
    if (p.eAt>now || status()?.phase!=='idle' || (status()?.until??0)>now || now<next.start+34) {
      adapter.input({aim:bearing(p,v.boss)});
      await sleep(35);
      continue;
    }
    const direction=bearing(p,v.boss);
    const available=chooseLane(bulwarkTrialWorld(v),v,p);
    if (!available) {
      const world=bulwarkTrialWorld(v);
      const fallback=[direction+.8,direction-.8,direction+1.7,direction-1.7,direction+Math.PI]
        .find(aim=>clearTrialWalk(world,p,step(p,aim,23)));
      adapter.input(fallback===undefined?{}:{moveX:Math.cos(fallback),moveY:Math.sin(fallback),aim:heading(direction)});
      await sleep(30);
      continue;
    }
    await submit({aim:heading(direction)});
    const goal=chooseLane(bulwarkTrialWorld(view()),view(),owner());
    if(!goal)continue;
    const eventStart=adapter.events.length, originalE=owner().eAt, departure=point(owner());
    await submit({technique2:true,aim:bearing(owner(),goal)});
    const mark=cue();
    if(!mark||status()?.phase!=='marked')continue;
    assert.equal(owner().eAt,originalE);
    assert(distance(mark,departure)<2);
    while (status()?.phase==='marked'&&distance(owner(),goal)>7&&view().combatTick+8<mark.until) {
      const p=owner(), angle=bearing(p,goal);
      adapter.input({moveX:Math.cos(angle),moveY:Math.sin(angle),aim:heading(angle)});
      await sleep(27);
    }
    await submit({aim:bearing(owner(),view().boss)});
    const before=point(owner()), walked=status()?.walked??0;
    if(status()?.phase!=='marked'||walked<rules.minimumWalk||distance(owner(),mark)<rules.minimumDisplacement){
      observations.push({issue:'The live trail did not mature',mark,walked,before,phase:status()?.phase});
      continue;
    }
    await submit({technique2:true,aim:bearing(owner(),mark)});
    const motion=cue(), paid=owner().eAt;
    if(!motion?.returning){observations.push({issue:'The live trail could not commit',mark,walked,before});continue;}
    assert.equal(motion.id,mark.id);
    assert.equal(motion.until-motion.at,rules.returnTicks);
    assert(paid>originalE&&distance(owner(),before)>0);

    let parked, fired, redirect;
    if(fitting==='hold'){
      await wait(()=>status()?.canHold||!cue(),'Hold becomes eligible or the paid trace closes',1_600);
      if(status()?.canHold){
        await submit({technique2:true,aim:bearing(owner(),view().boss)});
        if(status()?.phase==='resting'&&cue()?.resting){
          parked=point(owner());
          const start=adapter.events.length;
          await submit({fire:true,aim:bearing(owner(),view().boss)});
          const heldPosition=point(owner());
          await submit({technique2:true,aim:bearing(owner(),mark)});
          fired=adapter.events.slice(start).flatMap(e=>e.type==='shots'?e.shots:[]).find(shot=>shot.owner===adapter.id)?.id;
          assert(distance(parked,heldPosition)<.1);
        }
      }
    }else if(fitting==='side'){
      await wait(()=>status()?.sideWindow||!cue(),'The last leg enters the side window or closes',1_600);
      if(status()?.sideWindow){
        const p=owner(), world=bulwarkTrialWorld(view()), toward=bearing(p,mark);
        const radius=Math.min(rules.sideMaximum,distance(p,mark));
        const aim=[toward+Math.PI/2,toward-Math.PI/2].find(angle=>clearTrialWalk(world,p,step(p,angle,radius)));
        if(aim!==undefined){
          await submit({technique2:true,aim:heading(aim)});
          redirect=cue()?.exit;
          if(redirect)assert(distance(p,redirect)<=rules.sideMaximum+2);
        }
      }
    }
    const remaining=cue();
    if(remaining){assert.equal(remaining.id,mark.id);assert.equal(remaining.until,motion.until);}
    await wait(()=>!cue(),'The paid trace terminates',1_650);
    assert.equal(owner().eAt,paid);
    const landed=notes(eventStart,'arrive')[0], landedAt=point(owner());
    if(landed && distance(landedAt,redirect??mark)<2 &&
       (fitting==='entry'||fitting==='hold'&&parked&&fired&&notes(eventStart,'resume').length===1||fitting==='side'&&redirect&&notes(eventStart,'side').length===1)){
      assert.equal(notes(eventStart,'return').length,1);
      assert.equal(notes(eventStart,'mark').length,1);
      accepted={ mark,motion,walked,before,originalE,paid,landedAt,landed,parked,fired,redirect,
        holdEvents:notes(eventStart,'hold').length,resumes:notes(eventStart,'resume').length,sideEvents:notes(eventStart,'side').length };
    }else observations.push({issue:'The route ended without verified handling',mark,motion,walked,before,landed:!!landed,parked,fired,redirect});
  }
  return {accepted,observations};
}

async function earnedFlow(adapter) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const p = closeHealth(view(),adapter.id); assert(p); return p; };
  const status = () => owner().kit.waymark;
  const purchased = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind:'skill',item });
    assert(result.ok,JSON.stringify({ item,result }));
    purchased.push({ item,earned:owner().sp+spending(owner()),clears:owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(row => row.classId === 'mage').sort((a,b) => b.tier-a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind:'weapon',item:weapon.id })).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({ kind:'upgrade',item });
  }
  async function submit(input) {
    const sequence = adapter.input(input);
    await wait(() => owner().ack >= sequence,'Ordinary control is acknowledged');
  }

  const isFitted = fitting !== 'entry';
  assert.equal(owner().sp,3);
  await buy('mage-warding-1');
  await buy(mageSpatialIds.entry);
  if (isFitted) assert(!(await adapter.purchase({ kind:'skill',item:mageSpatialIds[fitting] })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat','The ordinary opening encounter begins');
  if (isFitted) {
    const shopLimit = Date.now()+135_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase),'Reach the first shop after an ordinary clear');
      if (view().phase === 'combat') {
        adapter.input(restRaidInput(view(),owner(),[...adapter.observed.values()]));
        adapter.allyPressure?.();
      } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(owner().sp+spending(owner()),9);
    await buy(mageSpatialIds[fitting]);
    const other = fitting === 'hold' ? mageSpatialIds.side : mageSpatialIds.hold;
    assert.equal((await adapter.purchase({ kind:'skill',item:other })).reason,'incompatibleItem');
    await equip();
    await wait(() => view().phase === 'combat','The second ordinary encounter begins',95_000);
  }
  const next = { boss:view().boss.id,arena:view().arenaId,start:view().combatTick };
  const firstClear = owner().progress.clears;

  adapter.pause(true);
  await wait(() => adapter.paused(),'The authority acknowledges pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ technique1:true });
  await sleep(90);
  assert.equal(view().combatTick,pausedAt);
  assert(owner().ack < ignored && status()?.phase === 'idle',
    JSON.stringify({ fitting,transport,pausedAt,ack:owner().ack,ignored,privateStatus:status() }));
  adapter.pause(false);
  await wait(() => !adapter.paused(),'The authority acknowledges resume');
  await adapter.stopAlly?.();

  const { accepted,observations }=await traceOperation(adapter,view,owner,status,submit,next);
  const witnessed=await adapter.peerWitness?.(accepted.mark.id);
  return {passed:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,transport,fitting,bought:purchased,firstClear,next,
    result:accepted,observations,witnessed,pausedCommandsDiscarded:true,noCheckpointImports:true};
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Sable', classId: 'mage' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'waymark-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), mage = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], mage: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  mage.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, mage.id)?.kit.waymark !== undefined) leaks++;
  };
  mage.onEvents = batch => remember(state.events, state.observed, batch, mage.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  mage.onPurchase = entry => replies.mage.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await mage.connect({ ...setup, name: 'Sable', classId: 'mage', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => mage.view?.players.length === 2 && host.view?.players.length === 2, 'Actual non-host Mage lobby');
    assert.equal(mage.view.owner, host.id);
    assert.notEqual(mage.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: mage.id, view: () => mage.view,
      input: props => { mage.input(inputFrame(mage.view, ++sequence, props)); return sequence; },
      purchase: request => reply(mage, replies.mage, request), start: () => host.start(),
      vote: i => { host.vote(i); mage.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => mage.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'The host stops on the ordinary map');
      },
      peerWitness: async id => {
        await wait(()=>{const row=peers.cues.get(id);return row?.mark&&row.return;},'Host sees the same mark and paid movement');
        assert.equal(leaks,0);
        assert(!peers.events.some(e=>e.type==='sound'&&e.owner===mage.id&&e.id.startsWith('mage-waymark-')));
        const sharedPhysical=peers.cues.get(id);
        if(fitting==='hold')assert(sharedPhysical.resting);
        if(fitting==='side')assert(sharedPhysical.exit);
        return {nonHost:true,sharedPhysical,ownedStatePrivate:true,ownedSoundsPrivate:true};
      },
    });
    host.endMatch();
    await wait(() => [host, mage].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    mage.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, testedAudience: testAudience });
console.log(JSON.stringify({ passed:true,transport,fitting,encounter:result.next.boss,firstClear:result.firstClear,walked:result.result.walked,landedAt:result.result.landedAt }));
