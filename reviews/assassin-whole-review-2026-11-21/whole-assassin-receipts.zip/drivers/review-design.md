# Scoped Assassin study

Run Duelist, Infiltrator and Mark Hunter together from the published Mark Hunter source. In every build, spend earned points on the three foundations and one fitting per route. Retain the 27-point limit and the issued tactical, concealment and Passage transformations. Use normal purchases to verify where the three routes and their prerequisites first fit together.

Compare all eight fitting combinations across both Solo and two-player fights. Include layouts with masonry bends, more than one priority enemy and bosses that move through a cutoff. Give each route access to its own recovery clock. During danger, keep ordinary Q, E and U available through the issued controls.

Record genuine openings, echoes and crossings on the same Assassin. Track spend, expiration and initiations that get interrupted while another route is active. Report paid fit operations separately from selecting or buying a fit. Keep measured Class results separate from the later balance pass.

Use controlled hybrid fights to check transitions that ordinary runs seldom reach. Validate the same quiet cover route, physical echo, damage authority and shared cutoff with paired clients. Supply scenario limits and missed operations alongside positive results.
