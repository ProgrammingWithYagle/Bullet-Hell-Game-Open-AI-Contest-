import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { mixedPilot } from './mixed-pilot.mjs';

const [destination, cohort, filter, attempt = 'runtime02'] = process.argv.slice(2);
assert(destination && ['solo','party'].includes(cohort) && /^runtime\d\d$/.test(attempt));
const here = file => new URL('./' + file, import.meta.url);
const checked = readJson(here(attempt + '.json'));
assert(checked.passed && checked.checkoutExact && checked.protocol === 92);
const api = await verifiedBundle(fileURLToPath(here(attempt + '.mjs')), checked.bundle);
const { Game, data, HZ, idleInput, PROTOCOL, CONTENT_REVISION, viewOf, distance, segmentRect, segmentCircle, clearTrialWalk,
  restRaidInput, duelistIds, infiltratorIds, markHunterIds } = api;
assert(PROTOCOL === 92 && CONTENT_REVISION === checked.revision);

const scenarios = [['gatehouse','baby',41],['sunken-chapel','normal',73],['ossuary-works','normal',109]];
const families = ['duelist','infiltrator','hunter'];
const builds = ['passing','counter'].flatMap(duelist => ['relay','threshold'].flatMap(infiltrator =>
  ['canted','transfer'].map(hunter => ({ duelist, infiltrator, hunter })))).map((p, i) => ({ ...p,
    id: families.map(name => p[name]).join('-'), opening: families[i % families.length],
    issuedMove: ['aftercut','decoy-veil','unwritten-traps'][i % families.length] }));
const one = filter?.split('/');
if (one) assert(one.length === 3 && scenarios.some(row => row[0] === one[0]) && builds.some(row => row.id === one[1]) && ['active','unused'].includes(one[2]));
const point = ({ x, y }) => ({ x, y });
const angle = heading => Math.atan2(Math.sin(heading), Math.cos(heading));
const actions = { 'assassin-duel-': 'duelist', 'assassin-slip-': 'infiltrator', 'assassin-writ-': 'hunter' };

function run(arena, difficulty, seed, fitted, active) {
  const game = new Game({ mode: 'standard', difficulty, seed, arenaSelection: 'route', openingArenaId: arena, maxPlayers: cohort === 'solo' ? 1 : 2 });
  const assassin = game.addPlayer('solo', 'Nyx', 'assassin');
  const ally = cohort === 'party' ? game.addPlayer('ally', 'Lane', 'soldier') : undefined;
  const actors = ally ? [assassin, ally] : [assassin];
  const shots = new Map(), notes = [], purchases = [], fights = [], intents = [];
  const trace = createHash('sha256');
  let serial = 0, steps = 0, lastShop = -1, lastEncounter = -1, allRoutesAt;
  const kits = {
    duelist: ['assassin-precision-1', duelistIds.entry, duelistIds[fitted.duelist]],
    infiltrator: ['assassin-ambush-1', infiltratorIds.entry, infiltratorIds[fitted.infiltrator]],
    hunter: ['assassin-evasion-1', markHunterIds.entry, markHunterIds[fitted.hunter]],
  };
  const first = families.indexOf(fitted.opening);
  const order = [...families.slice(first), ...families.slice(0, first)];
  const available = () => assassin.totalSp - assassin.skills.reduce((sum, id) => sum + game.skillCost(id), 0);
  const buy = (player, kind, item) => game.transact(player.id, { kind, item, id: 'assassin-study-' + ++serial });
  const skillIndex = new Map([...data.skills, ...data.specializationSkills, ...data.generalSkills].map(card => [card.id, card]));

  function buySkill(id) {
    if (assassin.skills.includes(id)) return;
    const result = buy(assassin, 'skill', id);
    assert(result.ok, JSON.stringify({ id, fitted, effective: assassin.skills, earned: assassin.totalSp, result }));
    purchases.push({ item: id, earned: assassin.totalSp, clears: assassin.progress.clears, at: game.combatTick, remaining: available() });
  }
  function acquire(name, earned) {
    const cards = kits[name].slice(0, 2).filter(id => !assassin.skills.includes(id));
    if (assassin.totalSp >= earned && cards.reduce((n, id) => n + game.skillCost(id), 0) <= available()) cards.forEach(buySkill);
  }
  function fit(name, earned) {
    const [, entry, fitting] = kits[name];
    if (assassin.totalSp >= earned && assassin.skills.includes(entry) && game.skillCost(fitting) <= available()) buySkill(fitting);
  }
  function issuedMove() {
    const capstone = data.skills.find(card => card.classId === 'assassin' && card.transform === fitted.issuedMove);
    assert(capstone);
    const chain = [];
    for (let card = capstone; card && !assassin.skills.includes(card.id); card = skillIndex.get(card.prerequisite)) chain.unshift(card.id);
    if (chain.reduce((sum, id) => sum + game.skillCost(id), 0) <= available()) chain.forEach(buySkill);
  }
  function progress() {
    fit(order[0], 5);
    acquire(order[1], 8);
    acquire(order[2], 11);
    fit(order[1], 13);
    fit(order[2], 16);
    if (!allRoutesAt && Object.values(kits).every(([, , fit]) => assassin.skills.includes(fit))) {
      allRoutesAt = { earned: assassin.totalSp, clears: assassin.progress.clears, tick: game.combatTick };
    }
    if (assassin.totalSp >= 21) issuedMove();
  }
  function equip(player) {
    for (const weapon of data.weapons.filter(w => w.classId === player.classId).sort((a, b) => b.tier - a.tier)) {
      if (player.weapon === weapon.id || buy(player, 'weapon', weapon.id).ok) break;
    }
    for (const type of ['damage','health','fire-rate','reload','magazine']) buy(player, 'upgrade', type);
    buy(player, 'supply', 'medkit');
  }
  assert.equal(assassin.totalSp, 3);
  acquire(order[0], 3);
  assert.equal(available(), 0);
  for (const actor of actors) equip(actor);
  assert(game.start());

  function danger(view, at, horizon) {
    if (view.minions.some(actor => actor.health > 0 && distance(actor, at) < 28 + Math.min(28, horizon * 2.8))) return true;
    if (view.fields.some(field => field.kind === 'zone' && distance(field, at) < field.radius + 12)) return true;
    for (const shot of shots.values()) {
      const life = Math.min(horizon, shot.expires - view.combatTick);
      if (life <= 0 || distance(shot, at) > 500) continue;
      const elapsed = (view.combatTick - shot.seenAt) / HZ;
      const from = { x: shot.x + shot.vx * elapsed, y: shot.y + shot.vy * elapsed };
      const to = { x: from.x + shot.vx * life / HZ, y: from.y + shot.vy * life / HZ };
      const contact = segmentCircle(from, to, at, shot.radius + data.rules.playerRadius + 2);
      if (contact !== null && !game.obstacles.some(wall => (segmentRect(from, to, wall, shot.radius)?.t ?? Infinity) <= contact)) return true;
    }
    return false;
  }
  const context = { ...api, game, danger };
  const ordinary = explicitNavigation(context);
  const drive = mixedPilot(context, fitted, order, row => intents.push(row));
  while (!['victory','defeat'].includes(game.phase) && steps++ < 90000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of actors) game.vote(actor.id, 0);
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        progress();
        for (const actor of actors) equip(actor);
      }
      game.step();
      game.drainEvents();
      continue;
    }
    if (game.encounter !== lastEncounter) {
      lastEncounter = game.encounter;
      fights.push({ at: game.combatTick, arena: game.arena.id, boss: game.boss.id, earned: assassin.totalSp });
    }
    const observed = viewOf(game, assassin.id);
    const start = { q: assassin.qAt, e: assassin.eAt, u: assassin.ultimateAt, position: point(assassin), health: assassin.health };
    let performed;
    for (const actor of actors) {
      const view = observed.players.find(row => row.id === actor.id);
      const base = actor.status === 'active' ? ordinary(observed, view, restRaidInput(observed, view, [...shots.values()])) :
        actor.status === 'downed' ? { interact: true } : {};
      const commands = active && actor === assassin && actor.status === 'active' ? drive(observed, view, base, actor) : base;
      const input = { ...idleInput(), ...commands, sequence: actor.ack + 1, clientTick: game.combatTick };
      input.aim = angle(input.aim);
      if (actor === assassin) performed = input;
      trace.update(JSON.stringify(input));
      assert(game.submitInput(actor.id, input));
    }
    assert([performed.technique1, performed.technique2, performed.technique3].filter(Boolean).length <= 1);
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) {
        if (shot.owner === 'hostile') shots.set(shot.id, { ...shot, seenAt: game.combatTick });
      }
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== assassin.id) continue;
      const prefix = Object.keys(actions).find(id => event.id.startsWith(id));
      if (!prefix) continue;
      const route = actions[prefix], action = event.id.slice(prefix.length);
      notes.push({ route, action, at: game.combatTick, boss: game.boss.id, start, point: point(event),
        recovery: { q: assassin.qAt, e: assassin.eAt, u: assassin.ultimateAt }, equipment: assassin.skills.slice(),
        flags: { q: performed.q, e: performed.e, u: performed.ultimate, action1: performed.technique1, action2: performed.technique2, action3: performed.technique3 },
        kit: game.kitStatus(assassin.id) });
    }
    trace.update(JSON.stringify([game.phase, game.combatTick, game.boss.health, ...actors.map(a => [a.x, a.y, a.health, a.ammo, a.qAt, a.eAt, a.ultimateAt, a.damageDealt, a.damageTaken])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  assert(assassin.totalSp <= 27 && available() >= 0 && assassin.skills.filter(id => skillIndex.get(id).capstone).length <= 1);
  return { arena, difficulty, seed, build: fitted, active, won: game.phase === 'victory', clears: assassin.progress.clears,
    allRoutesAt, purchases, notes, fights, intents, trace: trace.digest('hex') };
}

const rows = [];
for (const scenario of scenarios) {
  if (one && scenario[0] !== one[0]) continue;
  for (const fitted of builds) {
    if (one && fitted.id !== one[1]) continue;
    for (const active of one ? [one[2] === 'active'] : [false, true]) {
      const row = run(...scenario, fitted, active);
      rows.push(row);
      const used = {};
      for (const note of row.notes) {
        const key = note.route + '/' + note.action;
        used[key] = (used[key] ?? 0) + 1;
      }
      console.log(JSON.stringify({ arena: row.arena, fitting: fitted.id, active, won: row.won, clears: row.clears, allRoutesAt: row.allRoutesAt, used }));
    }
  }
}
assert.equal(rows.length, one ? 1 : 48);
receipt(destination, { passed: true, checkoutExact: true, protocol: PROTOCOL, revision: CONTENT_REVISION, cohort, mode: 'standard',
  gameBundle: checked.bundle, runtimeSourceSha256: checked.runtimeSourceSha256, rows });
