import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';

const destination = process.argv[2];
assert(destination);
const here = file => new URL('./' + file, import.meta.url);
const exact = readJson(here('runtime02.json'));
const { Game, viewOf, idleInput, distance, duelistIds, calledOpeningRules, infiltratorIds, slipRouteRules,
  markHunterIds, crossingWritRules } = await verifiedBundle(fileURLToPath(here('runtime02.mjs')), exact.bundle);
const point = ({ x, y }) => ({ x, y });
const bearing = (from, to) => Math.atan2(to.y - from.y, to.x - from.x);
const start = { x: 550, y: 423 };
const cover = { x: 630, y: 450, width: 80, height: 170 };

function routine(choices) {
  const game = new Game({ mode: 'endless', seed: 41, difficulty: 'normal', arenaSelection: 'fixed', openingArenaId: 'gatehouse', maxPlayers: 2 });
  game.encounter = 9;
  const owner = game.addPlayer('nyx', 'Nyx', 'assassin');
  const ally = game.addPlayer('ally', 'Lane', 'soldier');
  assert.equal(owner.totalSp, 27);
  const bought = [
    'assassin-precision-1', duelistIds.entry, duelistIds[choices.duelist],
    'assassin-ambush-1', infiltratorIds.entry, infiltratorIds[choices.infiltrator],
    'assassin-evasion-1', markHunterIds.entry, markHunterIds[choices.hunter],
  ];
  for (const item of bought) assert(game.transact(owner.id, { id: item, kind: 'skill', item }).ok, item);
  const spent = owner.skills.reduce((sum, id) => sum + game.skillCost(id), 0);
  assert.equal(spent, 15);
  assert(game.start());
  const potency = game.stats(owner).ability;
  assert.equal(potency, 1.05);
  const arena = structuredClone(game.arena);
  arena.obstacles = [];
  arena.lavaPits = [];
  Object.defineProperty(game, 'arena', { get: () => arena });
  Object.assign(owner, { x: 500, y: 500 });
  Object.assign(ally, { x: 460, y: 760 });
  Object.assign(game.boss, { x: 1290, y: 710, staggerUntil: 5000, deadline: 5000 });

  const body = (id, x, y, speed = 0, radius = 19) => game.minions.spawn(id, { kind: 'ordinary', x, y, health: 1500,
    speed, radius, damage: 0 }, game.combatTick);
  const quarry = body(990001, 742, 500);
  const alternate = body(990002, 743, 557);
  const rival = body(990003, 660, 422, 0, 10);
  const notes = [];
  function tick(inputs = {}) {
    for (const actor of [owner, ally]) assert(game.submitInput(actor.id, { ...idleInput(), aim: 0, sequence: actor.ack + 1,
      clientTick: game.combatTick, ...(actor === owner ? inputs : {}) }));
    game.step();
    const emitted = game.drainEvents().filter(event => event.type === 'sound' && event.owner === owner.id).map(event => event.id);
    notes.push(...emitted.map(id => ({ id, tick: game.combatTick, at: point(owner) })));
    return emitted;
  }
  const contains = (responses, id) => assert(responses.includes(id), JSON.stringify({ id, responses, at: game.combatTick, kit: game.kitStatus(owner.id) }));
  const status = () => game.kitStatus(owner.id);
  const cue = kind => game.classCues().find(row => row.kind === kind && row.owner === owner.id);
  const clocks = () => ({ q: owner.qAt, e: owner.eAt, u: owner.ultimateAt });
  const has = (id, at) => notes.some(row => row.id === id && row.tick >= at);

  contains(tick({ technique3: true }), 'assassin-writ-mark');
  assert.deepEqual(clocks(), { q: 0, e: 0, u: 0 });
  while (status().crossingWrit.phase !== 'confirmed' && game.combatTick < 80) tick({ fire: true });
  assert.equal(status().crossingWrit.phase, 'confirmed');
  assert(has('assassin-writ-proof', 0) && has('assassin-writ-confirm', 0));
  for (let i = 0; i < 20 && [...game.shots.values()].some(shot => shot.owner === owner.id); i++) tick();

  let pin;
  if (choices.hunter === 'canted') {
    contains(tick({ technique3: true }), 'assassin-writ-pin');
    pin = status().crossingWrit.pin;
    assert(pin && owner.ultimateAt === 0);
  }
  contains(tick({ technique3: true, aim: pin ? Math.PI / 8 : 0 }), 'assassin-writ-set');
  const line = cue('assassin-writ-cutoff');
  assert(line && line.until - line.at === crossingWritRules.cutoffTicks);
  if (pin) assert.deepEqual(point(line), pin);
  const uPaid = owner.ultimateAt;
  assert(uPaid > line.until && owner.qAt === 0 && owner.eAt === 0);

  let moving = quarry;
  if (choices.hunter === 'transfer') {
    const aim = bearing(owner, alternate);
    contains(tick({ technique3: true, aim }), 'assassin-writ-proposal');
    const time = game.combatTick;
    for (let i = 0; i < 24 && !has('assassin-writ-transfer', time); i++) tick({ fire: true, aim });
    assert(has('assassin-writ-transfer', time));
    assert.deepEqual(cue('assassin-writ-cutoff'), line);
    assert.deepEqual(point(cue('assassin-writ-quarry')), point(alternate));
    moving = alternate;
    for (let i = 0; i < 20 && [...game.shots.values()].some(shot => shot.owner === owner.id); i++) tick();
  }
  const beforeCross = moving.health;
  const duel = () => ({ technique1: true, aim: bearing(owner, rival) });
  contains(tick(duel()), 'assassin-duel-focus');
  const simultaneous = { tick: game.combatTick, writ: cue('assassin-writ-cutoff'), duel: cue('assassin-duel-focus') };
  assert(simultaneous.writ?.id === line.id && simultaneous.duel?.owner === owner.id);
  const peer = viewOf(game, ally.id);
  assert.deepEqual(peer.classCues, viewOf(game, owner.id).classCues);
  const peerKit = peer.players.find(row => row.id === owner.id).kit;
  assert(peerKit.calledOpening === undefined && peerKit.crossingWrit === undefined);

  moving.speed = 228;
  const crossingStart = game.combatTick;
  function measure(side) {
    for (let i = 0; i < 23 && status().calledOpening.phase !== 'open'; i++) tick({ moveY: side, aim: bearing(owner, rival) });
    assert.equal(status().calledOpening.phase, 'open');
  }
  measure(1);
  if (choices.duelist === 'counter') {
    const focus = cue('assassin-duel-focus');
    contains(tick({ ...duel(), moveY: -1 }), 'assassin-duel-turn');
    assert(cue('assassin-duel-focus').countering && cue('assassin-duel-focus').until === focus.until && owner.eAt === 0);
    measure(-1);
  }
  const flanked = point(owner);
  const rivalHealth = rival.health;
  const strike = tick(choices.duelist === 'passing' ? { ...duel(), moveY: 1 } : duel());
  contains(strike, 'assassin-duel-hit');
  if (choices.duelist === 'passing') {
    contains(strike, 'assassin-duel-pass');
    assert(owner.y > flanked.y);
  } else assert.deepEqual(point(owner), flanked);
  assert(Math.abs(rival.health - (rivalHealth - calledOpeningRules.hit * potency)) < 1e-8);
  assert(Math.abs(moving.health - (beforeCross - crossingWritRules.strike * potency)) < 1e-8);
  assert(has('assassin-writ-strike', crossingStart));
  const firstTwo = clocks();
  assert(firstTwo.e > game.combatTick && firstTwo.u === uPaid && firstTwo.q === 0);

  moving.speed = 0;
  for (const actor of [quarry, alternate, rival]) Object.assign(actor, { x: 1400, y: 830, speed: 0 });
  const wall = { ...cover };
  arena.obstacles.push(wall);
  Object.assign(owner, start);
  Object.assign(ally, { x: 490, y: 700 });
  body(990004, 755, 420, 0, 10);
  const stepRoute = { technique2: true, aim: bearing(start, wall) };
  contains(tick(stepRoute), 'assassin-slip-mark');
  const initialVeil = status().veilUntil;
  for (let i = 0; i < 22 && status().slipRoute.phase !== 'exit'; i++) tick({ moveY: 1 });
  assert(status().slipRoute.phase === 'exit' && distance(owner, start) >= slipRouteRules.leaveDistance);
  let echo, motion;
  if (choices.infiltrator === 'relay') {
    contains(tick(stepRoute), 'assassin-slip-exchange');
    const initial = cue('decoy');
    assert(initial.slipRouteEcho && status().slipRoute.phase === 'relay');
    assert(game['emitShot']('hostile', initial.x - 8, initial.y, 0, 30, 14, 4, 0, 1));
    tick();
    const hurt = cue('decoy').health;
    assert.equal(hurt, initial.health - 14);
    const since = game.combatTick;
    contains(tick(stepRoute), 'assassin-slip-relay');
    for (let i = 0; i < 12 && status().slipRoute.phase === 'relaying'; i++) tick();
    assert(has('assassin-slip-arrive', since));
    const arrived = cue('decoy');
    assert(arrived.id === initial.id && arrived.until === initial.until && arrived.health === hurt);
    echo = arrived;
    motion = { from: point(initial), to: point(arrived), healthBefore: initial.health, healthAfter: arrived.health };
  } else {
    contains(tick(stepRoute), 'assassin-slip-arm');
    assert(status().slipRoute.phase === 'watch' && status().veilUntil === initialVeil && !cue('decoy'));
    Object.assign(ally, { x: start.x - 22, y: start.y });
    const chaser = body(990005, start.x - 114, start.y, 244, 10);
    const before = point(chaser), since = game.combatTick;
    for (let i = 0; i < 12 && status().slipRoute.phase === 'watch'; i++) tick();
    assert(has('assassin-slip-threshold', since) && has('assassin-slip-exchange', since));
    assert(distance(chaser, start) <= slipRouteRules.thresholdRadius);
    echo = cue('decoy');
    assert.deepEqual(point(echo), start);
    motion = { from: before, to: point(chaser), triggeredByHostile: true };
  }
  assert(owner.qAt > game.combatTick && owner.eAt === firstTwo.e && owner.ultimateAt === firstTwo.u);
  assert(status().veilUntil < initialVeil);
  const other = viewOf(game, ally.id);
  assert(other.classCues.some(row => row.kind === 'decoy' && row.id === echo.id));
  assert(!other.players.find(row => row.id === owner.id).kit.slipRoute);
  return { choices, bought, earned: owner.totalSp, spent, potency, simultaneous, line, pin, transferred: choices.hunter === 'transfer',
    targetDamage: { duel: rivalHealth - rival.health, cutoff: beforeCross - moving.health },
    clocks: clocks(), echo, motion, notes };
}

const cases = [routine({ duelist: 'passing', infiltrator: 'relay', hunter: 'canted' }),
  routine({ duelist: 'counter', infiltrator: 'threshold', hunter: 'transfer' })];
receipt(destination, { passed: true, scopedControlledFights: true, protocol: exact.protocol, revision: exact.revision,
  gameBundle: exact.bundle, runtimeSourceSha256: exact.runtimeSourceSha256, cases });
console.log(JSON.stringify({ passed: true, cases: cases.map(row => ({ choices: row.choices, cutoff: row.targetDamage.cutoff,
  duel: row.targetDamage.duel, echo: row.echo.id, motion: row.motion, clocks: row.clocks })) }));
