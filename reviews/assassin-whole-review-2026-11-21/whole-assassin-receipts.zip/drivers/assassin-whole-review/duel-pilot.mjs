const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const forward = (p,a,d) => ({ x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d });
const around = angle => Math.atan2(Math.sin(angle),Math.cos(angle));

export function duelistPilot({ game, data, rules, ids, distance, segmentRect, clearTrialWalk, danger, fitting }) {
  let plan, spentClock, reserveUntil = 0;
  const visible = (a,b,pad=1) => !game.obstacles.some(wall => segmentRect(a,b,wall,pad));
  function movement(view,p,aim) {
    const world = { ...game.arena, obstacles:game.obstacles, tick:view.combatTick };
    const next = forward(p,aim,23);
    if (clearTrialWalk(world,p,next) && !danger(view,next,5)) return { moveX: Math.cos(aim), moveY: Math.sin(aim) };
  }
  function openingTarget(view,p){
    const boss={...view.boss,radius:data.bosses.find(row=>row.id===view.boss.id)?.radius??24,key:'boss'};
    const further=view.minions.filter(row=>row.health>0).map(row=>({...row,key:'actor-'+row.id}));
    return [boss,...further].filter(row=>distance(p,row)>=rules.minimumPickRange+3&&distance(p,row)<=rules.maximumPickRange-3&&
      visible(p,row,rules.pad)).sort((a,b)=>Number(b.key==='boss')-Number(a.key==='boss')||distance(p,a)-distance(p,b))[0];
  }
  function lateralMove(view,p,target,sign){
    const base=bearing(p,target), world={...game.arena,obstacles:game.obstacles,tick:view.combatTick};
    for(const offset of [Math.PI/2,1.24,1.80]){
      const angle=base+sign*offset, end=forward(p,angle,25);
      if(!clearTrialWalk(world,p,end)||!visible(end,target,rules.pad)||danger(view,end,6)||distance(end,target)>rules.maximumReach-10)continue;
      return {moveX:Math.cos(angle),moveY:Math.sin(angle)};
    }
  }
  function decide(view,p,base,duelist){
    const now=view.combatTick,state=p.kit.calledOpening,aim=bearing(p,view.boss);
    const target=view.classCues.find(row=>row.kind==='assassin-duel-focus'&&row.owner===duelist.id);
    const hands=!base.dodge&&duelist.reloadAt<=now&&duelist.dashUntil<=now&&p.health>=p.maxHealth*.36;
    if(target){
      const atTarget=bearing(p,target);
      if(!hands||danger(view,p,4))return base;
      if(state?.phase==='open'){
        const same=lateralMove(view,p,target,plan?.sign??1);
        const others=lateralMove(view,p,target,-(plan?.sign??1));
        if(fitting==='passing'&&duelist.skills.includes(ids.passing)&&state.canPass&&same)return {...same,technique1:true,aim:atTarget};
        if(fitting==='counter'&&duelist.skills.includes(ids.counter)&&state.canCounter&&others&&now+12<state.until){
          plan.turnSign=-plan.sign;
          return {...others,technique1:true,aim:atTarget};
        }
        return {technique1:true,aim:atTarget};
      }
      const sign=state?.phase==='reposition'?plan?.turnSign??1:plan?.sign??1;
      const stride=lateralMove(view,p,target,sign)??lateralMove(view,p,target,-sign);
      return stride?{...stride,fire:base.fire,aim:atTarget}:{...base,e:false};
    }
    if(!hands||duelist.eAt>now||(state?.until??0)>now||duelist.ultimateAt<=now&&p.health<p.maxHealth*.48)return base;
    if(spentClock!==duelist.eAt){spentClock=duelist.eAt;reserveUntil=now+85;}
    if(now>=reserveUntil)return base;
    const pending=openingTarget(view,p);
    const multiple=view.minions.filter(row=>row.health>0&&distance(row,p)<=185&&visible(p,row,2)&&
      Math.abs(around(bearing(p,row)-aim))<.43).length>1;
    if(multiple&&base.e)return base;
    if(pending&&!danger(view,p,8)){
      for(const sign of [1,-1]){
        if(lateralMove(view,p,pending,sign)){
          plan={sign,target:pending.key};
          return {technique1:true,aim:bearing(p,pending)};
        }
      }
    }
    const closer=distance(p,view.boss)>197&&distance(p,view.boss)<390&&visible(p,view.boss,2)&&!danger(view,p,6)
      ?movement(view,p,aim):undefined;
    return {...base,...closer,e:false};
  }
  return decide;
}
