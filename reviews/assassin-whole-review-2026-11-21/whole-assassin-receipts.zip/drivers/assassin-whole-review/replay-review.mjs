import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdirSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const output = process.argv[2];
assert(/^replays\d\d$/.test(output));
const here = file => new URL('./' + file, import.meta.url);
const run = promisify(execFile);
const file = 'whole-assassin-runs.mjs';
const digest = path => sha256(readFileSync(here(path)));
const original = ['solo','party'].map(cohort => readJson(here('whole-standard-' + cohort + '01.json')));
const bundle = readJson(here('runtime02.json'));
assert(original.every(row => row.passed && row.rows.length === 48 && row.gameBundle === bundle.bundle));
const completed = row => [
  ['duelist','hit'], ['infiltrator','exchange'], ['hunter','strike'],
].filter(([route, effect]) => row.notes.some(note => note.route === route && note.action === effect)).length;
function sample(rows) {
  const best = rows.filter(row => row.active).toSorted((a, b) => completed(b) - completed(a) || b.notes.length - a.notes.length);
  const selected = [];
  for (const row of best) if (!selected.some(found => found.build.id === row.build.id) && selected.length < 4) selected.push(row);
  const ordinary = rows.filter(row => !row.active);
  selected.push(ordinary.find(row => row.arena === 'gatehouse'), ordinary.find(row => row.arena === 'ossuary-works'));
  return selected;
}
mkdirSync(here(output));
const selections = original.map(cohort => ({ cohort: cohort.cohort, rows: sample(cohort.rows) }));
const compared = [];
for (let offset = 0; offset < 6; offset++) {
  for (const result of await Promise.allSettled(selections.map(async ({ cohort, rows }) => {
    const expected = rows[offset];
    const policy = expected.active ? 'active' : 'unused';
    const selector = [expected.arena, expected.build.id, policy].join('/');
    const path = output + '/' + [cohort, expected.arena, expected.build.id, policy].join('-') + '.json';
    await run(process.execPath, [fileURLToPath(here(file)), fileURLToPath(here(path)), cohort, selector],
      { cwd: fileURLToPath(here('./')), windowsHide: true, timeout: 145_000 });
    const actual = readJson(here(path));
    assert.equal(actual.gameBundle, bundle.bundle);
    assert.equal(actual.rows.length, 1);
    assert.deepEqual(actual.rows[0], expected, selector);
    return { path, cohort, policy, selector, trace: expected.trace, records: expected.notes.length, sha256: digest(path) };
  }))) {
    if (result.status === 'rejected') throw result.reason;
    compared.push(result.value);
  }
}
assert.equal(compared.length, 12);
receipt(here(output + '/summary.json'), { passed: true, gameBundle: bundle.bundle, driver: digest(file), exactInputsAndOutcomes: true, cases: compared });
console.log(JSON.stringify({ passed: true, cases: compared.length }));
