import { duelistPilot } from './duel-pilot.mjs';
import { fittingRoutePilot } from '../assassin-infiltrator/fitting-route-pilot.mjs';
import { writPilot } from '../assassin-mark-hunter/writ-pilot-fittings.mjs';

export function mixedPilot(context, built, rotation, record) {
  const { duelistIds, calledOpeningRules, slipRouteRules, crossingWritRules, danger } = context;
  const queued = { duelist: [], infiltrator: [], hunter: [] };
  const duel = duelistPilot({ ...context, ids: duelistIds, rules: calledOpeningRules, fitting: built.duelist });
  const slip = fittingRoutePilot({ ...context, rules: slipRouteRules }, detail => queued.infiltrator.push(detail));
  const writ = writPilot({ ...context, rules: crossingWritRules, fitting: built.hunter });
  const keys = { duelist: 'technique1', infiltrator: 'technique2', hunter: 'technique3' };
  let priority = 0, suggested, reconsider = 0;

  return (view, owner, base, player) => {
    const now = view.combatTick;
    const { slipRoute, crossingWrit } = owner.kit;
    const owned = {
      duelist: owner.skills.includes(context.duelistIds.entry),
      infiltrator: owner.skills.includes(context.infiltratorIds.entry),
      hunter: owner.skills.includes(context.markHunterIds.entry),
    };
    const active = {
      duelist: view.classCues.some(cue => cue.kind === 'assassin-duel-focus' && cue.owner === owner.id),
      infiltrator: ['walk','exit','watch','relay'].includes(slipRoute?.phase),
      hunter: ['marked','confirmed','pinned','transfer'].includes(crossingWrit?.phase),
    };
    for (const lines of Object.values(queued)) lines.length = 0;
    const input = {
      duelist: owned.duelist ? duel(view, owner, base, player) : base,
      infiltrator: owned.infiltrator ? slip(view, owner, base, player) : base,
      hunter: owned.hunter ? writ(view, owner, base, player, detail => queued.hunter.push(detail)) : base,
    };
    const fireRoute = name => {
      if (input[name][keys[name]] && !active[name]) {
        priority = (rotation.indexOf(name) + 1) % rotation.length;
        suggested = undefined;
      }
      for (const intent of queued[name]) record({ route: name, ...intent });
      return input[name];
    };
    if (base.dodge && danger(view, owner, 7) || owner.health < owner.maxHealth * .32) return base;
    const ordered = [...rotation.slice(priority), ...rotation.slice(0, priority)];
    const current = ordered.find(name => owned[name] && active[name]);
    if (current) return fireRoute(current);

    const immediate = ordered.find(name => owned[name] && !!input[name][keys[name]]);
    if (immediate) return fireRoute(immediate);

    const due = { duelist: owner.eAt, infiltrator: owner.qAt, hunter: owner.ultimateAt };
    const moving = name => owned[name] && due[name] <= now &&
      Math.hypot((input[name].moveX ?? 0) - (base.moveX ?? 0), (input[name].moveY ?? 0) - (base.moveY ?? 0)) > .17;
    if (suggested && now < reconsider && moving(suggested)) return fireRoute(suggested);
    const following = ordered.find(moving);
    if (!following) return base;
    suggested = following;
    reconsider = now + 22;
    return fireRoute(following);
  };
}
