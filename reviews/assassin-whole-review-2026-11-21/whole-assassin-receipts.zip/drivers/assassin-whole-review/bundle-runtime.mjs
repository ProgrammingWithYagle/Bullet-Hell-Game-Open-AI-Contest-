import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { createRequire } from 'node:module';
import { readFileSync, readdirSync, realpathSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const [attempt] = process.argv.slice(2);
assert(/^runtime\d\d$/.test(attempt) && realpathSync(process.cwd()) === realpathSync(checkout));
const here = file => new URL('./' + file, import.meta.url);
const edition = readJson(here('../assassin-mark-hunter/content01.json'));
const plan = readJson(here('../assassin-mark-hunter/install-plan01.json'));
assert(edition.revision === plan.revision && edition.protocol === 92);
for (const { path, next } of plan.files) assert.equal(sha256(readFileSync(join(checkout, path))), next, path);
const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
const entry = [
  "export { Game, data } from './src/shared/game.ts';",
  "export { HZ, idleInput, PROTOCOL, CONTENT_REVISION } from './src/shared/protocol.ts';",
  "export { viewOf } from './src/shared/view.ts';",
  "export { distance, segmentRect, segmentCircle } from './src/shared/geometry.ts';",
  "export { duelistIds, calledOpeningRules } from './src/shared/assassin-called-opening.ts';",
  "export { infiltratorIds, slipRouteRules } from './src/shared/assassin-slip-route.ts';",
  "export { markHunterIds, crossingWritRules, cutoffReach } from './src/shared/assassin-crossing-writ.ts';",
  "export { restRaidInput } from './tests/helpers/sniper-rest-raid-policy.ts';",
  "export { clearTrialWalk } from './tests/helpers/tank-bulwark-staging.ts';",
  "export { runtimeArena } from './src/shared/arena-layouts.ts';",
].join('\n');

function sourcePaths(base) {
  return readdirSync(join(checkout, base), { withFileTypes: true }).flatMap(child => {
    assert(!child.isSymbolicLink());
    const path = base + '/' + child.name;
    return child.isDirectory() ? sourcePaths(path) : [path];
  });
}
function fingerprint(paths) {
  const hash = createHash('sha256');
  for (const file of paths.sort()) hash.update(file + '\0').update(readFileSync(join(checkout, file)));
  return hash.digest('hex');
}
const measuredSource = sourcePaths('src');
const runtimeSha = fingerprint(measuredSource);
const snapshotSha = fingerprint([...measuredSource, ...sourcePaths('tests'), 'package.json', 'pnpm-lock.yaml',
  'pnpm-workspace.yaml', 'tsconfig.json', 'vite.config.ts', 'index.html']);
const result = await build({ absWorkingDir: checkout, stdin: { contents: entry, loader: 'ts', resolveDir: checkout },
  bundle: true, write: false, format: 'esm', platform: 'node', target: 'node24', logLevel: 'silent', metafile: true });
const paths = Object.keys(result.metafile.inputs).map(path => path.replace(/ with \{[^{}]+\}$/, '').replaceAll('\\','/'));
const files = [...new Set(paths.filter(path => /^(src|content|tests)\//.test(path)))].sort();
assert(files.includes('content/catalog.json') && ['called-opening','slip-route','crossing-writ'].every(id => files.includes('src/shared/assassin-' + id + '.ts')));
const bytes = result.outputFiles[0].contents;
const output = { passed: true, checkoutExact: true, protocol: 92, revision: edition.revision,
  runtimeSourceSha256: runtimeSha, sourceSnapshotSha256: snapshotSha, bundle: sha256(bytes),
  inputs: Object.fromEntries(files.map(file => [file, sha256(readFileSync(join(checkout, file)))])) };
writeFileSync(here(attempt + '.mjs'), bytes, { flag: 'wx' });
receipt(here(attempt + '.json'), output);
console.log(JSON.stringify({ protocol: output.protocol, revision: output.revision, bundle: output.bundle, source: runtimeSha, inputs: files.length }));
