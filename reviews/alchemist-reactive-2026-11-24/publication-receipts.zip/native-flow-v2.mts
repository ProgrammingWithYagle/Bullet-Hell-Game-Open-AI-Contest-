import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { repoImport } from '../bonded/study-paths.mjs';
import { waitFor } from '../formation/native-flow-v4.mts';
import { navigationPolicy } from '../ranger-whole/navigation-policy.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { reactiveIds, reactiveRules } = await repoImport('src/shared/alchemist-reactive.ts');
const recipeRules = data.rules.alchemy;
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
export { waitFor };

const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const heading = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
const offset = (point, direction, travel) => ({ x: point.x + Math.cos(direction) * travel, y: point.y + Math.sin(direction) * travel });
const quiet = (frame, aim = frame.aim) => ({ ...frame, aim, q: false, e: false, ultimate: false, technique1: false, technique2: false, technique3: false,
  fire: false, reload: false, sprint: false });
const move = (frame, aim) => ({ ...frame, moveX: Math.cos(aim), moveY: Math.sin(aim) });
const visible = (map, a, b, pad) => !map.obstacles.some(wall => segmentRect(a, b, wall, pad) !== null);

export async function reactionFlow(adapter, fitting) {
  const view = () => { const state = adapter.view(); assert(state); return state; };
  const actor = () => { const row = view().players.find(p => p.id === adapter.id); assert(row); return row; };
  const kit = () => actor().kit;
  const controls = navigationPolicy({ ordinary: restRaidInput, arenaFor: runtimeArena, segmentRect, segmentCircle, playerRadius: data.rules.playerRadius });
  const ordinary = () => controls(view(), actor(), [...adapter.observed.values()]);
  const cues = (kind, recipe) => view().classCues.filter(cue => cue.kind === kind && cue.owner === adapter.id && (!recipe || cue.recipe === recipe));
  const purchases = [], attempts = [];
  const owned = () => actor().skills.reduce((cost, id) => cost + [...data.skills, ...data.specializationSkills].find(row => row.id === id).cost, 0);
  const diagnose = () => JSON.stringify({ fitting, boss: view().boss.id, phase: view().phase, tick: view().combatTick,
    eAt: actor().eAt, qAt: actor().qAt, health: actor().health, kit: kit().alchemyReaction, prepared: kit().alchemyPrepared, attempts: attempts.slice(-4) });
  async function buy(id) {
    assert((await adapter.purchase({ kind: 'skill', item: id })).ok, id);
    purchases.push({ item: id, earned: owned() + actor().sp, clears: actor().progress.clears });
  }
  async function outfit() {
    for (const weapon of data.weapons.filter(weapon => weapon.classId === 'alchemist').sort((a, b) => b.tier - a.tier)) {
      if (actor().weapon === weapon.id || (await adapter.purchase({ kind: 'weapon', item: weapon.id })).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) await adapter.purchase({ kind: 'upgrade', item });
    await adapter.purchase({ kind: 'supply', item: 'medkit' });
  }
  assert.equal(actor().sp, 3);
  await buy('alchemist-mixtures-1');
  await buy(reactiveIds.entry);
  await waitFor(() => !!kit().alchemyReaction, 'owner Action 1 arrived');
  if (fitting !== 'entry') assert(!(await adapter.purchase({ kind: 'skill', item: reactiveIds[fitting] })).ok);
  await outfit();
  adapter.start();
  await waitFor(() => view().phase === 'combat', 'opening combat');
  if (fitting !== 'entry') {
    const deadline = Date.now() + 125_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < deadline && !['defeat', 'victory'].includes(view().phase), diagnose());
      if (view().phase === 'combat') {
        const frame = ordinary();
        adapter.input({ ...quiet(frame), fire: frame.fire === true, reload: frame.reload === true });
        adapter.ally?.(true);
      } else if (['mutationVote', 'contractVote', 'secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(24);
    }
    assert.equal(actor().progress.clears, 1);
    assert.equal(owned() + actor().sp, 5);
    await buy(reactiveIds[fitting]);
    assert.equal((await adapter.purchase({ kind: 'skill', item: reactiveIds[fitting === 'wick' ? 'vent' : 'wick'] })).reason, 'incompatibleItem');
    await outfit();
    await waitFor(() => view().phase === 'combat', 'fitted combat', 90000);
  }
  const firstClear = actor().progress.clears;
  console.log(JSON.stringify({ fitting, firstClear, purchases, boss: view().boss.id }));

  let binding, activeThrow, witness;
  let pauseRejected = false;
  let selectedAt = -1, issuedAt = -1;
  let lastPrimary = -Infinity;
  const deadline = Date.now() + 125_000;
  const range = fitting === 'wick' ? 160 : 239;
  while (Date.now() < deadline && view().phase === 'combat') {
    const state = view(), p = actor(), status = kit().alchemyReaction, tick = state.combatTick;
    const target = state.boss, map = runtimeArena(state.arenaId, state.run.difficulty), frame = ordinary();
    const aim = heading(p, target), still = { ...quiet(frame, aim), moveX: 0, moveY: 0 };
    adapter.ally?.(false);

    if (activeThrow) {
      const flight = cues('alchemy-flask', 'flare').find(cue => cue.at >= activeThrow.started);
      if (flight) activeThrow.flight = flight;
      if (activeThrow.flight && tick >= activeThrow.flight.until) {
        const landed = cues('alchemy-pool', 'flare').find(cue => cue.at === activeThrow.flight.until && distance(cue, activeThrow.binding) < .01);
        if (landed && target.health < activeThrow.health) {
          const retained = cues('alchemy-pool', 'binding').some(cue => cue.id === activeThrow.binding.id && cue.until === activeThrow.binding.until);
          const reaction = adapter.events.slice(activeThrow.events).some(event => event.type === 'sound' && event.id === 'alchemy-react' && event.owner === adapter.id);
          assert.equal(retained, fitting === 'vent');
          assert.equal(reaction, fitting !== 'vent');
          assert.equal(p.eAt - activeThrow.prior, activeThrow.recovery);
          assert.equal(activeThrow.flight.until - activeThrow.flight.at, fitting === 'wick' ? reactiveRules.wickFlightTicks : recipeRules.flightTicks);
          return { passed: true, fitting, firstClear, boss: target.id, bought: purchases, witness, pauseRejected, attempts,
            result: { hit: true, original: activeThrow.binding, flight: activeThrow.flight, landed, retained, reaction,
              damage: activeThrow.health - target.health, recovery: activeThrow.recovery, beforeReadyAt: activeThrow.prior,
              readyAt: p.eAt, chalkBefore: activeThrow.chalk, chalkAfter: activeThrow.chalkAfter, samples: activeThrow.samples } };
        }
        attempts.push({ reason: 'early Flask landed outside the living target', tick, at: activeThrow.flight.at, pool: activeThrow.binding.id });
        activeThrow = undefined;
        binding = undefined;
        issuedAt = -1;
      } else if (!activeThrow.flight && tick > activeThrow.started + 38) {
        attempts.push({ reason: 'no early Flask flight observed', tick });
        activeThrow = undefined;
        binding = undefined;
        issuedAt = -1;
      }
      adapter.input(still);
      await sleep(21);
      continue;
    }

    if (!binding && issuedAt >= 0) {
      binding = cues('alchemy-pool', 'binding').find(cue => cue.at >= issuedAt);
      if (!binding && tick > issuedAt + 35) { issuedAt = -1; attempts.push({ reason: 'Binding did not land', tick }); }
    }
    if (binding && (tick >= p.eAt || tick >= binding.until)) {
      attempts.push({ reason: 'Binding window ended', tick, pool: binding.id });
      binding = undefined;
      issuedAt = -1;
    }
    const have = kit().alchemyPrepared ?? [];
    if (binding) {
      const phi = heading(p, binding);
      adapter.input({ ...still, aim: phi });
      if (status?.stage === 'ready' && status.target && distance(status.target, binding) < .01 && distance(binding, target) <= 35 &&
          p.eAt - tick > 12 && tick > lastPrimary + 33 && !cues('alchemy-pool', 'flare').length) {
        if (!pauseRejected) {
          witness = await adapter.witness?.(status);
          adapter.pause(true);
          await waitFor(() => adapter.paused(), 'pause before early throw');
          const pausedAt = view().combatTick, before = { eAt: actor().eAt, chalk: kit().alchemyChalk, vials: [...kit().alchemyPrepared] };
          adapter.input({ technique1: true, aim: phi });
          await sleep(115);
          assert.equal(view().combatTick, pausedAt);
          assert.equal(actor().eAt, before.eAt);
          assert.equal(kit().alchemyChalk, before.chalk);
          assert.deepEqual(kit().alchemyPrepared, before.vials);
          pauseRejected = true;
          adapter.pause(false);
          await waitFor(() => !adapter.paused() && view().combatTick > pausedAt, 'resumed before launch');
          continue;
        }
        const current = actor(), started = view().combatTick;
        const recovery = current.eAt - (binding.at - recipeRules.flightTicks);
        const trial = { binding, started, recovery, prior: current.eAt, health: view().boss.health, events: adapter.events.length,
          chalk: kit().alchemyChalk, chalkAfter: undefined, samples: current.ammo };
        const sequence = adapter.input({ ...still, aim: phi, dodge: false, supply: -1, technique1: true });
        await waitFor(() => actor().ack >= sequence || view().phase !== 'combat', diagnose);
        if (kit().alchemyReaction?.stage === 'spent') {
          assert.equal(actor().ammo, trial.samples);
          trial.chalkAfter = kit().alchemyChalk;
          assert(trial.chalkAfter <= trial.chalk);
          activeThrow = trial;
        }
      }
    } else if (issuedAt >= 0) {
      adapter.input(still);
    } else if (have[0] === 'binding' && have[1] === 'flare') {
      const room = distance(p, target);
      if (tick >= p.eAt && room < range && visible(map, p, target, 8)) {
        issuedAt = tick;
        adapter.throw({ x: target.x, y: target.y });
        adapter.input(still);
      } else {
        const spot = offset(target, heading(target, p), range - 40);
        adapter.input(visible(map, p, spot, 15) && distance(p, spot) > 6 && room > range - 15 ? move(still, heading(p, spot)) : quiet(frame));
      }
    } else if (have[0] === 'flare') {
      if (tick >= p.eAt && visible(map, p, target, 8) && distance(p, target) < 270) adapter.throw({ x: target.x, y: target.y });
      adapter.input(quiet(frame));
    } else {
      const recipe = have.length ? 'flare' : 'binding';
      if (kit().alchemyRecipe !== recipe && tick > selectedAt + 6) { adapter.select(recipe); selectedAt = tick; }
      if (kit().alchemyRecipe === recipe && tick >= p.qAt && tick >= (kit().alchemyBrewUntil ?? 0) && !frame.dodge) {
        adapter.input({ ...quiet(frame), q: true });
      } else {
        const needsStock = (kit().alchemyChalk ?? 0) < 2 && tick >= (kit().alchemyBrewUntil ?? 0);
        const fire = needsStock && frame.fire;
        if (fire) lastPrimary = tick;
        adapter.input({ ...quiet(frame), fire, reload: needsStock && frame.reload });
      }
    }
    await sleep(22);
  }
  assert.fail(diagnose());
}
