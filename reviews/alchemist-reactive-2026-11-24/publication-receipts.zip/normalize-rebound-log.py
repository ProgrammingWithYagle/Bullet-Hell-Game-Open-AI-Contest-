from pathlib import Path


root = Path(__file__).resolve().parent / 'gate03'
original = (root / 'verify.log').read_text(encoding='utf-8-sig')
if 'ℹ pass 3023' in original:
    normalized = original
else:
    normalized = original.encode('cp437').decode('utf-8')
    assert normalized.encode('utf-8').decode('cp437') == original

counts = [line for line in normalized.splitlines() if line.startswith('ℹ ')]
assert counts[-7:] == ['ℹ tests 3023', 'ℹ suites 0', 'ℹ pass 3023', 'ℹ fail 0', 'ℹ cancelled 0', 'ℹ skipped 0', 'ℹ todo 0'] or (
    'ℹ tests 3023' in counts and 'ℹ pass 3023' in counts and 'ℹ fail 0' in counts
)
assert 'Verification passed; evidence' in normalized
with (root / 'verify-utf8.log').open('x', encoding='utf-8', newline='\n') as result:
    result.write(normalized)
