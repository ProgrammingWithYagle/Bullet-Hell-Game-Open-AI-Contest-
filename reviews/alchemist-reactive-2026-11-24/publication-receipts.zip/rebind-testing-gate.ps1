$ErrorActionPreference = 'Stop'
$checkout = 'C:\Users\yigal\OneDrive\Documents\ChatGPT\OpenAI Multiplayer Game Contest (Bullet Hell)'
if ((Resolve-Path -LiteralPath '.').Path -cne $checkout) { throw 'Use the canonical checkout.' }
$source = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-commit01.json') -Raw | ConvertFrom-Json
$pushed = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-push01.json') -Raw | ConvertFrom-Json
if (!$source.passed -or $source.sourceCommit -cne '61fe200deb40e4881239c58fb39e63ae73e69d6f' -or $source.protocol -ne 105 -or
    !$pushed.passed -or $pushed.head -cne $source.sourceCommit -or $source.sourceCommit -cne (git -c core.bare=false --work-tree=. rev-parse HEAD) -or $LASTEXITCODE) {
  throw 'Use the gated and pushed Reactive Mixtures commit.'
}
$changes = git -c core.bare=false --work-tree=. status --porcelain=v1 --untracked-files=all
if ($LASTEXITCODE -or $changes) { throw 'Preserve other checkout changes.' }

$out = (Resolve-Path -LiteralPath 'output').Path
$wrongName = 'playtest-alchemist-reactive-2026-11-24-testing-61fe200'
$wrong = (Resolve-Path -LiteralPath (Join-Path $out $wrongName)).Path
$dist = [IO.Path]::GetFullPath((Join-Path $checkout 'dist'))
if ((Split-Path -Parent $wrong) -cne $out -or (Split-Path -Leaf $wrong) -cne $wrongName -or (Split-Path -Parent $dist) -cne $checkout -or
    (Test-Path -LiteralPath $dist) -or ((Get-Item -LiteralPath $wrong).Attributes -band [IO.FileAttributes]::ReparsePoint)) {
  throw 'The partial build path or original dist path differs.'
}
$scope = 'reviews/alchemist-reactive-2026-11-24'
if ((Test-Path -LiteralPath (Join-Path $wrong 'preview-build.json')) -or (Test-Path -LiteralPath "$scope/preview-testing.json") -or
    (Test-Path -LiteralPath "$scope/processes-testing.json")) { throw 'Preserve any existing verified preview.' }
foreach ($port in 5454,2830) {
  $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$port)
  $probe.ExclusiveAddressUse = $true
  try { $probe.Start() } finally { $probe.Stop() }
}
$gate = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'gate01/generated/reviews/runtime-verification.json') -Raw | ConvertFrom-Json
if (!$gate.passed -or $gate.runtimeSourceSha256 -cne $source.runtimeSourceSha256 -or $gate.sourceSnapshotSha256 -cne $source.sourceSnapshotSha256) {
  throw 'The rejected build has no exact source gate.'
}
foreach ($member in $gate.artifacts) {
  if ($member.path -cnotmatch '^dist/[a-zA-Z0-9_./-]+$' -or $member.path.Split('/').Contains('..')) { throw 'Unexpected original gate artifact.' }
  $path = Join-Path $wrong $member.path.Substring(5)
  if ((Get-FileHash -LiteralPath $path).Hash.ToLowerInvariant() -cne $member.sha256) { throw 'A rejected build artifact changed.' }
}
$script = Get-ChildItem -LiteralPath (Join-Path $wrong 'assets') -Filter 'index-*.js' -File | Where-Object {
  Select-String -LiteralPath $_.FullName -Pattern 'http://127.0.0.1:2828' -SimpleMatch -Quiet
}
if (@($script).Count -ne 1 -or (Select-String -LiteralPath $script.FullName -Pattern 'http://127.0.0.1:2830' -SimpleMatch -Quiet)) {
  throw 'The testing endpoint mismatch could not be reproduced.'
}
$rejected = Join-Path $PSScriptRoot 'testing-freeze-before-rebind.json'
if (Test-Path -LiteralPath $rejected) { throw 'Preserve the original rejected frozen build receipt.' }
[ordered]@{ sourceCommit=$source.sourceCommit; expected='http://127.0.0.1:2830'; actual='http://127.0.0.1:2828';
  rejectedRoot=$wrongName; priorGateArtifactsChecked=$gate.artifacts.Count; wrongScriptSha256=(Get-FileHash -LiteralPath $script.FullName).Hash.ToLowerInvariant();
  launchRecordsFound=$false; recordedAt=[datetime]::UtcNow.ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath $rejected -Encoding utf8NoBOM
Move-Item -LiteralPath $wrong -Destination $dist
if (!(Test-Path -LiteralPath $dist) -or (Test-Path -LiteralPath $wrong)) { throw 'Partial testing output did not return to its original dist path.' }

$runner = 'C:\Users\yigal\Documents\Codex\2026-11-18\ok\work\bastion-admission\run-gate.ps1'
& $runner -ReceiptDirectory (Join-Path $PSScriptRoot 'gate02') -TestingBackend 2830
exit $LASTEXITCODE
