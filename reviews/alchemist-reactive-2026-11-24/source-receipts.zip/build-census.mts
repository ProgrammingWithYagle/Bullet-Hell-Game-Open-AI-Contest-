import assert from 'node:assert/strict';
import { join } from 'node:path';
import { checkout, readJson, receipt, repoImport } from '../bonded/study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION } = await repoImport('src/shared/protocol.ts');
const { conflictingSkill } = await repoImport('src/shared/skill-conflicts.ts');
const { reactiveIds } = await repoImport('src/shared/alchemist-reactive.ts');
const [target, edition] = process.argv.slice(2);
assert(target && PROTOCOL === 105 && (edition === undefined || edition === 'staged'));
const prior = readJson(join(checkout, 'reviews/ranger-field-controller-2026-11-24/build-census.json'));
assert.equal(prior.totalSets, 31627);
assert(!prior.reports.some(report => report.classId === 'alchemist'));

const skills = new Map([...data.skills, ...data.generalSkills, ...data.specializationSkills].map(node => [node.id, node]));
const transforms = data.skills.filter(node => node.classId === 'alchemist' && node.transform);
const techniques = data.specializationSkills.filter(node => node.classId === 'alchemist');
assert.deepEqual(transforms.map(node => node.transform).sort(), ['second-extraction', 'settled-batch', 'split-pour']);
assert.deepEqual(techniques.map(node => node.id), Object.values(reactiveIds));
const significant = new Set([...techniques, ...transforms, ...data.generalSkills].map(node => node.id));
const prerequisites = new Set<string>();
function include(id: string) {
  if (prerequisites.has(id)) return;
  const node = skills.get(id);
  assert(node, id);
  if (node.prerequisite) include(node.prerequisite);
  prerequisites.add(id);
}
for (const id of significant) include(id);
const choices = [...prerequisites], acquired: string[] = [], additions = new Map(), baseline = new Map();
function walk(index: number, spent: number, capstones: number) {
  if (index === choices.length) {
    const results = acquired.includes(reactiveIds.entry) ? additions : baseline;
    const signature = acquired.filter(id => significant.has(id)).sort().join('|');
    if (!results.has(signature) || results.get(signature).spent > spent) {
      results.set(signature, { skills: [...acquired], spent, remaining: 27 - spent, capstones, operationAndSharedSignature: signature });
    }
    return;
  }
  const id = choices[index], node = skills.get(id)!;
  walk(index + 1, spent, capstones);
  if (spent + node.cost > 27 || Number(node.freePlaySpRequired ?? 0) > 27 || node.capstone && capstones ||
      node.prerequisite && !acquired.includes(node.prerequisite) || conflictingSkill(acquired, id)) return;
  acquired.push(id);
  walk(index + 1, spent + node.cost, capstones + Number(node.capstone));
  acquired.pop();
}
walk(0, 0, 0);
const count = (id: string) => [...additions.values()].filter(row => row.skills.includes(id)).length;
const fitting = { wick: count(reactiveIds.wick), vent: count(reactiveIds.vent),
  transformations: Object.fromEntries(transforms.map(node => [node.transform, count(node.id)])), exclusions: 0 };
assert(fitting.wick > 0 && fitting.wick === fitting.vent && baseline.size > 0);
assert(Object.values(fitting.transformations).every(value => value > 0));
const traced = [...prior.reports, { classId:'alchemist', techniques:techniques.length, fitting, distinctSets:0,
  builds: [...baseline.values(), ...additions.values()] }];
const reports = traced.map(report => {
  let purchases = 0;
  for (const row of report.builds) {
    const game = new Game({ mode: 'endless', seed: 41, maxPlayers: 1 });
    game.encounter = 9;
    const actor = game.addPlayer('solo', 'Build census', report.classId);
    assert.equal(actor.totalSp, 27);
    for (const item of row.skills) assert(game.transact(actor.id, { id:'buy-' + ++purchases, kind:'skill', item }).ok, item);
    assert.deepEqual(actor.skills, row.skills);
    assert.equal(actor.skills.reduce((spent, id) => spent + game.skillCost(id), 0), row.spent);
    if (report.classId !== 'alchemist') continue;
    const status = game.kitStatus(actor.id).alchemyReaction;
    assert.equal(Boolean(status), row.skills.includes(reactiveIds.entry));
    const wick = row.skills.includes(reactiveIds.wick), vent = row.skills.includes(reactiveIds.vent);
    if (status) assert.equal(status.fitting, wick ? 'wick' : vent ? 'vent' : 'standard');
    if (wick || vent) {
      const rejected = wick ? reactiveIds.vent : reactiveIds.wick;
      assert.equal(game.transact(actor.id, { id:'excluded', kind:'skill', item:rejected }).reason, 'incompatibleItem');
      assert(!actor.skills.includes(rejected));
      fitting.exclusions++;
    }
  }
  return { ...report, purchases, priorSetsPreserved: report.distinctSets, distinctSets: report.builds.length };
});
const priorSetCount = reports.reduce((sum, report) => sum + report.priorSetsPreserved, 0);
const totalSets = reports.reduce((sum, report) => sum + report.distinctSets, 0);
assert.equal(priorSetCount, prior.totalSets);
assert.equal(totalSets, priorSetCount + additions.size + baseline.size);
assert.equal(fitting.exclusions, fitting.wick + fitting.vent);
receipt(target, { scratchOnly: edition === 'staged', protocol:PROTOCOL, contentRevision:CONTENT_REVISION, priorSetCount,
  totalSets, alchemistIssuedSetsFirstEnumerated:baseline.size, alchemistReactiveSets:additions.size, reports,
  scope:'Canonical 27-SP purchases. The tracked issued sets plus the first Alchemist census for its issued transformations, General and Reactive Mixtures.' });
console.log(JSON.stringify({ passed:true, totalSets, priorSetCount, alchemistIssuedSetsFirstEnumerated:baseline.size,
  alchemistReactiveSets:additions.size, fitting }));
