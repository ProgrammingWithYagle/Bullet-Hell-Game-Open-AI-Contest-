const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const heading = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);

export function reactionPolicy({ route, arenaFor, segmentRect, segmentCircle, reach, wickReach }) {
  const clear = (map, a, b, pad) => !map.obstacles.some(wall => segmentRect(a, b, wall, pad) !== null);
  const safeStep = (map, a, b) => clear(map, a, b, 13) && map.lavaPits.every(pit =>
    segmentCircle(a, b, pit, pit.radius + 13) === null);
  return (view, player, hostile, chemistry, active, fitting) => {
    const base = route(view, player, hostile);
    const input = { ...base, e: false, q: false };
    if (base.dodge || base.supply >= 0 || player.status !== 'active') return input;
    const { kit } = player, tick = view.combatTick, boss = view.boss;
    const map = arenaFor(view.arenaId, view.run.difficulty);
    const range = distance(player, boss), headingToBoss = heading(player, boss);
    const allowedReach = fitting === 'wick' ? wickReach : reach;
    const ownedBindings = view.classCues.filter(cue => cue.kind === 'alchemy-pool' && cue.recipe === 'binding' && cue.owner === player.id);
    const binding = ownedBindings.filter(cue => distance(cue, boss) <= cue.radius * .67 && distance(player, cue) <= allowedReach - 5 &&
      clear(map, player, cue, 8) && cue.until > tick + 16).sort((a, b) => distance(a, boss) - distance(b, boss))[0];
    if (active && binding && ['aim', 'ready'].includes(kit.alchemyReaction?.stage) && tick + 3 < player.eAt) {
      return { ...input, aim: heading(player, binding), technique1: true, fire: false, ultimate: false, reload: false, sprint: false };
    }
    if ((kit.alchemyBrewUntil ?? 0) > tick) return input;
    const prepared = kit.alchemyPrepared ?? [];
    if (prepared[0] === 'flare' && tick >= player.eAt && range <= reach - 3 && clear(map, player, boss, 8)) {
      if (chemistry.throw(boss)) return input;
    }
    if (prepared[0] === 'binding' && tick >= player.eAt && prepared[1] === 'flare') {
      const castReach = active ? allowedReach - 15 : reach - 15;
      if (range < castReach && clear(map, player, boss, 8) && chemistry.throw(boss)) return input;
      if (range >= castReach && clear(map, player, boss, 8)) {
        const ahead = { x: player.x + Math.cos(headingToBoss) * 32, y: player.y + Math.sin(headingToBoss) * 32 };
        if (safeStep(map, player, ahead)) return { ...input, moveX: Math.cos(headingToBoss), moveY: Math.sin(headingToBoss) };
      }
    }
    if (prepared.length < 2 && prepared[0] !== 'flare') {
      const recipe = prepared.length ? 'flare' : 'binding';
      if (kit.alchemyRecipe !== recipe) chemistry.select(recipe);
      else if (tick >= player.qAt) return { ...input, q: true };
    }
    return input;
  };
}
