import assert from 'node:assert/strict';
import { closeSync, mkdirSync, openSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt } from '../bonded/study-paths.mjs';
import { digest } from '../bonded/run-native.mjs';

const [folder, edition = 'source'] = process.argv.slice(2);
assert(folder && ['source','staged'].includes(edition));
mkdirSync(folder);
const driver = fileURLToPath(new URL('seeded-study.mts',import.meta.url));
const overlay = new URL('overlay-loader.mjs',import.meta.url).href;
const policySha256 = digest(new URL('reaction-policy.mjs',import.meta.url));
const navigationSha256 = digest(new URL('study-navigation.mjs',import.meta.url));
function run(mode,party,subset) {
  const stem = join(folder,[mode,party,subset].join('-'));
  const log = stem + '.log', raw = stem + '.json', fd = openSync(log,'wx');
  const preload = edition === 'staged' ? ['--import',overlay] : [];
  return new Promise((resolve,reject) => {
    const child = spawn(process.execPath,[...preload,'--import','tsx',driver,mode,party,raw,subset,edition],
      { cwd:checkout,stdio:['ignore',fd,fd],windowsHide:true });
    const timer = setTimeout(() => child.kill(),240000);
    child.once('error',failure => { clearTimeout(timer);closeSync(fd);reject(failure); });
    child.once('exit',code => {
      clearTimeout(timer);closeSync(fd);
      if (code) reject(Error(log + ' exited ' + code));
      else if (code === null) reject(Error(log + ' stopped'));
      else resolve({ report:readJson(raw), files:[raw,log].map(file => ({ file:file.split(/[\\/]/).at(-1),sha256:digest(file) })) });
    });
  });
}

const jobs = ['short','standard'].flatMap(mode => ['solo','pair'].map(party => ({mode,party})));
const results = await Promise.all(jobs.map(async ({mode,party}) => {
  const full = await run(mode,party,'full'), replay = await run(mode,party,'replay');
  const { revision, runtimeSourceSha256 } = full.report;
  for (const { report } of [full,replay]) {
    assert.equal(report.protocol,105);
    assert.equal(report.scratchOnly,edition === 'staged');
    assert.equal(report.runtimeSourceSha256,runtimeSourceSha256);
    assert.equal(report.revision,revision);
    assert.equal(report.driverSha256,digest(driver));
    assert.equal(report.policySha256,policySha256);
    assert.equal(report.navigationSha256,navigationSha256);
  }
  assert.equal(full.report.rows.length,18);
  assert.equal(replay.report.rows.length,3);
  for (const row of full.report.rows.filter(row => row.active)) {
    const other = full.report.rows.find(match => !match.active && match.arena === row.arena && match.fitting === row.fitting);
    assert(other && !other.launched.length && !other.landed.length);
    const shared = Math.min(other.purchases.length,row.purchases.length);
    assert.deepEqual(other.purchases.slice(0,shared),row.purchases.slice(0,shared));
    if (other.clears && row.clears) assert.deepEqual(other.purchases,row.purchases);
  }
  for (const row of replay.report.rows) assert.deepEqual(row,full.report.rows.find(match => match.active && match.arena === row.arena && match.fitting === row.fitting));
  const cases = ['entry','wick','vent'].map(fitting => {
    const rows = full.report.rows.filter(row => row.fitting === fitting);
    return { fitting, unusedWins:rows.filter(row => !row.active && row.won).length, activeWins:rows.filter(row => row.active && row.won).length,
      fittingsReached:rows.filter(row => row.active && row.acquired).length, earlyThrows:rows.flatMap(row => row.launched).length,
      earlyLandings:rows.flatMap(row => row.landed).length, damageOnLandingTick:rows.flatMap(row => row.landed).filter(row => row.ownerCreditOnLandingTick > 0).length,
      keptBinding:rows.flatMap(row => row.landed).filter(row => row.retained).length };
  });
  const summary = {mode,party,revision,runtimeSourceSha256,runs:18,exactReplays:3,cases,files:[...full.files,...replay.files]};
  console.log(JSON.stringify(summary));
  return summary;
}));
const rows = results.flatMap(row => row.cases);
const total = key => rows.reduce((n,row) => n + row[key],0);
const summary = { passed:true,scratchOnly:edition === 'staged',matches:72,pairedComparisons:36,exactReplays:12,
  earlyThrows:total('earlyThrows'),earlyLandings:total('earlyLandings'),damageOnLandingTick:total('damageOnLandingTick'),keptBinding:total('keptBinding'),
  policySha256,navigationSha256,driverSha256:digest(driver),results };
for (const fitting of ['entry','wick','vent']) assert(rows.some(row => row.fitting === fitting && row.earlyLandings > 0),fitting);
assert(summary.earlyLandings <= summary.earlyThrows && summary.damageOnLandingTick > 0 && summary.keptBinding > 0);
receipt(join(folder,'study-summary.json'),summary);
