import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { navigationPolicy } from './study-navigation.mjs';
import { reactionPolicy } from './reaction-policy.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { reactiveIds, reactiveRules } = await repoImport('src/shared/alchemist-reactive.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [mode, party, output, subset, edition] = process.argv.slice(2);
assert(PROTOCOL === 105 && ['short', 'standard'].includes(mode) && ['solo', 'pair'].includes(party) && output);
assert(['full','replay','pilot'].includes(subset) && ['source','staged'].includes(edition));
const fittings = ['entry', 'wick', 'vent'] as const;
const worlds = [['gatehouse', 41], ['sunken-chapel', 67], ['ossuary-works', 103]] as const;
const rules = data.rules.alchemy;
const nav = { ordinary: restRaidInput, arenaFor: runtimeArena, segmentRect, segmentCircle, playerRadius:data.rules.playerRadius };
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

function simulate(arena, seed, fitting, active) {
  const game = new Game({ mode, difficulty:'normal', seed, openingArenaId:arena, arenaSelection:'fixed', maxPlayers:party === 'solo' ? 1 : 2 });
  const owner = game.addPlayer('perrin', 'Perrin', 'alchemist');
  const players = party === 'solo' ? [owner] : [owner, game.addPlayer('mara', 'Mara', 'soldier')];
  const route = navigationPolicy(nav), routeAlly = navigationPolicy(nav);
  const choose = reactionPolicy({ route, arenaFor:runtimeArena, segmentRect, segmentCircle, reach:rules.flaskRange, wickReach:reactiveRules.wickRange });
  const chemistry = { select:recipe => game.selectAlchemy(owner.id,recipe), throw:point => game.throwAlchemy(owner.id,point) };
  const hostile = new Map(), purchases = [], launched = [], landed = [];
  const pending = new Map(), trace = createHash('sha256');
  let serial = 0, shop = -1, frames = 0;
  function buy(actor, kind, item) {
    const result = game.transact(actor.id, { id:'reactive-study-' + ++serial, kind, item });
    if (result.ok) purchases.push({ owner:actor.id,kind,item,earned:actor.totalSp,clears:actor.progress.clears });
    return result.ok;
  }
  function outfit(actor) {
    for (const weapon of data.weapons.filter(w => w.classId === actor.classId).sort((a,b) => b.tier - a.tier)) {
      if (actor.weapon === weapon.id || buy(actor,'weapon',weapon.id)) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy(actor,'upgrade',item);
    buy(actor,'supply','medkit');
  }
  assert.equal(owner.totalSp,3);
  assert(buy(owner,'skill','alchemist-mixtures-1') && buy(owner,'skill',reactiveIds.entry));
  if (fitting !== 'entry') assert(!buy(owner,'skill',reactiveIds[fitting]));
  players.forEach(outfit);
  assert(game.start());
  while (!['victory','defeat'].includes(game.phase) && frames++ < 90000) {
    if (game.phase !== 'combat') {
      hostile.clear(); pending.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of players) game.vote(actor.id,1);
      if (game.phase === 'shop' && shop !== game.encounter) {
        shop = game.encounter;
        if (fitting !== 'entry' && owner.totalSp >= 5 && !owner.skills.includes(reactiveIds[fitting])) assert(buy(owner,'skill',reactiveIds[fitting]));
      }
      game.step(); game.drainEvents(); continue;
    }
    const view = viewOf(game,owner.id), shots = [...hostile.values()];
    const eAt = owner.eAt, directBefore = owner.damageDealt;
    const joint = active && owner.skills.includes(reactiveIds[fitting]);
    let tried = false;
    for (const actor of players) {
      const player = view.players.find(p => p.id === actor.id);
      assert(player);
      const control = actor.status !== 'active' ? { interact:true } : actor === owner ? choose(view,player,shots,chemistry,joint,fitting) : routeAlly(view,player,shots);
      const input = { ...idleInput(), ...control, sequence:actor.ack + 1, clientTick:game.combatTick };
      input.aim = Math.atan2(Math.sin(input.aim), Math.cos(input.aim));
      if (actor === owner) tried = input.technique1;
      trace.update(JSON.stringify(input));
      assert(game.submitInput(actor.id,input));
    }
    game.step();
    const batch = game.drainEvents();
    for (const event of batch) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') hostile.set(shot.id,{ ...shot, seenAt:game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) hostile.delete(id);
    }
    const at = game.combatTick;
    if (tried || pending.size) {
      const cues = game.classCues().filter(cue => 'recipe' in cue && cue.owner === owner.id);
      if (tried && owner.eAt > eAt) {
        assert(joint && eAt > at);
        const flight = cues.find(cue => cue.kind === 'alchemy-flask' && cue.recipe === 'flare' && cue.at === at);
        assert(flight);
        assert.equal(flight.until - at, fitting === 'wick' ? reactiveRules.wickFlightTicks : rules.flightTicks);
        const target = view.classCues.find(cue => cue.kind === 'alchemy-pool' && cue.recipe === 'binding' && cue.owner === owner.id &&
          distance(cue,{x:flight.x2,y:flight.y2}) < .01);
        assert(target);
        const row = { at, flight:flight.id, target:target.id, arriving:flight.until, deadline:target.until,
          x:flight.x2, y:flight.y2, eAt, nextE:owner.eAt, boss:view.boss.id };
        launched.push(row); pending.set(flight.id,row);
      }
      for (const [id, row] of pending) if (row.arriving <= at) {
        const pool = cues.find(cue => cue.kind === 'alchemy-pool' && cue.recipe === 'flare' && cue.at === row.arriving && distance(cue,row) < .01);
        if (pool) {
          const retained = cues.some(cue => cue.kind === 'alchemy-pool' && cue.id === row.target && cue.until === row.deadline);
          const reaction = batch.some(event => event.type === 'sound' && event.owner === owner.id && event.id === 'alchemy-react');
          assert.equal(retained, fitting === 'vent');
          assert.equal(reaction, fitting !== 'vent');
          landed.push({ flight:id,tick:at,reportedPool:pool.id,retained,reaction,ownerCreditOnLandingTick:owner.damageDealt-directBefore });
        }
        pending.delete(id);
      }
    }
    trace.update(JSON.stringify([at, game.boss.health, owner.x, owner.y, owner.health, owner.ammo, owner.damageDealt, owner.qAt, owner.eAt, batch]));
  }
  assert(['defeat','victory'].includes(game.phase));
  assert(landed.length <= launched.length);
  if (!active) assert(!launched.length && !landed.length);
  return { arena,seed,fitting,active,won:game.phase === 'victory',clears:owner.progress.clears,acquired:owner.skills.includes(reactiveIds[fitting]),
    purchases,launched,landed,totalDamage:owner.damageDealt,trace:trace.digest('hex') };
}

const rows = [];
for (const [worldIndex,[arena,seed]] of worlds.entries()) for (const [index,fitting] of fittings.entries()) for (const active of [false,true]) {
  if (subset === 'replay' && (!active || worldIndex !== index)) continue;
  if (subset === 'pilot' && worldIndex !== index) continue;
  const row = simulate(arena,seed,fitting,active);
  rows.push(row);
  console.log(JSON.stringify({arena,fitting,active,won:row.won,clears:row.clears,launched:row.launched.length,landed:row.landed.length}));
}
assert.equal(rows.length, subset === 'full' ? 18 : subset === 'replay' ? 3 : 6);
function runtimeFiles(dir) {
  const base = new URL('stage/' + dir + '/',import.meta.url);
  const names = new Map(readdirSync(join(checkout,dir),{withFileTypes:true}).map(row => [row.name,row]));
  if (edition === 'staged' && existsSync(base)) for (const row of readdirSync(base,{withFileTypes:true})) names.set(row.name,row);
  return [...names.values()].flatMap(row => row.isDirectory() ? runtimeFiles(dir + '/' + row.name) : [dir + '/' + row.name]);
}
const source = createHash('sha256');
for (const path of runtimeFiles('src').sort()) {
  const staged = new URL('stage/' + path,import.meta.url);
  const file = edition === 'staged' && existsSync(staged) ? fileURLToPath(staged) : join(checkout,path);
  source.update(path + '\0').update(readFileSync(file));
}
receipt(output, { mode,party,subset,scratchOnly:edition === 'staged',protocol:PROTOCOL,revision:CONTENT_REVISION,runtimeSourceSha256:source.digest('hex'),
  driverSha256:sha256(readFileSync(new URL(import.meta.url))),policySha256:sha256(readFileSync(new URL('reaction-policy.mjs',import.meta.url))),
  navigationSha256:sha256(readFileSync(new URL('study-navigation.mjs',import.meta.url))),rows });
