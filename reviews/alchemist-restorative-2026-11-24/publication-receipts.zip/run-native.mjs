import assert from 'node:assert/strict';
import { existsSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

export const currentDriver = fileURLToPath(new URL('native-alchemist-v2.mts',import.meta.url));
export { digest, runChild };

export function verifyNative(row,{transport,fitting,revision,worker,difficulty}) {
  assert(row.passed && !row.scratchOnly && row.protocol === 107 && row.contentRevision === revision);
  assert.equal(row.transport,transport);
  assert.equal(row.fitting,fitting);
  assert.equal(row.difficulty,difficulty);
  assert.equal(row.driverSha256,digest(currentDriver));
  assert.equal(row.flowSha256,digest(new URL('native-flow-v2.mts',import.meta.url)));
  assert.equal(row.policySha256,digest(join(checkout,'tests/helpers/sniper-rest-raid-policy.ts')));
  assert(row.pauseRejected && row.bought[1].earned === 3);
  if (fitting !== 'entry') assert(row.firstClear === 1 && row.bought[2].earned === 5);
  const outcome = row.result;
  assert(outcome.hit && outcome.positiveCareCue && outcome.healed > 0 && outcome.healthAfter - outcome.healthBefore === outcome.healed);
  assert(outcome.naturalWound.missing > 7 && outcome.naturalWound.health < outcome.naturalWound.maxHealth);
  assert.equal(outcome.flight.until - outcome.flight.at,15);
  assert.equal(outcome.placed.id,outcome.flight.id);
  assert.equal(outcome.placed.at,outcome.flight.until);
  assert.equal(outcome.placed.until - outcome.placed.at,210);
  assert.equal(outcome.placed.uses,fitting === 'shared' ? 2 : 1);
  assert.equal(outcome.remaining,outcome.placed.uses - 1);
  assert.equal(outcome.ownerReceives,transport === 'worker' || fitting === 'quick');
  if (transport === 'worker') {
    assert(row.wholeOptimizedWorker && row.workerPatched === false);
    if (worker) assert.equal(row.workerSha256,worker);
  } else assert(row.peers === 2 && row.witness.joinedNonHost && row.witness.ownerStateStayedPrivate && row.witness.observedPlan);
}

async function testSource(folder,difficulty = 'normal',filter) {
  assert(folder && !existsSync(folder) && ['normal','baby'].includes(difficulty));
  mkdirSync(folder);
  const {sha256:revision} = readJson(join(checkout,'content/revision.json'));
  const keys = ['worker','peer'].flatMap(transport => ['entry','shared','quick'].map(fitting => [transport,fitting]));
  const chosen = filter ? keys.filter(key => filter.split(',').includes(key.join('-'))) : keys;
  assert(chosen.length);
  const cases = await Promise.all(chosen.map(async ([transport,fitting]) => {
    const stem = transport + '-' + fitting, raw = join(folder,stem + '.json'), log = join(folder,stem + '.log');
    const code = await runChild([currentDriver,transport,fitting,raw,'-','testing',difficulty],log,320000);
    const result = existsSync(raw) ? readJson(raw) : undefined;
    let error;
    if (code === 0) {
      try { verifyNative(result,{transport,fitting,revision,difficulty}); }
      catch (failure) { error = String(failure); }
    }
    const row = { transport,fitting,code,error,passed:code === 0 && !error && result?.passed === true,
      logSha256:digest(log), rawSha256:result && digest(raw) };
    console.log(JSON.stringify(row));
    return row;
  }));
  const passed = cases.every(row => row.passed);
  receipt(join(folder,'checks.json'),{passed,difficulty,cases,driver:digest(currentDriver)});
  if (!passed) process.exitCode = 1;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) await testSource(...process.argv.slice(2));
