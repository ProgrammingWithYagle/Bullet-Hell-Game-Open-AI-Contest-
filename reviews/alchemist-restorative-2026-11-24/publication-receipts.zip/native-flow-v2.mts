import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { repoImport } from '../bonded/study-paths.mjs';
import { waitFor } from '../formation/native-flow-v4.mts';
import { navigationPolicy } from '../ranger-whole/navigation-policy.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { restorativeIds, dressingRules } = await repoImport('src/shared/alchemist-restorative.ts');
const recipeRules = data.rules.alchemy;
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
export { waitFor };

const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const heading = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
const offset = (point, direction, travel) => ({ x: point.x + Math.cos(direction) * travel, y: point.y + Math.sin(direction) * travel });
const quiet = (frame, aim = frame.aim) => ({ ...frame, aim, q: false, e: false, ultimate: false, technique1: false, technique2: false, technique3: false,
  fire: false, reload: false, sprint: false });
const move = (frame, aim) => ({ ...frame, moveX: Math.cos(aim), moveY: Math.sin(aim) });
const visible = (map, a, b, pad) => !map.obstacles.some(wall => segmentRect(a, b, wall, pad) !== null);

export async function restorativeFlow(adapter, fitting) {
  const view = () => { const state = adapter.view(); assert(state); return state; };
  const actor = () => { const row = view().players.find(p => p.id === adapter.id); assert(row); return row; };
  const kit = () => actor().kit;
  const controls = navigationPolicy({ ordinary: restRaidInput, arenaFor: runtimeArena, segmentRect, segmentCircle, playerRadius: data.rules.playerRadius });
  const ordinary = () => controls(view(), actor(), [...adapter.observed.values()]);
  const cues = (kind, recipe) => view().classCues.filter(cue => cue.kind === kind && cue.owner === adapter.id && (!recipe || cue.recipe === recipe));
  const purchases = [];
  const owned = () => actor().skills.reduce((cost, id) => cost + [...data.skills, ...data.specializationSkills].find(row => row.id === id).cost, 0);
  const diagnose = () => JSON.stringify({ fitting, boss: view().boss.id, phase: view().phase, tick: view().combatTick,
    eAt: actor().eAt, qAt: actor().qAt, health: actor().health, kit: kit().alchemyDressing, prepared: kit().alchemyPrepared });
  async function buy(id) {
    assert((await adapter.purchase({ kind: 'skill', item: id })).ok, id);
    purchases.push({ item: id, earned: owned() + actor().sp, clears: actor().progress.clears });
  }
  async function outfit() {
    for (const weapon of data.weapons.filter(weapon => weapon.classId === 'alchemist').sort((a, b) => b.tier - a.tier)) {
      if (actor().weapon === weapon.id || (await adapter.purchase({ kind: 'weapon', item: weapon.id })).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) await adapter.purchase({ kind: 'upgrade', item });
    await adapter.purchase({ kind: 'supply', item: 'medkit' });
  }
  assert.equal(actor().sp, 3);
  await buy('alchemist-dyehouse-1');
  await buy(restorativeIds.entry);
  await waitFor(() => !!kit().alchemyDressing, 'owner Action 3 arrived');
  if (fitting !== 'entry') assert(!(await adapter.purchase({ kind: 'skill', item: restorativeIds[fitting] })).ok);
  await outfit();
  adapter.start();
  await waitFor(() => view().phase === 'combat', 'opening combat');
  if (fitting !== 'entry') {
    const deadline = Date.now() + 125_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < deadline && !['defeat', 'victory'].includes(view().phase), diagnose());
      if (view().phase === 'combat') {
        const frame = ordinary();
        adapter.input({ ...quiet(frame), fire: frame.fire === true, reload: frame.reload === true });
        adapter.ally?.(true);
      } else if (['mutationVote', 'contractVote', 'secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(24);
    }
    assert.equal(actor().progress.clears, 1);
    assert.equal(owned() + actor().sp, 5);
    await buy(restorativeIds[fitting]);
    assert.equal((await adapter.purchase({ kind: 'skill', item: restorativeIds[fitting === 'shared' ? 'quick' : 'shared'] })).reason, 'incompatibleItem');
    await outfit();
    await waitFor(() => view().phase === 'combat', 'fitted combat', 90000);
  }
  const firstClear = actor().progress.clears;
  console.log(JSON.stringify({ fitting, firstClear, purchases, boss: view().boss.id }));

  const tick = () => view().combatTick;
  const patient = () => fitting !== 'quick' && adapter.patient ? adapter.patient() : actor();
  const myTreatment = () => patient().id === actor().id;
  const gap = () => patient().maxHealth - patient().health;
  const sameFight = () => view().phase === 'combat' && actor().progress.clears === firstClear && patient().status === 'active';
  const stop = (frame, aim = frame.aim) => ({ ...quiet(frame,aim),moveX:0,moveY:0,dodge:false,supply:-1 });
  async function follow(check,note,command) {
    const cutoff = Date.now() + 76000;
    while (!check()) {
      assert(sameFight() && Date.now() < cutoff,note + ' ' + diagnose());
      const frame = quiet(ordinary());
      adapter.input(command(frame));
      await sleep(22);
    }
  }

  let chosenAt = -Infinity;
  await follow(() => kit().alchemyPrepared?.[0] === 'mending','real Mending prepared',frame => {
    if (!myTreatment()) adapter.movePatient?.(actor());
    if (kit().alchemyRecipe !== 'mending' && chosenAt + 7 <= tick()) { adapter.select('mending'); chosenAt = tick(); }
    return { ...frame, q:kit().alchemyRecipe === 'mending' && tick() >= actor().qAt && !frame.dodge };
  });
  await follow(() => gap() > 7,'a real boss attack wounds the patient',frame => {
    const boss = view().boss, who = patient(), map = runtimeArena(view().arenaId,view().run.difficulty);
    const angle = heading(who,boss), ahead = offset(who,angle,24);
    const walk = distance(who,boss) > 205 && visible(map,who,ahead,14) && map.lavaPits.every(pit => distance(ahead,pit) > pit.radius + 13);
    if (!myTreatment()) {
      adapter.movePatient?.(walk ? ahead : undefined);
      return frame;
    }
    return walk ? move(stop(frame),angle) : stop(frame);
  });
  const naturalWound = { id:patient().id,tick:tick(),missing:gap(),health:patient().health,maxHealth:patient().maxHealth };
  if (!myTreatment()) await follow(() => distance(patient(),actor()) < 110,'the injured teammate walks within aid distance',frame => {
    adapter.movePatient?.(actor());
    return stop(frame);
  });

  let planHeading = 0;
  await follow(() => {
    const state = kit().alchemyDressing, target = state?.targets?.[0];
    if (state?.stage !== 'ready' || !target) return false;
    const who = patient(), p = actor(), map = runtimeArena(view().arenaId,view().run.difficulty);
    return distance(who,target) <= 220 && visible(map,who,target,14) && distance(target,view().boss) >= 115 &&
      map.lavaPits.every(pit => segmentCircle(who,target,pit,pit.radius + 14) === null);
  },'choose a reachable legal dressing position',frame => {
    const p = actor(), angle = heading(view().boss,p);
    const choices = [angle,angle+.68,angle-.68,angle+1.36,angle-1.36,angle+Math.PI];
    planHeading = choices[Math.floor(tick()/5) % choices.length];
    adapter.movePatient?.(myTreatment() ? undefined : actor());
    return stop(frame,Math.atan2(Math.sin(planHeading),Math.cos(planHeading)));
  });
  const position = kit().alchemyDressing.targets[0], aim = heading(actor(),position);
  const witness = await adapter.witness?.({ targets:kit().alchemyDressing.targets });
  const before = { eAt:actor().eAt,ammo:actor().ammo,tick:tick() };
  adapter.input({ technique3:true,aim });
  const findFlight = () => cues('alchemy-flask','mending').find(row => row.at >= before.tick);
  await waitFor(() => !!findFlight(),'real treatment flight');
  const parcel = findFlight();
  assert(parcel && parcel.until - parcel.at === recipeRules.flightTicks);
  assert(actor().eAt > before.eAt && actor().ammo === before.ammo && kit().alchemyPrepared.length === 0);
  const findDressing = () => cues('alchemy-dressing','mending').find(row => row.id === parcel.id);
  await waitFor(() => !!findDressing(),'the placed treatment');
  const placed = findDressing();
  assert(placed && placed.at === parcel.until && placed.until === placed.at + dressingRules.lifeTicks);
  assert.equal(placed.uses,fitting === 'shared' ? 2 : 1);

  adapter.pause(true);
  await waitFor(() => adapter.paused(),'hold time while the dressing is active');
  const pausedAt = tick(), pausedHealth = patient().health;
  adapter.input({ technique3:true,aim });
  await sleep(115);
  assert.equal(tick(),pausedAt);
  assert.equal(patient().health,pausedHealth);
  assert.equal(findDressing()?.until,placed.until);
  adapter.pause(false);
  await waitFor(() => !adapter.paused() && tick() > pausedAt,'resume the active dressing');

  let immediatelyBefore = patient().health;
  const firstEvent = adapter.events.length;
  const consumed = () => (findDressing()?.uses ?? 0) < placed.uses;
  await follow(consumed,'a real injured patient uses a portion',frame => {
    const who = patient();
    assert(tick() < placed.until,'ordinary placement expired before use ' + diagnose());
    immediatelyBefore = who.health;
    const goal = distance(who,placed) > 12 ? placed : undefined;
    if (!myTreatment()) {
      adapter.movePatient?.(goal);
      return stop(frame);
    }
    return goal ? move(stop(frame),heading(who,goal)) : stop(frame);
  });
  const healed = patient().health - immediatelyBefore;
  const credited = () => adapter.events.slice(firstEvent).some(event => event.type === 'sound' && event.id === 'alchemy-ready' && event.owner === adapter.id);
  await waitFor(credited,'positive care emitted by the authority');
  assert(healed > 0 && tick() < placed.until && patient().health <= patient().maxHealth,'real positive healing ' + JSON.stringify({ immediatelyBefore, received:patient().health, healed, ...JSON.parse(diagnose()) }));
  const left = findDressing()?.uses ?? 0;
  assert.equal(left,placed.uses - 1);
  return { passed:true,fitting,firstClear,boss:view().boss.id,bought:purchases,witness,pauseRejected:true,
    result:{ hit:true,healed,positiveCareCue:credited(),healthBefore:immediatelyBefore,healthAfter:immediatelyBefore + healed,naturalWound,ownerReceives:myTreatment(),flight:parcel,placed,remaining:left,readyAt:actor().eAt } };
}
