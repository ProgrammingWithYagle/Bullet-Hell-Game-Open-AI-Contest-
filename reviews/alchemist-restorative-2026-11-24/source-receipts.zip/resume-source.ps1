$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
$OutputEncoding = [Console]::OutputEncoding
$checkout = 'C:\Users\yigal\OneDrive\Documents\ChatGPT\OpenAI Multiplayer Game Contest (Bullet Hell)'
if ((Resolve-Path -LiteralPath '.').Path -cne $checkout) { throw 'Use the canonical checkout.' }

$prior = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-studies01.json') -Raw | ConvertFrom-Json
$edition = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'content01.json') -Raw | ConvertFrom-Json
if ($prior.passed -or $prior.protocol -ne 107 -or $prior.revision -cne $edition.revision) {
  throw 'Only resume the stopped protocol 107 comparison here.'
}
foreach ($case in $prior.outcomes) {
  $log = Join-Path $PSScriptRoot $case.log
  if ((Get-FileHash -LiteralPath $log -Algorithm SHA256).Hash.ToLowerInvariant() -cne $case.logSha256) {
    throw "Preserve the recorded source study $($case.name)."
  }
}
$passed = @($prior.outcomes | Where-Object passed)
$failed = @($prior.outcomes | Where-Object {!$_.passed})
if ($passed.Count -ne 2 -or $failed.Count -ne 1 -or $failed[0].name -cne 'seeded balance comparison' -or
    !(Select-String -LiteralPath (Join-Path $PSScriptRoot $failed[0].log) -Pattern 'standard-pair-full\.log stopped' -Quiet)) {
  throw 'Inspect the original source study before retrying.'
}
$exitFile = Join-Path $PSScriptRoot 'gate01/exit-code.txt'
if ((Get-Content -LiteralPath $exitFile -Raw).Trim() -cne '0') { throw 'The local gate must pass first.' }
$newLog = Join-Path $PSScriptRoot 'seeded02.log'
if (Test-Path -LiteralPath $newLog) { throw 'Preserve the retry evidence before attempting another run.' }
& node (Join-Path $PSScriptRoot 'run-seeded.mjs') (Join-Path $PSScriptRoot 'seeded02') source bounded *> $newLog
if ($LASTEXITCODE) { Get-Content -LiteralPath $newLog -Tail 20; exit $LASTEXITCODE }
& (Join-Path $PSScriptRoot 'publish-source.ps1')
if ($LASTEXITCODE) { exit $LASTEXITCODE }
& (Join-Path $PSScriptRoot 'publish-previews-after-source.ps1')
exit $LASTEXITCODE
