import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { existsSync, readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { navigationPolicy } from './study-navigation.mjs';
import { dressingPolicy } from './dressing-policy.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { restorativeIds, dressingRules } = await repoImport('src/shared/alchemist-restorative.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [mode, party, output, subset, edition] = process.argv.slice(2);
assert(PROTOCOL === (edition === 'staged' ? 106 : 107) && ['short', 'standard'].includes(mode) && ['solo', 'pair'].includes(party) && output);
assert(['full','replay','pilot'].includes(subset) && ['source','staged'].includes(edition));
const fittings = ['entry', 'shared', 'quick'] as const;
const worlds = [['gatehouse', 41], ['sunken-chapel', 67], ['ossuary-works', 103]] as const;
const rules = data.rules.alchemy;
const nav = { ordinary: restRaidInput, arenaFor: runtimeArena, segmentRect, segmentCircle, playerRadius:data.rules.playerRadius };
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

function simulate(arena, seed, fitting, active) {
  const game = new Game({ mode, difficulty:'normal', seed, openingArenaId:arena, arenaSelection:'fixed', maxPlayers:party === 'solo' ? 1 : 2 });
  const owner = game.addPlayer('perrin', 'Perrin', 'alchemist');
  const players = party === 'solo' ? [owner] : [owner, game.addPlayer('mara', 'Mara', 'soldier')];
  const choose = dressingPolicy({ ownerRoute:navigationPolicy(nav),partnerRoute:navigationPolicy(nav),arenaFor:runtimeArena,
    segmentRect,segmentCircle,reach:dressingRules.range });
  const chemistry = { select:recipe => game.selectAlchemy(owner.id,recipe), throw:point => game.throwAlchemy(owner.id,point) };
  const hostile = new Map(), purchases = [], launched = [], packed = [], used = [], recorded = new Set();
  const pending = new Map(), trace = createHash('sha256');
  let serial = 0, shop = -1, frames = 0;
  function buy(actor, kind, item) {
    const result = game.transact(actor.id, { id:'restorative-study-' + ++serial, kind, item });
    if (result.ok) purchases.push({ owner:actor.id,kind,item,earned:actor.totalSp,clears:actor.progress.clears });
    return result.ok;
  }
  function outfit(actor) {
    for (const weapon of data.weapons.filter(w => w.classId === actor.classId).sort((a,b) => b.tier - a.tier)) {
      if (actor.weapon === weapon.id || buy(actor,'weapon',weapon.id)) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy(actor,'upgrade',item);
    buy(actor,'supply','medkit');
  }
  assert.equal(owner.totalSp,3);
  assert(buy(owner,'skill','alchemist-dyehouse-1') && buy(owner,'skill',restorativeIds.entry));
  if (fitting !== 'entry') assert(!buy(owner,'skill',restorativeIds[fitting]));
  players.forEach(outfit);
  assert(game.start());
  while (!['victory','defeat'].includes(game.phase) && frames++ < 90000) {
    if (game.phase !== 'combat') {
      hostile.clear(); pending.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of players) game.vote(actor.id,1);
      if (game.phase === 'shop' && shop !== game.encounter) {
        shop = game.encounter;
        if (fitting !== 'entry' && owner.totalSp >= 5 && !owner.skills.includes(restorativeIds[fitting])) assert(buy(owner,'skill',restorativeIds[fitting]));
      }
      game.step(); game.drainEvents(); continue;
    }
    const view = viewOf(game,owner.id), shots = [...hostile.values()];
    const eAt = owner.eAt, healedBefore = owner.healing, retained = view.classCues.filter(cue => cue.kind === 'alchemy-dressing' && cue.owner === owner.id);
    const joint = active && owner.skills.includes(restorativeIds[fitting]);
    let tried = false;
    for (const actor of players) {
      const player = view.players.find(p => p.id === actor.id);
      assert(player);
      const control = actor.status !== 'active' ? { interact:true } : choose(view,player,owner,shots,chemistry,joint,fitting);
      const input = { ...idleInput(), ...control, sequence:actor.ack + 1, clientTick:game.combatTick };
      input.aim = Math.atan2(Math.sin(input.aim), Math.cos(input.aim));
      if (actor === owner) tried = input.technique3;
      trace.update(JSON.stringify(input));
      assert(game.submitInput(actor.id,input));
    }
    game.step();
    const batch = game.drainEvents();
    for (const event of batch) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') hostile.set(shot.id,{ ...shot, seenAt:game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) hostile.delete(id);
    }
    const at = game.combatTick;
    if (tried || pending.size || retained.length) {
      const cues = game.classCues().filter(cue => 'recipe' in cue && cue.owner === owner.id);
      if (tried && owner.eAt > eAt) {
        assert(joint && eAt < at);
        const flight = cues.find(cue => cue.kind === 'alchemy-flask' && cue.recipe === 'mending' && cue.at === at);
        assert(flight && flight.until - at === rules.flightTicks);
        launched.push({at,boss:view.boss.id,flight:flight.id,due:flight.until,eAt:owner.eAt});
        pending.set(flight.id,flight);
      }
      const fields = cues.filter(cue => cue.kind === 'alchemy-dressing');
      for (const field of fields) if (!recorded.has(field.id)) {
        assert(joint && field.until - field.at === dressingRules.lifeTicks && field.uses === (fitting === 'shared' ? 2 : 1));
        assert(pending.has(field.id) && pending.get(field.id).until === field.at);
        packed.push({id:field.id,at:field.at,until:field.until,uses:field.uses,boss:view.boss.id});
        recorded.add(field.id);
      }
      if (owner.healing > healedBefore) for (const field of retained) {
        if (field.until <= at) continue;
        const remaining = fields.find(now => now.id === field.id)?.uses ?? 0;
        if (remaining >= field.uses) continue;
        assert(recorded.has(field.id) && remaining === field.uses - 1);
        used.push({id:field.id,at,remaining,healing:owner.healing-healedBefore,boss:view.boss.id});
      }
      for (const [id,flight] of pending) if (at >= flight.until) pending.delete(id);
    }
    trace.update(JSON.stringify([at, game.boss.health, owner.x, owner.y, owner.health, owner.ammo, owner.damageDealt, owner.healing, owner.qAt, owner.eAt, batch]));
  }
  assert(['defeat','victory'].includes(game.phase));
  assert(packed.length <= launched.length && used.length <= packed.reduce((n,row) => n + row.uses,0));
  if (!active) assert(!launched.length && !packed.length && !used.length);
  return { arena,seed,fitting,active,won:game.phase === 'victory',clears:owner.progress.clears,acquired:owner.skills.includes(restorativeIds[fitting]),
    purchases,launched,packed,used,totalHealing:owner.healing,trace:trace.digest('hex') };
}

const rows = [];
for (const [worldIndex,[arena,seed]] of worlds.entries()) for (const [index,fitting] of fittings.entries()) for (const active of [false,true]) {
  if (subset === 'replay' && (!active || worldIndex !== index)) continue;
  if (subset === 'pilot' && worldIndex !== index) continue;
  const row = simulate(arena,seed,fitting,active);
  rows.push(row);
  console.log(JSON.stringify({arena,fitting,active,won:row.won,clears:row.clears,launched:row.launched.length,placed:row.packed.length,used:row.used.length}));
}
assert.equal(rows.length, subset === 'full' ? 18 : subset === 'replay' ? 3 : 6);
function runtimeFiles(dir) {
  const base = new URL('stage/' + dir + '/',import.meta.url);
  const names = new Map(readdirSync(join(checkout,dir),{withFileTypes:true}).map(row => [row.name,row]));
  if (edition === 'staged') for (const layer of [...['../alchemist-reactive/stage/','../alchemist-prepared/stage/',
      '../alchemist-prepared/content-pilot/'].map(path => new URL(path + dir + '/',import.meta.url)),base]) {
    if (existsSync(layer)) for (const row of readdirSync(layer,{withFileTypes:true})) names.set(row.name,row);
  }
  return [...names.values()].flatMap(row => row.isDirectory() ? runtimeFiles(dir + '/' + row.name) : [dir + '/' + row.name]);
}
const source = createHash('sha256');
for (const path of runtimeFiles('src').sort()) {
  const staged = new URL('stage/' + path,import.meta.url);
  const layers = ['../alchemist-prepared/content-pilot/','../alchemist-prepared/stage/','../alchemist-reactive/stage/'];
  const alternate = edition === 'staged' ? [staged,...layers.map(root => new URL(root + path,import.meta.url))].find(existsSync) : undefined;
  const file = alternate ? fileURLToPath(alternate) : join(checkout,path);
  source.update(path + '\0').update(readFileSync(file));
}
receipt(output, { mode,party,subset,scratchOnly:edition === 'staged',protocol:PROTOCOL,revision:CONTENT_REVISION,runtimeSourceSha256:source.digest('hex'),
  driverSha256:sha256(readFileSync(new URL(import.meta.url))),policySha256:sha256(readFileSync(new URL('dressing-policy.mjs',import.meta.url))),
  navigationSha256:sha256(readFileSync(new URL('study-navigation.mjs',import.meta.url))),rows });
