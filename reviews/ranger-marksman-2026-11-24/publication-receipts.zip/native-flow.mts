import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { repoImport } from '../bonded/study-paths.mjs';
import { waitFor } from '../formation/native-flow-v4.mts';
import { normalizedAim, standing } from '../formation/formation-policy.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { rangerSightIds, rangerSightRules } = await repoImport('src/shared/ranger-sight.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
export { waitFor };

export async function rangerFlow(adapter, fitting) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const player = view().players.find(row => row.id === adapter.id); assert(player); return player; };
  const status = () => owner().kit.rangerSight;
  const cue = () => view().classCues.find(row => row.kind === 'ranger-sight' && row.owner === adapter.id);
  const ownedCost = () => owner().skills.reduce((sum,id)=>sum+[...data.skills,...data.specializationSkills].find(node=>node.id===id).cost,0);
  const ordinary = () => restRaidInput(view(),owner(),[...adapter.observed.values()]);
  const bought = [], attempts = [];
  const diagnostic = () => JSON.stringify({ fitting,phase:view().phase,boss:view().boss.id,tick:view().combatTick,health:owner().health,ammo:owner().ammo,status:status(),attempts:attempts.slice(-4) });
  async function buy(item) {
    assert((await adapter.purchase({kind:'skill',item})).ok,item);
    bought.push({ item,earned:ownedCost()+owner().sp,clears:owner().progress.clears });
  }
  async function outfit() {
    for (const bow of data.weapons.filter(row=>row.classId==='ranger').sort((a,b)=>b.tier-a.tier)) {
      if (owner().weapon===bow.id || (await adapter.purchase({kind:'weapon',item:bow.id})).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({kind:'upgrade',item});
    await adapter.purchase({kind:'supply',item:'medkit'});
  }
  assert.equal(owner().sp,3);
  await buy('ranger-bowcraft-1');
  await buy(rangerSightIds.entry);
  await waitFor(()=>!!status(),'owner receives Sight Draw state');
  if (fitting!=='entry') assert(!(await adapter.purchase({kind:'skill',item:rangerSightIds[fitting]})).ok);
  await outfit();
  adapter.start();
  await waitFor(()=>view().phase==='combat','opening combat');
  if (fitting!=='entry') {
    const end=Date.now()+135000;
    while(view().phase!=='shop') {
      assert(Date.now()<end && !['victory','defeat'].includes(view().phase),diagnostic());
      if(view().phase==='combat') { adapter.input(ordinary()); adapter.ally?.(true); }
      if(['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(ownedCost()+owner().sp,5);
    await buy(rangerSightIds[fitting]);
    assert.equal((await adapter.purchase({kind:'skill',item:rangerSightIds[fitting==='roll'?'bearing':'roll']})).reason,'incompatibleItem');
    await outfit();
    await waitFor(()=>view().phase==='combat','next fight',90000);
  }
  const firstClear=owner().progress.clears;
  console.log(JSON.stringify({type:'earned purchase',fitting,firstClear,bought,boss:view().boss.id}));

  adapter.pause(true);
  await waitFor(()=>adapter.paused(),'pause acknowledged');
  const pausedAt=view().combatTick, pausedAmmo=owner().ammo;
  adapter.input({technique1:true});
  await sleep(120);
  assert.equal(view().combatTick,pausedAt);
  assert.equal(owner().ammo,pausedAmmo);
  assert(!cue());
  adapter.input({});
  adapter.pause(false);
  await waitFor(()=>!adapter.paused() && view().combatTick>pausedAt,'resumed');

  const timeLimit=Date.now()+105000;
  while(Date.now()<timeLimit && !['defeat','victory'].includes(view().phase)) {
    if(view().phase!=='combat') {
      if(['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(45);
      continue;
    }
    const ctrl=ordinary(), p=owner(), world=runtimeArena(view().arenaId,view().run.difficulty);
    const enemy=view().boss;
    const heading=()=>Math.atan2(view().boss.y-owner().y,view().boss.x-owner().x);
    const blocked=Math.hypot(enemy.x-p.x,enemy.y-p.y)>635 || world.obstacles.some(wall=>segmentRect(p,enemy,wall,4));
    if(owner().ammo===0 || status()?.stage!=='ready' || view().combatTick<p.dashUntil || blocked ||
      fitting==='roll' && (p.dodgeAt>view().combatTick || p.stamina<24)) {
      adapter.input(ctrl);
      adapter.ally?.(true);
      await sleep(25);
      continue;
    }
    const x=p.x,y=p.y,pre=heading();
    const side=attempts.length%2===0?1:-1;
    const offset=fitting==='bearing'?side*Math.PI/3:0;
    const aim=normalizedAim(pre+offset);
    const escape=[pre+Math.PI+side*.03,pre+side*.03].find(angle=>{
      const landing={x:x+Math.cos(angle)*150,y:y+Math.sin(angle)*150};
      const range=Math.hypot(enemy.x-landing.x,enemy.y-landing.y);
      return range>105 && range<640 && !world.obstacles.some(wall=>segmentRect(p,landing,wall,19)) &&
        !world.lavaPits.some(pit=>segmentCircle(p,landing,pit,pit.radius+19)!==null);
    });
    if(fitting==='roll' && escape===undefined) {
      adapter.input(ctrl);
      await sleep(24);
      continue;
    }
    adapter.ally?.(false);
    const quiet={...standing(ctrl),aim};
    const first=adapter.input(quiet);
    await waitFor(()=>owner().ack>=first || view().phase!=='combat',diagnostic);
    if(status()?.stage!=='ready') continue;
    const arrows=owner().ammo;
    const start=adapter.input({...quiet,technique1:true});
    await waitFor(()=>owner().ack>=start || view().phase!=='combat',diagnostic);
    adapter.input(quiet);
    const primed=cue();
    if(!primed) continue;
    assert.equal(owner().ammo,arrows-1);
    assert.equal(primed.until-primed.at,rangerSightRules.duration);
    await waitFor(()=>!cue() || status()?.stage==='release',diagnostic);
    if(!cue()) continue;
    const held=cue();
    let shifted, dodgeDistance=0;
    if(fitting==='bearing') {
      const target=heading();
      const adjust=adapter.input({...quiet,aim:target,technique1:true});
      await waitFor(()=>owner().ack>=adjust || !cue(),diagnostic);
      adapter.input({...quiet,aim:target});
      shifted=cue();
      if(!shifted || Math.abs(normalizedAim(shifted.aim-held.aim))<rangerSightRules.halfArc || shifted.readyAt<=held.readyAt) {
        attempts.push({id:held.id,reason:'new bearing missed',aim:held.aim});
        continue;
      }
      await waitFor(()=>!cue() || status()?.stage==='release',diagnostic);
    } else if(fitting==='roll') {
      const origin=owner();
      const dodge=adapter.input({...quiet,dodge:true,moveX:Math.cos(escape!),moveY:Math.sin(escape!)});
      await waitFor(()=>owner().ack>=dodge || !cue(),diagnostic);
      shifted=cue();
      adapter.input(quiet);
      if(!shifted || status()?.stage!=='rolling') { attempts.push({id:held.id,reason:'roll missed'}); continue; }
      await waitFor(()=>!cue() || status()?.stage==='release',diagnostic);
      dodgeDistance=Math.hypot(owner().x-origin.x,owner().y-origin.y);
      assert(dodgeDistance>18);
    }
    const ready=cue();
    if(!ready || status()?.stage!=='release') continue;
    assert.equal(ready.id,held.id);
    assert.equal(ready.until,held.until);
    const direction=heading();
    if(Math.abs(normalizedAim(direction-ready.aim))>rangerSightRules.halfArc*.93) {
      attempts.push({id:held.id,reason:'boss left the held arc',aim:ready.aim,direction});
      continue;
    }
    const hp=view().boss.health, from={x:owner().x,y:owner().y}, eventStart=adapter.events.length;
    const release=adapter.input({...quiet,aim:direction,technique1:true});
    await waitFor(()=>owner().ack>=release || view().phase!=='combat',diagnostic);
    adapter.input({...quiet,aim:direction});
    await waitFor(()=>adapter.events.slice(eventStart).some(event=>event.type==='sound' && event.owner===adapter.id && event.id==='ranger-sight-release') || view().phase!=='combat',diagnostic);
    const chosen=adapter.events.slice(eventStart).flatMap(event=>event.type==='shots'?event.shots:[]).find(shot=>shot.owner===adapter.id &&
      Math.hypot(shot.x-from.x,shot.y-from.y)<12 && Math.abs(Math.hypot(shot.vx,shot.vy)-rangerSightRules.speed)<1);
    assert(chosen && chosen.pierce===0);
    assert.equal(owner().ammo,arrows-1);
    const witness=await adapter.witness?.(held);
    const hitLimit=Date.now()+1350;
    while(Date.now()<hitLimit && view().phase==='combat' && view().boss.health>=hp) await sleep(20);
    const hit=view().boss.health<hp;
    if(!hit) { attempts.push({id:held.id,reason:'arrow missed the boss',shot:chosen.id}); continue; }
    return {passed:true,firstClear,bought,fitting,pauseRejected:true,boss:view().boss.id,attempts,
      result:{arrowCost:1,held,shifted,shot:{id:chosen.id,x:chosen.x,y:chosen.y},dodgeDistance,hit,witness}};
  }
  throw Error('Sight Draw did not reach a fitted release: '+diagnostic());
}
