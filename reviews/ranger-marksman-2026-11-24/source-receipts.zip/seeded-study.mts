import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { sightPolicy } from './sight-policy.mjs';

const { Game, data }=await repoImport('src/shared/game.ts');
const { viewOf }=await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput }=await repoImport('src/shared/protocol.ts');
const { rangerSightIds, rangerSightRules }=await repoImport('src/shared/ranger-sight.ts');
const { runtimeArena }=await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle }=await repoImport('src/shared/geometry.ts');
const { restRaidInput }=await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [mode,party,output,replay]=process.argv.slice(2);
assert(PROTOCOL===102 && ['short','standard'].includes(mode) && ['solo','pair'].includes(party) && output);
const archetypes=['entry','roll','bearing'] as const;
const worlds=[['gatehouse',41],['sunken-chapel',67],['ossuary-works',103]] as const;
const choose=sightPolicy({ordinary:restRaidInput,arenaFor:runtimeArena,segmentRect,segmentCircle,rules:rangerSightRules});

function simulate(arena,seed,fitting,active) {
  const game=new Game({mode,difficulty:'normal',seed,openingArenaId:arena,arenaSelection:'fixed',maxPlayers:party==='solo'?1:2});
  const owner=game.addPlayer('nela','Nela','ranger');
  const partyMembers=party==='solo'?[owner]:[owner,game.addPlayer('mara','Mara','soldier')];
  const observed=new Map(), shotOwners=new Map(), impacts=[];
  const purchases=[], events=[];
  const trace=createHash('sha256');
  let serial=0, shop=-1, frames=0;
  const realCollision=game.friendlyCollision.bind(game);
  game.friendlyCollision=(shot,...args)=>{
    const before=owner.damageDealt;
    const result=realCollision(shot,...args);
    if(shot.owner===owner.id && owner.damageDealt>before && Math.abs(Math.hypot(shot.vx,shot.vy)-rangerSightRules.speed)<.001) {
      impacts.push({id:shot.id,tick:game.combatTick,amount:owner.damageDealt-before});
    }
    return result;
  };
  function buy(actor,kind,item) {
    const result=game.transact(actor.id,{id:'sight-study-'+ ++serial,kind,item});
    if(result.ok)purchases.push({owner:actor.id,kind,item,earned:actor.totalSp,clears:actor.progress.clears});
    return result.ok;
  }
  function outfit(actor) {
    for(const weapon of data.weapons.filter(w=>w.classId===actor.classId).sort((a,b)=>b.tier-a.tier)) {
      if(actor.weapon===weapon.id || buy(actor,'weapon',weapon.id))break;
    }
    for(const item of ['damage','health','fire-rate','reload','magazine'])buy(actor,'upgrade',item);
    buy(actor,'supply','medkit');
  }
  assert.equal(owner.totalSp,3);
  assert(buy(owner,'skill','ranger-bowcraft-1') && buy(owner,'skill',rangerSightIds.entry));
  if(fitting!=='entry')assert(!buy(owner,'skill',rangerSightIds[fitting]));
  partyMembers.forEach(outfit);
  assert(game.start());

  while(!['victory','defeat'].includes(game.phase) && frames++<90000) {
    if(game.phase!=='combat') {
      observed.clear();
      if(['mutationVote','contractVote','secretOffer'].includes(game.phase))for(const p of partyMembers)game.vote(p.id,0);
      if(game.phase==='shop' && game.encounter!==shop) {
        shop=game.encounter;
        if(fitting!=='entry' && owner.totalSp>=5 && !owner.skills.includes(rangerSightIds[fitting])) {
          assert(buy(owner,'skill',rangerSightIds[fitting]));
          assert(owner.progress.clears>=1);
        }
      }
      game.step();game.drainEvents();continue;
    }
    const view=viewOf(game,owner.id), hostile=[...observed.values()];
    const fitted=owner.skills.includes(rangerSightIds[fitting]);
    const enabled=active&&fitted;
    for(const actor of partyMembers) {
      const p=view.players.find(row=>row.id===actor.id);
      assert(p);
      const control=actor.status!=='active'?{interact:true}:actor===owner?choose(view,p,hostile,enabled):restRaidInput(view,p,hostile);
      const input={...idleInput(),...control,sequence:actor.ack+1,clientTick:game.combatTick};
      input.aim=Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      assert(game.submitInput(actor.id,input));
    }
    game.step();
    const batch=game.drainEvents();
    const released=batch.some(event=>event.type==='sound' && event.id==='ranger-sight-release' && event.owner===owner.id);
    for(const event of batch) {
      if(event.type==='shots')for(const shot of event.shots) {
        if(shot.owner==='hostile')observed.set(shot.id,{...shot,seenAt:game.combatTick});
        if(released&&shot.owner===owner.id&&Math.abs(Math.hypot(shot.vx,shot.vy)-rangerSightRules.speed)<.001)shotOwners.set(shot.id,game.combatTick);
      }
      if(event.type==='remove')for(const id of event.ids)observed.delete(id);
      if(event.type==='sound'&&event.owner===owner.id&&event.id.startsWith('ranger-sight-')) {
        assert(enabled);
        events.push({id:event.id,tick:game.combatTick,boss:view.boss.id,clears:owner.progress.clears});
      }
    }
    trace.update(JSON.stringify([game.combatTick,game.boss.health,owner.x,owner.y,owner.health,owner.ammo,owner.damageDealt,game.kitStatus(owner.id).rangerSight]));
  }
  assert(['defeat','victory'].includes(game.phase));
  const hits=impacts.filter(row=>shotOwners.has(row.id)&&row.tick>=shotOwners.get(row.id));
  return { arena,seed,fitting,active,won:game.phase==='victory',clears:owner.progress.clears,acquired:owner.skills.includes(rangerSightIds[fitting]),
    purchases,events,hits,arrows:[...shotOwners.keys()],trace:trace.digest('hex') };
}

const rows=[];
for(const [index,[arena,seed]] of worlds.entries())for(const [kind,fitting] of archetypes.entries())for(const active of [false,true]) {
  if(replay&&(!active||index!==kind))continue;
  const row=simulate(arena,seed,fitting,active);
  rows.push(row);
  console.log(JSON.stringify({arena,fitting,active,won:row.won,clears:row.clears,arrows:row.arrows.length,hits:row.hits.length}));
}
assert.equal(rows.length,replay?3:18);
function sourceFiles(dir) {
  return readdirSync(join(checkout,dir),{withFileTypes:true}).flatMap(row=>{
    const path=dir+'/'+row.name;
    return row.isDirectory()?sourceFiles(path):[path];
  });
}
const hash=createHash('sha256');
for(const path of sourceFiles('src').sort())hash.update(path+'\0').update(readFileSync(join(checkout,path)));
receipt(output,{protocol:PROTOCOL,revision:CONTENT_REVISION,runtimeSourceSha256:hash.digest('hex'),mode,party,replay:!!replay,
  driverSha256:sha256(readFileSync(new URL(import.meta.url))),policySha256:sha256(readFileSync(new URL('./sight-policy.mjs',import.meta.url))),rows});
