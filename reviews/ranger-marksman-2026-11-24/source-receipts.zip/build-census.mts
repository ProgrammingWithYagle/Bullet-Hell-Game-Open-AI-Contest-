import assert from 'node:assert/strict';
import { join } from 'node:path';
import { checkout, readJson, receipt, repoImport } from '../bonded/study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION } = await repoImport('src/shared/protocol.ts');
const { conflictingSkill } = await repoImport('src/shared/skill-conflicts.ts');
const { rangerSightIds } = await repoImport('src/shared/ranger-sight.ts');
const target = process.argv[2];
assert(target && PROTOCOL === 102);
const issued = readJson(join(checkout,'reviews/summoner-formation-2026-11-23/build-census.json'));
assert.equal(issued.totalSets,27980);
const skills = new Map([...data.skills,...data.generalSkills,...data.specializationSkills].map(skill=>[skill.id,skill]));
const transforms = data.skills.filter(skill=>skill.classId==='ranger' && skill.transform);
const techniques = data.specializationSkills.filter(skill=>skill.classId==='ranger');
assert.equal(transforms.length,3);
assert.equal(techniques.length,3);
const significant = new Set([...techniques,...transforms,...data.generalSkills].map(skill=>skill.id));
const ordered = new Set<string>();
function prerequisites(id: string) {
  const item = skills.get(id);
  assert(item);
  if (item.prerequisite && !ordered.has(item.prerequisite)) prerequisites(item.prerequisite);
  ordered.add(id);
}
for (const id of significant) prerequisites(id);
const choices = [...ordered];
const results = new Map();
const acquired: string[] = [];
function walk(index: number, spent: number, capstones: number) {
  if (index === choices.length) {
    if (!acquired.includes(rangerSightIds.entry)) return;
    const signature = acquired.filter(id=>significant.has(id)).sort().join('|');
    if (!results.has(signature) || results.get(signature).spent>spent) {
      results.set(signature,{ skills:[...acquired],spent,remaining:27-spent,capstones,operationAndSharedSignature:signature });
    }
    return;
  }
  const id=choices[index], node=skills.get(id)!;
  walk(index+1,spent,capstones);
  if (spent+node.cost>27 || Number(node.freePlaySpRequired ?? 0)>27 || node.capstone && capstones ||
    node.prerequisite && !acquired.includes(node.prerequisite) || conflictingSkill(acquired,id)) return;
  acquired.push(id);
  walk(index+1,spent+node.cost,capstones+Number(node.capstone));
  acquired.pop();
}
walk(0,0,0);

const reports = [...issued.reports,{classId:'ranger',techniques:techniques.length,distinctSets:0,builds:[...results.values()]}].map(report=>{
  let purchases=0, exclusions=0;
  for (const row of report.builds) {
    const game = new Game({mode:'endless',seed:41,maxPlayers:1});
    game.encounter=9;
    const actor = game.addPlayer('solo','Build census',report.classId);
    assert.equal(actor.totalSp,27);
    for (const item of row.skills) assert(game.transact(actor.id,{id:'buy-'+ ++purchases,kind:'skill',item}).ok,item);
    assert.deepEqual(actor.skills,row.skills);
    assert.equal(actor.skills.reduce((cost,id)=>cost+game.skillCost(id),0),row.spent);
    if (report.classId !== 'ranger') continue;
    assert(game.kitStatus(actor.id).rangerSight);
    const excluded = actor.skills.includes(rangerSightIds.roll) ? rangerSightIds.bearing :
      actor.skills.includes(rangerSightIds.bearing) ? rangerSightIds.roll : undefined;
    if (excluded) {
      assert.equal(game.transact(actor.id,{id:'excluded',kind:'skill',item:excluded}).reason,'incompatibleItem');
      assert(!actor.skills.includes(excluded));
      exclusions++;
    }
  }
  const fitting = report.classId==='ranger' ? {
    roll:report.builds.filter(row=>row.skills.includes(rangerSightIds.roll)).length,
    bearing:report.builds.filter(row=>row.skills.includes(rangerSightIds.bearing)).length,
    transformations:Object.fromEntries(transforms.map(skill=>[skill.transform,report.builds.filter(row=>row.skills.includes(skill.id)).length])), exclusions,
  } : report.fitting;
  return { ...report,fitting,purchases,distinctSets:report.builds.length,priorSetsPreserved:report.distinctSets };
});
const preserved = reports.reduce((count,report)=>count+report.priorSetsPreserved,0);
assert.equal(preserved,issued.totalSets);
const ranger = reports.find(report=>report.classId==='ranger');
assert(ranger.fitting.roll > 0 && ranger.fitting.roll === ranger.fitting.bearing);
assert(Object.values(ranger.fitting.transformations).every(value=>value>0));
const total = reports.reduce((count,report)=>count+report.distinctSets,0);
receipt(target,{ protocol:PROTOCOL,contentRevision:CONTENT_REVISION,priorSetCount:preserved,totalSets:total,reports,
  scope:'Canonical 27-SP purchases. The tracked issued sets and Ranger Marksman combinations with General and the three Ranger transformations.' });
console.log(JSON.stringify({passed:true,total,preserved,ranger:ranger.distinctSets,fittings:ranger.fitting}));
