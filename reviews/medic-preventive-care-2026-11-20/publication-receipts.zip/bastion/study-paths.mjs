import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, writeFileSync } from 'node:fs';
import { isAbsolute, join } from 'node:path';
import { pathToFileURL } from 'node:url';

export const checkout = process.env.GRAVE_ACCORD_CHECKOUT ??
  'C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)';
export const priorStudy = process.env.GRAVE_ACCORD_BASTION_HANDOFF ??
  'C:/Users/yigal/Documents/Codex/2026-11-10/continue-grave-accord-in-the-same/work/tank-bastion-stage';

export const readJson = path => JSON.parse(readFileSync(path, 'utf8'));
export const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
export const repoImport = path => import(pathToFileURL(join(checkout, path)).href);
export const priorImport = path => import(pathToFileURL(join(priorStudy, path)).href);
export const receipt = (path, evidence) => writeFileSync(path, JSON.stringify(evidence, null, 2) + '\n', { flag: 'wx' });

export async function verifiedBundle(name, expected) {
  const path = isAbsolute(name) ? name : join(priorStudy, name);
  assert.equal(sha256(readFileSync(path)), expected, name);
  return import(pathToFileURL(path).href);
}
