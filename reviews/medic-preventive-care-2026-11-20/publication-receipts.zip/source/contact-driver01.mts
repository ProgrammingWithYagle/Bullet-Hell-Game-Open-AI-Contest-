import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL, idleInput, HZ } = await repoImport('src/shared/protocol.ts');
const { preventiveCareIds, precautionRules } = await repoImport('src/shared/medic-preventive-care.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect } = await repoImport('src/shared/geometry.ts');
const args = process.argv.slice(2);
const [transport, fitting, out, supplied, testAudience = 'public'] = args;
assert(PROTOCOL === 86 && ['worker', 'peer'].includes(transport) && ['entry', 'doorstep', 'layered'].includes(fitting) && out);
const setup = { mode: 'short', difficulty: 'baby', arenaSelection: 'fixed', openingArenaId: 'gatehouse' } as const;
const spending = p => p.skills.reduce((sum, id) => sum + [...data.specializationSkills, ...data.skills].find(node => node.id === id).cost, 0);
const point = p => ({ x: p.x, y: p.y });
const angle = (from, to) => Math.atan2(to.y - from.y, to.x - from.x);
const closeHealth = (view, id) => view?.players.find(player => player.id === id);

async function wait(truth, why, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, why);
    await sleep(8);
  }
}
function pilotState() {
  return { events: [], observed: new Map(), cues: new Map() };
}
function recordCues(cues, view) {
  for (const cue of view.classCues) {
    if (cue.kind.startsWith('medic-precaution-')) cues.set(cue.kind + ':' + cue.id, cue);
  }
}
const straight = (from, direction, amount) => ({ x: from.x + Math.cos(direction) * amount, y: from.y + Math.sin(direction) * amount });
function heading(view, from, goal, reach = 0) {
  if (distance(from, goal) <= reach) return {};
  const toward = angle(from, goal), world = bulwarkTrialWorld(view);
  const lengths = Math.min(distance(from, goal), 25);
  const course = [0, .40, -.40, .80, -.80, 1.25, -1.25, 1.8, -1.8, 2.5, -2.5, Math.PI]
    .map(offset => toward + offset)
    .map(aim => ({ aim, end: straight(from, aim, lengths) }))
    .filter(({ end }) => clearTrialWalk(world, from, end))
    .sort((a,b) => distance(a.end,goal) - distance(b.end,goal))[0];
  return course ? { moveX: Math.cos(course.aim), moveY: Math.sin(course.aim) } : {};
}

function findProjectile(view, patient, observed) {
  const now = view.combatTick, world = bulwarkTrialWorld(view);
  const viable = [];
  for (const shot of observed.values()) {
    if (shot.owner !== 'hostile' || shot.expires <= now + 3 || distance(shot, patient) > 500) continue;
    const seconds = Math.max(0, now - shot.seenAt) / HZ;
    const from = { x: shot.x + shot.vx * seconds, y: shot.y + shot.vy * seconds };
    for (const steps of [3, 6, 9, 12, 16, 20]) {
      if (shot.expires < now + steps) break;
      const end = { x: from.x + shot.vx * steps / HZ, y: from.y + shot.vy * steps / HZ };
      const reach = distance(patient, end);
      if (reach > 9 + patient.speed * steps / HZ ||
          !clearTrialWalk(world, patient, end) ||
          world.obstacles.some(wall => segmentRect(from, end, wall, shot.radius))) continue;
      viable.push({ id: shot.id, point: end, at: now + steps, score: reach + steps * 1.9 });
      break;
    }
  }
  return viable.sort((a,b) => a.score - b.score)[0];
}
function findSeam(view, patient, touched) {
  const world = bulwarkTrialWorld(view);
  return view.bossCues.filter(cue => cue.kind === 'stitch-seam' && !cue.disabled && !touched.has(cue.id) &&
    cue.until > view.combatTick + 5 && cue.at <= view.combatTick + 42)
    .flatMap(cue => {
      const dx = cue.x2 - cue.x1, dy = cue.y2 - cue.y1;
      const target = Math.max(.1,Math.min(.90,((patient.x - cue.x1) * dx + (patient.y - cue.y1) * dy) / (dx * dx + dy * dy)));
      return [target,.25,.5,.75].map(ratio => ({ cue, goal: { x: cue.x1 + dx * ratio, y: cue.y1 + dy * ratio } }));
    }).filter(({ goal }) => Number.isFinite(goal.x) && distance(patient,goal) < 135 && clearTrialWalk(world,patient,goal))
    .sort((a,b) => distance(patient,a.goal) - distance(patient,b.goal))[0];
}
function hunt(view, patient, observed, seam) {
  if (seam) return heading(view,patient,seam.goal,3);
  const shot = findProjectile(view, patient, observed);
  if (shot) return heading(view, patient, shot.point, 4);
  const away = angle(view.boss, patient);
  const rim = [away, away + .7, away - .7, away + 1.25, away - 1.25].map(axis => straight(view.boss, axis, 132));
  const world = bulwarkTrialWorld(view);
  const lane = rim.find(target => clearTrialWalk(world, patient, target) &&
    !world.obstacles.some(wall => segmentRect(view.boss, target, wall, 4)));
  return lane ? heading(view, patient, lane, 10) : heading(view, patient, view.boss, 116);
}

async function earnedFlow(adapter) {
  const view = () => {
    const current = adapter.view();
    assert(current);
    return current;
  };
  const owner = () => closeHealth(view(), adapter.id);
  const patient = () => closeHealth(view(), adapter.patientId ?? adapter.id);
  const ally = !!adapter.patientId;
  const landscape = () => bulwarkTrialWorld(view());
  const line = (from, to) => !landscape().obstacles.some(wall => segmentRect(from, to, wall, 1));
  const sounds = (event, from) => adapter.events.slice(from).filter(row => row.type === 'sound' &&
    row.id === 'medic-precaution-' + event && row.owner === adapter.id);
  const purchase = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind: 'skill', item });
    assert(result.ok, JSON.stringify({ item, result }));
    purchase.push({ item, earned: owner().sp + spending(owner()), clears: owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(w => w.classId === 'medic').sort((a,b) => b.tier - a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind: 'weapon', item: weapon.id })).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) await adapter.purchase({ kind: 'upgrade', item });
  }
  const fitted = fitting !== 'entry';
  assert.equal(owner().sp, 3);
  await buy('medic-chemistry-1');
  await buy(preventiveCareIds.entry);
  if (fitted) assert(!(await adapter.purchase({ kind: 'skill', item: preventiveCareIds[fitting] })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat', 'The ordinary opening encounter begins');
  const shopLimit = Date.now() + 125_000;
  while (view().phase !== 'shop') {
    assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase), 'Reach the shop with an actual first clear');
    if (view().phase === 'combat') {
      const p = owner();
      const input = restRaidInput(view(),p,[...adapter.observed.values()]);
      adapter.input({ ...input, q: p.health <= p.maxHealth - 19 && !!input.q, e: p.health <= p.maxHealth - 16 && !!input.e });
      adapter.allyPressure?.();
    } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
    await sleep(25);
  }
  assert.equal(owner().progress.clears, 1);
  assert.equal(owner().sp + spending(owner()), 9);
  if (fitted) {
    await buy(preventiveCareIds[fitting]);
    const other = fitting === 'doorstep' ? 'layered' : 'doorstep';
    assert.equal((await adapter.purchase({ kind: 'skill', item: preventiveCareIds[other] })).reason, 'incompatibleItem');
  }
  await equip();
  await wait(() => view().phase === 'combat', 'The second ordinary encounter begins', 95_000);
  const next = { boss: view().boss.id, start: view().combatTick };

  adapter.pause(true);
  await wait(() => adapter.paused(), 'The authority acknowledges pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ technique3: true });
  await sleep(75);
  assert.equal(view().combatTick, pausedAt);
  assert(owner().ack < ignored);
  assert.equal(owner().kit.precautionWrap?.phase, 'idle');
  adapter.pause(false);
  await wait(() => !adapter.paused(), 'The authority acknowledges resume');

  function carryPatient(input) {
    if (ally) adapter.allyHunt(input);
    else adapter.input(input);
  }
  function eligibleStation(p) {
    const { bounds, obstacles } = landscape(), r = precautionRules.stationRadius;
    return p.x >= bounds.x + r && p.y >= bounds.y + r && p.x <= bounds.x + bounds.width - r &&
      p.y <= bounds.y + bounds.height - r && !obstacles.some(wall => segmentRect(p,p,wall,r));
  }
  const witness = (kind, from, id) => [...adapter.cues.values()].find(cue => cue.kind === 'medic-precaution-' + kind &&
    cue.owner === adapter.id && cue.at >= from && (id === undefined || cue.id === id));
  const remain = Date.now() + 86_000;
  const observed = adapter.allyObserved ?? adapter.observed;
  let pending, result, previousTarget, lastHealth, lastShield;
  const touched = new Set(), contacts = [];
  const rejected = [];
  while (!result) {
    const v = view(), p = owner(), t = patient(), state = p.kit.precautionWrap;
    const aim = ally ? angle(p,t) : angle(p,v.boss), now = v.combatTick;
    assert(Date.now() < remain && v.phase === 'combat', JSON.stringify({
      reason: 'Finish the wrap through an actual hostile impact', fitting, pending, rejected,
      tick: now, t: point(t), p: point(p), health: t.health, shield: t.shield, qAt: p.qAt,
      state, boss: v.boss.id, shots: observed.size, contacts,
    }));
    if (previousTarget && (t.health < lastHealth - .01 || t.shield < lastShield - .01)) {
      touched.add(previousTarget.cue.id);
      contacts.push({ at: now, id: previousTarget.cue.id, x: t.x, y: t.y, health: t.health, shield: t.shield });
    }
    lastHealth = t.health;
    lastShield = t.shield;
    if (pending) {
      if (p.qAt > pending.qAt) pending.paid = p.qAt;
      const healing = witness('dose', pending.at);
      if (healing && sounds('dose', pending.events).length) {
        const gained = t.health - pending.lowest;
        const fittedAction = fitting === 'entry' || fitting === 'doorstep' && pending.claim || fitting === 'layered' && pending.release;
        if (gained > 0 && fittedAction) {
          result = { healing, amount: gained, pending };
          break;
        }
      }
      pending.lowest = Math.min(pending.lowest, t.health);
      if (state?.phase === 'idle') pending.idleSince ??= now;
      else pending.idleSince = undefined;
      if (pending.idleSince !== undefined && now - pending.idleSince >= 8) {
        rejected.push({ at: pending.at, tick: now, paid: pending.paid ?? null, station: !!pending.station,
          claimed: !!pending.claim, hits: pending.hits ?? 0, lowest: pending.lowest });
        pending = undefined;
      }
    }
    const reach = distance(p,t) <= 80 && line(p,t);
    if (!pending && state?.phase === 'idle' && p.qAt <= now && (state.until ?? 0) <= now &&
        p.status === 'active' && t.status === 'active' && p.health > 34 && t.health > 38 &&
        p.reloadAt <= now && p.dashUntil <= now && t.shield < 1 &&
        (!ally || distance(p,t) >= 12 && reach) && (fitting !== 'doorstep' || eligibleStation(p))) {
      if (ally) await adapter.stopAlly();
      const selected = fitting === 'doorstep' && ally ? angle(patient(),owner()) : aim;
      const start = { at: view().combatTick, qAt: p.qAt, health: t.health, lowest: t.health, events: adapter.events.length };
      const seq = adapter.input({ aim: selected, technique3: true });
      await wait(() => owner().ack >= seq, 'The authority acknowledges the actual wrap input');
      const accepted = owner().kit.precautionWrap;
      if (accepted?.phase === 'armed' || accepted?.phase === 'settling') {
        pending = { ...start, until: accepted.until, initialPatient: accepted.patient };
        assert.equal(accepted.patient, fitting === 'doorstep' ? p.id : t.id);
        if (accepted.phase === 'armed') assert.equal(owner().qAt, start.qAt);
      }
      continue;
    }
    if (pending && state?.phase === 'armed' && !pending.station && !pending.layer && fitting !== 'entry' &&
        (fitting === 'doorstep' ? state.canPlace : state.canLayer)) {
      const seq = adapter.input({ aim, technique3: true });
      await wait(() => owner().ack >= seq, 'The fitting command is acknowledged');
      if (fitting === 'layered' && owner().kit.precautionWrap?.phase === 'layered') {
        pending.layer = { at: view().combatTick, until: owner().kit.precautionWrap.until };
        assert.equal(pending.layer.until, pending.until);
      }
      if (fitting === 'doorstep' && owner().kit.precautionWrap?.phase === 'station') {
        await wait(() => witness('station', pending.at), 'A physical kit sits on clear ground');
        pending.station = witness('station', pending.at);
        assert.equal(pending.station.until, pending.until);
        assert.equal(owner().qAt, pending.qAt);
      }
      continue;
    }
    if (pending && state?.phase === 'station' && pending.station) {
      const spot = pending.station, world = landscape(), outside = distance(t,spot) > spot.radius;
      if (outside) pending.wasOutside = true;
      const goals = [0, Math.PI / 2, -Math.PI / 2, Math.PI, .58, -.58, 2.56, -2.56]
        .map(a => straight(spot,a,spot.radius + 14));
      const goal = pending.wasOutside ? spot : goals.find(candidate => clearTrialWalk(world,t,candidate));
      if (ally) adapter.input({ aim });
      carryPatient(goal ? heading(v,t,goal,3) : {});
    } else if (pending && fitting === 'doorstep' && pending.station && state?.phase === 'armed' && !pending.claim) {
      assert(pending.wasOutside && state.patient === t.id && state.until === pending.until);
      pending.claim = { at: now, patient: t.id, position: point(t), kitId: pending.station.id };
    } else if (pending && state?.phase === 'layered' && state.capturedHits > 0 &&
        (state.capturedHits >= 2 || state.until <= now + 14 || t.health < 38) && (!ally || reach)) {
      pending.hits = state.capturedHits;
      const seq = adapter.input({ aim, technique3: true });
      if (ally) adapter.allyHunt({});
      await wait(() => owner().ack >= seq, 'The layered release is acknowledged');
      if (owner().kit.precautionWrap?.phase === 'settling') pending.release = now;
    } else if (pending && state?.phase === 'settling') {
      adapter.input({ aim });
      if (ally) adapter.allyHunt({});
    } else {
      if (ally) {
        const axis = angle(t,v.boss), safety = [axis + Math.PI / 2, axis - Math.PI / 2, axis + Math.PI]
          .map(direction => straight(t,direction,fitting === 'doorstep' ? 38 : 55));
        const position = safety.find(goal => clearTrialWalk(landscape(),p,goal) && line(goal,t) &&
          (fitting !== 'doorstep' || eligibleStation(goal)));
        adapter.input({ ...(position ? heading(v,p,position,12) : heading(v,p,t,43)), aim,
          e: !pending && p.eAt <= now && (p.health < 37 || t.health < 39) && reach });
      }
      const exposed = t.shield < 1 && !pending && t.health < 39;
      previousTarget = exposed ? undefined : findSeam(v,t,touched);
      carryPatient(exposed
        ? { ...heading(v,t,landscape().playerSpawn,18), ...(!ally && p.eAt <= now ? { e: true } : {}) }
        : hunt(v,t,observed,previousTarget));
    }
    await sleep(24);
  }

  const { healing, amount, pending: confirmed } = result;
  assert.equal(healing.patient, patient().id);
  assert(confirmed.paid > confirmed.qAt && owner().qAt === confirmed.paid);
  assert(amount > 0 && amount <= confirmed.health - confirmed.lowest + 1e-6);
  if (fitting === 'doorstep') assert(confirmed.station && confirmed.wasOutside && confirmed.claim &&
    confirmed.station.id === confirmed.claim.kitId && sounds('claim', confirmed.events).length === 1);
  if (fitting === 'layered') assert(confirmed.layer && confirmed.hits > 0 && confirmed.hits <= 2 &&
    confirmed.release && sounds('capture', confirmed.events).length === confirmed.hits);
  const physical = [healing], key = healing.kind + ':' + healing.id;
  const witnessed = await adapter.peerWitness?.([key]);
  return { passed: true, protocol: PROTOCOL, contentRevision: CONTENT_REVISION, transport, fitting, bought: purchase,
    patient: ally ? 'actual-teammate' : 'self', firstClear: 1, next,
    before: { at: confirmed.at, health: confirmed.health, qAt: confirmed.qAt },
    woundedHealth: confirmed.lowest, paid: confirmed.paid, amount, conditions: confirmed,
    physical, witnessed, observedSeamContacts: contacts, ordinaryImpactOnly: true,
    pausedCommandsDiscarded: true, noCheckpointImports: true };
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Iona', classId: 'medic' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'preventive-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), medic = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], medic: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  medic.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, medic.id)?.kit.precautionWrap !== undefined) leaks++;
  };
  medic.onEvents = batch => remember(state.events, state.observed, batch, medic.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  medic.onPurchase = entry => replies.medic.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await medic.connect({ ...setup, name: 'Iona', classId: 'medic', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => medic.view?.players.length === 2 && host.view?.players.length === 2, 'Actual non-host Medic lobby');
    assert.equal(medic.view.owner, host.id);
    assert.notEqual(medic.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: medic.id, patientId: host.id, view: () => medic.view,
      input: props => { medic.input(inputFrame(medic.view, ++sequence, props)); return sequence; },
      purchase: request => reply(medic, replies.medic, request), start: () => host.start(),
      vote: i => { host.vote(i); medic.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => medic.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      allyObserved: peers.observed, allyHunt: i => hostInput(i), stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'Patient stops on the ordinary map');
      },
      peerWitness: async ids => {
        await wait(() => ids.some(id => peers.cues.has(id)), 'Host sees the same physical admitted dose');
        assert.equal(leaks, 0);
        assert(!peers.events.some(e => e.type === 'sound' && e.owner === medic.id && e.id.startsWith('medic-precaution-')));
        assert(!host.room.state.players.get(medic.id).lineworkOwner);
        return { nonHost: true, sharedCue: ids.find(id => peers.cues.has(id)), ownedStatePrivate: true, ownedSoundsPrivate: true };
      },
    });
    host.endMatch();
    await wait(() => [host, medic].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    medic.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, testedAudience: testAudience });
console.log(JSON.stringify({ ...result, physical: result.physical.map(cue => cue.id) }));
