import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { conductorPilot } from './conductor-native-pilot.mjs';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';

export function recordBardCues(cues, view) {
  for (const cue of view.classCues) {
    if (cue.kind !== 'bard-response-stage' && cue.kind !== 'bard-phrase') continue;
    let record = cues.get(cue.id);
    if (!record) {
      record = { first: cue, last: cue, phases: [], cooldown: view.players.find(row => row.id === cue.owner)?.qAt };
      cues.set(cue.id, record);
    }
    record.last = cue;
    if (!record.phases.length || record.phases.at(-1).proof !== cue.proof || record.phases.at(-1).shifted !== cue.shifted) {
      record.phases.push(cue);
    }
  }
}

export function createCombatPolicy({ adapter, view, data, HZ, rules, runtimeArena, bulwarkTrialWorld, clearTrialWalk,
  segmentRect, segmentCircle, distance, restRaidInput, fitting }) {
  let worldTick = -1, world;
  const projection = {
    get arena() { return runtimeArena(view().arenaId, view().run.difficulty); },
    get obstacles() {
      const seen = view();
      if (worldTick !== seen.combatTick || world?.arenaId !== seen.arenaId) {
        worldTick = seen.combatTick;
        world = { ...bulwarkTrialWorld(seen), arenaId: seen.arenaId };
      }
      return world.obstacles;
    },
    get combatTick() { return view().combatTick; },
    get encounter() { return view().encounter; },
    movementSpeed(player) { return player.speed; },
  };
  function danger(seen, at, horizon) {
    if (seen.minions.some(row => row.health > 0 && distance(row, at) < 24 + horizon)) return true;
    if (seen.fields.some(row => row.kind === 'zone' && distance(row, at) < row.radius + 8)) return true;
    for (const shot of adapter.observed.values()) {
      const time = Math.min(horizon, shot.expires - seen.combatTick);
      if (time <= 0 || shot.owner !== 'hostile' || distance(shot, at) > 475) continue;
      const elapsed = Math.max(0, seen.combatTick - shot.seenAt) / HZ;
      const from = { x: shot.x + shot.vx * elapsed, y: shot.y + shot.vy * elapsed };
      const to = { x: from.x + shot.vx * time / HZ, y: from.y + shot.vy * time / HZ };
      const contact = segmentCircle(from, to, at, shot.radius + data.rules.playerRadius + 2);
      if (contact !== null && !projection.obstacles.some(wall => (segmentRect(from, to, wall, shot.radius)?.t ?? Infinity) <= contact)) return true;
    }
    return false;
  }
  const context = { game: projection, data, HZ, rules, distance, segmentRect, clearTrialWalk, danger };
  const navigate = explicitNavigation(context);
  const perform = conductorPilot({ ...context, fitting, exerciseFit: true });
  const ordinary = (seen, body) => navigate(seen, body, restRaidInput(seen, body, [...adapter.observed.values()]));
  return {
    ordinary,
    invoke(seen, body, record) {
      const routine = ordinary(seen, body);
      return perform(seen, body, { ...routine, q: false, ultimate: routine.ultimate && body.health < body.maxHealth * .4 }, record);
    },
  };
}

export async function exerciseConductor({ adapter, view, owner, submit, fitting, rules, distance, equip, policy }) {
  const limit = Date.now() + 165_000;
  const plans = [], start = view().combatTick, oldRecovery = owner().qAt, eventStart = adapter.events.length;
  let lastShop = view().encounter, lastTick = -1;
  const at = cue => ({ x:cue.originX, y:cue.originY });
  const wantsShift = fitting === 'side', wantsReturn = fitting === 'reprise';
  for (;;) {
    const seen = view(), body = owner();
    const sounds = adapter.events.slice(eventStart).filter(event => event.type === 'sound' && event.owner === adapter.id && event.id.startsWith('bard-answer-'));
    const cueRecords = [...adapter.cues.values()].filter(row => row.first.owner === adapter.id && row.first.at >= start);
    if (Date.now() >= limit || ['defeat','victory'].includes(seen.phase)) {
      assert.fail(JSON.stringify({ fitting,phase:seen.phase,tick:seen.combatTick,boss:seen.boss.id, hp:body.health,
        plans:plans.slice(-24), sounds:sounds.map(row=>row.id), stages:cueRecords.filter(row=>row.first.kind==='bard-response-stage').slice(-5) }));
    }
    if (seen.phase !== 'combat') {
      if (['mutationVote','contractVote','secretOffer'].includes(seen.phase)) adapter.vote(0);
      if (seen.phase === 'shop' && seen.encounter !== lastShop) { lastShop = seen.encounter; await equip(); }
      await sleep(20);
      continue;
    }
    const stages = cueRecords.filter(row => row.first.kind === 'bard-response-stage');
    const phrases = cueRecords.map(row => row.first).filter(cue => cue.kind === 'bard-phrase' && !cue.encore);
    for (const row of stages) {
      const { first, last } = row;
      const origin = at(first), expected = wantsReturn ? origin : last;
      const call = phrases.find(cue => cue.beat === 0 && cue.at === first.at && distance(cue,origin) < .8);
      const answer = phrases.find(cue => cue.beat === 1 && cue.at > first.at && cue.at < first.until && distance(cue,expected) < .8);
      if (!call || !answer || !last.proof || wantsShift !== !!last.shifted || !sounds.some(s => s.id === 'bard-answer-release')) continue;
      if (wantsReturn && !sounds.some(s => s.id === 'bard-answer-reprise')) continue;
      assert.equal(first.until - first.at, rules.stageTicks);
      assert.equal(last.id, first.id);
      assert.equal(last.until, first.until);
      assert.deepEqual(at(last), origin);
      assert(call.cadence >= rules.cadence && call.cadence === answer.cadence);
      assert(body.qAt > oldRecovery && body.qAt > answer.at);
      if (row.cooldown !== undefined) assert.equal(body.qAt, row.cooldown);
      assert(sounds.some(s => s.id === 'bard-answer-call'));
      assert(sounds.some(s => s.id === 'bard-answer-proof' && distance(s,last) < .8));
      if (wantsShift) assert(distance(first,last) >= rules.shiftMinimum && distance(first,last) <= rules.shiftMaximum);
      return { stage:row, call, answer, recovery:body.qAt, shifted:wantsShift, returned:wantsReturn,
        sounds:sounds.map(row=>row.id), plans:plans.slice(-45), boss:seen.boss.id };
    }
    if (seen.combatTick === lastTick) { await sleep(10); continue; }
    lastTick = seen.combatTick;
    const input = body.status === 'active' ? policy.invoke(seen,body,row=>plans.push(row)) : { interact:true };
    await submit(input);
    adapter.allyCover?.();
  }
}
