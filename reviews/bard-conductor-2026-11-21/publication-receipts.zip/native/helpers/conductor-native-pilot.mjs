const bearing = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
const advance = (a, angle, gap) => ({ x: a.x + Math.cos(angle) * gap, y: a.y + Math.sin(angle) * gap });

export function conductorPilot({ game, rules, distance, segmentRect, clearTrialWalk, danger, fitting, exerciseFit }) {
  let lastClock = -1, reserveUntil = 0;
  return (view, player, normal, record) => {
    const now = view.combatTick;
    const stage = player.kit.conducting;
    if (player.health < player.maxHealth * .36 || danger(view, player, 5)) return normal;
    const clear = (a, b, pad = 2) => !game.obstacles.some(wall => segmentRect(a, b, wall, pad));
    const hostiles = [view.boss, ...view.minions].filter(enemy => enemy.health > 0);
    const nearest = from => hostiles.filter(target => clear(from, target)).sort((a, b) => distance(from,a) - distance(from,b))[0];
    const friends = view.players.filter(actor => actor.id !== player.id && actor.status === 'active');
    const terrain = { ...game.arena, obstacles: game.obstacles, tick: now };
    const cue = view.classCues.find(row => row.kind === 'bard-response-stage' && row.owner === player.id);
    const call = cue && { x: cue.originX, y: cue.originY };
    function coverScore(site) {
      const nearby = hostiles.filter(enemy => distance(enemy, site) <= 150 && clear(site, enemy));
      const endangered = friends.filter(friend => distance(friend, site) <= 144 && danger(view, friend, 11));
      return nearby.length * 2 + endangered.length * 2.4 + (distance(player, site) <= 142 && danger(view, player, 11) ? 1.45 : 0);
    }

    if (stage?.phase === 'answer' && stage.ready) {
      if (call && fitting === 'reprise' && player.skills.includes('bard-conductor-reprise-1') && distance(player, call) >= rules.repriseRange &&
          distance(player, call) <= rules.ownerReach && clear(player, call, rules.floorPadding) && (exerciseFit || coverScore(call) > coverScore(stage.stage))) {
        record({ action:'reprise', tick:now, at:call });
        return { technique1:true, aim:bearing(player,call) };
      }
      const useful = hostiles.some(enemy => distance(enemy, stage.stage) <= 151 && clear(stage.stage, enemy)) ||
        friends.some(friend => distance(friend, stage.stage) <= 144 && danger(view, friend, 12));
      if (useful || stage.until - now < 11) {
        record({ action: 'answer', tick: now, at: stage.stage });
        return { technique1: true, aim: call && stage.returning ? bearing(call,stage.stage) : player.aim };
      }
      return normal;
    }
    if (stage?.phase === 'listening') {
      if (cue && call && fitting === 'side' && player.skills.includes('bard-conductor-side-stage-1') && !cue.shifted && stage.until - now > 35) {
        const heading = bearing(call,stage.stage);
        const risky = danger(view,stage.stage,10) || !clearTrialWalk(terrain,player,stage.stage);
        const options = [.35,-.35,.5,-.5,.64,-.64].map(offset => {
          const aim = heading + offset;
          return { aim, at:advance(call,aim,rules.reach) };
        }).filter(({at}) => distance(stage.stage,at) >= rules.shiftMinimum && distance(stage.stage,at) <= rules.shiftMaximum &&
           clearTrialWalk(terrain,player,at) && clear(call,at,rules.floorPadding) && !danger(view,at,10) && nearest(at));
        options.sort((a,b) => coverScore(b.at) - coverScore(a.at) || distance(player,a.at) - distance(player,b.at));
        const alternative = options[0];
        if (alternative && (exerciseFit || risky || coverScore(alternative.at) > coverScore(stage.stage))) {
          if (player.kit.cadence >= 1) {
            record({ action:'shift', tick:now, from:stage.stage, at:alternative.at });
            return { technique1:true, aim:alternative.aim };
          }
          const enemy = nearest(player);
          if (enemy && distance(player,stage.stage) > rules.stageRadius + 8) {
            return { ...normal, moveX:0, moveY:0, fire:true, aim:bearing(player,enemy) };
          }
        }
      }
      if (distance(player, stage.stage) <= rules.stageRadius * .77) {
        const target = nearest(player);
        return target ? { ...normal, aim: bearing(player, target), fire: true, moveX: 0, moveY: 0 } : normal;
      }
      const preferred = bearing(player, stage.stage);
      for (const offset of [0, .36, -.36, .72, -.72]) {
        const heading = preferred + offset, end = advance(player, heading, 22);
        if (clearTrialWalk(terrain, player, end) && !danger(view, end, 6)) {
          return { ...normal, moveX: Math.cos(heading), moveY: Math.sin(heading), dodge: false };
        }
      }
      return normal;
    }
    if (player.qAt > now) return normal;
    if (lastClock !== player.qAt) {
      lastClock = player.qAt;
      reserveUntil = now + 95;
    }
    if (player.kit.cadence < rules.cadence) return now < reserveUntil ? { ...normal, q: false } : normal;
    const enemy = nearest(player);
    if (!enemy) return now < reserveUntil ? { ...normal, q: false } : normal;
    const direct = bearing(player, enemy);
    const sites = [0,.36,-.36,.72,-.72,1.08,-1.08].map(offset => {
      const aim = direct + offset, stage = advance(player, aim, rules.reach);
      return { aim, stage };
    }).filter(({ stage }) => clearTrialWalk(terrain, player, stage) && !danger(view, stage, 10) &&
      distance(stage, enemy) > 65 && distance(stage, enemy) < 231 && !!nearest(stage));
    sites.sort((a, b) => distance(a.stage, enemy) - distance(b.stage, enemy));
    if (sites.length) {
      record({ action: 'call', tick: now, from: { x: player.x, y: player.y }, stage: sites[0].stage, cadence: player.kit.cadence });
      return { technique1: true, aim: sites[0].aim };
    }
    return now < reserveUntil ? { ...normal, q: false } : normal;
  };
}
