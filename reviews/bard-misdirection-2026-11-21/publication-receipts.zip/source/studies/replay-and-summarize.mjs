import assert from 'node:assert/strict';
import { execFile as execute } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const exec = promisify(execute);
const here = path => new URL('./' + path, import.meta.url);
const digest = path => sha256(readFileSync(here(path)));
const actions = ['set','arm','take','arrive','turn','second'];
const policies = ['banked','unused','misdirection','wrong','second'];
const count = (run,action) => run.effects.filter(event=>event.action===action).length;
const edition = readJson(here('content01.json'));
const compiled = readJson(here('game02.json'));
assert.equal(digest('game02.mjs'),compiled.bundle);
for (const [path,sum] of Object.entries(compiled.inputs)) {
  const candidates=['stage/','../bard-lament/stage/','../bard-conductor/stage/'].map(folder=>folder+path);
  assert.equal(digest(candidates.find(path=>existsSync(here(path)))),sum);
}
const files = [];
const results = [];
const sequence = 'replays01';
mkdirSync(here(sequence+'/'));
for (const mode of ['short','standard']) for (const cohort of ['solo','party']) {
  const path = `${mode}-${cohort}02.json`;
  const group = readJson(here(path));
  assert(group.stageOnly && group.revision===edition.revision && group.bundle===compiled.bundle && group.mode===mode && group.cohort===cohort);
  assert(group.rows.length===20 && group.controls.length===4 && group.controls.every(row=>row.sameTrace));
  for (const row of group.rows) {
    if (row.policy === 'banked' || row.policy === 'unused') assert.equal(row.effects.length,0);
    if (row.purchases.length) assert.deepEqual(row.purchases.map(p=>[p.earned,p.clears]), [[mode==='short'?9:5,1]]);
    for(const event of row.effects.filter(e=>['take','turn','second'].includes(e.action))){
      assert(event.cues.some(cue=>cue.kind==='bard-false-entrance'&&cue.armed));
    }
  }
  const counts = policies.map(policy=>{
    const rows = group.rows.filter(row=>row.policy===policy);
    assert.equal(rows.length,4);
    return { policy, runs:rows.length, wins:rows.filter(row=>row.won).length, earnedFitting:rows.filter(row=>row.purchases.length).length,
      ...Object.fromEntries(actions.map(action=>[action,rows.reduce((n,row)=>n+count(row,action),0)])) };
  });
  files.push({ path, sha256:digest(path), mode, cohort, counts, matches:group.controls.length });
  results.push(...await Promise.all(['misdirection','wrong','second'].map(async policy=>{
    const focus = policy==='wrong'?'turn':policy==='second'?'second':'take';
    const row = group.rows.filter(row=>row.policy===policy).sort((a,b)=>count(b,focus)-count(a,focus) || count(b,'take')-count(a,'take'))[0];
    const caseName = [mode,cohort,policy].join('-');
    const out = `${sequence}/${caseName}.json`, logfile = `${sequence}/${caseName}.log`;
    const replay = await exec(process.execPath, [fileURLToPath(here('natural-misdirection.mjs')),fileURLToPath(here(out)),cohort,mode,'game02',row.arena+'/'+policy],{
      cwd:fileURLToPath(here('')), windowsHide:true, timeout:180_000, maxBuffer:1024*1024,
    });
    writeFileSync(here(logfile),replay.stdout,{flag:'wx'});
    const reproduced = readJson(here(out));
    assert.equal(reproduced.rows.length,1);
    assert.deepEqual(reproduced.rows[0],row);
    return { case:caseName,path:out,sha256:digest(out),logSha256:digest(logfile),arena:row.arena,trace:row.trace,focus,count:count(row,focus) };
  })));
}
const rows = files.flatMap(file=>file.counts);
const totals = Object.fromEntries(actions.map(action=>[action,rows.reduce((n,row)=>n+row[action],0)]));
assert(totals.turn>0 && totals.second>0 && results.length===12);
receipt(here(sequence+'/summary.json'),{ passed:true,replays:results,revision:edition.revision,bundle:compiled.bundle });
receipt(here('study-summary01.json'),{ passed:true,revision:edition.revision,bundle:compiled.bundle, cases:rows.reduce((n,row)=>n+row.runs,0),
  matchedControls:files.reduce((n,file)=>n+file.matches,0),exactReplays:results.length,totals,files,replaySha256:digest(sequence+'/summary.json'),
  policies:Object.fromEntries(policies.map(policy=>[policy,{runs:rows.filter(row=>row.policy===policy).reduce((n,row)=>n+row.runs,0),
    wins:rows.filter(row=>row.policy===policy).reduce((n,row)=>n+row.wins,0)}])) });
console.log(JSON.stringify(readJson(here('study-summary01.json'))));
