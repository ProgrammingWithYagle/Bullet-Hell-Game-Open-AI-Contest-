import assert from 'node:assert/strict';

export function verifyNativeCase(record, expected) {
  const {transport,fitting,revision,driver,worker}=expected;
  assert(record.passed&&record.protocol===95&&record.contentRevision===revision&&record.driverSha256===driver);
  assert(record.transport===transport&&record.fitting===fitting&&record.pausedCommandsDiscarded&&record.noCheckpointImports);
  assert.equal(record.firstClear,fitting==='entry'?0:1);
  if(fitting!=='entry')assert.equal(record.bought.at(-1).earned,5);
  const {stage,targets,trace,paid,sounds,boss}=record.result;
  assert.equal(boss,'matron');
  assert(stage.first.id===stage.last.id&&stage.first.until===stage.last.until&&!stage.first.armed&&stage.last.armed);
  assert.deepEqual([...new Set(stage.phases.flatMap(cue=>cue.target===undefined?[]:[cue.target]))],targets);
  assert.equal(targets.length,fitting==='second'?2:1);
  assert.equal(Boolean(stage.last.moved),fitting==='wrong');
  assert.equal(Boolean(stage.last.repeats),fitting==='second');
  assert(trace.length>1&&trace.every(sample=>sample.actor===targets.at(-1)));
  const advanced=trace[0].distance-trace.at(-1).distance;
  assert(advanced>3);
  if(fitting==='wrong')assert(Math.hypot(stage.first.x-stage.last.x,stage.first.y-stage.last.y)>3);
  if(fitting==='second'){
    assert(sounds.includes('bard-entrance-arrive')&&sounds.includes('bard-entrance-second'));
    assert.deepEqual([stage.first.x,stage.first.y],[stage.last.x,stage.last.y]);
  }
  assert(Number.isSafeInteger(paid.e)&&Number.isSafeInteger(paid.u));
  if(transport==='worker')assert(record.wholeOptimizedWorker&&!record.workerPatched&&record.workerSha256===worker);
  else assert(record.witnessed.nonHost&&record.witnessed.ownedStatePrivate&&record.witnessed.ownedSoundsPrivate);
  return {transport,fitting,boss,firstClear:record.firstClear,stage:stage.first.id,targets,advanced};
}
