const point = ({x,y}) => ({x,y});
const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const forward = (p,a,d) => ({ x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d });

export function explicitNavigation({game, data, HZ, distance, segmentRect, clearTrialWalk, danger}) {
  const visible=(a,b,r=1)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,r));
  function movement(view,p,aim) {
    const target=forward(p,aim,23), world={ ...game.arena,obstacles:game.obstacles,tick:view.combatTick };
    return clearTrialWalk(world,p,target) && !danger(view,target,5) ? { moveX:Math.cos(aim),moveY:Math.sin(aim) } : undefined;
  }
  const navigation = new Map();
  const radius = data.rules.playerRadius;
  const aimVector = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  function firingLane(view, player, target, input) {
    const boss = point(target);
    const walls = game.obstacles;
    const occluded = (from) => walls.some(wall => segmentRect(from, boss, wall, 4));
    if (!occluded(player)) {
      navigation.delete(player.id);
      return;
    }
    if (player.health < player.maxHealth * .28 || danger(view, player, 10)) return;
    const now = game.combatTick;
    const world = { ...game.arena, obstacles: walls, tick: now, playerRadius: radius };
    const clear = (a, b) => clearTrialWalk(world, a, b);
    let chase = navigation.get(player.id);
    if (!chase || chase.encounter !== game.encounter || now >= chase.at + 55 || chase.target !== target.id) {
      const margin = radius + 14;
      const bends = walls.flatMap(wall => [
        { x: wall.x - margin, y: wall.y - margin }, { x: wall.x + wall.width + margin, y: wall.y - margin },
        { x: wall.x - margin, y: wall.y + wall.height + margin }, { x: wall.x + wall.width + margin, y: wall.y + wall.height + margin },
      ]).filter(p => clear(p, p));
      const goals = [142, 200, 275, 360].flatMap(range => Array.from({ length: 20 }, (_, i) => {
        const aim = aimVector(i * Math.PI / 10);
        return { x: boss.x + aim.x * range, y: boss.y + aim.y * range };
      })).filter(p => clear(p, p) && !occluded(p));
      const points = [point(player), ...bends, ...goals];
      const cheapest = points.map((_, i) => i === 0 ? 0 : Infinity);
      const parent = points.map(() => -1), visited = new Set();
      let path = [];
      for (let pass = 0; pass < points.length; pass++) {
        let index = -1, shortest = Infinity;
        for (let i = 0; i < points.length; i++) if (!visited.has(i) && cheapest[i] < shortest) {
          index = i;
          shortest = cheapest[i];
        }
        if (index < 0) break;
        if (index > bends.length) {
          for (let start = index; start > 0; start = parent[start]) path.unshift(points[start]);
          break;
        }
        visited.add(index);
        for (let next = 1; next < points.length; next++) {
          const step = distance(points[index], points[next]);
          if (visited.has(next) || shortest + step >= cheapest[next] || !clear(points[index], points[next])) continue;
          cheapest[next] = shortest + step;
          parent[next] = index;
        }
      }
      chase = { at: now, encounter: game.encounter, path, target: target.id };
      navigation.set(player.id, chase);
    }
    while (chase.path.length && distance(player, chase.path[0]) < 2) chase.path.shift();
    const next = chase.path[0];
    if (!next || !clear(player, next)) return;
    const scale = Math.max(distance(player, next), game.movementSpeed(player) / HZ);
    return { ...input, moveX: (next.x - player.x) / scale, moveY: (next.y - player.y) / scale, dodge: false };
  }


  function ordinary(view,p,current) {
    const targets=view.bossCues.filter(c=>c.health>0 && ['service-prop','stitch-pin','raid-prop','early-prop'].includes(c.kind) &&
      distance(p,c)<530 && visible(p,c,2)).sort((a,b)=>distance(p,a)-distance(p,b));
    const immediate=view.minions.filter(c=>c.health>0 && distance(p,c)<82 && visible(p,c,2));
    const target=immediate.sort((a,b)=>distance(p,a)-distance(p,b))[0]??targets[0]??view.boss;
    const aim=bearing(p,target);
    if(immediate.length) {
      const retreat=[aim+Math.PI,aim+1.6,aim-1.6].map(h=>movement(view,p,h)).find(Boolean);
      return { ...current,...retreat,aim,fire:true };
    }
    if(visible(p,target,2))
      return { ...current,aim,fire:current.fire || distance(p,target)<320 };
    if(current.dodge || danger(view,p,6))return current;
    return firingLane(view,p,target,{ ...current,aim }) ?? current;
  }

  return ordinary;
}
