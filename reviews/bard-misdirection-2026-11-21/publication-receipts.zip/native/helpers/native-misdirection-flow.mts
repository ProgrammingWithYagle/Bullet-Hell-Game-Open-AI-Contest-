import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { misdirectionPilot } from './misdirection-pilot.mjs';

export function recordMisdirectionCues(cues,view) {
  for(const cue of view.classCues){
    if(cue.kind!=='bard-false-entrance')continue;
    let known=cues.get(cue.id);
    if(!known){known={first:cue,last:cue,phases:[]};cues.set(cue.id,known);}
    if(JSON.stringify(known.last)!==JSON.stringify(cue)||!known.phases.length)known.phases.push(cue);
    known.last=cue;
  }
}

export function createCombatPolicy({ adapter,view,data,HZ,rules,runtimeArena,bulwarkTrialWorld,clearTrialWalk,
  segmentRect,segmentCircle,distance,restRaidInput,fitting }) {
  let worldTick=-1,world;
  const game={
    get arena(){return runtimeArena(view().arenaId,view().run.difficulty);},
    get obstacles(){
      const seen=view();
      if(worldTick!==seen.combatTick||world?.arenaId!==seen.arenaId){
        worldTick=seen.combatTick;world={...bulwarkTrialWorld(seen),arenaId:seen.arenaId};
      }
      return world.obstacles;
    },
    get combatTick(){return view().combatTick;},
    get encounter(){return view().encounter;},
    movementSpeed(body){return body.speed;},
  };
  function danger(seen,point,horizon){
    if(seen.minions.some(actor=>actor.health>0&&distance(actor,point)<22+horizon))return true;
    if(seen.fields.some(field=>field.kind==='zone'&&distance(field,point)<field.radius+8))return true;
    for(const shot of adapter.observed.values()){
      const time=Math.min(horizon,shot.expires-seen.combatTick);
      if(time<=0||shot.owner!=='hostile'||distance(shot,point)>435)continue;
      const elapsed=Math.max(0,seen.combatTick-shot.seenAt)/HZ;
      const from={x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed};
      const to={x:from.x+shot.vx*time/HZ,y:from.y+shot.vy*time/HZ};
      const hit=segmentCircle(from,to,point,shot.radius+data.rules.playerRadius+2);
      if(hit!==null&&!game.obstacles.some(wall=>(segmentRect(from,to,wall,shot.radius)?.t??Infinity)<=hit))return true;
    }
    return false;
  }
  const context={game,data,HZ,rules,distance,segmentRect,clearTrialWalk,danger};
  const navigate=explicitNavigation(context);
  const use=misdirectionPilot({...context,policy:fitting,exercise:true});
  const ordinary=(seen,body)=>navigate(seen,body,restRaidInput(seen,body,[...adapter.observed.values()]));
  return {ordinary,invoke(seen,body,record){
    const baseline=ordinary(seen,body);
    return use(seen,body,{...baseline,q:false,e:false,ultimate:false},record);
  }};
}

export async function exerciseMisdirection({adapter,view,owner,submit,fitting,rules,distance,equip,policy}){
  const deadline=Date.now()+180_000, beginning=view().combatTick, eventStart=adapter.events.length;
  const plans=[],tracks=new Map(),clocks=new Map();
  let lastShop=view().encounter,lastTick=-1;
  for(;;){
    const seen=view(), body=owner();
    const records=[...adapter.cues.values()].filter(row=>row.first.owner===adapter.id&&row.first.at>=beginning);
    const sounds=adapter.events.slice(eventStart).filter(e=>e.type==='sound'&&e.owner===adapter.id&&e.id.startsWith('bard-entrance-')).map(e=>e.id);
    if(Date.now()>=deadline||['victory','defeat'].includes(seen.phase))assert.fail(JSON.stringify({fitting,phase:seen.phase,boss:seen.boss.id,
      tick:seen.combatTick,plans:plans.slice(-24),cues:records.slice(-7),sounds,hp:body.health}));
    if(seen.phase!=='combat'){
      if(['mutationVote','contractVote','secretOffer'].includes(seen.phase))adapter.vote(0);
      if(seen.phase==='shop'&&seen.encounter!==lastShop){lastShop=seen.encounter;await equip();}
      await sleep(20);continue;
    }
    for(const row of records){
      const first=row.first,last=row.last;
      const targets=[...new Set(row.phases.flatMap(cue=>cue.target===undefined?[]:[cue.target]))];
      assert(row.phases.every(cue=>cue.id===first.id&&cue.until===first.until));
      if(targets.length){
        const actor=seen.minions.find(minion=>minion.id===last.target);
        const live=seen.classCues.some(cue=>cue.kind==='bard-false-entrance'&&cue.id===first.id&&cue.target===last.target&&cue.moved===last.moved);
        if(actor&&last.target!==undefined&&seen.combatTick>lastTick&&live){
          const key=`${first.id}/${last.target}/${last.moved===true}`;
          const list=tracks.get(key)??[];
          list.push({tick:seen.combatTick,actor:actor.id,distance:distance(actor,last),x:actor.x,y:actor.y});
          tracks.set(key,list);
        }
        const trace=tracks.get(`${first.id}/${targets.at(-1)}/${last.moved===true}`)??[];
        const walked=trace.length>1&&trace[0].distance-trace.at(-1).distance>3;
        const done=fitting==='entry'?targets.length===1&&walked:
          fitting==='wrong'?targets.length===1&&last.moved&&walked:
          targets.length===2&&last.repeats&&walked&&sounds.includes('bard-entrance-arrive');
        if(done){
          assert(first.until-first.at===rules.cueDuration&&row.phases.some(cue=>cue.armed));
          for(const event of ['set','arm','take'])assert(sounds.includes('bard-entrance-'+event));
          if(fitting==='wrong')assert(sounds.includes('bard-entrance-turn')&&distance(first,last)>=rules.turnMinimum);
          if(fitting==='second'){
            assert(sounds.includes('bard-entrance-second'));
            assert.deepEqual([first.x,first.y],[last.x,last.y]);
          }
          const paid=clocks.get(first.id);
          assert(paid&&paid.e===body.eAt&&paid.u===body.ultimateAt);
          return {stage:row,targets,trace,paid,sounds,plans:plans.slice(-30),boss:seen.boss.id};
        }
      }
      if(!clocks.has(first.id))clocks.set(first.id,{ e:body.eAt,u:body.ultimateAt });
    }
    if(seen.combatTick===lastTick){await sleep(10);continue;}
    lastTick=seen.combatTick;
    const input=body.status==='active'?policy.invoke(seen,body,row=>plans.push(row)):{interact:true};
    await submit(input);
    adapter.allyCover?.();
  }
}
