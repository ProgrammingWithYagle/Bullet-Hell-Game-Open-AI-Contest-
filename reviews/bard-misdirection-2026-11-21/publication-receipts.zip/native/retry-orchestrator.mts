import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { closeSync, existsSync, mkdirSync, openSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { setTimeout as sleep } from 'node:timers/promises';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';
import { verifyNativeCase } from './verify-native-case.mjs';

const [priorName,outName,driverName='native-study.mts'] = process.argv.slice(2);
assert(/^frozen\d\d$/.test(priorName)&&/^frozen\d\d$/.test(outName)&&priorName!==outName);
assert(/^[a-z][a-z0-9-]+\.mts$/.test(driverName));
const here = file=>fileURLToPath(new URL('./'+file,import.meta.url));
const priorDir=here(priorName), output=here(outName), driver=here(driverName);
assert(!existsSync(output));
const prior=readJson(join(priorDir,'frozen-verification.json'));
const source=readJson(here('source-commit01.json'));
const scope='reviews/bard-misdirection-2026-11-21';
const hash=path=>sha256(readFileSync(path));
assert(!prior.passed&&prior.protocol===95&&prior.sourceCommit===source.sourceCommit&&prior.contentRevision===source.contentRevision);
assert.equal(hash(here('native-study.mts')),prior.nativeDriverSha256);
assert.equal(prior.audiences.length,2);
assert(prior.audiences.every(row=>row.caseCount===7));
const httpEvidenceFolder=prior.httpEvidenceFolder??priorName;
assert(/^frozen\d\d$/.test(httpEvidenceFolder));
mkdirSync(output);

async function get(url) {
  const response=await fetch(url,{signal:AbortSignal.timeout(8_000)});
  assert.equal(response.status,200);
  return response.json();
}
async function health(preview,expected) {
  const row=await get(preview.endpoint+'/api/health');
  assert(row.status==='ok'&&row.startedAt===expected&&row.protocolVersion===95&&row.contentRevision===prior.contentRevision);
  assert.equal(row.sourceCommit,prior.sourceCommit);
  return row;
}
async function idle(preview) {
  const limit=Date.now()+90_000;
  for (;;) {
    const row=await get(preview.endpoint+'/api/metrics');
    if (row.rooms===0&&row.connections===0) return row;
    assert(Date.now()<limit,'The earlier test room still has live activity.');
    await sleep(250);
  }
}
function launch(args,log) {
  const descriptor=openSync(log,'wx');
  return new Promise<number|null>((resolve,reject)=>{
    const task=spawn(process.execPath,['--import','tsx',driver,...args],
      {cwd:checkout,stdio:['ignore',descriptor,descriptor],windowsHide:true});
    const timer=setTimeout(()=>task.kill(),420_000);
    task.once('error',error=>{clearTimeout(timer);closeSync(descriptor);reject(error);});
    task.once('exit',code=>{clearTimeout(timer);closeSync(descriptor);resolve(code);});
  });
}

const audiences=[];
let retriedCases=0;
for (const previous of prior.audiences) {
  const name=previous.audience;
  assert(name==='testing'||name==='public');
  const preview=readJson(join(checkout,scope,'preview-'+name+'.json'));
  assert.equal(preview.manifestSha256,previous.manifestSha256);
  assert.equal(hash(preview.manifestPath),previous.manifestSha256);
  assert.equal(hash(preview.backend.path),previous.backendSha256);
  assert.equal(hash(join(checkout,scope,'smoke-'+name+'.json')),previous.httpSha256);
  assert.equal(hash(here(httpEvidenceFolder+'/'+name+'-http.log')),previous.httpLogSha256);
  const workerPath=join(preview.root,previous.worker.path);
  assert.equal(hash(workerPath),previous.worker.sha256);
  await health(preview,previous.backendStartedAt);
  await idle(preview);
  const cases=[];
  for (const original of previous.cases) {
    const oldFolder=original.folder??priorName;
    assert(/^frozen\d\d$/.test(oldFolder));
    assert.equal(hash(here(oldFolder+'/'+original.log)),original.logSha256);
    if (original.passed) {
      assert.equal(hash(here(oldFolder+'/'+original.raw)),original.resultSha256);
      cases.push({...original,folder:oldFolder});
      continue;
    }
    retriedCases++;
    const {transport,fitting}=original, stem=name+'-'+transport+'-'+fitting;
    const log=join(output,stem+'.log'), raw=join(output,stem+'.json');
    const endpoint=transport==='worker'?workerPath:preview.endpoint;
    const status=await launch([transport,fitting,raw,endpoint,name],log);
    await health(preview,previous.backendStartedAt);
    const response=existsSync(raw)?readJson(raw):undefined;
    let passed=status===0&&response?.passed===true;
    let error;
    if (passed) {
      try {
        assert.equal(response.testedAudience,name);
        verifyNativeCase(response,{transport,fitting,revision:prior.contentRevision,driver:hash(driver),worker:previous.worker.sha256});
      } catch (failure) { passed=false;error=String(failure); }
    }
    cases.push({...original,passed,status,error,folder:outName,logSha256:hash(log),raw:response?stem+'.json':undefined,
      resultSha256:response?hash(raw):undefined,backendStartedAt:previous.backendStartedAt});
    console.log(JSON.stringify({audience:name,transport,fitting,passed,status,error}));
    await idle(preview);
  }
  const metrics=await idle(preview);
  await health(preview,previous.backendStartedAt);
  const next={...previous,passed:cases.every(row=>row.passed),cases,remainingProbeRooms:metrics.rooms,
    remainingProbeConnections:metrics.connections};
  receipt(join(output,'result-'+name+'.json'),next);
  audiences.push(next);
}
assert(retriedCases>0);
const passed=audiences.every(row=>row.passed);
const retryHelpers=driverName==='retry-wrong-door.mts'?Object.fromEntries(
  ['wrong-door-retry-flow.mts','wrong-door-retry-pilot.mjs'].map(name=>[name,hash(here(name))])):undefined;
receipt(join(output,'frozen-verification.json'),{...prior,passed,audiences,checkedAt:new Date().toISOString(),previousAttempt:priorName,
  httpEvidenceFolder,retryDriver:driverName,retryDriverSha256:hash(driver),retryHelpers,retriedCases});
console.log(JSON.stringify({passed,retriedCases,audiences:audiences.map(row=>row.passed)}));
if (!passed) process.exitCode=1;
