const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const point = (from,angle,distance) => ({x:from.x+Math.cos(angle)*distance,y:from.y+Math.sin(angle)*distance});

export function misdirectionPilot({game,rules,distance,segmentRect,clearTrialWalk,danger,policy,exercise=false}) {
  let origin, nextCast=0, lastCue;
  return (view,body,routine,record) => {
    const state=body.kit.misdirecting, now=view.combatTick;
    const terrain={...game.arena,obstacles:game.obstacles,tick:now};
    const clear=(a,b,pad=4)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,pad));
    const free=view.minions.filter(actor=>actor.kind==='ordinary'&&actor.goalX===undefined&&actor.speed>0&&actor.damage>0&&actor.health>0);
    const others=view.players.filter(row=>row.id!==body.id&&row.status==='active');
    const nearest=(actor,from)=>others.every(row=>distance(actor,row)>distance(actor,from));
    const cue=view.classCues.find(row=>row.kind==='bard-false-entrance'&&row.owner===body.id);
    function candidate(actor,at,from){
      return distance(actor,from)>actor.radius+50&&distance(actor,from)<rules.hearOwner-6&&
        distance(actor,at)>actor.radius+rules.arrive+7&&distance(actor,at)<rules.radius-3&&nearest(actor,from)&&clear(actor,at,actor.radius+1);
    }
    if(body.health<body.maxHealth*.26||danger(view,body,4))return routine;
    if(!state||state.phase==='idle'){
      if(body.kit.cadence<rules.cadence||now<nextCast||now<(state?.until??0)||!free.length||routine.dodge)return routine;
      const proposals=[];
      for(const actor of free.filter(actor=>distance(actor,body)>95&&distance(actor,body)<rules.hearOwner+12)){
        const direct=bearing(body,actor);
        for(const offset of [.62,-.62,.82,-.82,1.05,-1.05,.45,-.45]){
          const aim=direct+offset, site=point(body,aim,rules.reach);
          if(!clearTrialWalk(terrain,body,site)||!candidate(actor,site,body))continue;
          const walk=direct-offset*1.6, escape=point(body,walk,rules.walked+10);
          if(!clearTrialWalk(terrain,body,escape)||danger(view,escape,8)||!nearest(actor,escape))continue;
          proposals.push({aim,site,escape,actor,weight:distance(actor,site)+distance(body,actor)*.4});
        }
      }
      const choice=proposals.sort((a,b)=>a.weight-b.weight)[0];
      if(!choice)return routine;
      origin={x:body.x,y:body.y,escape:choice.escape,at:now};
      nextCast=now+5;
      record({action:'set',at:now,from:{x:body.x,y:body.y},point:choice.site,escape:choice.escape,initialActor:choice.actor.id});
      return {technique3:true,aim:choice.aim,fire:routine.fire};
    }
    if(!cue)return routine;
    if(lastCue!==cue.id){lastCue=cue.id;nextCast=now+5;}
    const active={...routine,q:false,e:false,ultimate:false,sprint:false};
    if(state.phase==='walk'&&origin&&distance(body,origin.escape)>4){
      const aim=bearing(body,origin.escape), next=point(body,aim,16);
      if(clearTrialWalk(terrain,body,next)&&!danger(view,next,4))return {...active,moveX:Math.cos(aim),moveY:Math.sin(aim),fire:true,dodge:false};
    }
    if(state.phase==='distracting'&&origin&&policy==='wrong'&&body.skills.includes('bard-misdirection-wrong-door-1')&&
      !cue.moved&&body.kit.cadence>=1){
      const quarry=free.find(actor=>actor.id===state.target), initial=bearing(origin,cue);
      if(quarry){
        const choices=[.36,-.36,.45,-.45,.54,-.54,.65,-.65,.76,-.76].flatMap(offset=>{
          const aim=initial+offset, spot=point(origin,aim,rules.reach);
          const run=distance(spot,quarry);
          return run>=quarry.radius+rules.arrive+26&&run<=quarry.radius+rules.arrive+112&&
            distance(spot,body)<rules.hearOwner&&clearTrialWalk(terrain,body,spot)&&clear(quarry,spot,quarry.radius)&&
            (exercise||distance(spot,body)>distance(cue,body)+14)?[{aim,spot}]:[];
        }).sort((a,b)=>Math.abs(distance(a.spot,quarry)-77)-Math.abs(distance(b.spot,quarry)-77));
        if(choices.length){
          record({action:'turn',at:now,target:quarry.id,point:choices[0].spot});
          return {technique3:true,aim:choices[0].aim};
        }
      }
    }
    if(state.phase==='second'&&policy==='second'&&state.ready&&free.some(actor=>candidate(actor,cue,body))){
      record({action:'second',at:now,point:{x:cue.x,y:cue.y}});
      return {technique3:true,aim:body.aim};
    }
    return state.phase==='distracting'||state.phase==='second'?active:routine;
  };
}
