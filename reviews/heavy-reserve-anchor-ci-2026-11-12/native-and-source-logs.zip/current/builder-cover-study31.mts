import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { root, stage, issuedReview, read, write, sha, fingerprints, git } from './common.mjs';
import { scope, source } from './publication.mjs';

process.chdir(root);
const commit = source();
assert.equal(git('rev-parse', 'HEAD'), commit);
const before = fingerprints(), proof = read(scope + '/source-verification.json');
assert.equal(proof.sourceSnapshotSha256, before.sourceSnapshotSha256);
assert.equal(proof.runtimeSourceSha256, before.runtimeSourceSha256);
const { Game, data } = await import(pathToFileURL(root + '/src/shared/game.ts').href);
const { HZ, idleInput } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { segmentRect } = await import(pathToFileURL(root + '/src/shared/geometry.ts').href);
const { lineworkIds, heavyLineworkRules } = await import(pathToFileURL(root + '/src/shared/heavy-linework.ts').href);
const { constructHit } = await import(pathToFileURL(root + '/src/shared/class-kits.ts').href);
const { builderIds, builderPoseLegal } = await import(pathToFileURL(root + '/src/shared/engineer-builder.ts').href);
const { engineerRules, chargeLegal } = await import(pathToFileURL(root + '/src/shared/engineer-pathways.ts').href);

const studied = read(issuedReview + '/reserve-geometry.json').rows.filter(row => row.passed && row.difficulty === 'normal');
const point = (actor) => ({ x: actor.x, y: actor.y });
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const eye = (line) => ({ x: line.origin.x + 1.25 * line.normal.x, y: line.origin.y + 1.25 * line.normal.y });

function screenPlacement(game, heavy, first, alternate) {
  const from = point(heavy), end = eye(first), other = eye(alternate);
  const facing = Math.atan2(end.y - from.y, end.x - from.x);
  const terrain = { bounds: game.arena.bounds, lava: game.arena.lavaPits };
  const ctx = { obstacles: game.obstacles, terrain };
  const radius = data.rules.playerRadius;
  for (const fraction of [0.5, 0.65, 0.35, 0.8]) for (let turn = 0; turn < 8; turn++) {
    const aim = facing + turn * Math.PI / 4;
    const pose = { x: from.x + fraction * (end.x - from.x), y: from.y + fraction * (end.y - from.y), aim, halfSpan: engineerRules.builderHalfSpan };
    const engineer = { x: pose.x - Math.cos(aim) * engineerRules.builderReach, y: pose.y - Math.sin(aim) * engineerRules.builderReach };
    if (engineer.x - radius < terrain.bounds.x || engineer.y - radius < terrain.bounds.y ||
      engineer.x + radius > terrain.bounds.x + terrain.bounds.width || engineer.y + radius > terrain.bounds.y + terrain.bounds.height) continue;
    if (ctx.obstacles.some(rect => segmentRect(engineer, engineer, rect, radius))) continue;
    if (!builderPoseLegal(pose, ctx) || !chargeLegal(pose, engineer, ctx)) continue;
    const shape = { kind: 'wall', ...pose };
    if (constructHit(from, end, shape, 1) === null || constructHit(from, other, shape, 1) !== null) continue;
    return { pose, engineer };
  }
}

function trial(row, earlySelection) {
  const game = new Game({ mode: 'short', seed: 41, maxPlayers: 2, openingArenaId: row.arena,
    arenaSelection: 'fixed', difficulty: row.difficulty });
  const heavy = game.addPlayer('heavy', 'Hux', 'heavy');
  const engineer = game.addPlayer('engineer', 'Tamsin', 'engineer');
  const buy = (player, item) => assert(game.transact(player.id, { id: item, kind: 'skill', item }).ok, item);
  buy(heavy, 'heavy-ordnance-1');
  buy(heavy, lineworkIds.entry);
  heavy.totalSp = 15;
  buy(heavy, lineworkIds.reserve);
  buy(engineer, 'engineer-constructs-1');
  buy(engineer, builderIds.entry);
  assert(game.start());
  let sequence = 0;
  const step = (heavyInput = {}, engineerInput = {}) => {
    sequence++;
    for (const [actor, input] of [[heavy, heavyInput], [engineer, engineerInput]] as const) {
      assert(game.submitInput(actor.id, { ...idleInput(), clientTick: game.combatTick, sequence, ...input }));
    }
    game.step();
    game.drainEvents();
  };
  const line = () => game.kitStatus(heavy.id).lineworkConnection;
  for (let tick = 0; distance(heavy, row.setup) > 0.6 && tick < 55; tick++) {
    const length = Math.max(distance(heavy, row.setup), game.movementSpeed(heavy) / HZ);
    step({ aim: row.selected.a.aim, moveX: (row.setup.x - heavy.x) / length, moveY: (row.setup.y - heavy.y) / length });
  }
  assert(distance(heavy, row.setup) <= 0.6);
  const ammo = heavy.ammo;
  step({ aim: row.selected.a.aim, technique1: true });
  for (let tick = 0; !line() && tick < heavyLineworkRules.flightTicks; tick++) step();
  assert(line());
  const original = line()!, recovery = game.kitStatus(heavy.id).lineworkRecovery;
  step({ aim: row.selected.b.aim, technique3: true });
  for (let tick = 0; !line()?.reserve && tick < heavyLineworkRules.flightTicks; tick++) step();
  const alternate = line()?.reserve;
  assert(alternate);
  const placement = screenPlacement(game, heavy, original, alternate);
  assert(placement, 'No valid same-screen comparison found for this pair');
  // Controlled placement isolates the route decision. Deploy, assembly, contacts and motion are real commands.
  Object.assign(engineer, placement.engineer);
  step({}, { aim: placement.pose.aim, q: true });
  const screen = game.classCues().find(cue => cue.kind === 'wall' && cue.owner === engineer.id && cue.builder);
  assert(screen && game.combatTick < screen.buildingUntil);
  assert(line()?.reserve && !line().active);
  if (earlySelection) {
    step({ aim: row.selected.b.aim, technique3: true });
    assert(line()?.reserveSelected && !line().active);
  } else step();
  const start = point(heavy);
  while (game.combatTick < screen.buildingUntil + 1) step();
  assert(constructHit(start, eye(original), screen, 1) !== null);
  assert.equal(constructHit(start, eye(alternate), screen, 1), null);
  step({ technique2: true });
  for (let tick = 0; tick < 8; tick++) step();
  const movedTowardReserve = distance(start, alternate.origin) - distance(heavy, alternate.origin);
  if (earlySelection) {
    assert(line()?.reserveSelected && line().active);
    assert.equal(line().until, original.until);
    assert(movedTowardReserve > 20);
  } else {
    assert.equal(line(), undefined);
    assert.equal(movedTowardReserve, 0);
  }
  assert.equal(heavy.ammo, ammo - 2);
  assert.equal(game.kitStatus(heavy.id).lineworkRecovery, recovery);
  return { firstAnchor: original.origin, reserveAnchor: alternate.origin, screen: point(screen), buildTick: screen.buildingUntil,
    originalUntil: original.until, recovery, paidRounds: ammo - heavy.ammo, movedTowardReserve, actualLineSurvived: !!line() };
}

const rows = [];
for (const row of studied) for (const earlySelection of [false, true]) {
  try { rows.push({ arena: row.arena, difficulty: row.difficulty, earlySelection, passed: true, ...trial(row, earlySelection) }); }
  catch (error) { rows.push({ arena: row.arena, difficulty: row.difficulty, earlySelection, passed: false, error: error.stack ?? String(error) }); }
}
assert.deepEqual(fingerprints(), before);
const passed = rows.filter(row => row.passed).length;
write(stage + '/builder-cover-study31.json', { measuredAt: new Date().toISOString(), sourceCommit: commit,
  runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256,
  driverSha256: sha(fs.readFileSync(new URL(import.meta.url))), rows, passed,
  scope: 'Controlled local shared Game comparison. Hux uses controlled 15 earned SP and Tamsin uses the ordinary 3-SP purchase. Engineer placement isolates geometry. Actual build completion, line contact, separate selector and motor use normal authority and combat clocks.' });
console.log(JSON.stringify({ passed, total: rows.length, failures: rows.filter(row => !row.passed).map(row => [row.arena, row.earlySelection, row.error.split('\n')[0]]) }));
