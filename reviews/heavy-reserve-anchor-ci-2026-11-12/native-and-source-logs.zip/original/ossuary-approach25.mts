import assert from 'node:assert/strict';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import { root, stage, read, write, sha, fingerprints } from './common.mjs';

process.chdir(root);
const proof = read(stage + '/reserve-applied07.json'), before = fingerprints();
assert.equal(proof.revision, read('content/revision.json').sha256);
const { Game, data } = await import(pathToFileURL(root + '/src/shared/game.ts').href);
const { idleInput, HZ } = await import(pathToFileURL(root + '/src/shared/protocol.ts').href);
const { viewOf } = await import(pathToFileURL(root + '/src/shared/view.ts').href);
const { segmentCircle, segmentRect } = await import(pathToFileURL(root + '/src/shared/geometry.ts').href);
const { restRaidInput } = await import(pathToFileURL(root + '/tests/helpers/sniper-rest-raid-policy.ts').href);
const geometry = read('reviews/heavy-lineworker-entry-2026-11-12/reserve-geometry.json');
const id = 'heavy-linework-reserve-1';
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
const point = p => ({ x: p.x, y: p.y });
const angle = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);

function approachRoute(g, start, goal) {
  const clearance = data.rules.playerRadius;
  const b = g.arena.bounds;
  const walls = g.obstacles;
  const inside = p => p.x > b.x + clearance && p.y > b.y + clearance &&
    p.x < b.x + b.width - clearance && p.y < b.y + b.height - clearance;
  const clear = (a, b) => !walls.some(wall => segmentRect(a, b, wall, clearance + 0.2));
  const nodes = [start, goal];
  for (const wall of walls) for (const sx of [-1, 1]) for (const sy of [-1, 1]) {
    const p = { x: wall.x + (sx > 0 ? wall.width : 0) + sx * (clearance + 4),
      y: wall.y + (sy > 0 ? wall.height : 0) + sy * (clearance + 4) };
    if (inside(p) && clear(p, p)) nodes.push(p);
  }
  const costs = nodes.map(() => Infinity), predecessor = nodes.map(() => -1), visited = new Set();
  costs[0] = 0;
  for (;;) {
    let next = -1;
    for (let n = 0; n < nodes.length; n++) if (!visited.has(n) && (next < 0 || costs[n] < costs[next])) next = n;
    if (next < 0 || !Number.isFinite(costs[next])) return [];
    if (next === 1) break;
    visited.add(next);
    for (let n = 1; n < nodes.length; n++) {
      const cost = costs[next] + distance(nodes[next], nodes[n]);
      if (cost < costs[n] && clear(nodes[next], nodes[n])) {
        costs[n] = cost;
        predecessor[n] = next;
      }
    }
  }
  const route = [];
  for (let n = 1; n > 0; n = predecessor[n]) route.unshift(nodes[n]);
  return route;
}

function trial(arena, difficulty, seed, useReserve, seekFiringLane) {
  const g = new Game({ mode: 'short', difficulty, seed, maxPlayers: 1, openingArenaId: arena, arenaSelection: 'fixed' });
  const p = g.addPlayer('solo', 'Earned reserve study', 'heavy');
  const observed = new Map(), operations = [], clears = [], purchases = [], states = [];
  let serial = 0, sequence = 0, phase = '', cleared = 0, attempted = false, probe;
  let operation, stageAt = 0, route = [], plan, castOrigin, motorStart, first, alternate;
  let nextPlanAt = 0, approach = [];
  const approaches = [];
  const clearShot = (from, to) => !g.obstacles.some(wall => segmentRect(from, to, wall, 3));
  const note = (kind, fields = {}) => operations.push({ kind, tick: g.combatTick, position: point(p), health: p.health, ammo: p.ammo, ...fields });
  const buy = (kind, item) => {
    const result = g.transact(p.id, { id: 'reserve-study-' + ++serial, kind, item });
    if (result.ok) purchases.push({ kind, item, encounter: g.encounter, earned: p.totalSp });
    return result;
  };
  function shop() {
    if (!p.skills.includes('heavy-ordnance-1')) assert(buy('skill', 'heavy-ordnance-1').ok);
    if (!p.skills.includes('heavy-linework-1')) assert(buy('skill', 'heavy-linework-1').ok);
    if (g.encounter === 1 && useReserve) {
      const before = { total: p.totalSp, skills: [...p.skills], coins: p.coins };
      probe = buy('skill', id);
      assert(!probe.ok);
      assert.deepEqual({ total: p.totalSp, skills: [...p.skills], coins: p.coins }, before);
    }
    if (g.encounter === 2 && useReserve) {
      assert.equal(p.totalSp, 15);
      assert(buy('skill', id).ok);
    }
    if (g.encounter > 0 && !p.skills.includes('general-sprint')) buy('skill', 'general-sprint');
    if (g.encounter > 1 && !p.skills.includes('general-double-dash')) buy('skill', 'general-double-dash');
    for (const weapon of data.weapons.filter(w => w.classId === 'heavy').sort((a, b) => b.tier - a.tier)) {
      if (p.weapon === weapon.id || buy('weapon', weapon.id).ok) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy('upgrade', item);
    buy('supply', 'medkit');
  }
  assert.equal(p.totalSp, 3);
  shop();
  assert(g.start());

  function switchTo(value) { operation = value; stageAt = g.combatTick; }
  const walk = to => {
    const length = Math.max(distance(p, to), g.movementSpeed(p) / HZ);
    return { aim: angle(p, to), moveX: (to.x - p.x) / length, moveY: (to.y - p.y) / length };
  };
  function fireFromClearGround(view, ordinary) {
    if (!seekFiringLane || clearShot(p, view.boss)) {
      approach = [];
      return ordinary;
    }
    while (approach.length && distance(p, approach[0]) <= 0.8) approach.shift();
    if (!approach.length && g.combatTick >= nextPlanAt) {
      nextPlanAt = g.combatTick + 30;
      const boss = view.boss, radius = data.rules.playerRadius;
      let shortest = Infinity;
      for (const length of [185, 260, 330]) for (let turn = 0; turn < 16; turn++) {
        const angle = turn * Math.PI / 8;
        const destination = { x: boss.x + Math.cos(angle) * length, y: boss.y + Math.sin(angle) * length };
        if (!clearShot(destination, boss)) continue;
        const candidate = approachRoute(g, point(p), destination);
        if (!candidate.length) continue;
        let last = point(p), distanceAlongRoute = 0;
        for (const waypoint of candidate) {
          if (g.arena.lavaPits.some(lava => segmentCircle(last, waypoint, lava, lava.radius + radius) !== null)) {
            distanceAlongRoute = Infinity;
            break;
          }
          distanceAlongRoute += distance(last, waypoint);
          last = waypoint;
        }
        if (distanceAlongRoute < shortest) {
          shortest = distanceAlongRoute;
          approach = candidate;
        }
      }
      if (approach.length) approaches.push({ tick: g.combatTick, encounter: g.encounter, from: point(p), boss: point(view.boss), waypoints: structuredClone(approach), length: shortest });
    }
    if (!approach.length) return ordinary;
    const { moveX, moveY } = walk(approach[0]);
    return { ...ordinary, moveX, moveY, e: false };
  }
  function reserveControl(kit) {
    const line = kit.lineworkConnection;
    if (!operation) return;
    if (g.combatTick - stageAt > (operation === 'approach' ? 150 : 25)) {
      note('approach-or-command-bound', { operation }); switchTo(undefined); return;
    }
    if (operation === 'approach') {
      while (route.length && distance(p, route[0]) <= 0.8) route.shift();
      if (route.length) return walk(route[0]);
      castOrigin = point(p); switchTo('first-flight'); note('manual-first-cast');
      return { aim: plan.selected.a.aim, technique1: true };
    }
    if (operation === 'first-flight') {
      if (!line) return {};
      first = line.origin;
      note('first-anchor', { from: castOrigin, anchor: first, originalUntil: line.until });
      if (useReserve) {
        switchTo('reserve-flight');
        return { aim: plan.selected.b.aim, technique3: true };
      }
      alternate = first;
      motorStart = point(p); switchTo('haul'); return { technique2: true };
    }
    if (operation === 'reserve-flight') {
      if (!line) { note('lost-first-anchor-during-flight'); switchTo(undefined); return; }
      if (!line.reserve) return {};
      alternate = line.reserve.origin;
      assert(distance(first, alternate) >= 100);
      assert.equal(line.reserve.until, line.until);
      note('paid-reserve-attachment', { first, alternate, originalUntil: line.until });
      switchTo('selected'); return { technique3: true };
    }
    if (operation === 'selected') {
      if (!line?.reserveSelected) { note('reserve-selection-unavailable'); switchTo(undefined); return; }
      note('selected-reserve', { anchor: line.origin, originalUntil: line.until });
      motorStart = point(p); switchTo('haul'); return { technique2: true };
    }
    if (operation === 'haul') {
      if (!line) { note('line-lost-during-haul'); switchTo(undefined); return; }
      if (g.combatTick - stageAt < 8) return {};
      note('actual-haul', { distance: distance(p, motorStart), towardSelected: distance(motorStart, alternate) - distance(p, alternate),
        towardFirst: distance(motorStart, first) - distance(p, first), originalUntil: line.until });
      switchTo(undefined); return { technique1: true };
    }
  }

  while (g.tick < 50_000 && !['victory', 'defeat'].includes(g.phase)) {
    if (phase !== g.phase) {
      phase = g.phase;
      states.push({ phase, encounter: g.encounter, tick: g.tick, earned: p.totalSp });
      if (phase === 'shop') shop();
      if (phase === 'combat') {
        observed.clear();
        nextPlanAt = 0;
        approach = [];
        switchTo(undefined);
        if (g.encounter === 2 && !attempted) {
          attempted = true;
          plan = geometry.rows.find(row => row.arena === g.currentArenaId && row.difficulty === difficulty && row.passed);
          route = plan ? approachRoute(g, point(p), plan.setup) : [];
          if (route.length) { note('route-start', { route: structuredClone(route) }); switchTo('approach'); }
          else note('no-current-route');
        }
      }
    }
    if (['mutationVote', 'contractVote', 'secretOffer'].includes(phase)) g.vote(p.id, 0);
    if (phase === 'combat') {
      const view = viewOf(g, p.id), actor = view.players.find(player => player.id === p.id);
      const input = reserveControl(actor.kit) ?? fireFromClearGround(view, restRaidInput(view, actor, [...observed.values()]));
      assert(g.submitInput(p.id, { ...idleInput(), ...input, sequence: ++sequence, clientTick: g.combatTick }));
    }
    g.step();
    for (const event of g.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) observed.set(shot.id, { ...shot, seenAt: g.combatTick });
      if (event.type === 'remove') for (const shot of event.ids) observed.delete(shot);
    }
    if (p.progress.clears > cleared) {
      cleared = p.progress.clears;
      clears.push({ actualClears: cleared, earned: p.totalSp, tick: g.combatTick });
    }
  }
  assert(['victory', 'defeat'].includes(g.phase));
  return { arena, difficulty, seed, useReserve, seekFiringLane, approaches, terminalCombatTick: g.combatTick, outcome: g.phase, clears, purchases, operations, phaseStates: states,
    earlyProbe: probe, finalSpent: p.skills.reduce((sum, skill) => sum + g.skillCost(skill), 0), finalEarned: p.totalSp,
    damageTaken: p.damageTaken, endingHealth: p.health };
}

const rows = [];
const arena = 'ossuary-works';
for (const difficulty of ['baby', 'normal']) for (const seed of [41, 73]) for (const seekFiringLane of [true]) for (const useReserve of [false, true]) {
  const row = trial(arena, difficulty, seed, useReserve, seekFiringLane);
  rows.push(row);
  console.log(JSON.stringify({ arena, difficulty, seed, useReserve, seekFiringLane, approaches: row.approaches.length, outcome: row.outcome, clears: row.clears.length,
    purchased: row.purchases.some(purchase => purchase.item === id), operations: row.operations.map(operation => operation.kind) }));
}
assert.deepEqual(fingerprints(), before);
write(stage + '/ossuary-approach25.json', { measuredAt: new Date().toISOString(), base: proof.base,
  contentRevision: proof.revision, runtimeSourceSha256: before.runtimeSourceSha256, sourceSnapshotSha256: before.sourceSnapshotSha256,
  driverSha256: sha(fs.readFileSync(new URL(import.meta.url))), rows,
  scope: 'Local comparison of a visible-cover firing-lane approach on Ossuary Works. The original policy and approach policy use identical source, shops, seeds and encounter rules. Only ordinary movement and timing of the existing brace command change. No injected positions, resources, checkpoint or clock changes.' });
