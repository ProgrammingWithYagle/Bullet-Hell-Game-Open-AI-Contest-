import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { closeSync, existsSync, mkdirSync, openSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const [commit, previous, target, driverArgument] = process.argv.slice(2);
assert(/^[0-9a-f]{40}$/.test(commit) && previous && target && !existsSync(target));
const driver = fileURLToPath(new URL(driverArgument ?? './native-study-retry01.mts', import.meta.url));
const frozen = readJson(join(previous, 'frozen-verification.json'));
const digest = path => sha256(readFileSync(path));
const scope = 'reviews/medic-field-surgery-2026-11-19';
const check = relative => join(checkout, scope, relative);
assert(!frozen.passed && frozen.sourceCommit === commit && frozen.protocol === 83 && frozen.audiences.length === 2);
assert.equal(dirname(resolve(target)), dirname(resolve(previous)));
mkdirSync(target);

async function http(url) {
  const response = await fetch(url, { signal: AbortSignal.timeout(10_000) });
  assert.equal(response.status, 200);
  return response;
}
function launch(args, log) {
  const fd = openSync(log, 'wx');
  return new Promise<number | null>((resolve, reject) => {
    const child = spawn(process.execPath, ['--import', 'tsx', driver, ...args],
      { cwd: checkout, windowsHide: true, stdio: ['ignore', fd, fd] });
    const timer = setTimeout(() => child.kill(), 240_000);
    child.once('error', error => { clearTimeout(timer); closeSync(fd); reject(error); });
    child.once('exit', status => { clearTimeout(timer); closeSync(fd); resolve(status); });
  });
}

async function retry(audience) {
  assert(['testing', 'public'].includes(audience.audience) && audience.cases.length === 6,
    'A full original matrix with HTTP receipts is required for a selective retry');
  const preview = readJson(check('preview-' + audience.audience + '.json'));
  const health = async () => {
    const row = await (await http(preview.endpoint + '/api/health')).json();
    assert(row.sourceCommit === commit && row.status === 'ok' && row.protocolVersion === 83);
    assert.equal(row.contentRevision, frozen.contentRevision);
    assert.equal(row.audience, audience.audience);
    assert.equal(row.startedAt, audience.backendStartedAt, 'All cases must reuse the same verified backend start');
    return row;
  };
  await health();
  assert.equal(digest(preview.manifestPath), audience.manifestSha256);
  assert.equal(digest(preview.backend.path), audience.backendSha256);
  const worker = join(preview.root, audience.worker.path);
  assert.equal(digest(worker), audience.worker.sha256);
  const served = await http(new URL(audience.worker.path, preview.url).href);
  assert.equal(sha256(Buffer.from(await served.arrayBuffer())), audience.worker.sha256);
  const cases = [];
  for (const prior of audience.cases) {
    const folder = prior.folder ?? resolve(previous).split(/[\\/]/).at(-1);
    assert(/^frozen\d\d$/.test(folder));
    const archive = join(dirname(previous), folder);
    assert.equal(digest(join(archive, prior.log)), prior.logSha256);
    if (prior.passed) {
      assert.equal(digest(join(archive, prior.raw)), prior.resultSha256);
      assert.equal(prior.backendStartedAt, audience.backendStartedAt);
      cases.push({ ...prior, folder });
      continue;
    }
    const { fitting, transport } = prior;
    const tag = audience.audience + '-' + transport + '-' + fitting;
    const log = tag + '.log', raw = tag + '.json';
    const status = await launch([transport, fitting, join(target, raw), transport === 'worker' ? worker : preview.endpoint,
      audience.audience], join(target, log));
    await health();
    const result = existsSync(join(target, raw)) ? readJson(join(target, raw)) : undefined;
    const passed = status === 0 && result?.passed === true;
    if (passed) {
      assert(result.protocol === 83 && result.contentRevision === frozen.contentRevision && result.testedAudience === audience.audience);
      assert(result.fitting === fitting && result.transport === transport && result.doses >= 2 && result.pausedCommandsDiscarded && result.noCheckpointImports);
      assert.deepEqual(result.bought.map(row => row.earned), fitting === 'entry' ? [3, 3] : [3, 3, 9]);
      if (transport === 'worker') assert(result.wholeOptimizedWorker && !result.workerPatched && result.workerSha256 === audience.worker.sha256);
      else assert(result.witnessed.nonHost && result.witnessed.ownedStatePrivate && result.witnessed.ownedSoundsPrivate);
    }
    cases.push({ fitting, transport, status, passed, folder: resolve(target).split(/[\\/]/).at(-1), log, logSha256: digest(join(target, log)),
      raw: result && raw, resultSha256: result && digest(join(target, raw)), backendStartedAt: audience.backendStartedAt,
      prior: { folder, log: prior.log, sha256: prior.logSha256 } });
    console.log(JSON.stringify({ audience: audience.audience, fitting, transport, passed, status }));
  }
  const until = Date.now() + 12_000;
  let metrics;
  do {
    metrics = await (await http(preview.endpoint + '/api/metrics')).json();
    if (metrics.rooms === 0 && metrics.connections === 0) break;
    await sleep(100);
  } while (Date.now() < until);
  await health();
  const passed = cases.every(row => row.passed) && metrics.rooms === 0 && metrics.connections === 0;
  const result = { ...audience, passed, cases, remainingProbeRooms: metrics.rooms, remainingProbeConnections: metrics.connections };
  receipt(join(target, 'result-' + audience.audience + '.json'), result);
  return result;
}
const results = await Promise.allSettled(frozen.audiences.map(retry));
const passed = results.every(row => row.status === 'fulfilled' && row.value.passed);
const report = { ...frozen, passed, checkedAt: new Date().toISOString(),
  retryDriver: driver.replaceAll('\\', '/').split('/').at(-1), retryDriverSha256: digest(driver),
  originalMatrixSha256: digest(join(previous, 'frozen-verification.json')),
  audiences: results.map(row => row.status === 'fulfilled' ? row.value : { passed: false, error: String(row.reason) }) };
receipt(join(target, 'frozen-verification.json'), report);
console.log(JSON.stringify({ passed, audiences: report.audiences.map(item => item.passed ? 'passed' : item.error ?? 'failed') }));
if (!passed) process.exitCode = 1;
