import assert from 'node:assert/strict';

export function checkGuideAcquisition(result, transport, fitting) {
  assert(result.passed);
  assert.equal(result.fitting, fitting);
  assert.equal(result.transport, transport);
  assert.deepEqual(result.actualEarnedSequence, [3, 9, 15]);
  assert.equal(result.actualClears, 2);
  assert.equal(result.originalLifetimeTicks, 150);
  assert.equal(result.spent, fitting === 'bare' ? 6 : 8);
  const { guide } = result;
  assert(guide.pausedRedirectDiscarded && guide.firstHaul > 45 && guide.towardOriginal > 8);
  assert.equal(guide.paidGuideRounds, 1);
  assert.equal(guide.originalUntil, guide.redirectedUntil);
  assert(guide.originalRecovery > guide.originalUntil);
  assert(Math.hypot(guide.guide.x - guide.masonryFoot.x, guide.guide.y - guide.masonryFoot.y) >= 11.9);
  assert.notEqual(result.firstAnchorId, result.secondAnchorId);
  assert.equal(result.payout, 0);
  if (fitting === 'yoke') assert(result.paidPrimaryProjectiles > 0);
  else assert.equal(result.paidPrimaryProjectiles, 0);
  const purchases = result.menuObservations.filter(row => row.item === 'heavy-linework-guide-1');
  assert.deepEqual(purchases.map(row => [row.earned, row.requests, row.before - row.after]), [[9, 0, 0], [15, 1, 3]]);
  const reserve = result.menuObservations.find(row => row.item === 'heavy-linework-reserve-1');
  assert(reserve?.earned === 15 && reserve.requests === 0 && reserve.before === reserve.after);
  if (transport === 'worker') assert(result.wholeOptimizedWorker && result.workerPatched === false);
  else assert(result.realPeers === 3 && result.heavyIsNonHost && result.ownerPrivateAnchorAndRemovals && result.sharedPhysicalContact);
}
