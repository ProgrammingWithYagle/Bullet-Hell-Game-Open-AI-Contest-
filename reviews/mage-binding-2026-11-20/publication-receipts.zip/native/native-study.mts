import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL } = await repoImport('src/shared/protocol.ts');
const { mageBindingIds, pivotSigilRules: rules } = await repoImport('src/shared/mage-pivot-sigil.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect } = await repoImport('src/shared/geometry.ts');

const [transport, fitting, out, supplied, testAudience = 'public'] = process.argv.slice(2);
assert(PROTOCOL === 87 && ['worker','peer'].includes(transport) && ['entry','fixed','reverse'].includes(fitting) && out);
const setup = { mode:'short', difficulty:'baby', arenaSelection:'fixed', openingArenaId:'gatehouse' } as const;
const point = ({ x,y }) => ({ x,y });
const bearing = (from,to) => Math.atan2(to.y-from.y,to.x-from.x);
const heading = angle => Math.atan2(Math.sin(angle),Math.cos(angle));
const step = (p,angle,reach) => ({ x:p.x+Math.cos(angle)*reach,y:p.y+Math.sin(angle)*reach });
const closeHealth = (view,id) => view?.players.find(player => player.id === id);
const spending = p => p.skills.reduce((sum,id) => sum+[...data.specializationSkills,...data.skills].find(row => row.id === id).cost,0);

async function wait(truth, detail, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(8);
  }
}
function pilotState() {
  return { events: [], observed: new Map(), cues: new Map() };
}
function recordCues(cues, view) {
  for (const cue of view.classCues) if (cue.kind.startsWith('mage-pivot-')) cues.set(cue.kind + ':' + cue.id, cue);
}

function inside(world,p,padding) {
  const bounds = world.bounds;
  return p.x >= bounds.x+padding && p.y >= bounds.y+padding &&
    p.x <= bounds.x+bounds.width-padding && p.y <= bounds.y+bounds.height-padding;
}
function visible(world,from,to,padding) {
  return !world.obstacles.some(wall => segmentRect(from,to,wall,padding));
}
function floor(world,from,pivot) {
  const radius = rules.markRadius + 1;
  return inside(world,pivot,radius) && visible(world,pivot,pivot,radius) && visible(world,from,pivot,3) &&
    world.lavaPits.every(pit => distance(pit,pivot) > pit.radius+radius);
}
function clearRay(world,from,angle) {
  const end = step(from,angle,rules.shortestStroke+2);
  return inside(world,end,rules.halfWidth+1) && visible(world,from,end,rules.halfWidth+1);
}
function targets(view) {
  return [view.boss,...view.minions].filter(target => target.health > 0);
}
function strokePlan(world,view,pivot) {
  for (const target of targets(view)) {
    const length = distance(pivot,target);
    if (length < 28 || length > rules.reach-12 || !visible(world,pivot,target,rules.halfWidth)) continue;
    const final = bearing(pivot,target);
    const turn = fitting === 'reverse' ? final+Math.PI : final;
    const offset = fitting === 'reverse' ? .75 : fitting === 'fixed' ? .56 : .30;
    const initial = [turn-offset,turn+offset].find(angle => clearRay(world,pivot,angle));
    if (initial !== undefined && clearRay(world,pivot,turn)) return { initial:heading(initial), turn:heading(turn), target:point(target) };
  }
}

function markPlan(world,view,p) {
  for (const target of targets(view).sort((a,b) => distance(p,a)-distance(p,b))) {
    const gap = distance(p,target);
    if (gap < 112 || gap > 245) continue;
    const axis = bearing(p,target);
    for (const offset of [0,.28,-.28,.48,-.48,.73,-.73,.96,-.96]) {
      const aim = heading(axis+offset), pivot = step(p,aim,rules.markReach);
      if (floor(world,p,pivot) && strokePlan(world,view,pivot)) return { aim,pivot };
    }
  }
}

function moveToLane(world,view,p) {
  const away = bearing(view.boss,p);
  const spots = [172,195,216].flatMap(reach => [0,.42,-.42,.79,-.79,1.10,-1.10,1.60,-1.60,2.1,-2.1,Math.PI]
    .map(offset => step(view.boss,away+offset,reach)));
  const lane = spots.filter(goal => distance(p,goal) > 7 && clearTrialWalk(world,p,goal) && markPlan(world,view,goal))
    .sort((a,b) => distance(p,a)-distance(p,b))[0];
  const aim = bearing(p,lane ?? view.boss);
  for (const angle of [aim,aim+.6,aim-.6,aim+1.1,aim-1.1,aim+1.7,aim-1.7]) {
    if (clearTrialWalk(world,p,step(p,angle,21))) return { moveX:Math.cos(angle),moveY:Math.sin(angle),aim:heading(aim) };
  }
  return { aim:heading(aim) };
}

async function earnedFlow(adapter) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const p = closeHealth(view(),adapter.id); assert(p); return p; };
  const status = () => owner().kit.pivotSigil;
  const ownedCue = (kind,id?) => view().classCues.find(cue => cue.kind === 'mage-pivot-'+kind && cue.owner === adapter.id &&
    (id === undefined || cue.id === id));
  const notes = (from,event) => adapter.events.slice(from).filter(e => e.type === 'sound' && e.id === 'mage-pivot-'+event && e.owner === adapter.id);
  const purchased = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind:'skill',item });
    assert(result.ok,JSON.stringify({ item,result }));
    purchased.push({ item,earned:owner().sp+spending(owner()),clears:owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(row => row.classId === 'mage').sort((a,b) => b.tier-a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind:'weapon',item:weapon.id })).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({ kind:'upgrade',item });
  }
  async function submit(input) {
    const sequence = adapter.input(input);
    await wait(() => owner().ack >= sequence,'Ordinary control is acknowledged');
  }

  const isFitted = fitting !== 'entry';
  assert.equal(owner().sp,3);
  await buy('mage-control-1');
  await buy(mageBindingIds.entry);
  if (isFitted) assert(!(await adapter.purchase({ kind:'skill',item:mageBindingIds[fitting] })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat','The ordinary opening encounter begins');
  if (isFitted) {
    const shopLimit = Date.now()+135_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase),'Reach the first shop after an ordinary clear');
      if (view().phase === 'combat') {
        adapter.input(restRaidInput(view(),owner(),[...adapter.observed.values()]));
        adapter.allyPressure?.();
      } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(owner().sp+spending(owner()),9);
    await buy(mageBindingIds[fitting]);
    const other = fitting === 'fixed' ? mageBindingIds.reverse : mageBindingIds.fixed;
    assert.equal((await adapter.purchase({ kind:'skill',item:other })).reason,'incompatibleItem');
    await equip();
    await wait(() => view().phase === 'combat','The second ordinary encounter begins',95_000);
  }
  const next = { boss:view().boss.id,arena:view().arenaId,start:view().combatTick };
  const firstClear = owner().progress.clears;

  adapter.pause(true);
  await wait(() => adapter.paused(),'The authority acknowledges pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ technique1:true });
  await sleep(90);
  assert.equal(view().combatTick,pausedAt);
  assert(owner().ack < ignored && status()?.phase === 'idle',
    JSON.stringify({ fitting,transport,pausedAt,ack:owner().ack,ignored,privateStatus:status() }));
  adapter.pause(false);
  await wait(() => !adapter.paused(),'The authority acknowledges resume');
  await adapter.stopAlly?.();

  let accepted;
  const observations = [];
  const until = Date.now()+63_000;
  while (!accepted) {
    const v = view(), p = owner(), now = v.combatTick, world = bulwarkTrialWorld(v);
    assert(Date.now() < until && v.phase === 'combat' && p.status === 'active',
      JSON.stringify({ fitting,transport,next,current:{ phase:v.phase,hp:p.health,position:point(p),tick:now,boss:point(v.boss) },observations }));
    if (p.qAt > now || (status()?.phase === 'idle' && (status()?.until ?? 0) > now)) {
      adapter.input({ aim:bearing(p,v.boss) });
      await sleep(35);
      continue;
    }
    if (status()?.phase === 'marked') {
      adapter.input({ aim:bearing(p,v.boss) });
      await sleep(35);
      continue;
    }
    const candidate = markPlan(world,v,p);
    if (!candidate) {
      adapter.input(moveToLane(world,v,p));
      await sleep(26);
      continue;
    }
    await submit({ aim:candidate.aim });
    const fresh = markPlan(bulwarkTrialWorld(view()),view(),owner());
    if (!fresh) continue;
    const eventStart = adapter.events.length, originalQ = owner().qAt;
    await submit({ technique1:true,aim:fresh.aim });
    const mark = ownedCue('mark');
    if (!mark) continue;
    assert.equal(owner().qAt,originalQ);
    const plan = strokePlan(bulwarkTrialWorld(view()),view(),mark);
    if (!plan) {
      observations.push({ attempt:observations.length+1,result:'lane closed',mark });
      continue;
    }
    await submit({ technique1:true,aim:plan.initial });
    const stroke = ownedCue('stroke',mark.id);
    if (!stroke) {
      observations.push({ attempt:observations.length+1,result:'stroke refused',mark });
      continue;
    }
    const paidQ = owner().qAt;
    assert(paidQ > view().combatTick);
    assert.equal(stroke.until-stroke.at,rules.strokeTicks);
    await submit({ aim:plan.turn });
    let fitted, shotId, shotInWindow = false, facing;
    if (isFitted) {
      const armed = () => fitting === 'fixed' ? status()?.canFix : status()?.reverseArmed;
      await wait(() => armed() || !ownedCue('stroke',mark.id),'The real line turns or closes',1_600);
      const latest = ownedCue('stroke',mark.id);
      if (latest && armed()) {
        facing = heading(bearing(latest,{ x:latest.toX,y:latest.toY })+(fitting === 'reverse' ? Math.PI : 0));
        await submit({ technique1:true,aim:facing });
        fitted = ownedCue('stroke',mark.id);
        if (!(fitting === 'fixed' ? fitted?.fixed : fitted?.reversed)) fitted = undefined;
      }
    }
    if (fitting === 'fixed' && fitted) {
      const afterFit = adapter.events.length;
      await submit({ fire:true,aim:bearing(owner(),view().boss) });
      await wait(() => adapter.events.slice(afterFit).some(event => event.type === 'shots' && event.shots.some(shot => shot.owner === adapter.id)) ||
        !ownedCue('stroke',mark.id),'A normal primary shot or the original deadline',1_500);
      shotId = adapter.events.slice(afterFit).flatMap(e => e.type === 'shots' ? e.shots : [])
        .find(shot => shot.owner === adapter.id)?.id;
      const anchored = ownedCue('stroke',mark.id);
      if (anchored) {
        assert.deepEqual(point(anchored),point(fitted));
        assert.equal(anchored.toX,fitted.toX);
        assert.equal(anchored.toY,fitted.toY);
        shotInWindow = !!shotId;
      }
    }
    const hit = () => notes(eventStart,'contact').length > 0;
    await wait(() => hit() || !ownedCue('stroke',mark.id),'A real contact or expiry',1_500);
    assert.equal(owner().qAt,paidQ);
    const fitEvent = fitting === 'entry' ? [] : notes(eventStart,fitting);
    if (hit() && (!isFitted || fitted && fitEvent.length === 1 && (fitting !== 'fixed' || shotInWindow))) {
      assert.equal(notes(eventStart,'mark').length,1);
      assert.equal(notes(eventStart,'stroke').length,1);
      if (fitted) assert.equal(fitted.until,stroke.until);
      const hitAfterReverse = fitting === 'reverse' && adapter.events.indexOf(notes(eventStart,'contact')[0]) > adapter.events.indexOf(fitEvent[0]);
      if (fitting === 'reverse' && !hitAfterReverse) {
        observations.push({ attempt:observations.length+1,result:'only pre-reverse contact',mark,stroke,fitted });
        continue;
      }
      accepted = { mark,stroke,fitted,originalQ,paidQ,shotId,shotInWindow,facing,contacts:notes(eventStart,'contact'),hitAfterReverse,plan };
    } else observations.push({ attempt:observations.length+1,result:'no confirmed contact and fitting',mark,stroke,fitted,shotId });
  }

  const witnessed = await adapter.peerWitness?.([
    accepted.mark.kind+':'+accepted.mark.id,accepted.stroke.kind+':'+accepted.stroke.id,
  ]);
  const current = accepted.stroke;
  await wait(() => !ownedCue('stroke',current.id),'The original stroke expires',1_500);
  assert(view().combatTick >= current.until);
  return { passed:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,transport,fitting,bought:purchased,firstClear,next,
    result:accepted,observations,witnessed,expiredAt:view().combatTick,pausedCommandsDiscarded:true,noCheckpointImports:true };
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Sable', classId: 'mage' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'binding-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), mage = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], mage: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  mage.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, mage.id)?.kit.pivotSigil !== undefined) leaks++;
  };
  mage.onEvents = batch => remember(state.events, state.observed, batch, mage.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  mage.onPurchase = entry => replies.mage.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await mage.connect({ ...setup, name: 'Sable', classId: 'mage', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => mage.view?.players.length === 2 && host.view?.players.length === 2, 'Actual non-host Mage lobby');
    assert.equal(mage.view.owner, host.id);
    assert.notEqual(mage.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: mage.id, view: () => mage.view,
      input: props => { mage.input(inputFrame(mage.view, ++sequence, props)); return sequence; },
      purchase: request => reply(mage, replies.mage, request), start: () => host.start(),
      vote: i => { host.vote(i); mage.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => mage.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'The host stops on the ordinary map');
      },
      peerWitness: async ids => {
        await wait(() => ids.every(id => peers.cues.has(id)), 'The host sees the same floor mark and paid stroke');
        assert.equal(leaks,0);
        assert(!peers.events.some(e => e.type === 'sound' && e.owner === mage.id && e.id.startsWith('mage-pivot-')));
        const physical = ids.map(id => peers.cues.get(id));
        if (fitting === 'fixed') {
          await wait(() => peers.cues.get(ids[1])?.fixed,'The host sees the fixed line');
          physical[1] = peers.cues.get(ids[1]);
        }
        if (fitting === 'reverse') {
          await wait(() => peers.cues.get(ids[1])?.reversed,'The host sees the reversed line');
          physical[1] = peers.cues.get(ids[1]);
        }
        return { nonHost:true,sharedPhysical:physical,ownedStatePrivate:true,ownedSoundsPrivate:true };
      },
    });
    host.endMatch();
    await wait(() => [host, mage].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    mage.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, testedAudience: testAudience });
console.log(JSON.stringify({ passed:true,transport,fitting,encounter:result.next.boss,firstClear:result.firstClear,contacts:result.result.contacts.length }));
