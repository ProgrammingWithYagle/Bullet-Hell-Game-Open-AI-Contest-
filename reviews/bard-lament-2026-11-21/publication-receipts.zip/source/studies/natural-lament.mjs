import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { lamentPilot } from './lament-pilot.mjs';

const [output, cohort, mode = 'short', bundleName = 'game01', sample] = process.argv.slice(2);
assert(output && ['solo','party'].includes(cohort) && ['short','standard'].includes(mode) && /^game\d\d$/.test(bundleName));
const here = path => new URL('./' + path, import.meta.url);
const verified = readJson(here(bundleName + '.json'));
const api = await verifiedBundle(fileURLToPath(here(bundleName + '.mjs')), verified.bundle);
const { Game, data, viewOf, HZ, idleInput, CONTENT_REVISION, lamentIds, lamentRules: rules,
  distance, segmentRect, segmentCircle, restRaidInput } = api;
const worlds = [['gatehouse','baby',41], ['sunken-chapel','normal',73], ['ossuary-works','normal',109], ['crown-crypt','baby',61]];
const policies = ['banked','unused','lament','cross','closing'];
const filter = sample?.split('/');
if (filter) assert(filter.length === 2 && worlds.some(world => world[0] === filter[0]) && policies.includes(filter[1]));

function conduct(arena,difficulty,seed,policy) {
  const game = new Game({ mode, difficulty, seed, openingArenaId: arena, arenaSelection:'route', maxPlayers:cohort === 'solo' ? 1 : 2 });
  const bard = game.addPlayer('solo','Iven','bard');
  const ally = cohort === 'party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [bard,ally] : [bard];
  const trace = createHash('sha256'), shots = new Map(), effects = [], plans = [], purchases = [];
  let serial = 0, passes = 0, lastShop = -1;
  const buy = (player,kind,item) => game.transact(player.id,{kind,item,id:'lament-study-' + ++serial});
  assert.equal(bard.totalSp,3);
  assert(buy(bard,'skill','bard-notecraft-1').ok);
  if (policy !== 'banked') assert(buy(bard,'skill',lamentIds.entry).ok);
  function equipment(p) {
    for (const item of data.weapons.filter(weapon => weapon.classId === p.classId).sort((a,b) => b.tier-a.tier))
      if (p.weapon === item.id || buy(p,'weapon',item.id).ok) break;
    for (const item of ['damage','health','fire-rate','reload','magazine']) buy(p,'upgrade',item);
    buy(p,'supply','medkit');
  }
  actors.forEach(equipment);
  assert(game.start());
  function danger(view,point,horizon) {
    if (view.minions.some(target => target.health > 0 && distance(target,point) < 26 + horizon * 2)) return true;
    if (view.fields.some(field => field.kind === 'zone' && distance(field,point) < field.radius + 12)) return true;
    for (const shot of shots.values()) {
      const left = Math.min(horizon,shot.expires - view.combatTick);
      if (left <= 0 || distance(point,shot) > 410) continue;
      const flown = (view.combatTick - shot.seenAt) / HZ;
      const a = { x: shot.x + shot.vx * flown, y: shot.y + shot.vy * flown };
      const b = { x: a.x + shot.vx * left / HZ, y: a.y + shot.vy * left / HZ };
      const hit = segmentCircle(a,b,point,shot.radius + data.rules.playerRadius + 2);
      if (hit !== null && !game.obstacles.some(wall => (segmentRect(a,b,wall,shot.radius)?.t ?? Infinity) <= hit)) return true;
    }
    return false;
  }
  const context = { ...api, game, danger, rules };
  const navigate = explicitNavigation(context);
  const play = lamentPilot({ ...context, policy });
  while (!['victory','defeat'].includes(game.phase) && passes++ < 90000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of actors) game.vote(actor.id,0);
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        actors.forEach(equipment);
        if (['cross','closing'].includes(policy) && !bard.skills.includes(lamentIds[policy])) {
          const id = lamentIds[policy];
          assert(bard.totalSp >= 5 && buy(bard,'skill',id).ok);
          assert.equal(buy(bard,'skill',lamentIds[policy === 'cross' ? 'closing' : 'cross']).reason,'incompatibleItem');
          purchases.push({ id, earned:bard.totalSp, clears:bard.progress.clears });
        }
      }
      game.step();
      game.drainEvents();
      continue;
    }
    const seen = viewOf(game,bard.id);
    let ownerInput;
    const before = { e: bard.eAt, cadence: seen.players.find(player => player.id === bard.id).kit.cadence, at: { x: bard.x, y: bard.y } };
    for (const actor of actors) {
      const player = seen.players.find(row => row.id === actor.id);
      const base = actor.status === 'active' ? navigate(seen,player,restRaidInput(seen,player,[...shots.values()])) :
        actor.status === 'downed' ? {interact:true} : {};
      const choice = ['lament','cross','closing'].includes(policy) && actor === bard && actor.status === 'active' ? play(seen,player,base,request => plans.push(request)) : base;
      const frame = { ...idleInput(), ...choice, sequence: actor.ack + 1, clientTick: game.combatTick };
      frame.aim = Math.atan2(Math.sin(frame.aim), Math.cos(frame.aim));
      if (actor === bard) ownerInput = frame;
      trace.update(JSON.stringify(frame));
      assert(game.submitInput(actor.id, frame));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id,{...shot,seenAt:game.combatTick});
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== bard.id || !event.id.startsWith('bard-lament-')) continue;
      const action = event.id.slice('bard-lament-'.length);
      if (action === 'start') assert(ownerInput.technique2 && before.e < bard.eAt && before.cadence >= rules.cadence);
      if (['turn','chord'].includes(action)) assert(ownerInput.technique2 && before.e === bard.eAt);
      effects.push({ action, at:game.combatTick,boss:game.boss.id, before, paidUntil:bard.eAt, state:game.kitStatus(bard.id).lamenting,
        cues:game.classCues().filter(cue => cue.owner === bard.id && cue.kind.startsWith('bard-lament-')) });
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(a => [a.x,a.y,a.health,a.qAt,a.eAt,a.ammo,a.damageDealt])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  return { arena,difficulty,seed,policy,won:game.phase === 'victory',clears:bard.progress.clears,trace:trace.digest('hex'),effects,plans,purchases };
}

const rows = [], controls = [];
for (const world of worlds) {
  if (filter && world[0] !== filter[0]) continue;
  const outcomes = (filter ? [filter[1]] : policies).map(policy => conduct(...world,policy));
  if (!filter) {
    assert.equal(outcomes[0].trace,outcomes[1].trace);
    controls.push({ arena:world[0],sameTrace:true });
  }
  for (const row of outcomes) console.log(JSON.stringify({ arena:row.arena,policy:row.policy,won:row.won,clears:row.clears,
    outcomes:Object.fromEntries(['start','pulse','end','turn','chord'].map(action => [action,row.effects.filter(item => item.action === action).length])) }));
  rows.push(...outcomes);
}
receipt(output,{stageOnly:true,bundle:verified.bundle,revision:CONTENT_REVISION,mode,cohort,rows,controls});
