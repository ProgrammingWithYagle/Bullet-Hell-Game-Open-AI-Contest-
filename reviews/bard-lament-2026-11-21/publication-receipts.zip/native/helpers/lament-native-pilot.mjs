const facing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const forward = (point,angle,length) => ({ x:point.x+Math.cos(angle)*length, y:point.y+Math.sin(angle)*length });

export function lamentPilot({game,rules,distance,segmentRect,segmentCircle,danger,policy,nativeProbe}) {
  return (view,body,routine,record) => {
    const state=body.kit.lamenting, now=view.combatTick;
    const targets=[view.boss,...view.minions].filter(enemy=>enemy.health>0);
    const clear=(a,b,pad=0)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,pad));
    function end(from,heading) {
      const {bounds,lavaPits}=game.arena;
      for(let length=rules.reach;length>=rules.minimumReach;length-=20){
        const point=forward(from,heading,length);
        if(point.x<bounds.x+11||point.y<bounds.y+11||point.x>bounds.x+bounds.width-11||point.y>bounds.y+bounds.height-11)continue;
        if(clear(from,point,8)&&!lavaPits.some(pit=>segmentCircle(from,point,pit,pit.radius+8)!==null))return point;
      }
    }
    function laneTargets(from,to){
      return targets.filter(enemy=>clear(from,enemy)&&segmentCircle(from,to,enemy,rules.width+(enemy.radius??30))!==null);
    }
    const score = rows => rows.reduce((total,row)=>total+(row===view.boss?1.8:1),0);
    if(body.health<body.maxHealth*.26 || danger(view,body,5))return routine;
    if(state?.phase==='sustain'){
      const {from,to}=state.lane, aim=facing(from,to);
      const current=laneTargets(from,to);
      const hold={aim,fire:routine.fire,moveX:0,moveY:0};
      const own=view.classCues.find(cue=>cue.kind==='bard-lament-line'&&cue.owner===body.id);
      if(policy==='cross'&&body.skills.includes('bard-lament-cross-verse-1')&&own&&!own.turned&&state.left>1&&state.left<rules.beats){
        const options=[.41,-.41,.67,-.67,.93,-.93,1.19,-1.19].flatMap(delta=>{
          const angle=aim+delta, point=end(from,angle);
          return point?[{angle,point,score:score(laneTargets(from,point))}]:[];
        }).sort((a,b)=>b.score-a.score);
        if(options[0] && (nativeProbe || options[0].score>score(current))){
          record({action:'turn',at:now,from,to:options[0].point});
          return {...hold,technique2:true,aim:options[0].angle};
        }
      }
      if(policy==='closing'&&state.closing){
        const near=targets.filter(enemy=>clear(to,enemy)&&distance(enemy,to)<=rules.chordRadius+(enemy.radius??30));
        if(near.length&&(nativeProbe||near.some(enemy=>!current.includes(enemy))||state.left<=2)){
          record({action:'chord',at:now,to,left:state.left,contacts:state.contacts});
          return {...hold,technique2:true};
        }
      }
      return hold;
    }
    if(body.eAt>now||body.kit.cadence<rules.cadence||routine.dodge||routine.sprint)return routine;
    const sights=targets.filter(enemy=>distance(enemy,body)<rules.reach+50&&clear(body,enemy)&&distance(body,enemy)>55);
    const candidates=sights.flatMap(enemy=>{
      const aim=facing(body,enemy), point=end(body,aim);
      return point?[{aim,point,score:score(laneTargets(body,point))}]:[];
    }).sort((a,b)=>b.score-a.score);
    if(candidates[0]?.score>0&&!danger(view,body,rules.firstBeat)){
      record({action:'start',at:now,from:{x:body.x,y:body.y},to:candidates[0].point,cadence:body.kit.cadence});
      return {technique2:true,aim:candidates[0].aim,fire:routine.fire};
    }
    return routine;
  };
}
