import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { lamentPilot } from './lament-native-pilot.mjs';

export function recordLamentCues(cues, view) {
  for (const cue of view.classCues) {
    if (!cue.kind.startsWith('bard-lament-')) continue;
    const found = cues.get(cue.id);
    if (found) found.last = cue;
    else cues.set(cue.id,{ first:cue, last:cue, recovery:view.players.find(row=>row.id===cue.owner)?.eAt });
  }
}

export function createCombatPolicy({ adapter, view, data, HZ, rules, runtimeArena, bulwarkTrialWorld, clearTrialWalk,
  segmentRect, segmentCircle, distance, restRaidInput, fitting }) {
  let worldTick = -1, world;
  const game = {
    get arena() { return runtimeArena(view().arenaId,view().run.difficulty); },
    get obstacles() {
      const seen = view();
      if (worldTick !== seen.combatTick || world?.arenaId !== seen.arenaId) {
        worldTick = seen.combatTick;
        world = { ...bulwarkTrialWorld(seen),arenaId:seen.arenaId };
      }
      return world.obstacles;
    },
    get combatTick() { return view().combatTick; },
    get encounter() { return view().encounter; },
    movementSpeed(player) { return player.speed; },
  };
  function danger(seen, point, horizon) {
    if (seen.minions.some(target=>target.health>0&&distance(target,point)<24+horizon)) return true;
    if (seen.fields.some(field=>field.kind==='zone'&&distance(field,point)<field.radius+8)) return true;
    for (const shot of adapter.observed.values()) {
      const time = Math.min(horizon,shot.expires-seen.combatTick);
      if (time<=0 || shot.owner!=='hostile' || distance(shot,point)>420) continue;
      const elapsed = Math.max(0,seen.combatTick-shot.seenAt)/HZ;
      const from = { x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed };
      const to = { x:from.x+shot.vx*time/HZ,y:from.y+shot.vy*time/HZ };
      const contact = segmentCircle(from,to,point,shot.radius+data.rules.playerRadius+2);
      if(contact!==null&&!game.obstacles.some(wall=>(segmentRect(from,to,wall,shot.radius)?.t??Infinity)<=contact))return true;
    }
    return false;
  }
  const context = { game,data,HZ,rules,distance,segmentRect,segmentCircle,clearTrialWalk,danger };
  const navigate = explicitNavigation(context);
  const play = lamentPilot({ ...context,policy:fitting,nativeProbe:true });
  const ordinary = (seen,body) => navigate(seen,body,restRaidInput(seen,body,[...adapter.observed.values()]));
  return {
    ordinary,
    invoke(seen,body,record) {
      const routine = ordinary(seen,body);
      return play(seen,body,{...routine,e:false,ultimate:routine.ultimate&&body.health<body.maxHealth*.32},record);
    },
  };
}

export async function exerciseLament({ adapter,view,owner,submit,fitting,rules,equip,policy }) {
  const deadline = Date.now()+175_000;
  const from = view().combatTick, oldRecovery = owner().eAt, eventStart=adapter.events.length;
  let lastShop = view().encounter, lastTick = -1;
  const plans = [], traces = [];
  for (;;) {
    const seen = view(), body=owner();
    const updates = [...adapter.cues.values()].filter(row=>row.first.owner===adapter.id&&row.first.at>=from);
    const sounds = adapter.events.slice(eventStart).filter(event=>event.type==='sound'&&event.owner===adapter.id&&event.id.startsWith('bard-lament-'));
    if (Date.now()>=deadline || ['victory','defeat'].includes(seen.phase)) {
      assert.fail(JSON.stringify({ fitting,tick:seen.combatTick,phase:seen.phase,boss:seen.boss.id,hp:body.health,
        sounds:sounds.map(row=>row.id),lanes:updates.filter(row=>row.first.kind==='bard-lament-line').slice(-10),plans:plans.slice(-18),traces:traces.slice(-12) }));
    }
    if(seen.phase!=='combat'){
      if(['mutationVote','contractVote','secretOffer'].includes(seen.phase))adapter.vote(0);
      if(seen.phase==='shop'&&seen.encounter!==lastShop){lastShop=seen.encounter;await equip();}
      await sleep(20);
      continue;
    }
    for(const lane of updates.filter(row=>row.first.kind==='bard-lament-line')){
      const {first,last,recovery}=lane;
      const matching = updates.map(row=>row.first).filter(cue=>cue.at>=first.at&&cue.at<first.until&&cue.x===first.x&&cue.y===first.y);
      const pulses = matching.filter(cue=>cue.kind==='bard-lament-pulse');
      const chord = matching.find(cue=>cue.kind==='bard-lament-chord');
      const completed = fitting==='entry'?pulses.length===rules.beats:
        fitting==='cross'?last.turned&&pulses.length===rules.beats-1:
        chord&&pulses.length>=rules.chordProof&&pulses.length<rules.beats;
      if(!completed || body.kit.lamenting?.phase==='sustain')continue;
      assert(recovery>oldRecovery&&recovery===body.eAt&&recovery>first.until);
      assert.equal(first.until-first.at,rules.firstBeat+(rules.beats-1)*rules.interval+1);
      assert.deepEqual([first.id,first.until,first.x,first.y],[last.id,last.until,last.x,last.y]);
      assert(sounds.some(row=>row.id==='bard-lament-start'));
      if(fitting==='cross'){
        assert(sounds.some(row=>row.id==='bard-lament-turn'));
        assert.deepEqual([pulses[0].x2,pulses[0].y2],[first.x2,first.y2]);
        assert.deepEqual([pulses.at(-1).x2,pulses.at(-1).y2],[last.x2,last.y2]);
      }
      if(fitting==='closing'){
        assert(sounds.some(row=>row.id==='bard-lament-chord'));
        assert.deepEqual([chord.x2,chord.y2],[last.x2,last.y2]);
        assert(traces.some(row=>row.at>=first.at&&row.at<=chord.at&&row.contacts>=rules.chordProof));
      }
      return { lane,pulses,chord,turned:!!last.turned,endedWithChord:!!chord,recovery,boss:seen.boss.id,
        sounds:sounds.map(row=>row.id),plans:plans.slice(-35),traces:traces.slice(-28) };
    }
    if(seen.combatTick===lastTick){await sleep(10);continue;}
    lastTick=seen.combatTick;
    if(body.kit.lamenting?.phase==='sustain')traces.push({at:lastTick,contacts:body.kit.lamenting.contacts,left:body.kit.lamenting.left});
    const frame = body.status==='active'?policy.invoke(seen,body,row=>plans.push(row)):{interact:true};
    await submit(frame);
    adapter.allyCover?.();
  }
}
