import assert from 'node:assert/strict';

export function verifyNativeCase(record, expected) {
  const {transport,fitting,revision,driver,worker}=expected;
  assert(record.passed&&record.protocol===94&&record.contentRevision===revision&&record.driverSha256===driver);
  assert(record.transport===transport&&record.fitting===fitting&&record.pausedCommandsDiscarded&&record.noCheckpointImports);
  assert.equal(record.firstClear,fitting==='entry'?0:1);
  if(fitting!=='entry')assert.equal(record.bought.at(-1).earned,5);
  const {lane,pulses,chord,turned,endedWithChord,recovery,boss}=record.result;
  assert.deepEqual([lane.first.id,lane.first.until,lane.first.x,lane.first.y],[lane.last.id,lane.last.until,lane.last.x,lane.last.y]);
  assert.equal(turned,fitting==='cross');
  assert.equal(endedWithChord,fitting==='closing');
  assert.equal(recovery,lane.recovery);
  assert.equal(pulses.length,fitting==='entry'?5:fitting==='cross'?4:2);
  if(chord)assert.deepEqual([chord.x2,chord.y2],[lane.last.x2,lane.last.y2]);
  if(transport==='worker')assert(record.wholeOptimizedWorker&&!record.workerPatched&&record.workerSha256===worker);
  else assert(record.witnessed.nonHost&&record.witnessed.ownedStatePrivate&&record.witnessed.ownedSoundsPrivate);
  return {transport,fitting,boss,firstClear:record.firstClear,lane:lane.first.id,pulses:pulses.length,turned,chord:endedWithChord};
}
