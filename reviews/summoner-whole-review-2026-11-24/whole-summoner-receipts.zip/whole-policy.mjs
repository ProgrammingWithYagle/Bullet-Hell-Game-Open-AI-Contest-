import { bondInput } from '../bonded/bond-policy.mjs';
import { formationCue, normalizedAim, standing } from '../formation/formation-policy.mjs';

export function wholePolicy({ arenaFor, segmentRect, segmentCircle, formationRules, ordinary }) {
  const movementStarts = new Map();
  const lastUse = new Map();
  const count = new Map();
  const locked = new Set();

  return function play(view, owner, shots, active) {
    const base = bondInput(view, owner, shots, ordinary, false);
    if (!active) return base;
    const kit = owner.kit;
    const now = view.combatTick;
    const cue = formationCue(view, owner);
    const arena = arenaFor(view.arenaId, view.run.difficulty);
    const activeCohort = ['march', 'relay'].includes(kit.cohort?.stage);
    const activeBond = ['linked', 'returning'].includes(kit.bond?.stage);
    const shotDanger = point => shots.some(shot => {
      const lead = Math.max(0, now - shot.seenAt) / 30;
      const horizon = Math.min(10, shot.expires - now) / 30;
      if (horizon <= 0 || Math.hypot(shot.x - point.x, shot.y - point.y) > 300) return false;
      const from = { x: shot.x + shot.vx * lead, y: shot.y + shot.vy * lead };
      const to = { x: from.x + shot.vx * horizon, y: from.y + shot.vy * horizon };
      const hit = segmentCircle(from, to, point, shot.radius + 20);
      return hit !== null && !arena.obstacles.some(wall => (segmentRect(from, to, wall, shot.radius)?.t ?? Infinity) <= hit);
    });
    const withinWarning = view.warnings.some(w => w.kind === 'zone' && w.until > now &&
      Math.hypot(w.x - owner.x, w.y - owner.y) < w.radius + 22);
    const unsafe = base.dodge || (base.supply ?? -1) >= 0 || withinWarning;
    if (unsafe) return { ...base, e: base.e && !activeCohort && !activeBond && !cue };
    const bonded = kit.bond?.stage === 'ready';
    const turning = cue && kit.formation.fitting === 'turn' && cue.state === 'holding';
    if (kit.cohort?.stage === 'relay' && kit.cohort.canSend) {
      return { ...base, q: false, e: false, ultimate: false, fire: false, technique1: true };
    }
    if (cue) {
      if (bonded && kit.bond.fitting === 'close') {
        count.set('bond', (count.get('bond') ?? 0) + 1);
        return { ...base, q: false, e: false, ultimate: false, fire: false, technique2: true };
      }
      const towardBoss = Math.atan2(view.boss.y - cue.y, view.boss.x - cue.x);
      const nextFacing = normalizedAim(towardBoss - cue.aim);
      if (turning && kit.formation.canCommand && Math.abs(nextFacing) > 0.68) {
        return { ...base, aim: towardBoss, q: false, e: false, ultimate: false, technique3: true };
      }
      const steady = { ...base, q: false, e: false, ultimate: false, moveX: 0, moveY: 0 };
      if (kit.formation.fitting === 'walking' && cue.state === 'holding' && kit.formation.catches && !locked.has(cue.id)) {
        movementStarts.set(cue.id, now);
        locked.add(cue.id);
      }
      const movedAt = movementStarts.get(cue.id);
      if (movedAt !== undefined && now < movedAt + 4) {
        return { ...steady, moveX: Math.cos(cue.aim), moveY: Math.sin(cue.aim) };
      }
      return shotDanger(owner) ? { ...base, e: false, q: false, ultimate: false } : steady;
    }
    if (activeCohort || activeBond || base.q || base.ultimate) return { ...base, e: base.e && !activeCohort && !activeBond };
    const formAim = normalizedAim(base.aim);
    const center = { x: owner.x + Math.cos(formAim) * formationRules.lead, y: owner.y + Math.sin(formAim) * formationRules.lead };
    const formationReady = kit.formation?.stage === 'ready' && !arena.obstacles.some(wall => segmentRect(center, view.boss, wall, 8) !== null) &&
      Math.hypot(view.boss.x - owner.x, view.boss.y - owner.y) > 135;
    const ops = [
      { id: 'cohort', ready: kit.cohort?.canSend, input: { ...base, q: false, e: false, fire: false, technique1: true } },
      { id: 'bond', ready: bonded, input: { ...base, q: false, e: false, fire: false, technique2: true } },
      { id: 'formation', ready: formationReady, input: { ...standing(base), aim:formAim, technique3: true } },
    ].filter(op => op.ready && (lastUse.get(op.id) ?? -100) < now - 8);
    ops.sort((first, second) => (count.get(first.id) ?? 0) - (count.get(second.id) ?? 0));
    const op = ops[0];
    if (!op) return base;
    lastUse.set(op.id, now);
    count.set(op.id, (count.get(op.id) ?? 0) + 1);
    return op.input;
  };
}
