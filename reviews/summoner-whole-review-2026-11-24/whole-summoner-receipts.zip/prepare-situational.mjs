import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';

const root = new URL('./', import.meta.url);
const original = readFileSync(new URL('standard-runs.mts', root), 'utf8');
const updated = original
  .replace("import { wholePolicy } from './whole-policy.mjs';", "import { wholePolicy } from './whole-policy.mjs';\nimport { situationalInput } from './situational-input.mjs';")
  .replace('const { segmentRect, segmentCircle }', 'const { segmentRect, segmentCircle, moveBody }')
  .replace("const [output, cohort, sample, mode]", "const ordinary = situationalInput({ restRaidInput, runtimeArena, segmentRect, segmentCircle, moveBody });\nconst [output, cohort, sample, mode]")
  .replace('ordinary:restRaidInput', 'ordinary')
  .replace(' : restRaidInput(view, body, hostile)', ' : ordinary(view, body, hostile)')
  .replace("['gatehouse', 'normal', 73]", "['gatehouse', 'baby', 73]")
  .replace("arenaSelection:'route'", "arenaSelection:'fixed'")
  .replace('  driverSha256:sha256', "  situationalInputSha256:sha256(readFileSync(new URL('./situational-input.mjs', import.meta.url))), driverSha256:sha256");
assert(updated !== original && updated.includes('const ordinary = situationalInput') && updated.includes("arenaSelection:'fixed'"));
writeFileSync(new URL('standard-situational.mts', root), updated, { flag:'wx' });
