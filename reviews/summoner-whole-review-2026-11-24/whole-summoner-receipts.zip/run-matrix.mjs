import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

const out = process.argv[2];
assert(out);
const source = readJson(new URL('../formation/source-commit01.json', import.meta.url));
assert(source.passed && source.protocol === 101);
mkdirSync(out);
const driver = fileURLToPath(new URL('./standard-runs.mts', import.meta.url));
const policy = fileURLToPath(new URL('./whole-policy.mjs', import.meta.url));
const worlds = ['gatehouse', 'sunken-chapel', 'ossuary-works'];
const key = row => [row.arena, row.fitting, row.active ? 'active' : 'unused'].join(',');
const runEvidence = [];

async function run(stem, party, ...args) {
  const result = join(out, stem + '.json'), log = join(out, stem + '.log');
  assert.equal(await runChild([driver, result, party, ...args], log, 630000), 0, log);
  const report = readJson(result);
  assert.equal(report.protocol, source.protocol);
  assert.equal(report.contentRevision, source.contentRevision);
  assert.equal(report.runtimeSourceSha256, source.runtimeSourceSha256);
  assert.equal(report.driverSha256, digest(driver));
  assert.equal(report.policySha256, digest(policy));
  runEvidence.push({ result:stem + '.json', resultSha256:digest(result), log:stem + '.log', logSha256:digest(log) });
  return report.rows;
}

async function lane(party) {
  const rows = await run(party + '-all', party);
  assert.equal(rows.length, 48);
  const byKey = new Map(rows.map(row => [key(row), row]));
  assert.equal(byKey.size, 48);
  const inactive = rows.filter(row => !row.active);
  for (const row of inactive) {
    const actor = byKey.get(key({ ...row, active:true }));
    assert(actor && row.effects.length === 0);
    const common = Math.min(row.purchases.length, actor.purchases.length);
    assert.deepEqual(row.purchases.slice(0, common), actor.purchases.slice(0, common));
  }
  const replays = [];
  for (const [i, world] of worlds.entries()) {
    const act = rows.filter(row => row.active && row.arena === world)[i * 2];
    const skip = rows.filter(row => !row.active && row.arena === world)[i * 2];
    for (const row of [act, skip]) {
      const [replay] = await run(party + '-replay-' + replays.length, party, key(row));
      assert.deepEqual(replay, row);
      replays.push(key(row));
    }
  }
  const safeResume = [];
  if (party === 'solo') {
    for (const row of rows.filter(row => row.active && row.boundary)) {
      const [restored] = await run(party + '-resume-' + safeResume.length, party, key(row), 'restore');
      assert.deepEqual(restored, row);
      safeResume.push({ key:key(row), boundary:restored.boundary, continuation:restored.continuation, won:restored.won, clears:restored.clears });
    }
  }
  const summaries = [false, true].map(active => {
    const cases = rows.filter(row => row.active === active);
    const perEvent = {};
    for (const row of cases) for (const event of row.effects) perEvent[event.id] = (perEvent[event.id] ?? 0) + 1;
    return { party, active, runs:cases.length, wins:cases.filter(row => row.won).length, fullyFitted:cases.filter(row => row.fullyFitted).length,
      clears:cases.map(row => row.clears), allPaths:cases.filter(row => row.pathsUsed.length === 3).length,
      allFittedPaths:cases.filter(row => row.fittedUsed.length === 3).length, perEvent };
  });
  for (const row of summaries) console.log(JSON.stringify(row));
  return { party, replays, safeResume, summaries };
}

const outcomes = await Promise.allSettled(['solo', 'pair'].map(lane));
for (const row of outcomes) if (row.status === 'rejected') console.error(row.reason);
const passed = outcomes.every(row => row.status === 'fulfilled');
const result = { passed, source:source.sourceCommit, contentRevision:source.contentRevision, runtimeSourceSha256:source.runtimeSourceSha256,
  matches:96, pairedComparisons:48, exactReplays:passed ? 12 : undefined,
  outcomes:outcomes.map(row => row.status === 'fulfilled' ? row.value : { error:String(row.reason) }), files:runEvidence };
receipt(join(out, 'whole-summary.json'), result);
if (!passed) process.exitCode = 1;
