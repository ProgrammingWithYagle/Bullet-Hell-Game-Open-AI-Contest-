import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, readJson, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { CONTENT_REVISION, PROTOCOL, idleInput } = await repoImport('src/shared/protocol.ts');
const { formationIds, formationRules } = await repoImport('src/shared/summoner-formation.ts');
const { cohortIds } = await repoImport('src/shared/summoner-cohort.ts');
const { bondIds } = await repoImport('src/shared/summoner-bond.ts');
const source = readJson(new URL('../formation/source-commit01.json', import.meta.url));
const output = process.argv[2];
assert(output && source.protocol === PROTOCOL && source.contentRevision === CONTENT_REVISION);
const cases = [];

function fixture(secondOwner = false) {
  const game = new Game({ mode:'endless', difficulty:'normal', seed:41, openingArenaId:'gatehouse', arenaSelection:'fixed', maxPlayers:2 });
  game.encounter = 9;
  const owner = game.addPlayer('owner', 'Joss', 'summoner');
  const peer = secondOwner ? game.addPlayer('peer', 'Rue', 'summoner') : undefined;
  const players = peer ? [owner, peer] : [owner];
  const purchase = (p, item) => assert(game.transact(p.id, { id:item, kind:'skill', item }).ok, item);
  function fit(p, cohort, bond, formation) {
    assert.equal(p.totalSp, 27);
    for (const item of ['summoner-bonds-1', cohortIds.entry, cohortIds[cohort], bondIds.entry, bondIds[bond], formationIds.entry, formationIds[formation]]) {
      purchase(p, item);
    }
    assert.equal(p.skills.reduce((n, id) => n + game.skillCost(id), 0), 13);
  }
  function start() {
    assert(game.start());
    const arena = structuredClone(game.arena);
    arena.obstacles = [];
    arena.lavaPits = [];
    Object.defineProperty(game, 'arena', { get:() => arena });
    Object.assign(game.boss, { x:1390, y:790, health:100000, maxHealth:100000, staggerUntil:15000, deadline:15000 });
    players.forEach((p, i) => Object.assign(p, { x:490, y:500 + i * 210, aim:0, oldX:490, oldY:500 + i * 210 }));
  }
  const events = [];
  function tick(...inputs) {
    players.forEach((p, i) => {
      if (p.connected) assert(game.submitInput(p.id, { ...idleInput(), aim:0, sequence:p.ack + 1, clientTick:game.combatTick, ...inputs[i] }));
    });
    game.step();
    const batch = game.drainEvents();
    events.push(...batch);
    return batch;
  }
  function until(condition, input = () => [], limit = 240) {
    for (let i = 0; i < limit && !condition(); i++) tick(...input());
    assert(condition(), 'Controlled operation did not settle');
  }
  const kit = (p = owner) => game.kitStatus(p.id);
  const owned = (p = owner) => game.retinue.owned(p.id).filter(unit => unit.health > 0 && !unit.temporary);
  const line = (p = owner) => game.classCues().find(cue => cue.kind === 'summoner-formation' && cue.owner === p.id);
  const sound = (batch, id, p = owner) => batch.some(e => e.type === 'sound' && e.id === id && e.owner === p.id);
  let id = 880000;
  function catchAt(formation, damage = 9) {
    assert(formation?.state === 'holding');
    const nx = Math.cos(formation.aim), ny = Math.sin(formation.aim);
    const x = (formation.ax + formation.bx) / 2, y = (formation.ay + formation.by) / 2;
    const shot = ++id;
    game.shots.set(shot, { id:shot, owner:'hostile', x:x+34*nx, y:y+34*ny, vx:-2100*nx, vy:-2100*ny,
      radius:2, damage, expires:game.combatTick+8, pierce:0 });
    const batch = tick();
    assert(!game.shots.has(shot));
    return batch;
  }
  function mark() {
    const target = game.minions.spawn(++id, { kind:'ordinary', x:720, y:owner.y, health:3000, radius:17, speed:0, damage:1 }, game.combatTick);
    assert(target);
    until(() => kit().retinueMarkKey === 'ordinary:' + target.id, () => [{ fire:true }], 75);
    return target;
  }
  return { game, owner, peer, purchase, fit, start, tick, until, kit, owned, line, catchAt, mark, events, sound };
}

const close = fixture();
close.fit(close.owner, 'relay', 'close', 'turn');
close.start();
close.tick({ q:true });
const marked = close.mark(), bodies = close.owned();
assert.equal(bodies.length, 2);
const beforeLine = close.owner.ammo;
close.tick({ technique3:true });
assert.equal(close.owner.ammo, beforeLine - 2);
close.until(() => close.line()?.state === 'holding');
const original = close.line();
assert(close.sound(close.catchAt(original), 'summoner-formation-catch'));
const wounded = bodies.find(unit => unit.health < unit.maxHealth);
assert(wounded);
const health = wounded.health;
const blocked = close.owner.ammo;
close.tick({ technique1:true });
assert.equal(close.owner.ammo, blocked);
assert.equal(close.kit().cohort.canSend, false);
close.tick({ technique2:true });
assert.equal(close.owner.ammo, blocked - 2);
assert.equal(close.kit().bond.stage, 'linked');
close.until(() => close.sound(close.events, 'summoner-bond-mend'), () => [{ fire:true }], 60);
assert(wounded.health > health);
const restoredHealth = wounded.health - health;
assert.equal(close.line().id, original.id);
assert.equal(close.kit().formation.catches, 1);
const afterRepair = close.owner.ammo;
close.tick({ technique3:true, aim:Math.PI / 2 });
assert.equal(close.owner.ammo, afterRepair);
close.until(() => close.line()?.state === 'holding');
assert.equal(close.line().until - close.line().at, formationRules.duration);
assert.equal(close.line().aim - original.aim, Math.PI / 2);
assert(close.sound(close.catchAt(close.line()), 'summoner-formation-catch'));
assert(!close.line());
const healthAfterMark = marked.health;
assert(close.kit().cohort.canSend);
close.tick({ technique1:true });
close.until(() => close.kit().cohort.stage === 'relay');
assert(marked.health < healthAfterMark);
const relay = close.game.classCues().find(cue => cue.kind === 'summoner-cohort' && cue.state === 'relay');
const follower = bodies.find(unit => unit.id === relay?.unit);
assert(follower?.kind === 'wing');
for (const unit of bodies) if (unit !== follower) unit.attackAt = 15000;
const afterLeader = marked.health, relayFocus = close.owner.ammo;
const hit = close.game.retinueShotHit.bind(close.game);
const strikes = [];
close.game.retinueShotHit = (shot, player, key, damage) => {
  if (close.game.retinueShots.get(shot.id)?.unit === follower.id && key === 'ordinary:' + marked.id && damage > 0) {
    strikes.push({ id:shot.id, damage, at:close.game.combatTick });
  }
  hit(shot, player, key, damage);
};
close.tick({ technique1:true });
assert.equal(close.owner.ammo, relayFocus);
let firedAt;
for (let i = 0; i < 220 && !strikes.length; i++) {
  const assigned = close.game.classCues().some(cue => cue.kind === 'summoner-cohort' && cue.state === 'march' && cue.unit === follower.id);
  const nextAttack = follower.attackAt;
  close.tick();
  if (assigned && follower.attackAt > nextAttack) firedAt = close.game.combatTick;
}
assert(firedAt && strikes.length === 1 && strikes[0].at >= firedAt && strikes[0].at < follower.attackAt);
assert.equal(afterLeader - marked.health, strikes[0].damage);
cases.push({ case:'close-stitch, quarter turn and relay in one fight', repair:restoredHealth, realCatches:2,
  relayLeaderAndFollowerDamagedMark:true, orderedFollowerImpact:strikes[0] });

const peers = fixture(true);
peers.fit(peers.owner, 'cross', 'homeward', 'walking');
peers.fit(peers.peer, 'relay', 'close', 'turn');
peers.start();
peers.tick({ q:true }, { q:true });
peers.tick({ technique3:true }, { technique3:true });
peers.until(() => peers.line()?.state === 'holding' && peers.line(peers.peer)?.state === 'holding');
const other = peers.line(peers.peer), own = peers.line();
const ownerView = viewOf(peers.game, peers.owner.id), peerView = viewOf(peers.game, peers.peer.id);
assert.deepEqual(ownerView.classCues, peerView.classCues);
for (const [frame, player] of [[ownerView, peers.owner], [peerView, peers.peer]]) {
  for (const row of frame.players) assert.equal(!!row.kit.formation, row.id === player.id);
}
assert(peers.sound(peers.catchAt(own), 'summoner-formation-catch'));
const resident = peers.owned().find(unit => unit.health < unit.maxHealth);
assert(resident);
const stableFocus = peers.owner.ammo;
peers.tick({ technique2:true });
assert.equal(peers.kit().bond.stage, 'formation');
assert.equal(peers.owner.ammo, stableFocus);
peers.game.setConnected(peers.peer.id, false);
assert(!peers.line(peers.peer) && peers.owned(peers.peer).length === 0);
assert.equal(peers.line().id, own.id);
for (let i = 0; i < 4; i++) peers.tick({ moveY:1 });
peers.until(() => peers.line()?.state === 'holding');
assert(peers.line().y > own.y + 14);
assert.equal(peers.kit().formation.catches, 1);
assert(peers.sound(peers.catchAt(peers.line()), 'summoner-formation-catch'));
assert(!peers.line());
peers.tick({ technique2:true });
assert.equal(peers.kit().bond.stage, 'returning');
const returned = peers.owned().find(unit => unit.id === peers.kit().bond.unit);
assert(returned);
const beforeReturn = returned.health;
peers.until(() => peers.sound(peers.events, 'summoner-bond-mend'));
assert(returned.health > beforeReturn);
cases.push({ case:'two owners, walking formation, and physical Homeward return', keptCue:own.id, clearedCue:other.id,
  bothOwnerScopesPrivate:true, partnerCaughtAfterOtherOwnerLeft:true, repaired:returned.health - beforeReturn });

for (const transform of ['running-pack','closed-ranks','patient-company']) {
  const scenario = fixture();
  scenario.fit(scenario.owner, 'cross', 'close', 'walking');
  const transformation = data.skills.find(row => row.classId === 'summoner' && row.transform === transform);
  assert(transformation);
  const ancestors = [];
  for (let node = transformation; node; node = data.skills.find(row => row.id === node.prerequisite)) ancestors.unshift(node.id);
  for (const skill of ancestors) if (!scenario.owner.skills.includes(skill)) scenario.purchase(scenario.owner, skill);
  scenario.start();
  scenario.tick({ q:true, ultimate:true });
  const roster = scenario.game.retinue.owned(scenario.owner.id);
  assert.equal(roster.filter(unit => !unit.temporary).length, 2);
  const kinds = scenario.owned().map(unit => unit.kind);
  assert.equal(kinds[0], 'hound');
  assert.equal(kinds[1], transform === 'running-pack' ? 'hound' : 'wing');
  scenario.tick({ technique3:true });
  scenario.until(() => scenario.line()?.state === 'holding');
  assert(scenario.sound(scenario.catchAt(scenario.line()), 'summoner-formation-catch'));
  const warders = roster.filter(unit => unit.temporary);
  assert(warders.length >= 2);
  assert(warders.every(unit => !scenario.owned().includes(unit) && unit.health === unit.maxHealth));
  cases.push({ case:transform, ownedKinds:kinds, livingTemporaryExcluded:warders.length, realFormationCatch:true });
}

const files = ['src/shared/game.ts','src/shared/summoner-kit.ts','src/shared/summoner-cohort.ts','src/shared/summoner-bond.ts','src/shared/summoner-formation.ts'];
const proof = { passed:true, source:source.sourceCommit, protocol:PROTOCOL, contentRevision:CONTENT_REVISION,
  driverSha256:sha256(readFileSync(new URL(import.meta.url))), files:Object.fromEntries(files.map(path => [path, sha256(readFileSync(join(checkout,path)))])), cases };
receipt(output, proof);
console.log(JSON.stringify(cases));
