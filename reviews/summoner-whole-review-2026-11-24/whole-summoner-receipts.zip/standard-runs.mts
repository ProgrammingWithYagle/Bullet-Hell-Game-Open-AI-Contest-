import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { wholePolicy } from './whole-policy.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { cohortIds } = await repoImport('src/shared/summoner-cohort.ts');
const { bondIds } = await repoImport('src/shared/summoner-bond.ts');
const { formationIds, formationRules } = await repoImport('src/shared/summoner-formation.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [output, cohort, sample, mode] = process.argv.slice(2);
assert(PROTOCOL === 101 && output && ['solo', 'pair'].includes(cohort));
assert(!mode || mode === 'restore' && cohort === 'solo' && sample);
const worlds = [['gatehouse', 'normal', 73], ['sunken-chapel', 'baby', 67], ['ossuary-works', 'baby', 103]] as const;
const builds = ['cross', 'relay'].flatMap(march => ['close', 'homeward'].flatMap(bond => ['walking', 'turn'].map(line => ({ march, bond, line }))));
const key = build => [build.march, build.bond, build.line].join('/');
const rows = [];

function run(arena, difficulty, seed, build, active, restore) {
  let game = new Game({ mode:'standard', difficulty, seed, openingArenaId:arena, arenaSelection:'route', maxPlayers:cohort === 'solo' ? 1 : 2 });
  let summoner = game.addPlayer('solo', 'Joss Merrow', 'summoner');
  const players = cohort === 'solo' ? [summoner] : [summoner, game.addPlayer('ally', 'Mara', 'soldier')];
  const play = () => wholePolicy({ arenaFor:runtimeArena, segmentRect, segmentCircle, formationRules, ordinary:restRaidInput });
  let policy = play();
  const paths = [[cohortIds.entry, cohortIds[build.march]], [bondIds.entry, bondIds[build.bond]], [formationIds.entry, formationIds[build.line]]];
  const offset = (worlds.findIndex(world => world[0] === arena) + builds.indexOf(build)) % paths.length;
  const sequence = [...paths.slice(offset), ...paths.slice(0, offset)];
  const learned = id => summoner.skills.includes(id);
  const unspent = () => summoner.totalSp - summoner.skills.reduce((sum, id) => sum + game.skillCost(id), 0);
  const full = () => paths.every(([, fit]) => learned(fit));
  const purchases = [], effects = [], encounters = [];
  const shots = new Map();
  const trace = createHash('sha256'), continuation = createHash('sha256');
  let serial = 0, frames = 0, lastShop = -1, boundary;
  const buy = (player, kind, item) => game.transact(player.id, { kind, item, id: 'summoner-trial-' + ++serial }).ok;
  function learn(item) {
    assert(buy(summoner, 'skill', item), item);
    purchases.push({ item, earned:summoner.totalSp, clears:summoner.progress.clears, left:unspent() });
  }
  function advanceSkills() {
    if (!learned('summoner-bonds-1')) learn('summoner-bonds-1');
    for (const [entry] of sequence) if (!learned(entry) && unspent() >= 2) learn(entry);
    if (sequence.every(([entry]) => learned(entry))) {
      for (const [, fit] of sequence) if (!learned(fit) && unspent() >= 2) learn(fit);
    }
  }
  function outfit(player) {
    for (const item of data.weapons.filter(w => w.classId === player.classId).sort((a, b) => b.tier - a.tier)) {
      if (player.weapon === item.id || buy(player, 'weapon', item.id)) break;
    }
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy(player, 'upgrade', item);
    buy(player, 'supply', 'medkit');
  }
  function saveBoundary() {
    const save = game.offlineCheckpoint();
    assert(save?.phase === 'shop' && save.practiceOnly && save.contentRevision === CONTENT_REVISION);
    assert.deepEqual(save.player.skills, summoner.skills);
    assert.equal(save.player.totalSp - unspent(), 13);
    const payload = JSON.stringify(save);
    const stats = [summoner.ammo, summoner.qAt, summoner.eAt, summoner.ultimateAt];
    boundary = { sha256:sha256(payload), earned:save.player.totalSp, clears:summoner.progress.clears, skills:[...summoner.skills], stats };
    policy = play();
    if (!restore) return;
    game = Game.restoreOffline(JSON.parse(payload));
    summoner = game.players.get(save.player.id);
    players[0] = summoner;
    assert.deepEqual(summoner.skills, save.player.skills);
    assert.deepEqual([summoner.ammo, summoner.qAt, summoner.eAt, summoner.ultimateAt], stats);
    assert.equal(game.retinue.owned(summoner.id).length, 0);
    const kit = game.kitStatus(summoner.id);
    for (const path of [kit.cohort, kit.bond, kit.formation]) assert(path && path.recoveryAt === 0);
  }
  advanceSkills();
  assert.equal(purchases.length, 2);
  players.forEach(outfit);
  assert(game.start());

  while (!['victory', 'defeat'].includes(game.phase) && frames++ < 90000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote', 'contractVote', 'secretOffer'].includes(game.phase)) {
        for (const player of players) game.vote(player.id, game.phase === 'contractVote' ? 1 : 0);
      }
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        advanceSkills();
        players.forEach(outfit);
        if (!boundary && cohort === 'solo' && full()) saveBoundary();
      }
      game.step();
      game.drainEvents();
      continue;
    }
    const view = viewOf(game, summoner.id);
    const owned = view.players.find(p => p.id === summoner.id);
    const hostile = [...shots.values()];
    const fitted = full();
    const assignments = new Set(view.classCues.filter(cue => cue.kind === 'summoner-cohort' && cue.state === 'march' && cue.owner === summoner.id).map(cue => cue.unit));
    const attackBefore = new Map(game.retinue.owned(summoner.id).map(unit => [unit.id, unit.attackAt]));
    const encounter = { index:view.encounter, arena:view.arenaId, boss:view.boss.id };
    if (encounters.at(-1)?.index !== encounter.index) encounters.push(encounter);
    for (const player of players) {
      const body = view.players.find(p => p.id === player.id);
      assert(body);
      const control = player.status !== 'active' ? { interact: true } : player === summoner ?
        policy(view, owned, hostile, active) : restRaidInput(view, body, hostile);
      const base = { ...idleInput(), ...control, clientTick:game.combatTick };
      base.aim = Math.atan2(Math.sin(base.aim), Math.cos(base.aim));
      trace.update(JSON.stringify(base));
      if (boundary) continuation.update(JSON.stringify(base));
      assert(game.submitInput(player.id, { ...base, sequence:player.ack + 1 }));
    }
    game.step();
    const record = id => effects.push({ id, boss:encounter.boss, arena:encounter.arena, at:game.combatTick, clears:summoner.progress.clears, fitted });
    for (const entity of game.retinue.owned(summoner.id)) {
      if (assignments.has(entity.id) && entity.attackAt > (attackBefore.get(entity.id) ?? Infinity)) record('cohort-assigned-attack');
    }
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id, { ...shot, seenAt:game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type === 'sound' && event.owner === summoner.id && /^summoner-(?:cohort|bond|formation)-/.test(event.id)) {
        assert(active);
        record(event.id);
      }
    }
    const state = JSON.stringify([game.phase, game.combatTick, game.boss.health, ...players.map(p => [p.x, p.y, p.health, p.ammo, p.damageDealt]),
      game.kitStatus(summoner.id), ...game.retinue.owned(summoner.id).map(unit => [unit.id, unit.x, unit.y, unit.health, unit.attackAt])]);
    trace.update(state);
    if (boundary) continuation.update(state);
  }
  assert(['victory','defeat'].includes(game.phase));
  if (restore) assert(boundary);
  const terminals = [['cohort', 'cohort-assigned-attack'], ['bond', 'summoner-bond-mend'], ['formation', 'summoner-formation-catch']];
  const success = observed => terminals.filter(([, event]) => observed.some(row => row.id === event)).map(([path]) => path);
  return { arena, difficulty, seed, fitting:key(build), active, won:game.phase === 'victory', clears:summoner.progress.clears,
    fullyFitted:full(), pathsUsed:success(effects), fittedUsed:success(effects.filter(row => row.fitted)), encounters, purchases, effects,
    boundary, continuation:boundary && continuation.digest('hex'), trace:trace.digest('hex') };
}

for (const [arena, difficulty, seed] of worlds) for (const build of builds) for (const active of [false, true]) {
  if (sample && sample !== [arena, key(build), active ? 'active' : 'unused'].join(',')) continue;
  const row = run(arena, difficulty, seed, build, active, mode === 'restore');
  rows.push(row);
  console.log(JSON.stringify({ arena, fitting:row.fitting, active, won:row.won, clears:row.clears, fitted:row.fullyFitted,
    pathsUsed:row.pathsUsed, fittedUsed:row.fittedUsed, effects:row.effects.length }));
}
assert.equal(rows.length, sample ? 1 : 48);
function sourceFiles(dir) {
  return readdirSync(join(checkout, dir), { withFileTypes:true }).flatMap(entry => {
    const path = dir + '/' + entry.name;
    return entry.isDirectory() ? sourceFiles(path) : [path];
  });
}
const source = createHash('sha256');
for (const path of sourceFiles('src').sort()) source.update(path + '\0').update(readFileSync(join(checkout, path)));
receipt(output, { protocol:PROTOCOL, contentRevision:CONTENT_REVISION, runtimeSourceSha256:source.digest('hex'), cohort, sample, mode,
  driverSha256:sha256(readFileSync(new URL(import.meta.url))), policySha256:sha256(readFileSync(new URL('./whole-policy.mjs', import.meta.url))), rows });
