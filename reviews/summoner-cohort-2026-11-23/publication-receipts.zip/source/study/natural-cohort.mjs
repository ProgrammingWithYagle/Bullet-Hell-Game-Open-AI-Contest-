import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { cohortInput } from './cohort-pilot.mjs';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';

const [mode, cohort, output, selection] = process.argv.slice(2);
assert(['short','standard'].includes(mode) && ['solo','party'].includes(cohort) && output);
const selected=selection?.split(':');
const here=path=>new URL('./'+path,import.meta.url);
const compiled=readJson(here('game01.json'));
const { Game, data, viewOf, idleInput, restRaidInput, cohortIds, PROTOCOL, CONTENT_REVISION }=await verifiedBundle(fileURLToPath(here('game01.mjs')),compiled.bundle);
assert.equal(PROTOCOL,99);

const worlds=[['gatehouse',41],['sunken-chapel',67],['ossuary-works',103]];
const variants=['entry','cross','relay'];
function conduct(arena,seed,variant,active) {
  const game=new Game({mode,difficulty:'normal',seed,openingArenaId:arena,arenaSelection:'fixed',maxPlayers:cohort==='solo'?1:2});
  const summoner=game.addPlayer('joss','Joss','summoner');
  const support=cohort==='party'?game.addPlayer('squad','Mara','soldier'):undefined;
  const players=support?[summoner,support]:[summoner];
  const hostiles=new Map(), purchases=[], commands=[], attacks=[];
  const trace=createHash('sha256');
  let serial=0,frames=0,store=-1;

  function buy(player,kind,item) {
    const result=game.transact(player.id,{id:'cohort-study-'+ ++serial,kind,item});
    if (result.ok && kind==='skill') purchases.push({item,earned:player.totalSp,clears:player.progress.clears});
    return result.ok;
  }
  function outfit(player) {
    const weapons=data.weapons.filter(weapon=>weapon.classId===player.classId).sort((a,b)=>b.tier-a.tier);
    for (const weapon of weapons) if (weapon.id===player.weapon || buy(player,'weapon',weapon.id)) break;
    for (const upgrade of ['damage','health','fire-rate','reload','magazine']) buy(player,'upgrade',upgrade);
    buy(player,'supply','medkit');
  }
  assert(buy(summoner,'skill','summoner-bonds-1')&&buy(summoner,'skill',cohortIds.entry));
  assert.equal(summoner.totalSp,3);
  if (variant!=='entry') assert(!buy(summoner,'skill',cohortIds[variant]));
  players.forEach(outfit);
  assert(game.start());

  while (!['defeat','victory'].includes(game.phase) && frames++<90_000) {
    if (game.phase!=='combat') {
      hostiles.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const p of players) game.vote(p.id,0);
      if (game.phase==='shop' && store!==game.encounter) {
        store=game.encounter;
        if (variant!=='entry' && !summoner.skills.includes(cohortIds[variant]) && summoner.totalSp>=5) {
          assert(buy(summoner,'skill',cohortIds[variant]));
          assert(summoner.progress.clears>=1);
        }
        players.forEach(outfit);
      }
      game.step();
      game.drainEvents();
      continue;
    }
    const before=viewOf(game,summoner.id);
    const ready=before.classCues.filter(cue=>cue.kind==='summoner-cohort' && cue.state==='march' && cue.owner===summoner.id);
    const observed=[...hostiles.values()];
    const enabled=active && (variant==='entry' || summoner.skills.includes(cohortIds[variant]));
    for (const p of players) {
      const seen=before.players.find(player=>player.id===p.id);
      const command=p.status!=='active'?{interact:true}:p===summoner?
        cohortInput(before,seen,observed,restRaidInput,enabled):restRaidInput(before,seen,observed);
      const input={...idleInput(),...command,sequence:p.ack+1,clientTick:game.combatTick};
      input.aim=Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      assert(game.submitInput(p.id,input));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type==='shots') for (const shot of event.shots) if (shot.owner==='hostile') hostiles.set(shot.id,{...shot,seenAt:game.combatTick});
      if (event.type==='remove') for (const id of event.ids) hostiles.delete(id);
      if (event.type==='sound' && event.owner===summoner.id && event.id.startsWith('summoner-cohort-')) {
        assert(enabled);
        commands.push({id:event.id,tick:game.combatTick,boss:before.boss.id,clears:summoner.progress.clears});
      }
    }
    for (const order of ready) {
      const unit=game.retinue.entities.get(order.unit);
      if (unit?.action==='attack' && unit.actionAt===game.combatTick) attacks.push({unit:unit.id,kind:unit.kind,order:order.id,tick:unit.actionAt,boss:before.boss.id});
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,summoner.x,summoner.y,summoner.health,summoner.ammo,
      summoner.damageDealt,...game.retinue.owned(summoner.id).map(unit=>[unit.id,unit.x,unit.y,unit.health,unit.actionAt])]));
  }
  assert(['defeat','victory'].includes(game.phase));
  return {arena,seed,variant,active,won:game.phase==='victory',clears:summoner.progress.clears,
    acquired:variant==='entry'||summoner.skills.includes(cohortIds[variant]),purchases,commands,attacks,trace:trace.digest('hex')};
}

const rows=[];
for (const [arena,seed] of worlds) for (const variant of variants) for (const active of [false,true]) {
  if (selected && (selected[0]!==arena || selected[1]!==variant || selected[2]!==String(active))) continue;
  const row=conduct(arena,seed,variant,active);
  rows.push(row);
  console.log(JSON.stringify({mode,cohort,arena,variant,active,won:row.won,clears:row.clears,commands:row.commands.length,attacks:row.attacks.length}));
}
assert.equal(rows.length,selected?1:18);
receipt(output,{passed:true,protocol:PROTOCOL,revision:CONTENT_REVISION,bundle:compiled.bundle,mode,cohort,rows});
