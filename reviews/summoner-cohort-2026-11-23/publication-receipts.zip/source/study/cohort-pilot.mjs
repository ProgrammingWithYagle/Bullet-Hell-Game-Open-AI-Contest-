export function cohortInput(view, player, observed, restRaidInput, useCohort, suppressGather = false) {
  const base = restRaidInput(view, player, observed);
  const kit = player.kit;
  const units = (view.retinue ?? []).filter(unit => unit.owner === player.id && unit.health > 0);
  const summoning = player.qAt <= view.combatTick && (kit.retinuePermanent ?? 0) < (kit.retinueCapacity ?? 4);
  const recalling = !suppressGather && player.eAt <= view.combatTick && kit.cohort?.stage !== 'march' && kit.cohort?.stage !== 'relay' &&
    units.some(unit => unit.health < unit.maxHealth * 0.52);
  if (useCohort && kit.cohort?.canSend && !base.dodge && (base.supply ?? -1) < 0) {
    return { ...base, technique1: true, q: false, e: false, ultimate: false, fire: false };
  }
  return { ...base, q: summoning, e: recalling };
}
