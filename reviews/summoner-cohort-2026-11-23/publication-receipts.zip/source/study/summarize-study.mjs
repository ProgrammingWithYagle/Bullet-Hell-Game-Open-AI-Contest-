import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const here=path=>new URL('./'+path,import.meta.url);
const digest=path=>sha256(readFileSync(here(path)));
const compiled=readJson(here('game01.json'));
const content=readJson(here('content01.json'));
assert.equal(compiled.bundle,digest('game01.mjs'));
const groups=[], replays=[];
const replayDir='replays01/';
mkdirSync(here(replayDir));
const variants=['entry','cross','relay'];
const counts={orders:0,attacks:0,relayOpenings:0,secondOrders:0};
const run=promisify(execFile);
for (const mode of ['short','standard']) for (const cohort of ['solo','party']) {
  const stem=mode+'-'+cohort;
  const path=stem+'01.json';
  const group=readJson(here(path));
  assert(group.passed && group.protocol===99 && group.revision===content.revision && group.bundle===compiled.bundle);
  assert(group.rows.length===18 && group.mode===mode && group.cohort===cohort);
  const active=group.rows.filter(row=>row.active), controls=group.rows.filter(row=>!row.active);
  for (const row of active) {
    const control=controls.find(other=>other.arena===row.arena && other.seed===row.seed && other.variant===row.variant);
    assert(control && !control.commands.length && !control.attacks.length);
    assert.deepEqual(control.purchases,row.purchases);
    counts.orders+=row.commands.filter(event=>event.id==='summoner-cohort-drive').length;
    counts.relayOpenings+=row.commands.filter(event=>event.id==='summoner-cohort-open').length;
    counts.secondOrders+=row.commands.filter(event=>event.id==='summoner-cohort-relay').length;
    counts.attacks+=row.attacks.length;
  }
  for (const variant of variants) {
    const row=active.find(value=>value.variant===variant && value.commands.length) ?? active.find(value=>value.variant===variant);
    const selector=row.arena+':'+variant+':true';
    const member=replayDir+stem+'-'+variant;
    const result=await run(process.execPath,[fileURLToPath(here('natural-cohort.mjs')),mode,cohort,fileURLToPath(here(member+'.json')),selector],
      {cwd:checkout,windowsHide:true,maxBuffer:1_000_000});
    writeFileSync(here(member+'.log'),result.stdout+result.stderr,{flag:'wx'});
    const exact=readJson(here(member+'.json'));
    assert(exact.bundle===compiled.bundle && exact.rows.length===1);
    assert.deepEqual(exact.rows[0],row);
    replays.push({path:member+'.json',sha256:digest(member+'.json'),logSha256:digest(member+'.log'),mode,cohort,variant,trace:row.trace});
  }
  const wins=row=>variants.map(variant=>row.filter(value=>value.variant===variant && value.won).length);
  groups.push({mode,cohort,path,sha256:digest(path),cases:18,matched:9,activeWins:wins(active),ownedUnusedWins:wins(controls),
    dispatches:active.filter(row=>row.commands.length).length});
}
assert(counts.orders>0 && counts.attacks>0 && counts.relayOpenings>0 && counts.secondOrders>0);
assert(counts.secondOrders<=counts.relayOpenings);
assert.equal(replays.length,12);
receipt(here(replayDir+'summary.json'),{passed:true,bundle:compiled.bundle,revision:content.revision,cases:replays});
const result={passed:true,protocol:99,revision:content.revision,bundle:compiled.bundle,runs:72,matched:36,exactReplays:12,
  counts,groups,replaySummarySha256:digest(replayDir+'summary.json')};
receipt(here('study-summary01.json'),result);
console.log(JSON.stringify(result));
