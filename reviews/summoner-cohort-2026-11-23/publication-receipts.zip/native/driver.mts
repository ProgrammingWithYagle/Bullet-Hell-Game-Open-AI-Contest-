import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { cohortInput } from './cohort-pilot.mjs';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL } = await repoImport('src/shared/protocol.ts');
const { cohortIds, cohortRules } = await repoImport('src/shared/summoner-cohort.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');

const [transport, fitting, out, supplied, testAudience = 'public'] = process.argv.slice(2);
assert(PROTOCOL===99 && ['worker','peer'].includes(transport) && ['entry','cross','relay'].includes(fitting) && out);
const setup = {
  mode:fitting==='entry'?'short':'standard', difficulty:'normal', arenaSelection:'route', openingArenaId:'gatehouse',
  freePlay:{ openingBossId:'constable', variant:'normal', seed:73 },
} as const;
const closeHealth = (view,id) => view?.players.find(player => player.id === id);
const spending = p => p.skills.reduce((sum,id) => sum+[...data.specializationSkills,...data.skills].find(row=>row.id===id).cost,0);

async function wait(check, detail, limit=5_000) {
  const end=Date.now()+limit;
  while (!check()) {
    assert(Date.now()<end, typeof detail==='function' ? detail() : detail);
    await sleep(12);
  }
}

function pilotState() {
  return { events:[], observed:new Map(), cues:new Map() };
}

function recordCues(rows, view) {
  for (const cue of view.classCues) if (cue.kind==='summoner-cohort' && !rows.has(cue.id)) rows.set(cue.id,{ first:cue });
}

async function earnedFlow(adapter) {
  const view=()=>{const current=adapter.view();assert(current);return current;};
  const owner=()=>{const player=closeHealth(view(),adapter.id);assert(player);return player;};
  const status=()=>owner().kit.cohort;
  const bought=[];
  const liveUnits=()=> (view().retinue??[]).filter(unit=>unit.owner===adapter.id&&unit.health>0&&!unit.temporary);
  async function buy(item) {
    const purchase=await adapter.purchase({ kind:'skill',item });
    assert(purchase.ok,JSON.stringify({item,purchase}));
    bought.push({item,earned:owner().sp+spending(owner()),clears:owner().progress.clears});
  }
  async function outfit() {
    for (const weapon of data.weapons.filter(row=>row.classId==='summoner').sort((a,b)=>b.tier-a.tier)) {
      if (owner().weapon===weapon.id || (await adapter.purchase({kind:'weapon',item:weapon.id})).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({kind:'upgrade',item});
  }
  const ordinary = () => cohortInput(view(),owner(),[...adapter.observed.values()],restRaidInput,false,true);
  const control = props => {
    const aim = typeof props.aim==='number' ? Math.atan2(Math.sin(props.aim), Math.cos(props.aim)) : undefined;
    return adapter.input(aim===undefined ? props : {...props,aim});
  };
  async function submit(props) {
    const seq=control(props);
    await wait(()=>owner().ack>=seq || view().phase!=='combat','Ordinary input is acknowledged');
  }

  const fitted=fitting!=='entry';
  assert.equal(owner().sp,3);
  await buy('summoner-bonds-1');
  await buy(cohortIds.entry);
  await wait(()=>status()!==undefined,'The owner receives private command guidance');
  if (fitted) assert(!(await adapter.purchase({kind:'skill',item:cohortIds[fitting]})).ok);
  await outfit();
  adapter.start();
  await wait(()=>view().phase==='combat','The ordinary opening encounter begins');
  if (fitted) {
    const end=Date.now()+135_000;
    while (view().phase!=='shop') {
      assert(Date.now()<end && !['victory','defeat'].includes(view().phase),'Reach a real first-clear shop');
      if (view().phase==='combat') {
        control(ordinary());
        adapter.allyPressure?.();
      } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(owner().sp+spending(owner()),5);
    await buy(cohortIds[fitting]);
    assert.equal((await adapter.purchase({kind:'skill',item:cohortIds[fitting==='cross'?'relay':'cross']})).reason,'incompatibleItem');
    await outfit();
    await wait(()=>view().phase==='combat','The second ordinary encounter begins',95_000);
  }
  const firstClear=owner().progress.clears;
  const boss=view().boss.id;
  console.log(JSON.stringify({ milestone:'earned purchase',boss,fitting,firstClear,bought }));

  adapter.pause(true);
  await wait(()=>adapter.paused(),'The authority acknowledges pause');
  const pausedAt=view().combatTick;
  const ignored=control({technique1:true});
  await sleep(110);
  assert.equal(view().combatTick,pausedAt);
  assert(owner().ack<ignored && status()?.stage==='ready');
  adapter.pause(false);
  await wait(()=>!adapter.paused(),'The authority acknowledges resume');
  await adapter.stopAlly?.();

  const detail=()=>JSON.stringify({fitting,boss:view().boss.id,phase:view().phase,tick:view().combatTick,p:owner().health,
    ammo:owner().ammo,units:liveUnits().map(unit=>unit.kind),mark:owner().kit.retinueMarkKey,cohort:status(),remaining:view().boss.health});
  const near=Date.now()+45_000;
  while (!(status()?.canSend && owner().kit.retinueMarkKey==='boss')) {
    assert(Date.now()<near && view().phase==='combat','An actual beacon mark and living company are required. '+detail());
    const input=ordinary();
    control({...input,ultimate:false,e:false,q:input.q && liveUnits().length<2});
    adapter.allyCover?.();
    await sleep(24);
  }
  function quiet() {
    const input=ordinary();
    return {...input,q:false,e:false,ultimate:false,fire:false,reload:false,supply:-1};
  }
  async function watchFight(check, limit) {
    const end=Date.now()+limit;
    while(!check()) {
      assert(Date.now()<end && view().phase==='combat',detail());
      control(quiet());
      adapter.allyCover?.();
      await sleep(24);
    }
  }
  await submit(quiet());
  await wait(()=>status()?.canSend && owner().kit.retinueMarkKey==='boss',detail);
  const first=owner(), hpBefore=view().boss.health, at=view().combatTick;
  const company=liveUnits().map(unit=>unit.id);
  await submit({...quiet(),dodge:false,technique1:true});
  const expected=fitting==='relay'?1:2;
  const cues=()=>[...adapter.cues.values()].map(row=>row.first).filter(cue=>cue.owner===adapter.id && cue.at>=at);
  await wait(()=>cues().filter(cue=>cue.state==='march').length>=expected,detail);
  const issued=cues().filter(cue=>cue.state==='march').slice(0,expected);
  assert(issued.every(cue=>company.includes(cue.unit) && cue.until-cue.at===cohortRules.duration));
  assert.equal(new Set(issued.map(cue=>cue.unit)).size,expected);
  assert.equal(owner().ammo,first.ammo-1);
  assert.deepEqual([owner().qAt,owner().eAt,owner().ultimateAt],[first.qAt,first.eAt,first.ultimateAt]);
  const cooldown=status().recoveryAt;
  if (fitting==='cross') assert(Math.hypot(issued[0].x-issued[1].x,issued[0].y-issued[1].y)>32);

  let appeared, second, beforeSecond, afterSecond, hpBeforeSecond;
  if (fitting==='relay') {
    await watchFight(()=>status()?.stage==='relay',7_000);
    appeared=cues().find(cue=>cue.state==='relay');
    assert(appeared && company.includes(appeared.unit) && appeared.unit!==issued[0].unit);
    assert.equal(appeared.until-appeared.at,cohortRules.relayWindow);
    assert(view().boss.health<hpBefore);
    await wait(()=>status()?.canSend,detail);
    beforeSecond=owner().ammo;
    hpBeforeSecond=view().boss.health;
    await submit({...quiet(),dodge:false,technique1:true});
    await wait(()=>cues().filter(cue=>cue.state==='march').length===2,detail);
    second=cues().filter(cue=>cue.state==='march').at(-1);
    assert(second.unit===appeared.unit && second.until-second.at===cohortRules.relayDuration);
    afterSecond=owner().ammo;
    assert.equal(afterSecond,beforeSecond);
    assert.equal(status().recoveryAt,cooldown);
  }
  await watchFight(()=>view().boss.health < (hpBeforeSecond ?? hpBefore),8_000);
  const hpAfter=view().boss.health;
  assert(hpAfter<hpBefore);
  const result = { boss,issued,appeared,second,hpBefore,hpAfter,hpBeforeSecond,company,startingFocus:first.ammo,
    beforeSecond,afterSecond,cooldown,exactSpend:1 };
  const witnessed=await adapter.peerWitness?.(result);
  return {passed:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,transport,fitting,bought,firstClear,setup,
    result,witnessed,pausedCommandsDiscarded:true,noCheckpointImports:true};
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: setup.freePlay.seed, maxPlayers: 1 }, name: 'Joss', classId: 'summoner' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'cohort-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), blade = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], blade: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  blade.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, blade.id)?.kit.cohort !== undefined) leaks++;
  };
  blade.onEvents = batch => remember(state.events, state.observed, batch, blade.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  blade.onPurchase = entry => replies.blade.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await blade.connect({ ...setup, name: 'Joss', classId: 'summoner', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => blade.view?.players.length === 2 && host.view?.players.length === 2, 'The Summoner joins as the second player');
    assert.equal(blade.view.owner, host.id);
    assert.notEqual(blade.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: blade.id, view: () => blade.view,
      rawOwner: () => {
        const state = blade.room?.state.players.get(blade.id);
        return { private:state?.lineworkOwner, build:state ? JSON.parse(state.build).skills : undefined };
      },
      input: props => { blade.input(inputFrame(blade.view, ++sequence, props)); return sequence; },
      purchase: request => reply(blade, replies.blade, request), start: () => host.start(),
      vote: i => { host.vote(i); blade.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => blade.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'The host stops on the ordinary map');
      },
      allyCover: () => hostInput({ ...restRaidInput(host.view, readyHost(), [...peers.observed.values()]), q: false, e: false, ultimate: false, fire: false }),
      peerWitness: async operation => {
        const cues = [...operation.issued,operation.appeared,operation.second].filter(Boolean);
        await wait(()=>cues.every(cue=>peers.cues.has(cue.id)),'The host sees the real command positions and earned relay');
        for (const cue of cues) {
          const received=peers.cues.get(cue.id).first;
          for (const key of ['id','owner','unit','radius','at','until','state']) assert.equal(received[key],cue[key]);
          if (cue.state==='march') assert.deepEqual(received,cue);
        }
        assert.equal(leaks,0);
        return { nonHost:true, shared:cues.map(cue=>cue.id), ownedStatePrivate:true };
      },
    });
    host.endMatch();
    await wait(() => [host, blade].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    blade.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, driverSha256: sha256(readFileSync(new URL(import.meta.url))), testedAudience: testAudience });
console.log(JSON.stringify({passed:true,transport,fitting,boss:result.result.boss,firstClear:result.firstClear,
  orders:result.result.issued.length,relay:result.result.second?.unit,damage:result.result.hpBefore-result.result.hpAfter}));
