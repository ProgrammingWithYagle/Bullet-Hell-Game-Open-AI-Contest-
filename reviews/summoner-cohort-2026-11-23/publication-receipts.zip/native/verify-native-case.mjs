import assert from 'node:assert/strict';

export function verifyNativeCase(report, expected) {
  const { transport, fitting, revision, driver, worker } = expected;
  assert(report.passed && report.protocol===99 && report.contentRevision===revision && report.driverSha256===driver);
  assert(report.transport===transport && report.fitting===fitting && report.pausedCommandsDiscarded && report.noCheckpointImports);
  const entry=fitting==='entry', relay=fitting==='relay';
  assert.equal(report.firstClear,entry?0:1);
  assert.equal(report.bought.at(-1).earned,entry?3:5);
  const { boss, issued, appeared, second, hpBefore, hpAfter, hpBeforeSecond, company, beforeSecond, afterSecond, cooldown, exactSpend }=report.result;
  assert(typeof boss==='string' && boss.length>0);
  assert.equal(issued.length,relay?1:2);
  assert(issued.every(cue=>cue.kind==='summoner-cohort' && cue.state==='march' && company.includes(cue.unit) && cue.until-cue.at===105));
  assert.equal(new Set(issued.map(cue=>cue.unit)).size,issued.length);
  assert.equal(exactSpend,1);
  assert(hpAfter<hpBefore && cooldown===issued[0].at+232);
  if (fitting==='cross') assert(Math.hypot(issued[0].x-issued[1].x,issued[0].y-issued[1].y)>32);
  if (relay) {
    assert(appeared.state==='relay' && appeared.until-appeared.at===59);
    assert(second.state==='march' && second.until-second.at===90 && second.at<appeared.until && second.unit===appeared.unit);
    assert(company.includes(second.unit) && second.unit!==issued[0].unit && second.id!==appeared.id);
    assert.equal(beforeSecond,afterSecond);
    assert(hpAfter<hpBeforeSecond);
  } else assert(!appeared && !second);
  if (transport==='worker') {
    assert(report.wholeOptimizedWorker && !report.workerPatched && /^[0-9a-f]{64}$/.test(report.workerSha256));
    if (worker) assert.equal(report.workerSha256,worker);
  } else {
    assert(report.witnessed.nonHost && report.witnessed.ownedStatePrivate);
    for (const cue of [...issued,appeared,second].filter(Boolean)) assert(report.witnessed.shared.includes(cue.id));
  }
  return {transport,fitting,boss,firstClear:report.firstClear,issued:issued.length,relay:!!second,damage:hpBefore-hpAfter};
}
