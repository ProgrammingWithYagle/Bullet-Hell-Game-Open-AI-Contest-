import assert from 'node:assert/strict';

export function verifyNativeCase(report, expected) {
  const {transport,fitting,revision,driver,worker}=expected;
  assert(report.passed&&report.protocol===96&&report.contentRevision===revision&&report.driverSha256===driver);
  assert(report.transport===transport&&report.fitting===fitting&&report.pausedCommandsDiscarded&&report.noCheckpointImports);
  assert.equal(report.firstClear,fitting==='entry'?0:1);
  assert.equal(report.bought.at(-1).earned,fitting==='entry'?3:5);
  const {stage,first,release,turned,paid,boss}=report.result;
  assert(typeof boss==='string'&&boss.length>0);
  assert(first.hits.length>0&&release.hits.length>0&&paid.q>stage.first.at);
  assert(first.hits.every(row=>row.after<row.before)&&release.hits.every(row=>row.after<row.before));
  assert(stage.first.state==='preparing'&&stage.first.until-stage.first.at===57);
  assert.equal(turned,fitting==='turn');
  assert.equal(release.follow,fitting==='follow');
  if(fitting==='turn')assert(stage.phases.every(row=>row.id===stage.first.id&&row.until===stage.first.until));
  if(fitting==='follow')assert(release.cue.radius<first.cue.radius&&release.cue.id!==first.cue.id);
  if(transport==='worker')assert(report.wholeOptimizedWorker&&!report.workerPatched&&report.workerSha256===worker);
  else assert(report.witnessed.nonHost&&report.witnessed.ownedStatePrivate&&report.witnessed.sharedCut===release.cue.id);
  return {transport,fitting,boss,firstClear:report.firstClear,stage:stage.first.id,turned,
    firstHits:first.hits,releaseHits:release.hits};
}
