import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { measuredPilot } from './measured-pilot.mjs';

export function recordMeasuredCues(cues,view) {
  for(const cue of view.classCues){
    if(cue.kind!=='sword-measured-stance')continue;
    let known=cues.get(cue.id);
    if(!known){known={first:cue,last:cue,phases:[]};cues.set(cue.id,known);}
    if(JSON.stringify(known.last)!==JSON.stringify(cue)||!known.phases.length)known.phases.push(cue);
    known.last=cue;
  }
}

export function createCombatPolicy({ adapter,view,data,HZ,rules,runtimeArena,bulwarkTrialWorld,clearTrialWalk,
  segmentRect,segmentCircle,distance,restRaidInput,fitting }) {
  let worldTick=-1,world;
  const game={
    get arena(){return runtimeArena(view().arenaId,view().run.difficulty);},
    get obstacles(){
      const seen=view();
      if(worldTick!==seen.combatTick||world?.arenaId!==seen.arenaId){
        worldTick=seen.combatTick;world={...bulwarkTrialWorld(seen),arenaId:seen.arenaId};
      }
      return world.obstacles;
    },
    get combatTick(){return view().combatTick;},
    get encounter(){return view().encounter;},
    movementSpeed(body){return body.speed;},
  };
  function danger(seen,point,horizon){
    if(seen.minions.some(actor=>actor.health>0&&distance(actor,point)<22+horizon))return true;
    if(seen.fields.some(field=>field.kind==='zone'&&distance(field,point)<field.radius+8))return true;
    for(const shot of adapter.observed.values()){
      const time=Math.min(horizon,shot.expires-seen.combatTick);
      if(time<=0||shot.owner!=='hostile'||distance(shot,point)>435)continue;
      const elapsed=Math.max(0,seen.combatTick-shot.seenAt)/HZ;
      const from={x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed};
      const to={x:from.x+shot.vx*time/HZ,y:from.y+shot.vy*time/HZ};
      const hit=segmentCircle(from,to,point,shot.radius+data.rules.playerRadius+2);
      if(hit!==null&&!game.obstacles.some(wall=>(segmentRect(from,to,wall,shot.radius)?.t??Infinity)<=hit))return true;
    }
    return false;
  }
  const context={game,data,HZ,rules,distance,segmentRect,clearTrialWalk,danger};
  const navigate=explicitNavigation(context);
  const ordinaryUse = measuredPilot({ ...context, policy:'unused' });
  const fittingUse = measuredPilot({ ...context, policy:fitting==='entry' ? 'measured' : fitting });
  const baseline = (seen,body) => restRaidInput(seen,body,[...adapter.observed.values()]);
  return {
    ordinary:(seen,body) => ordinaryUse(seen,body,baseline(seen,body),navigate),
    invoke:(seen,body) => fittingUse(seen,body,baseline(seen,body),navigate),
  };
}

function healthMap(view) {
  return new Map([
    ['boss/'+view.boss.id,view.boss.health],
    ...view.minions.map(row=>['minion/'+row.id,row.health]),
    ...view.bossCues.filter(row=>['raid-prop','service-prop','early-prop','stitch-pin'].includes(row.kind)).map(row=>['part/'+row.id,row.health]),
  ]);
}
function damageBetween(before,after) {
  const now = healthMap(after);
  return [...before].flatMap(([id,health])=>{
    const lower = now.get(id);
    if (lower===undefined || lower>=health) return [];
    return [{ id,before:health,after:lower }];
  });
}
const angleDelta = (a,b) => Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)));

export async function exerciseMeasured({adapter,view,owner,submit,fitting,rules,equip,policy}) {
  const deadline = Date.now()+175_000, beginning = view().combatTick, eventStart = adapter.events.length;
  const payments = new Map(), readings = [], requested = [];
  let lastShop = view().encounter, lastTick = -1;
  const history = () => [...adapter.cues.values()].filter(row=>row.first.owner===adapter.id&&row.first.at>=beginning);
  const sounds = () => adapter.events.slice(eventStart).filter(event=>event.type==='sound'&&event.owner===adapter.id&&
    event.id.startsWith('sword-held-edge-')).map(event=>event.id);
  for (;;) {
    const seen = view(), body = owner();
    if (Date.now()>=deadline || ['victory','defeat'].includes(seen.phase)) {
      assert.fail(JSON.stringify({ fitting,phase:seen.phase,boss:seen.boss.id,tick:seen.combatTick,
        health:body.health,readings:readings.slice(-10),lastRequests:requested.slice(-12),sounds:sounds(),cues:history().slice(-5) }));
    }
    if (seen.phase!=='combat') {
      if (['mutationVote','contractVote','secretOffer'].includes(seen.phase)) adapter.vote(0);
      if (seen.phase==='shop' && seen.encounter!==lastShop) { lastShop=seen.encounter; await equip(); }
      await sleep(20);
      continue;
    }
    for (const row of history().filter(row=>row.first.state!=='cut'&&!payments.has(row.first.id))) {
      payments.set(row.first.id,{ q:body.qAt,e:body.eAt,u:body.ultimateAt,ammo:body.ammo });
    }
    if (seen.combatTick===lastTick) { await sleep(10); continue; }
    lastTick = seen.combatTick;
    const frame = body.status==='active' ? policy.invoke(seen,body) : {interact:true};
    const live = seen.classCues.find(cue=>cue.kind==='sword-measured-stance'&&cue.owner===adapter.id&&cue.state!=='cut');
    const tryCut = live && frame.technique1 && live.state!=='preparing';
    const before = tryCut ? healthMap(seen) : undefined;
    if (frame.technique1) requested.push({at:seen.combatTick,aim:frame.aim,stance:live?.id,state:live?.state});
    await submit(frame);
    adapter.allyCover?.();
    if (!tryCut) continue;
    const next = view();
    const commit = history().find(row=>row.first.state==='cut'&&row.first.at>seen.combatTick&&row.first.at<=next.combatTick);
    if (!commit) continue;
    const row = history().find(candidate=>candidate.first.id===live.id);
    const paid = payments.get(live.id);
    assert(row && paid);
    const hits = damageBetween(before,next);
    const finish = live.state==='following';
    const release = { cue:commit.first, snapshotTick:next.combatTick, hits, follow:finish };
    readings.push({stance:live.id,...release});
    const first = readings.find(result=>result.stance===live.id&&!result.follow);
    const heard = sounds();
    const turned = row.phases.some(cue=>angleDelta(cue.aim,row.first.aim)>rules.releaseAngle);
    const done = fitting==='entry' ? !finish&&hits.length>0 :
      fitting==='turn' ? !finish&&turned&&hits.length>0 :
      finish&&Boolean(first?.hits.length)&&hits.length>0;
    if (!done) continue;
    assert(first && paid.q===owner().qAt && paid.e===owner().eAt && paid.u===owner().ultimateAt);
    assert(row.first.until-row.first.at===rules.holdTicks && row.first.state==='preparing');
    assert.equal(release.cue.x,live.x);
    assert.equal(release.cue.y,live.y);
    assert(heard.includes('sword-held-edge-set')&&heard.includes('sword-held-edge-cut'));
    if (turned) assert(heard.includes('sword-held-edge-turn')&&row.phases.every(cue=>cue.until===row.first.until));
    if (finish) {
      assert(heard.includes('sword-held-edge-follow')&&heard.includes('sword-held-edge-second'));
      assert.equal(first.cue.radius,rules.first.reach);
      assert.equal(release.cue.radius,rules.follow.reach);
      assert(angleDelta(first.cue.aim,release.cue.aim)>rules.releaseAngle);
    }
    return {stage:row,first,release,turned,paid,sounds:heard,lastRequests:requested.slice(-20),boss:next.boss.id};
  }
}
