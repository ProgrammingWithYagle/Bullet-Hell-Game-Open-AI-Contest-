import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson,receipt,verifiedBundle } from '../bastion/study-paths.mjs';

const [destination,cohort,bundle='game03',mode='short',sample] = process.argv.slice(2);
assert(destination && ['solo','party'].includes(cohort) && ['short','standard'].includes(mode) && /^game[0-9]{2}$/.test(bundle));
const here = file => new URL('./'+file,import.meta.url);
const verified = readJson(here(bundle+'.json'));
const { Game,data,viewOf,HZ,idleInput,CONTENT_REVISION,fuseSealId,mageVolatileIds,fuseSealRules:rules,distance,
  segmentRect,segmentCircle,restRaidInput,clearTrialWalk } = await verifiedBundle(fileURLToPath(here(bundle+'.mjs')),verified.bundle);
const scenarios = [['gatehouse','baby',41],['sunken-chapel','normal',73],['ossuary-works','normal',109],['crown-crypt','baby',61]];
const policies = ['banked','unused','binding','ward','crossed','shunt','twin'];
const point = ({x,y}) => ({x,y});
const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const forward = (p,a,d) => ({ x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d });
const around = angle => Math.atan2(Math.sin(angle),Math.cos(angle));

function run(arena,difficulty,seed,policy) {
  const game = new Game({ mode,difficulty,seed,arenaSelection:'route',openingArenaId:arena,maxPlayers:cohort==='solo'?1:2 });
  const mage = game.addPlayer('solo','Sable','mage');
  const ally = cohort==='party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [mage,ally] : [mage];
  const shots = new Map(), events = [], fights = [];
  const trace = createHash('sha256');
  const purchases=[];
  let serial=0, steps=0, lastShop=-1, lastEncounter=-1, tryUntil=0, plan, fitting, fitPerformed=false;
  const pattern=policy==='twin'?'crossed':policy==='shunt'?'binding':policy;
  const buy = (actor,kind,item) => game.transact(actor.id,{ kind,item,id:'fuse-seal-study-'+(++serial) });
  assert.equal(mage.totalSp,3);
  assert(buy(mage,'skill','mage-hexcraft-1').ok);
  if(policy!=='banked') assert(buy(mage,'skill',fuseSealId).ok);
  function equipment(p) {
    for(const weapon of data.weapons.filter(w=>w.classId===p.classId).sort((a,b)=>b.tier-a.tier))
      if(p.weapon===weapon.id || buy(p,'weapon',weapon.id).ok)break;
    for(const item of ['damage','health','fire-rate','reload','magazine']) buy(p,'upgrade',item);
    buy(p,'supply','medkit');
  }
  for(const p of actors) equipment(p);
  assert(game.start());

  function danger(view,p,horizon) {
    if(view.minions.some(actor=>actor.health>0 && distance(actor,p)<28+Math.min(28,horizon*2.8)))return true;
    if(view.fields.some(field=>field.kind==='zone' && distance(field,p)<field.radius+12))return true;
    for(const shot of shots.values()) {
      const lifetime=Math.min(horizon,shot.expires-view.combatTick);
      if(lifetime<=0 || distance(shot,p)>500)continue;
      const elapsed=(view.combatTick-shot.seenAt)/HZ;
      const origin={ x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed };
      const end={ x:origin.x+shot.vx*lifetime/HZ,y:origin.y+shot.vy*lifetime/HZ };
      const entry=segmentCircle(origin,end,p,shot.radius+data.rules.playerRadius+2);
      if(entry!==null && !game.obstacles.some(wall=>(segmentRect(origin,end,wall,shot.radius)?.t??Infinity)<=entry))return true;
    }
    return false;
  }
  const visible=(a,b,r=1)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,r));
  function movement(view,p,aim) {
    const target=forward(p,aim,23), world={ ...game.arena,obstacles:game.obstacles,tick:view.combatTick };
    return clearTrialWalk(world,p,target) && !danger(view,target,5) ? { moveX:Math.cos(aim),moveY:Math.sin(aim) } : undefined;
  }
  const navigation = new Map();
  const navigationPlans = [];
  const radius = data.rules.playerRadius;
  const aimVector = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  function firingLane(player, target, input) {
    const boss = point(target);
    const walls = game.obstacles;
    const occluded = (from) => walls.some(wall => segmentRect(from, boss, wall, 4));
    if (!occluded(player)) {
      navigation.delete(player.id);
      return;
    }
    if (player.health < player.maxHealth * .28 || danger(viewOf(game, player.id), player, 10)) return;
    const now = game.combatTick;
    const world = { ...game.arena, obstacles: walls, tick: now, playerRadius: radius };
    const clear = (a, b) => clearTrialWalk(world, a, b);
    let chase = navigation.get(player.id);
    if (!chase || chase.encounter !== game.encounter || now >= chase.at + 55 || chase.target !== target.id) {
      const margin = radius + 14;
      const bends = walls.flatMap(wall => [
        { x: wall.x - margin, y: wall.y - margin }, { x: wall.x + wall.width + margin, y: wall.y - margin },
        { x: wall.x - margin, y: wall.y + wall.height + margin }, { x: wall.x + wall.width + margin, y: wall.y + wall.height + margin },
      ]).filter(p => clear(p, p));
      const goals = [142, 200, 275, 360].flatMap(range => Array.from({ length: 20 }, (_, i) => {
        const aim = aimVector(i * Math.PI / 10);
        return { x: boss.x + aim.x * range, y: boss.y + aim.y * range };
      })).filter(p => clear(p, p) && !occluded(p));
      const points = [point(player), ...bends, ...goals];
      const cheapest = points.map((_, i) => i === 0 ? 0 : Infinity);
      const parent = points.map(() => -1), visited = new Set();
      let path = [];
      for (let pass = 0; pass < points.length; pass++) {
        let index = -1, shortest = Infinity;
        for (let i = 0; i < points.length; i++) if (!visited.has(i) && cheapest[i] < shortest) {
          index = i;
          shortest = cheapest[i];
        }
        if (index < 0) break;
        if (index > bends.length) {
          for (let start = index; start > 0; start = parent[start]) path.unshift(points[start]);
          break;
        }
        visited.add(index);
        for (let next = 1; next < points.length; next++) {
          const step = distance(points[index], points[next]);
          if (visited.has(next) || shortest + step >= cheapest[next] || !clear(points[index], points[next])) continue;
          cheapest[next] = shortest + step;
          parent[next] = index;
        }
      }
      chase = { at: now, encounter: game.encounter, path, target: target.id };
      navigation.set(player.id, chase);
      if (path.length) navigationPlans.push({ player: player.id, encounter: game.encounter, tick: now, from: point(player), route: [...path] });
    }
    while (chase.path.length && distance(player, chase.path[0]) < 2) chase.path.shift();
    const next = chase.path[0];
    if (!next || !clear(player, next)) return;
    const scale = Math.max(distance(player, next), game.movementSpeed(player) / HZ);
    return { ...input, moveX: (next.x - player.x) / scale, moveY: (next.y - player.y) / scale, dodge: false };
  }


  function ordinary(view,p,current) {
    const targets=view.bossCues.filter(c=>c.health>0 && ['service-prop','stitch-pin','raid-prop','early-prop'].includes(c.kind) &&
      distance(p,c)<530 && visible(p,c,2)).sort((a,b)=>distance(p,a)-distance(p,b));
    const immediate=view.minions.filter(c=>c.health>0 && distance(p,c)<82 && visible(p,c,2));
    const target=immediate.sort((a,b)=>distance(p,a)-distance(p,b))[0]??targets[0]??view.boss;
    const aim=bearing(p,target);
    if(immediate.length) {
      const retreat=[aim+Math.PI,aim+1.6,aim-1.6].map(h=>movement(view,p,h)).find(Boolean);
      return { ...current,...retreat,aim,fire:true };
    }
    if(visible(p,target,2))
      return { ...current,aim,fire:current.fire || distance(p,target)<320 };
    if(current.dodge || danger(view,p,6))return current;
    return firingLane(p,target,{ ...current,aim }) ?? current;
  }

  function openings(view,p,pattern,exclude) {
    const possible=view.minions.filter(c=>c.health>0&&distance(p,c)<380);
    const bossRadius=data.bosses.find(row=>row.id===view.boss.id)?.radius??24;
    const targets=[{...view.boss,radius:bossRadius},...possible].filter(target=>target.id!==exclude);
    const {bounds}=game.arena;
    const clearPoint=(point,pad)=>point.x>=bounds.x+pad&&point.x<=bounds.x+bounds.width-pad&&
      point.y>=bounds.y+pad&&point.y<=bounds.y+bounds.height-pad;
    const straight=(aim,target)=>{
      const gap=distance(p,target);
      return gap<=rules.forwardReach+target.radius-6&&gap>57&&visible(p,target,rules.width);
    };
    const ward=(aim,target)=>{
      const center=forward(p,aim,rules.wardOffset);
      if(!clearPoint(center,rules.width)||!visible(p,center,rules.width))return false;
      const vx=target.x-center.x,vy=target.y-center.y,
        range=Math.abs(vx*Math.sin(aim)-vy*Math.cos(aim)), depth=Math.abs(vx*Math.cos(aim)+vy*Math.sin(aim));
      return range<=rules.wardSpan-4 && depth<=target.radius+rules.width-5 && visible(center,target,2);
    };
    for(const target of targets){
      const direction=bearing(p,target);
      for(const offset of pattern==='binding'?[0]:[0,.19,-.19,.32,-.32,.42,-.42]){
        const aim=direction+offset;
        const forwardBlocked=!visible(p,forward(p,aim,Math.min(rules.forwardReach,42)),rules.width);
        if(pattern==='binding'&&straight(aim,target)||pattern==='ward'&&ward(aim,target)||
          pattern==='crossed'&&!forwardBlocked&&ward(aim,target))return {aim,target:target.id,range:distance(p,target)};
      }
    }
  }

  function shuntLane(view,p) {
    const v=bearing(p,view.boss), world={...game.arena,obstacles:game.obstacles,tick:view.combatTick};
    for(const angle of [v+.97,v-.97,v+.60,v-.60,v+1.40,v-1.40]) {
      const goal=forward(p,angle,85);
      if(clearTrialWalk(world,p,goal)&&!danger(view,goal,13)&&openings(view,goal,pattern))return goal;
    }
  }

  function openingHold(view,p,base){
    const idle={...base,q:false,e:false,ultimate:false};
    if(base.dodge||danger(view,p,7))return idle;
    const axis=bearing(p,view.boss), optimal=fitting==='twin'?215:289;
    const sorted=[axis,axis+.64,axis-.64,axis+1.24,axis-1.24,axis+Math.PI]
      .map(angle=>({angle,loss:Math.abs(distance(stepPoint(p,angle),view.boss)-optimal)}))
      .sort((a,b)=>a.loss-b.loss);
    const move=sorted.map(row=>movement(view,p,row.angle)).find(Boolean);
    return move?{...idle,...move}:idle;
  }
  const stepPoint=(p,angle)=>forward(p,angle,23);

  function decide(view,p,base) {
    if(policy==='banked'||policy==='unused')return base;
    if((policy==='shunt'||policy==='twin')&&!fitting)return {...base,ultimate:false,q:false,e:false};
    const now=view.combatTick, state=p.kit.fuseSeal;
    const qReady=mage.qAt<=now,eReady=mage.eAt<=now;
    const hands=mage.reloadAt<=now&&mage.dashUntil<=now;
    const safe=!base.dodge&&p.health>p.maxHealth*.36&&!danger(view,p,5)&&hands;
    const aim=bearing(p,view.boss);
    if(state?.phase==='prepared'){
      if(!safe)return {...base,q:false,e:false,ultimate:false};
      const planned=fitting==='shunt'&&plan?.route?{aim:bearing(p,plan.route),target:view.boss.id,range:distance(p,view.boss)}:
        fitting==='twin'?(openings(view,p,'binding')??openings(view,p,'ward')):openings(view,p,pattern);
      if(!planned&&now+8<(state.until??0))return {...base,q:false,e:false,ultimate:false};
      if(!planned)return {...base,q:false,e:false,ultimate:true};
      plan={...plan,...planned};
      if(pattern==='ward'||plan.initialSpell==='ward')return {...base,q:false,e:eReady,ultimate:false,aim:planned.aim};
      return {...base,q:qReady,e:false,ultimate:false,aim:planned.aim};
    }
    if(state?.phase==='binding'||state?.phase==='ward'||state?.phase==='crossed'){
      const shape=state.phase;
      if(!safe)return {...base,q:false,e:false,ultimate:false};
      if(fitting==='shunt'&&shape==='binding'&&!plan?.shunted&&now+13<state.until){
        const route=plan?.route;
        const stride=route&&movement(view,p,bearing(p,route));
        if(stride&&distance(p,route)>7){
          if(state.canShunt){
            plan.shunted=true;
            return {...stride,technique3:true,aim};
          }
          return {...stride,aim,fire:visible(p,view.boss,2)};
        }
      }
      const second=fitting==='twin'?openings(view,p,shape==='binding'?'ward':'binding'):openings(view,p,'crossed');
      if(pattern==='crossed'&&!state.echo&&shape!=='crossed'&&now+3<state.until&&second) {
        if(shape==='binding'&&eReady)return {...base,q:false,e:true,ultimate:false,aim:plan?.aim??aim};
        if(shape==='ward'&&qReady)return {...base,q:true,e:false,ultimate:false,aim:plan?.aim??aim};
      }
      const leading=state.split?(plan?.initialSpell==='ward'?'ward':'binding'):shape;
      const planned=(state.echo&&openings(view,p,shape,plan?.firstTarget))||openings(view,p,leading);
      if(planned){
        plan={...plan,...planned};
        if(state.split)plan.firstTarget=planned.target;
        return {technique3:true,aim:planned.aim};
      }
      return {...base,q:false,e:false,ultimate:false};
    }
    if(mage.ultimateAt>now||p.health<p.maxHealth*.37)return base;
    if(!tryUntil)tryUntil=now+(fitting?148:84);
    const route=fitting==='shunt'?shuntLane(view,p):undefined;
    const forwardShape=openings(view,p,'binding'), wardShape=openings(view,p,'ward');
    const launch=fitting==='shunt'&&route?openings(view,route,'binding'):
      fitting==='twin'&&forwardShape&&wardShape?forwardShape:openings(view,p,pattern);
    const available=pattern==='binding'?qReady:pattern==='ward'?eReady:qReady&&eReady;
    const keepFirst=!!fitting&&!fitPerformed;
    if(safe&&launch&&available&&(state?.until??0)<=now&&(keepFirst||now<tryUntil)&&(fitting!=='shunt'||route)){
      const initialSpell=fitting==='twin'&&game.encounter%2===0?'ward':'binding';
      plan={...launch,prepared:now,route,initialSpell};
      return {technique3:true,aim:launch.aim};
    }
    if(keepFirst)return openingHold(view,p,base);
    if(now>=tryUntil){tryUntil=0;return base;}
    return {...base,q:false,e:false,ultimate:false};
  }

  while(!['victory','defeat'].includes(game.phase)&&steps++<90000) {
    if(game.phase!=='combat') {
      shots.clear();
      if(['mutationVote','contractVote','secretOffer'].includes(game.phase))for(const p of actors)game.vote(p.id,0);
      if(game.phase==='shop' && game.encounter!==lastShop) {
        lastShop=game.encounter;
        for(const p of actors)equipment(p);
        if(!fitting&&(policy==='shunt'||policy==='twin')) {
          fitting=policy;
          const other=fitting==='shunt'?'twin':'shunt';
          assert.equal(mage.totalSp,mode==='short'?9:5);
          assert(buy(mage,'skill',mageVolatileIds[fitting]).ok);
          assert.equal(buy(mage,'skill',mageVolatileIds[other]).reason,'incompatibleItem');
          purchases.push({id:mageVolatileIds[fitting],earned:mage.totalSp,tick:game.combatTick});
        }
      }
      game.step();game.drainEvents();
      continue;
    }
    if(game.encounter!==lastEncounter) {
      lastEncounter=game.encounter;
      tryUntil=0;
      fights.push({ boss:game.boss.id,arena:game.arena.id,earned:mage.totalSp,tick:game.combatTick });
    }
    const view=viewOf(game,mage.id), before={ u:mage.ultimateAt,q:mage.qAt,e:mage.eAt,pos:point(mage),health:mage.health,damage:mage.damageDealt };
    for(const actor of actors) {
      const p=view.players.find(row=>row.id===actor.id);
      const base=actor.status==='active' ? ordinary(view,p,restRaidInput(view,p,[...shots.values()])) :
        actor.status==='downed'?{ interact:true }:{};
      const input=actor===mage && actor.status==='active'?decide(view,p,base):base;
      const frame={ ...idleInput(),...input,sequence:actor.ack+1,clientTick:game.combatTick };
      frame.aim=around(frame.aim);
      trace.update(JSON.stringify(frame));
      assert(game.submitInput(actor.id,frame),JSON.stringify(frame));
    }
    game.step();
    for(const event of game.drainEvents()) {
      if(event.type==='shots')for(const s of event.shots)if(s.owner==='hostile')shots.set(s.id,{ ...s,seenAt:game.combatTick });
      if(event.type==='remove')for(const id of event.ids)shots.delete(id);
      if(event.type!=='sound'||event.owner!==mage.id||!event.id.startsWith('mage-fuse-'))continue;
      const action=event.id.slice('mage-fuse-'.length);
      if(action==='shunt'||action==='echo')fitPerformed=true;
      if(action==='prepare')assert(mage.ultimateAt===before.u);
      if(action==='binding'||action==='ward')assert(mage.ultimateAt>before.u&&Math.max(mage.qAt-before.q,mage.eAt-before.e)>0);
      const releases=['vent','split','echo'];
      if(['crossed','wound','shunt',...releases].includes(action))assert(mage.ultimateAt===before.u&&mage.ultimateAt>game.combatTick);
      const cue=game.classCues().find(c=>c.owner===mage.id&&(releases.includes(action)?c.kind==='mage-fuse-vent'&&c.at===game.combatTick:c.kind==='mage-fuse-point'));
      events.push({action,boss:game.boss.id,at:game.combatTick,after:{u:mage.ultimateAt,q:mage.qAt,e:mage.eAt},position:point(mage),
        health:mage.health,mageDamageOnTick:mage.damageDealt-before.damage,before,planned:plan&&{...plan},cue});
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(a=>[a.x,a.y,a.health,a.ammo,a.qAt,a.eAt,a.ultimateAt,a.damageDealt,a.damageTaken])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  return { arena,difficulty,seed,policy,won:game.phase==='victory',clears:mage.progress.clears,events,purchases,fights,navigationPlans,trace:trace.digest('hex') };
}
const chosen=sample?.split('/');
if(chosen)assert(chosen.length===2 && scenarios.some(row=>row[0]===chosen[0]) && policies.includes(chosen[1]));
const rows=[], controls=[];
for(const args of scenarios) {
  if(chosen && args[0]!==chosen[0])continue;
  const sampled=(chosen?[chosen[1]]:policies).map(policy=>run(...args,policy));
  if(!chosen){
    assert.equal(sampled[0].trace,sampled[1].trace,args[0]);
    controls.push({ arena:args[0],sameTrace:true });
  }
  rows.push(...sampled);
  for(const row of sampled)console.log(JSON.stringify({ arena:row.arena,policy:row.policy,won:row.won,clears:row.clears,
    marks:row.events.filter(e=>e.action==='prepare').length,
    paid:row.events.filter(e=>e.action==='binding'||e.action==='ward').length,
    vents:row.events.filter(e=>['vent','split','echo'].includes(e.action)).map(e=>e.cue?.phase),
    handles:row.events.filter(e=>['shunt','split','echo'].includes(e.action)).map(e=>e.action),
    damageTicks:row.events.filter(e=>['vent','split','echo'].includes(e.action)&&e.mageDamageOnTick>0).length,
    shortened:row.events.filter(e=>e.action==='wound').length }));
}
receipt(destination,{stageOnly:true,visiblePathNavigation:true,fuseShapeStudy:true,contentRevision:CONTENT_REVISION,
  bundleSha256:verified.bundle,mode,cohort,rows,controls});
