import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { Worker } from 'node:worker_threads';
import { setTimeout as sleep } from 'node:timers/promises';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bastion/study-paths.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { CONTENT_REVISION, PROTOCOL } = await repoImport('src/shared/protocol.ts');
const { mageVolatileIds, fuseSealRules: rules } = await repoImport('src/shared/mage-fuse-seal.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { bulwarkTrialWorld, clearTrialWalk } = await repoImport('tests/helpers/tank-bulwark-staging.ts');
const { distance, segmentRect } = await repoImport('src/shared/geometry.ts');

const [transport, fitting, out, supplied, testAudience = 'public'] = process.argv.slice(2);
assert(PROTOCOL === 89 && ['worker','peer'].includes(transport) && ['entry','shunt','twin'].includes(fitting) && out);
const setup = { mode:'short', difficulty:'baby', arenaSelection:'fixed', openingArenaId:'gatehouse' } as const;
const point = ({ x,y }) => ({ x,y });
const bearing = (from,to) => Math.atan2(to.y-from.y,to.x-from.x);
const heading = angle => Math.atan2(Math.sin(angle),Math.cos(angle));
const step = (p,angle,reach) => ({ x:p.x+Math.cos(angle)*reach,y:p.y+Math.sin(angle)*reach });
const closeHealth = (view,id) => view?.players.find(player => player.id === id);
const spending = p => p.skills.reduce((sum,id) => sum+[...data.specializationSkills,...data.skills].find(row => row.id === id).cost,0);

async function wait(truth, detail, ms = 5_000) {
  const end = Date.now() + ms;
  while (!truth()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(8);
  }
}
function pilotState() {
  return { events: [], observed: new Map(), cues: new Map() };
}
function recordCues(cues,view){
  for(const cue of view.classCues){
    if(cue.kind!=='mage-fuse-point'&&cue.kind!=='mage-fuse-vent')continue;
    const row=cues.get(cue.id)??{phases:[],positions:[]};
    if(cue.kind==='mage-fuse-vent')row.vent=cue;
    else {
      if(!row.phases.includes(cue.phase))row.phases.push(cue.phase);
      const last=row.positions.at(-1);
      if(!last||distance(last,cue)>.01)row.positions.push(point(cue));
      row.point=cue;
    }
    cues.set(cue.id,row);
  }
}
const flat = (view,from,to,pad) => !bulwarkTrialWorld(view).obstacles.some(wall=>segmentRect(from,to,wall,pad)!==null);
function castAim(v,p,shape,previous){
  const world=bulwarkTrialWorld(v);
  const main=bearing(p,v.boss);
  const offsets=[0,.25,-.25,.45,-.45,.72,-.72,1,-1,1.4,-1.4,2.15,-2.15,Math.PI];
  for(const offset of offsets){
    const aim=heading(main+offset);
    if(previous!==undefined&&Math.abs(heading(aim-previous))<.36)continue;
    const center=step(p,aim,shape==='ward'?rules.wardOffset:80);
    const bb=world.bounds;
    if(center.x<bb.x+rules.width||center.y<bb.y+rules.width||
       center.x>bb.x+bb.width-rules.width||center.y>bb.y+bb.height-rules.width||
       !flat(v,p,center,rules.width))continue;
    if(shape==='ward'&&![aim+Math.PI/2,aim-Math.PI/2].some(turn=>flat(v,center,step(center,turn,46),rules.width)))continue;
    return aim;
  }
}
function carryLane(v,p){
  const world=bulwarkTrialWorld(v), line=bearing(p,v.boss);
  for(const offset of [.74,-.74,1.17,-1.17,.44,-.44,1.60,-1.60,0,Math.PI]){
    const aim=heading(line+offset), goal=step(p,aim,82);
    if(!clearTrialWalk(world,p,goal))continue;
    if(castAim(v,goal,'binding')!==undefined)return {aim,goal};
  }
}

async function fuseOperation(adapter,view,owner,status,submit){
  const seal=()=>view().classCues.find(c=>c.kind==='mage-fuse-point'&&c.owner===adapter.id);
  const vents=()=>view().classCues.filter(c=>c.kind==='mage-fuse-vent'&&c.owner===adapter.id);
  const notes=(id,since)=>adapter.events.slice(since).filter(e=>e.type==='sound'&&e.owner===adapter.id&&e.id==='mage-fuse-'+id);
  let objective,prepared;
  const limit=Date.now()+45_000;
  while(!prepared){
    const v=view(),p=owner(),now=v.combatTick;
    assert(Date.now()<limit&&v.phase==='combat'&&p.status==='active',
      JSON.stringify({transport,fitting,phase:v.phase,position:point(p),clock:now,q:p.qAt,e:p.eAt,u:p.ultimateAt,status:status()}));
    const line=castAim(v,p,'binding'), ward=castAim(v,p,'ward'), carry=fitting==='shunt'?carryLane(v,p):undefined;
    const hasLane=line!==undefined&&(fitting!=='shunt'||carry)&&(fitting!=='twin'||ward!==undefined);
    if(!hasLane||p.ultimateAt>now||p.qAt>now||fitting==='twin'&&p.eAt>now){
      const direction=bearing(p,v.boss);
      const inward=[direction,direction+.55,direction-.55,direction+1.4,direction-1.4]
        .find(angle=>clearTrialWalk(bulwarkTrialWorld(v),p,step(p,angle,18)));
      adapter.input(inward===undefined?{}:{moveX:Math.cos(inward),moveY:Math.sin(inward),aim:heading(direction)});
      await sleep(26);
      continue;
    }
    await submit({aim:line});
    const original=owner().ultimateAt, start=adapter.events.length;
    objective={original,start,carry,line,ward};
    await submit({technique3:true,aim:line});
    if(status()?.phase==='prepared'&&seal())prepared=seal();
  }
  assert.equal(owner().ultimateAt,objective.original);
  const privateBefore=status();
  assert.equal(privateBefore?.guide,undefined);
  await submit({q:true,aim:objective.line});
  await wait(()=>status()?.phase==='binding'&&seal()?.id===prepared.id,'The paid Q makes a live forward charge',1_500);
  const paid=owner().ultimateAt, firstCharge=seal(), qClock=owner().qAt;
  assert(paid>objective.original&&qClock>view().combatTick&&firstCharge?.phase==='binding');
  assert(status()?.guide?.length===1);

  let shifted, crossed, echo, originalAngle, echoAngle;
  if(fitting==='shunt'){
    const aim=objective.carry.aim,moveX=Math.cos(aim),moveY=Math.sin(aim);
    let ticks=0;
    while(!status()?.canShunt&&status()?.phase==='binding'&&ticks++<17){
      await submit({moveX,moveY,aim:objective.line});
    }
    assert(status()?.canShunt,JSON.stringify({fitting,transport,status:status(),position:point(owner()),prepared}));
    await submit({moveX,moveY,technique3:true,aim:objective.line});
    await wait(()=>!!seal()&&distance(seal(),prepared)>=rules.shuntMinimum,'The room moves the paid seal to the walking body',1_300);
    shifted=seal();
    assert(shifted.id===prepared.id&&shifted.until<=firstCharge.until-rules.shuntCost);
    assert(distance(shifted,prepared)<=rules.shuntMaximum+.01);
  }else if(fitting==='twin'){
    await submit({e:true,aim:objective.ward});
    await wait(()=>status()?.phase==='crossed'&&status()?.split&&seal()?.phase==='crossed',
      'A later Ward payment crosses both charges',1_300);
    crossed=seal();
    assert(crossed.id===prepared.id&&crossed.until<=firstCharge.until);
  }
  const releaseView=view(), body=owner(), aim=castAim(releaseView,body,'binding');
  assert(aim!==undefined,JSON.stringify({fitting,phase:status(),body:point(body),release:releaseView.combatTick}));
  originalAngle=aim;
  await submit({technique3:true,aim});
  await wait(()=>ventFor(prepared.id)!==undefined,'The actual paid forward stroke reaches the owner',1_400);
  function ventFor(id){return adapter.cues.get(id)?.vent;}
  const vent=ventFor(prepared.id);
  assert(vent.phase==='binding'&&vent.segments.length===1);
  assert(vent.segments.every(leg=>distance(leg.from,leg.to)>=rules.minimumStroke&&distance(leg.from,leg.to)<=rules.forwardReach));
  if(fitting==='twin'){
    await wait(()=>status()?.echo&&seal()?.echo,'Twin Vent keeps the other charged shape on the same clock',1_200);
    assert.equal(seal().until,crossed.until);
    const turn=castAim(view(),owner(),'ward',aim);
    assert(turn!==undefined,JSON.stringify({fitting,phase:status(),body:point(owner()),aim}));
    echoAngle=turn;
    await submit({technique3:true,aim:turn});
    await wait(()=>[...adapter.cues.values()].some(row=>row.vent?.owner===adapter.id&&row.vent?.part==='echo'),
      'The visible echo uses its separate aim',1_350);
    echo=[...adapter.cues.values()].map(row=>row.vent).find(c=>c?.owner===adapter.id&&c.part==='echo');
    assert(echo.phase==='ward'&&echo.id!==vent.id&&vent.part==='first');
    assert(echo.at<crossed.until&&Math.abs(heading(echoAngle-originalAngle))>=.36);
  }
  assert.equal(owner().ultimateAt,paid);
  assert.equal(owner().qAt,qClock);
  assert.equal(status()?.phase,'idle');
  const expected=['prepare','binding',...(fitting==='shunt'?['shunt','vent']:fitting==='twin'?['crossed','split','echo']:['vent'])];
  await wait(()=>expected.every(key=>notes(key,objective.start).length===1),'Owner receives each action sound once',1_500);
  assert(status()?.guide===undefined&&vents().length<=2);
  return {prepared,firstCharge,shifted,crossed,vent,echo,paid,original:objective.original,qClock,
    sounds:expected,originalAngle,echoAngle,privateGuide:true};
}

async function earnedFlow(adapter) {
  const view = () => { const current = adapter.view(); assert(current); return current; };
  const owner = () => { const p = closeHealth(view(),adapter.id); assert(p); return p; };
  const status = () => owner().kit.fuseSeal;
  const purchased = [];
  async function buy(item) {
    const result = await adapter.purchase({ kind:'skill',item });
    assert(result.ok,JSON.stringify({ item,result }));
    purchased.push({ item,earned:owner().sp+spending(owner()),clears:owner().progress.clears });
  }
  async function equip() {
    for (const weapon of data.weapons.filter(row => row.classId === 'mage').sort((a,b) => b.tier-a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind:'weapon',item:weapon.id })).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({ kind:'upgrade',item });
  }
  async function submit(input) {
    const sequence = adapter.input(input);
    await wait(() => owner().ack >= sequence,'Ordinary control is acknowledged');
  }

  const isFitted = fitting !== 'entry';
  assert.equal(owner().sp,3);
  await buy('mage-hexcraft-1');
  await buy(mageVolatileIds.entry);
  if (isFitted) assert(!(await adapter.purchase({ kind:'skill',item:mageVolatileIds[fitting] })).ok);
  await equip();
  adapter.start();
  await wait(() => view().phase === 'combat','The ordinary opening encounter begins');
  if (isFitted) {
    const shopLimit = Date.now()+135_000;
    while (view().phase !== 'shop') {
      assert(Date.now() < shopLimit && !['defeat','victory'].includes(view().phase),'Reach the first shop after an ordinary clear');
      if (view().phase === 'combat') {
        adapter.input({...restRaidInput(view(),owner(),[...adapter.observed.values()]),q:false,e:false,ultimate:false});
        adapter.allyPressure?.();
      } else if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(owner().sp+spending(owner()),9);
    await buy(mageVolatileIds[fitting]);
    const other = fitting === 'shunt' ? mageVolatileIds.twin : mageVolatileIds.shunt;
    assert.equal((await adapter.purchase({ kind:'skill',item:other })).reason,'incompatibleItem');
    await equip();
    await wait(() => view().phase === 'combat','The second ordinary encounter begins',95_000);
  }
  const next = { boss:view().boss.id,arena:view().arenaId,start:view().combatTick };
  const firstClear = owner().progress.clears;

  adapter.pause(true);
  await wait(() => adapter.paused(),'The authority acknowledges pause');
  const pausedAt = view().combatTick;
  const ignored = adapter.input({ technique3:true });
  await sleep(90);
  assert.equal(view().combatTick,pausedAt);
  assert(owner().ack < ignored && status()?.phase === 'idle',
    JSON.stringify({ fitting,transport,pausedAt,ack:owner().ack,ignored,privateStatus:status() }));
  adapter.pause(false);
  await wait(() => !adapter.paused(),'The authority acknowledges resume');
  await adapter.stopAlly?.();

  const operation=await fuseOperation(adapter,view,owner,status,submit);
  const witnessed=await adapter.peerWitness?.(operation);
  return {passed:true,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,transport,fitting,bought:purchased,firstClear,next,
    result:operation,witnessed,pausedCommandsDiscarded:true,noCheckpointImports:true};
}

async function runWorker() {
  const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
  let code;
  if (supplied && supplied !== '-') code = readFileSync(supplied, 'utf8');
  else {
    const result = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'], bundle: true,
      minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(testAudience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = result.outputFiles[0].text;
  }
  const shim = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" +
    code + "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(shim).toString('base64')), { execArgv: [] });
  const state = pilotState(), replies = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', value => { error = value; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    else if (message.type === 'error') error = Error(JSON.stringify(message));
    else if (message.type === 'view') { view = message.view; recordCues(state.cues, view); }
    else if (message.type === 'events') remember(state.events, state.observed, message.events, view?.combatTick ?? 0);
    else if (message.type === 'purchaseResult') replies.set(message.id, message);
    else if (message.type === 'pauseState') paused = message.value;
  });
  const send = payload => worker.postMessage(payload);
  try {
    await wait(() => ready || error, 'Whole optimized worker starts');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: 41, maxPlayers: 1 }, name: 'Sable', classId: 'mage' });
    await wait(() => view || error, 'Worker sends lobby');
    if (error) throw error;
    const result = await earnedFlow({ ...state, id: 'solo', view: () => {
      if (error) throw error;
      return view;
    }, input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
    purchase: async request => {
      const id = 'fuse-' + ++serial;
      send({ type: 'purchase', request: { ...request, id } });
      await wait(() => confirmedPurchase(view, 'solo', request, replies.get(id)), 'Worker purchase acknowledged');
      return replies.get(id);
    }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
    pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeers() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const local = supplied && supplied !== '-' ? undefined : createGameServer({ audience: testAudience });
  if (local) await local.server.listen(0, '127.0.0.1');
  const endpoint = local ? 'http://127.0.0.1:' + local.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), mage = new Session(endpoint), state = pilotState();
  const peers = pilotState(), replies = { host: [], mage: [] };
  let sequence = 0, hostSequence = 0, leaks = 0;
  mage.onView = view => recordCues(state.cues, view);
  host.onView = view => {
    recordCues(peers.cues, view);
    if (closeHealth(view, mage.id)?.kit.fuseSeal !== undefined) leaks++;
  };
  mage.onEvents = batch => remember(state.events, state.observed, batch, mage.view?.combatTick ?? 0);
  host.onEvents = batch => remember(peers.events, peers.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = entry => replies.host.push(entry);
  mage.onPurchase = entry => replies.mage.push(entry);
  const reply = async (client, records, request) => {
    const index = records.length;
    client.purchase(request);
    await wait(() => confirmedPurchase(client.view, client.id, request, records[index]), 'Room purchase acknowledged');
    return records[index];
  };
  try {
    await host.connect({ ...setup, name: 'Ordinary host', classId: 'soldier', maxPlayers: 2 });
    await mage.connect({ ...setup, name: 'Sable', classId: 'mage', maxPlayers: 2 }, { roomId: host.room.roomId });
    await wait(() => mage.view?.players.length === 2 && host.view?.players.length === 2, 'Actual non-host Mage lobby');
    assert.equal(mage.view.owner, host.id);
    assert.notEqual(mage.id, host.id);
    const readyHost = () => closeHealth(host.view, host.id);
    for (const weapon of data.weapons.filter(w => w.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (readyHost().weapon === weapon.id || (await reply(host, replies.host, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const hostInput = i => host.input(inputFrame(host.view, ++hostSequence, i));
    const result = await earnedFlow({ ...state, id: mage.id, view: () => mage.view,
      input: props => { mage.input(inputFrame(mage.view, ++sequence, props)); return sequence; },
      purchase: request => reply(mage, replies.mage, request), start: () => host.start(),
      vote: i => { host.vote(i); mage.vote(i); }, pause: value => host.setMatchPaused(value), paused: () => mage.view?.matchPaused === true,
      allyPressure: () => hostInput(restRaidInput(host.view, readyHost(), [...peers.observed.values()])),
      stopAlly: async () => {
        hostInput({});
        const stopped = hostSequence;
        await wait(() => readyHost().ack >= stopped, 'The host stops on the ordinary map');
      },
      peerWitness: async operation => {
        const id=operation.prepared.id;
        await wait(()=>!!peers.cues.get(id)?.vent,'Host sees the same paid forward stroke');
        const sharedPhysical=peers.cues.get(id);
        assert.deepEqual(sharedPhysical.vent,operation.vent);
        assert(sharedPhysical.phases.includes('prepared'));
        if(fitting==='shunt')assert(sharedPhysical.positions.some(p=>distance(p,operation.shifted)<.05));
        if(operation.echo){
          await wait(()=>!!peers.cues.get(operation.echo.id)?.vent,'Host sees the actual second stroke');
          assert.deepEqual(peers.cues.get(operation.echo.id)?.vent,operation.echo);
        }
        assert.equal(leaks,0);
        assert(!peers.events.some(e=>e.type==='sound'&&e.owner===mage.id&&e.id.startsWith('mage-fuse-')));
        return {nonHost:true,sharedPhysical,ownedStatePrivate:true,ownedSoundsPrivate:true};
      },
    });
    host.endMatch();
    await wait(() => [host, mage].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'Host ends the ordinary probe');
    return result;
  } finally {
    mage.close(); host.close();
    if (local) await local.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeers());
receipt(out, { ...result, driverSha256: sha256(readFileSync(new URL(import.meta.url))), testedAudience: testAudience });
console.log(JSON.stringify({ passed:true,transport,fitting,encounter:result.next.boss,firstClear:result.firstClear,paid:result.result.paid,shifted:!!result.result.shifted,echo:!!result.result.echo }));
