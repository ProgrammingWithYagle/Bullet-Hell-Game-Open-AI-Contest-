$ErrorActionPreference='Stop'
$taskRepo='C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)'
$taskProof='reviews/heavy-tethered-menu21-2026-11-10'
$taskLaunchScope='reviews/heavy-tethered-menu21-launch03-2026-11-11'
$taskNode=(Get-Command node).Source
$taskShell=(Get-Process -Id $PID).Path
$taskProcesses=@{};foreach($taskProcess in (Get-CimInstance Win32_Process)){$taskProcesses[[int]$taskProcess.ProcessId]=$taskProcess}
$taskListeners=@(Get-NetTCPConnection -State Listen)
$taskObserved=@()
foreach($taskWhich in @('reviews/heavy-tethered-traverse-2026-11-10',$taskProof)){
 foreach($taskAudience in @('testing','public')){
  $taskRecord=Get-Content -LiteralPath (Join-Path $taskRepo ($taskWhich+'/processes-'+$taskAudience+'.json')) -Raw|ConvertFrom-Json
  foreach($taskRole in @('client','backend')){
   $taskExpected=$taskRecord.$taskRole;$taskLive=$taskProcesses[[int]$taskExpected.pid]
   if($taskLive){throw 'Recorded PID now exists; inspect its exact identity before relaunch.'}
   if($taskListeners|Where-Object LocalPort -eq $taskExpected.port){throw 'Target port is occupied; do not relaunch.'}
   $taskObserved += [ordered]@{scope=$taskWhich;audience=$taskAudience;role=$taskRole;pid=[int]$taskExpected.pid;createdAt=$taskExpected.startedAt;port=[int]$taskExpected.port;pidAbsent=$true;listenerAbsent=$true;agentCleanupPerformed=$false;originalReceiptSha256=(Get-FileHash -LiteralPath (Join-Path $taskRepo ($taskWhich+'/processes-'+$taskAudience+'.json')) -Algorithm SHA256).Hash.ToLowerInvariant()}
  }
 }
}
if($taskObserved.Count -ne 8){throw 'Unexpected prior identity count.'}
$taskObservationPath=Join-Path $taskRepo ($taskProof+'/prior-launches-absent03.json');if(Test-Path -LiteralPath $taskObservationPath){throw 'Preserve prior observation.'}
[IO.File]::WriteAllText($taskObservationPath,([ordered]@{observedAt=[DateTime]::UtcNow.ToString('o');identities=$taskObserved;cleanupPerformed=$false;causeOfProcessExitNotInferred=$true;originalLaunchRecordsAndLogsUntouched=$true}|ConvertTo-Json -Depth 7)+"`n",[Text.UTF8Encoding]::new($false))
$taskLaunchPath=Join-Path $taskRepo $taskLaunchScope;if(Test-Path -LiteralPath $taskLaunchPath){throw 'Inspect partial relaunch scope before retry.'};New-Item -ItemType Directory -Path $taskLaunchPath > $null
foreach($taskAudience in @('testing','public')){
 Copy-Item -LiteralPath (Join-Path $taskRepo ($taskProof+'/preview-'+$taskAudience+'.json')) -Destination (Join-Path $taskLaunchPath ('preview-'+$taskAudience+'.json'))
 $taskOutput=Join-Path $taskRepo ('output/heavy-tethered-menu21-launch03-'+$taskAudience+'-launcher.log')
 $taskErrors=Join-Path $taskRepo ('output/heavy-tethered-menu21-launch03-'+$taskAudience+'-launcher-errors.log')
 if((Test-Path -LiteralPath $taskOutput)-or(Test-Path -LiteralPath $taskErrors)){throw 'Preserve previous relaunch logs.'}
 $taskArgs=@('-NoProfile','-File',('"'+(Join-Path $taskRepo 'tools/launch-review.ps1')+'"'),'-Audience',$taskAudience,'-Scope',$taskLaunchScope)
 $taskLauncher=Start-Process -FilePath $taskShell -ArgumentList $taskArgs -WorkingDirectory $taskRepo -WindowStyle Hidden -PassThru -RedirectStandardOutput $taskOutput -RedirectStandardError $taskErrors
 Write-Output ('Started hidden fresh '+$taskAudience+' launcher PID '+$taskLauncher.Id+' UTC '+$taskLauncher.StartTime.ToUniversalTime().ToString('o'))
}
