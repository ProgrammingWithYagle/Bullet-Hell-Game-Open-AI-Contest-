$ErrorActionPreference='Stop'
$taskRepo='C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)'
$taskScope='reviews/heavy-tethered-menu21-2026-11-10'
$taskLaunchScope='reviews/heavy-tethered-menu21-launch03-2026-11-11'
$taskSource=(Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-commit.txt') -Raw).Trim()
$taskNode=(Get-Command node).Source
$taskInventory=@{};foreach($taskProcess in (Get-CimInstance Win32_Process)){$taskInventory[[int]$taskProcess.ProcessId]=$taskProcess}
$taskListeners=@(Get-NetTCPConnection -State Listen);$taskCurrent=@()
foreach($taskAudience in @('testing','public')){
 $taskRecord=Get-Content -LiteralPath (Join-Path $taskRepo ($taskLaunchScope+'/processes-'+$taskAudience+'.json')) -Raw|ConvertFrom-Json
 $taskPreview=Get-Content -LiteralPath (Join-Path $taskRepo ($taskScope+'/preview-'+$taskAudience+'.json')) -Raw|ConvertFrom-Json
 if($taskRecord.sourceCommit -cne $taskSource){throw 'Source mismatch.'}
 foreach($taskRole in @('backend','client')){
  $taskExpected=$taskRecord.$taskRole;$taskLive=$taskInventory[[int]$taskExpected.pid];$taskTicks=([DateTimeOffset]$taskExpected.startedAt).UtcDateTime.Ticks
  if($taskRole -eq 'backend'){$taskCommand='"'+$taskNode+'" "'+$taskPreview.backend.path+'"'}else{$taskRelative=[IO.Path]::GetRelativePath($taskRepo,$taskPreview.root);$taskCommand='"'+$taskNode+'" node_modules/vite/bin/vite.js preview --outDir '+$taskRelative+' --host 127.0.0.1 --port '+$taskExpected.port+' --strictPort'}
  if(!$taskLive -or $taskLive.CreationDate.ToUniversalTime().Ticks -ne ($taskTicks-($taskTicks%10)) -or $taskLive.CommandLine -cne $taskCommand){throw 'Current exact identity differs.'}
  if(!($taskListeners|Where-Object {$_.LocalPort -eq $taskExpected.port -and $_.OwningProcess -eq $taskExpected.pid})){throw 'Current listener differs.'}
  $taskCurrent += [ordered]@{scope=$taskLaunchScope;audience=$taskAudience;role=$taskRole;pid=[int]$taskExpected.pid;port=[int]$taskExpected.port;createdAt=$taskLive.CreationDate.ToUniversalTime().ToString('o');startProcessReportedAt=$taskExpected.startedAt;commandLine=$taskLive.CommandLine;sameProcessStillLive=$true;listenerStillOwned=$true}
 }
}
$taskHistory=Get-Content -LiteralPath (Join-Path $taskRepo 'reviews/heavy-tethered-traverse-2026-11-10/process-identities.json') -Raw|ConvertFrom-Json
$taskHistorical=@();foreach($taskExpected in @($taskHistory.identities)+@($taskHistory.olderRecordedIdentities)){
 $taskLive=$taskInventory[[int]$taskExpected.pid];$taskSame=$taskLive -and $taskLive.CommandLine -ceq $taskExpected.commandLine -and [DateTimeOffset]$taskLive.CreationDate -eq [DateTimeOffset]$taskExpected.createdAt
 $taskHistorical += [ordered]@{pid=$taskExpected.pid;port=$taskExpected.port;createdAt=$taskExpected.createdAt;commandLine=$taskExpected.commandLine;sameRecordedIdentityLive=[bool]$taskSame;listenerStillOwned=[bool]($taskSame -and ($taskListeners|Where-Object {$_.LocalPort -eq $taskExpected.port -and $_.OwningProcess -eq $taskExpected.pid}));observation=$(if($taskSame){'exact recorded identity live'}elseif($taskLive){'PID exists with a different identity'}else{'recorded PID absent'});cleanupPerformed=$false}
}
if($taskCurrent.Count -ne 4 -or $taskHistorical.Count -ne 124){throw 'Unexpected identity count.'}
$taskReport=[ordered]@{checkedAt=[DateTime]::UtcNow.ToString('o');sourceCommit=$taskSource;activeLaunchScope=$taskLaunchScope;identities=$taskCurrent;currentExactLiveCount=4;olderRecordedIdentities=$taskHistorical;olderRecordedCount=124;olderExactLiveCount=@($taskHistorical|Where-Object sameRecordedIdentityLive).Count;priorPendingLaunchObservation=$taskScope+'/prior-launches-absent03.json';historicalIdentityLedger='reviews/storage-retention-2026-11-10/retention-result.json';originalLaunchRecordsAndLogsUntouched=$true;olderRetiredProcessesNotRequiredOrRestarted=$true;cleanupPerformed=$false;limits='Fresh four service identities bind exact PID/full command/UTC/listener. All124older recorded identities remain historical observations. The original pending launch records are separately preserved; absent processes are not attributed to agent cleanup.'}
$taskPath=Join-Path $taskRepo ($taskScope+'/process-identities.json');if(Test-Path -LiteralPath $taskPath){throw 'Preserve existing process audit.'};[IO.File]::WriteAllText($taskPath,($taskReport|ConvertTo-Json -Depth 8)+"`n",[Text.UTF8Encoding]::new($false));Write-Output 'Verified four fresh exact identities; observed original124historical identities without restarting old services.'
