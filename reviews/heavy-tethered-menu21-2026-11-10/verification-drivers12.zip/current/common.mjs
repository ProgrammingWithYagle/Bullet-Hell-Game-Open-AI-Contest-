import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
export const root='C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)';
export const stage=path.dirname(fileURLToPath(import.meta.url));
export const scope='reviews/heavy-tethered-menu21-2026-11-10';
export const prior='reviews/heavy-tethered-traverse-2026-11-10';
export const oldStage='C:/Users/yigal/Documents/Codex/2026-11-05/continue-grave-accord-in-the-same/work/heavy-tethered-traverse-stage';
export const base='7d3ec1cbc7ccc84a02e5dfe0cab4c26cec5fbe28';
export const branch='feat/first-playable-loop';
export const expectedTests=2211;
export const tests=expectedTests;
export const runtime='c213467e0877fce574552b98139e4171a71ad4430069102a880db46c65f86de8';
export const env={...process.env,GIT_TERMINAL_PROMPT:'0',GCM_INTERACTIVE:'Never'};
for(const key of Object.keys(env))if(/^(GIT_TRACE|GCM_TRACE|GIT_CURL_VERBOSE)/i.test(key))delete env[key];
export const read=f=>JSON.parse(fs.readFileSync(f,'utf8'));
export const sha=b=>createHash('sha256').update(b).digest('hex');
export const write=(f,v)=>fs.writeFileSync(f,JSON.stringify(v,null,2)+'\n',{flag:'wx'});
export const walk=d=>fs.readdirSync(d).sort().flatMap(n=>{const f=d+'/'+n;assert(!fs.lstatSync(f).isSymbolicLink());return fs.statSync(f).isDirectory()?walk(f):[f];});
export const gitBytes=(...args)=>execFileSync('git',['-c','core.bare=false',...args],{cwd:root,env,stdio:['pipe','pipe','pipe'],maxBuffer:64*1024*1024,timeout:120000});
export const git=(...args)=>gitBytes(...args).toString('utf8').trim();
export const coreFiles=()=>[...walk('src'),...walk('tests'),'package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.json','vite.config.ts','index.html'].sort();
export function fingerprints(){const r=createHash('sha256'),s=createHash('sha256');for(const f of coreFiles()){const b=fs.readFileSync(f);assert(!b.includes(13),'Expected exact LF core source: '+f);s.update(f+'\0').update(b);if(f.startsWith('src/'))r.update(f+'\0').update(b);}return {runtimeSourceSha256:r.digest('hex'),sourceSnapshotSha256:s.digest('hex')};}
export function checkedGate(){const gate=read(scope+'/full-gate01.json'),result=read(scope+'/gate01-result.json');assert(gate.passed&&result.passed&&result.exitCode===0);assert.equal(gate.checks.length,7);assert(gate.checks.every(c=>c.passed));assert.deepEqual(result.counts,{tests:expectedTests,pass:expectedTests,fail:0,cancelled:0,skipped:0});assert.equal(sha(fs.readFileSync(scope+'/gate01.log')),result.logSha256);assert.equal(sha(fs.readFileSync('tools/verify.mjs')),gate.verificationDriverSha256);assert.deepEqual(fingerprints(),{runtimeSourceSha256:gate.runtimeSourceSha256,sourceSnapshotSha256:gate.sourceSnapshotSha256});assert.equal(gate.runtimeSourceSha256,runtime);return {gate,result};}
