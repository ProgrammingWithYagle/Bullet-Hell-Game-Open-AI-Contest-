import fs from 'node:fs';import assert from 'node:assert/strict';
import {root,stage,scope,base,branch,tests,write,git,checkedGate} from './common.mjs';
process.chdir(root);const source=fs.readFileSync(stage+'/source-commit.txt','utf8').trim();checkedGate();
assert.equal(git('rev-parse','HEAD'),source);assert.equal(git('rev-parse','HEAD^'),base);assert.equal(git('branch','--show-current'),branch);assert.equal(git('diff','--name-only'),'');assert.equal(git('diff','--cached','--name-only'),'');const pending=git('status','--porcelain=v1');assert(pending===''||pending==='?? '+scope+'/source-binding-audit12.json','Only the newly generated post-commit byte audit may be pending');
assert.equal(git('remote','get-url','origin'),'https://github.com/ProgrammingWithYagle/Bullet-Hell-Game-Open-AI-Contest-.git');
assert.equal(git('ls-remote','origin','refs/heads/'+branch).split(/\s/)[0],base);
git('push','origin','HEAD:refs/heads/'+branch);assert.equal(git('ls-remote','origin','refs/heads/'+branch).split(/\s/)[0],source);
write(stage+'/source-push01.json',{passed:true,checkedAt:new Date().toISOString(),sourceCommit:source,branch,remoteHead:source,tests,checks:7,force:false,mainMerged:false,productionDeployed:false,privateDatabaseUploaded:false,draftPR14StillRequired:true});
console.log(JSON.stringify({pushed:true,sourceCommit:source,tests,checks:7}));
