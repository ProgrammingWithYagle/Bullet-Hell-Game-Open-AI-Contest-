from pathlib import Path
import hashlib,json,zipfile,datetime
root=Path(r'C:\Users\yigal\OneDrive\Documents\ChatGPT\OpenAI Multiplayer Game Contest (Bullet Hell)')
scope=root/'reviews/heavy-tethered-menu21-2026-11-10'
archive=scope/'focused-windows-raw02.zip'
receipt=scope/'focused-windows-raw02.json'
assert not archive.exists() and not receipt.exists()
digest=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for name in ['focused01.log','focused02.log']:
        path=scope/name; raw=path.read_bytes(); normalized=raw.replace(b'\r\n',b'\n')
        assert b'\xe2\x84\xb9 tests 6' in raw
        z.writestr(name,raw)
        rows.append({'path':str(path.relative_to(root)).replace('\\','/'),'archiveMember':name,'rawSha256':digest(raw),'rawBytes':len(raw),'lfTextCopySha256':digest(normalized),'lfTextCopyBytes':len(normalized),'lineEndingsOnly':True})
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(rows)
    for row in rows:assert digest(z.read(row['archiveMember']))==row['rawSha256']
for row in rows:
    path=root/row['path']; raw=path.read_bytes();assert digest(raw)==row['rawSha256'];path.write_bytes(raw.replace(b'\r\n',b'\n'));assert digest(path.read_bytes())==row['lfTextCopySha256']
receipt.write_bytes((json.dumps({'passed':True,'checkedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archive':'reviews/heavy-tethered-menu21-2026-11-10/'+archive.name,'archiveSha256':digest(archive.read_bytes()),'allOriginalRawExecutionBytesVerified':True,'existingGitTextRulesUnchanged':True,'rows':rows},indent=2)+'\n').encode())
print(json.dumps({'preservedExactRawLogs':len(rows),'normalizedTextCopiesOnly':True,'gitRulesUnchanged':True}))
