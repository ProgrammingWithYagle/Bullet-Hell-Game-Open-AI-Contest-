import fs from 'node:fs';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {root,scope,base,git,write,sha,env,oldStage,prior,read} from './common.mjs';
process.chdir(root);assert.equal(git('rev-parse','HEAD'),base);
const repo='ProgrammingWithYagle/Bullet-Hell-Game-Open-AI-Contest-';
const credential=execFileSync('git',['-c','core.bare=false','credential','fill'],{input:'protocol=https\nhost=github.com\npath='+repo+'.git\n\n',encoding:'utf8',stdio:['pipe','pipe','pipe'],env,timeout:10000});
const token=credential.split(/\r?\n/).find(l=>l.startsWith('password='))?.slice(9);assert(token);
const headers={Authorization:'Bearer '+token,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'},api='https://api.github.com/repos/'+repo;
const get=async p=>{const r=await fetch(api+p,{headers,signal:AbortSignal.timeout(15000)});assert(r.ok,'GitHub HTTP '+r.status);return r.json();};
const bytes=async p=>{let r=await fetch(api+p,{headers,redirect:'manual',signal:AbortSignal.timeout(15000)});if(r.status===302){const u=new URL(r.headers.get('location'));assert(u.protocol==='https:'&&/(?:^|\.)(?:blob\.core\.windows\.net|githubusercontent\.com)$/.test(u.hostname));r=await fetch(u,{signal:AbortSignal.timeout(15000)});}assert(r.ok,'Evidence HTTP '+r.status);return Buffer.from(await r.arrayBuffer());};
const [listed,pr]=await Promise.all([get('/actions/runs?head_sha='+base+'&per_page=100'),get('/pulls/14')]);
assert(pr.draft&&pr.state==='open'&&pr.head.sha===base&&pr.head.ref==='feat/first-playable-loop');
const {decodeRuntimeEvidenceArchive}=await import(pathToFileURL(oldStage+'/unzip-runtime-artifact01.mjs').href);
const proof=read(prior+'/source-verification.json'),runs=[];
for(const event of ['push','pull_request']){
 const run=listed.workflow_runs.filter(r=>r.head_sha===base&&r.event===event).sort((a,b)=>b.id-a.id)[0];assert(run?.status==='completed'&&run.conclusion==='success');
 const {jobs,total_count}=await get('/actions/runs/'+run.id+'/attempts/'+run.run_attempt+'/jobs?per_page=100');assert.equal(jobs.length,total_count);
 const checked=[];for(const job of jobs){assert(job.conclusion==='success'&&job.steps.length&&job.steps.every(s=>s.conclusion==='success'));const raw=await bytes('/actions/jobs/'+job.id+'/logs'),text=raw.toString(),counts=Object.fromEntries(['tests','pass','fail','cancelled','skipped'].map(k=>[k,Number(text.match(new RegExp('ℹ '+k+'\\s+(\\d+)'))?.[1])]));assert.deepEqual(counts,{tests:2209,pass:2209,fail:0,cancelled:0,skipped:0});checked.push({id:job.id,conclusion:job.conclusion,steps:job.steps,counts,decodedLogSha256:sha(raw)});}
 const artifacts=await get('/actions/runs/'+run.id+'/artifacts?per_page=100'),artifact=artifacts.artifacts.find(a=>a.name==='verification-evidence'&&!a.expired);assert(artifact);const zip=await bytes('/actions/artifacts/'+artifact.id+'/zip'),decoded=decodeRuntimeEvidenceArchive(zip),report=JSON.parse(decoded.text);assert(report.passed&&report.checks.length===7&&report.checks.every(c=>c.passed));for(const k of ['runtimeSourceSha256','sourceSnapshotSha256','contentRevision','verificationDriverSha256','testFiles'])assert.equal(report[k],proof[k],k);
 runs.push({id:run.id,event,headSha:run.head_sha,url:run.html_url,conclusion:run.conclusion,jobs:checked,ownArtifact:{id:artifact.id,archiveSha256:sha(zip),reportMember:decoded.name,reportSha256:sha(decoded.text),runtimeSourceSha256:report.runtimeSourceSha256,sourceSnapshotSha256:report.sourceSnapshotSha256,checks:report.checks}});
}
write(scope+'/initial-remote-state.json',{checkedAt:new Date().toISOString(),passed:true,head:base,draftPR14:true,runs,credentialPrintedOrStored:false,source30fbVerificationRemainsSeparate:true});
console.log(JSON.stringify({passed:true,head:base,runs:runs.map(r=>({id:r.id,event:r.event,conclusion:r.conclusion})),draftPR14:true}));
