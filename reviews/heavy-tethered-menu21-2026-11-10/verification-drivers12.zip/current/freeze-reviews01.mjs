import fs from 'node:fs';import assert from 'node:assert/strict';import net from 'node:net';import {spawnSync} from 'node:child_process';
import {root,stage,scope,prior,sha,read,write,git,checkedGate} from './common.mjs';
process.chdir(root);const source=fs.readFileSync(stage+'/source-commit.txt','utf8').trim();assert.equal(git('rev-parse','HEAD'),source);const {gate}=checkedGate();
const ci=fs.existsSync(scope+'/source-ci.json')?read(scope+'/source-ci.json'):read(stage+'/ci-status-source.json');assert.equal(ci.head,source);if(!ci.passed)assert(ci.pending&&ci.runs.length===2&&ci.runs.every(r=>['in_progress','queued','completed'].includes(r.status)&&(!r.conclusion||r.conclusion==='success')),'The exact-source CI must be active or successful before preparing the pending pair');
assert(!fs.existsSync(scope+'/preview-testing.json')&&!fs.existsSync(scope+'/preview-public.json'));
for(const a of gate.artifacts)assert.equal(sha(fs.readFileSync(a.path)),a.sha256);
const text=gate.artifacts.filter(a=>/\.js$/.test(a.path)&&!a.path.includes('offline.worker-')).map(a=>fs.readFileSync(a.path,'utf8')).join('\n');assert(text.includes('http://127.0.0.1:2760'));
const ports=[5384,2760,5385,2761];for(const port of ports)await new Promise((resolve,reject)=>{const s=net.createServer();s.once('error',reject);s.listen({host:'127.0.0.1',port,exclusive:true},()=>s.close(resolve));});
write(scope+'/ports-before-freeze.json',{checkedAt:new Date().toISOString(),sourceCommit:source,ports,allAvailableByActualExclusiveBind:true,existingServicesStopped:false,exactSourceCIPendingAtFreeze:!ci.passed,completeFrozenProofAndRotationRequireSuccessfulExactCI:true});
const comparisons=[];
for(const [audience,client,backend] of [['testing',5384,2760],['public',5385,2761]]){
 const r=spawnSync(process.execPath,['tools/freeze-client-review.mjs',source,audience,scope,String(client),String(backend)],{encoding:'utf8',maxBuffer:8*1024*1024});fs.writeFileSync(scope+'/freeze-'+audience+'.log',(r.stdout??'')+(r.stderr??''),{flag:'wx'});assert.equal(r.status,0,'Inspect partial freezer writes before retry.');
 const p=read(scope+'/preview-'+audience+'.json'),old=read(prior+'/preview-'+audience+'.json'),m=read(p.manifestPath),before=read(old.manifestPath),worker=m.members.find(f=>/offline\.worker-.*\.js$/.test(f.path)),oldWorker=before.members.find(f=>/offline\.worker-.*\.js$/.test(f.path));
 assert.equal(worker.sha256,oldWorker.sha256);assert(fs.readFileSync(p.root+'/'+worker.path).equals(fs.readFileSync(old.root+'/'+oldWorker.path)));assert.equal(p.backend.sha256,old.backend.sha256);
 comparisons.push({audience,newSourceCommit:source,originalSourceCommit:old.sourceCommit,newPreview:p.url,originalPreview:old.url,newEndpoint:p.endpoint,originalEndpoint:old.endpoint,runtimeSourceSha256:p.runtimeSourceSha256,worker:{newPath:worker.path,originalPath:oldWorker.path,sha256:worker.sha256,allServedWorkerBytesIdentical:true},backendSha256:p.backend.sha256,allBackendBytesIdentical:true,originalManifestSha256:old.manifestSha256,newManifestSha256:p.manifestSha256});
 console.log(JSON.stringify({frozen:true,audience,files:p.files,workerAndBackendExactToOriginal:true}));
}
write(scope+'/runtime-retained-execution-binding.json',{passed:true,checkedAt:new Date().toISOString(),comparisons,retainedCasesKeepOriginalCommitHelperEndpointsAndTimestamps:true,currentTestCorrectionNotAppliedRetroactively:true});
