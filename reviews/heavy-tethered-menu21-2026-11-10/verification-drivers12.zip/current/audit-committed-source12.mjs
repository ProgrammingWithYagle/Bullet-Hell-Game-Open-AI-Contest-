import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {root, stage, scope, branch, read, sha, write, git, gitBytes, coreFiles, checkedGate, env} from './common.mjs';
process.chdir(root);
const source = fs.readFileSync(stage + '/source-commit.txt', 'utf8').trim();
assert.equal(git('rev-parse', 'HEAD'), source);
assert.equal(git('branch', '--show-current'), branch);
assert.equal(git('status', '--porcelain=v1'), '');
const {gate} = checkedGate();
const runtime = createHash('sha256'), snapshot = createHash('sha256'), files = coreFiles();
const refs=files.map(f=>source+':'+f);assert(refs.every(r=>!/[\r\n\0]/.test(r)));
const batch=execFileSync('git',['-c','core.bare=false','cat-file','--batch'],{cwd:root,env,input:refs.join('\n')+'\n',maxBuffer:64*1024*1024,stdio:['pipe','pipe','pipe'],timeout:120000});
let offset=0;
for (const f of files) {
  const newline=batch.indexOf(10,offset);assert(newline>offset);
  const header=batch.subarray(offset,newline).toString('ascii'),match=header.match(/^[a-f0-9]{40,64} blob (\d+)$/);assert(match,'Invalid batch header: '+header);
  const size=Number(match[1]),start=newline+1,end=start+size;assert.equal(batch[end],10);
  const committed=batch.subarray(start,end),local=fs.readFileSync(f);offset=end+1;
  assert(committed.equals(local), 'Git/local source bytes differ: ' + f);
  snapshot.update(f + '\0').update(committed);
  if (f.startsWith('src/')) runtime.update(f + '\0').update(committed);
}
assert.equal(offset,batch.length);
const committedRuntimeSourceSha256 = runtime.digest('hex'), committedSourceSnapshotSha256 = snapshot.digest('hex');
assert.equal(committedRuntimeSourceSha256, gate.runtimeSourceSha256);
assert.equal(committedSourceSnapshotSha256, gate.sourceSnapshotSha256);
assert.equal(sha(gitBytes('show', source + ':tools/verify.mjs')), gate.verificationDriverSha256);
write(scope + '/source-binding-audit12.json', {
  checkedAt: new Date().toISOString(), passed: true, sourceCommit: source, coreFiles: files.length,
  allWorkingAndCommittedCoreBytesExact: true, allCoreSourceBytesLF: true, differingFiles: [],
  boundedRawGitObjectBatchRead:true,rawGitObjectBytes:batch.length,
  workingRuntimeSourceSha256: gate.runtimeSourceSha256, workingSourceSnapshotSha256: gate.sourceSnapshotSha256,
  committedRuntimeSourceSha256, committedSourceSnapshotSha256, verificationDriverSha256: gate.verificationDriverSha256,
  olderRawExecutionProvenanceRetained: true, gitConfigurationChanged: false,
});
console.log(JSON.stringify({passed: true, sourceCommit: source, coreFiles: files.length, localAndGitSourceBytesExact: true}));
