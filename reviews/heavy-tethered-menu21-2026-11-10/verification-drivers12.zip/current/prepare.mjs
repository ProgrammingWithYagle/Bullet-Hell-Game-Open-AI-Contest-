import fs from 'node:fs';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
const root='C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)';
process.chdir(root);
const scope='reviews/heavy-tethered-menu21-2026-11-10';
const stage=new URL('./',import.meta.url);
const sha=b=>createHash('sha256').update(b).digest('hex');
const git=(...a)=>execFileSync('git',['-c','core.bare=false',...a],{encoding:'utf8'}).trim();
assert.equal(git('rev-parse','HEAD'),'7d3ec1cbc7ccc84a02e5dfe0cab4c26cec5fbe28');
assert.equal(git('branch','--show-current'),'feat/first-playable-loop');
assert.equal(git('status','--porcelain=v1'),'');
assert(!fs.existsSync(scope));
const original=fs.readFileSync('tests/helpers/heavy-post-menu-flow.ts');
assert(original.toString().includes('[3, 9, 12, 15, 20].includes(earned)'));
fs.writeFileSync(new URL('heavy-post-menu-flow.original.ts.txt',stage),original,{flag:'wx'});
const failures=['testing','public'].flatMap(a=>[
 'native01-'+a+'-partial.json',
 'native01-'+a+'-worker-post-standard-loose.log',
 'native01-'+a+'-room-post-standard-loose.log',
]).map(name=>{const path='reviews/heavy-tethered-traverse-2026-11-10/'+name;return {path,bytes:fs.statSync(path).size,sha256:sha(fs.readFileSync(path))};});
fs.mkdirSync(scope);
fs.writeFileSync(scope+'/original-failures.json',JSON.stringify({checkedAt:new Date().toISOString(),baseHead:git('rev-parse','HEAD'),sourceCommit:'30fbfefaa66faabd93416dc31e27310149df5fed',originalMenuHelperSha256:sha(original),originalHelperGitPath:'30fbfefaa66faabd93416dc31e27310149df5fed:tests/helpers/heavy-post-menu-flow.ts',failures,originalExecutionsNotRelabelled:true,originalFailureCause:'The actual Short three-clear path reaches legal21SP; the wrapper whitelist omits21 before capstone purchase.'},null,2)+'\n',{flag:'wx'});
const test=fs.readFileSync(new URL('heavy-post-acquisition.test.ts',stage));
assert(!test.includes(13));
fs.writeFileSync('tests/heavy-post-acquisition.test.ts',test,{flag:'wx'});
fs.writeFileSync('tests/helpers/heavy-post-menu-flow.ts',original.toString().replace('[3, 9, 12, 15, 20].includes(earned)','[3, 9, 12, 15, 20, 21].includes(earned)'));
console.log(JSON.stringify({prepared:true,scope,originalFailuresPreserved:failures.length,originalMenuHelperSha256:sha(original),newRegressionCases:2,runtimeChanged:false}));
