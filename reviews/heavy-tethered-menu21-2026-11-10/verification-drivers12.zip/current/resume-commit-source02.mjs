import fs from 'node:fs';import assert from 'node:assert/strict';
import {root,stage,base,branch,sha,read,git,gitBytes,checkedGate} from './common.mjs';
process.chdir(root);const plan=read(stage+'/source-commit-plan01.json');checkedGate();assert.equal(git('rev-parse','HEAD'),base);assert.equal(git('branch','--show-current'),branch);
assert.equal(git('diff','--name-only'),'');assert.deepEqual(git('diff','--cached','--name-only').split('\n').sort(),plan.files.map(f=>f.path).sort());
for(const f of plan.files){assert.equal(sha(fs.readFileSync(f.path)),f.sha256);assert.equal(sha(gitBytes('show',':'+f.path)),f.sha256);}
// Raw execution output is evidence, including emitted trailing spaces. Validate
// source/structured text without rewriting those raw log messages or Git rules.
git('diff','--cached','--check','--','.',':(glob,exclude)reviews/heavy-tethered-menu21-2026-11-10/*.log');
git('commit','-m','Verify legal 21 SP Tethered Traverse acquisition and native pause transport');
const source=git('rev-parse','HEAD');fs.writeFileSync(stage+'/source-commit.txt',source+'\n',{flag:'wx'});assert.equal(git('status','--porcelain=v1'),'');console.log(JSON.stringify({committed:true,sourceCommit:source,files:plan.files.length,tests:2211,checks:7,allStagedBytesExact:true,rawLogsPreservedIncludingWhitespace:true,gitConfigurationChanged:false}));
