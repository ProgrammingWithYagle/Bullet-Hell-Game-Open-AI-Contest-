$ErrorActionPreference='Stop'
$taskRepo='C:/Users/yigal/OneDrive/Documents/ChatGPT/OpenAI Multiplayer Game Contest (Bullet Hell)'
$taskScope='reviews/heavy-tethered-menu21-2026-11-10'
$taskOriginal=Get-Content -LiteralPath (Join-Path $taskRepo ($taskScope+'/process-identities.json')) -Raw|ConvertFrom-Json
$taskListeners=@(Get-NetTCPConnection -State Listen);$taskRows=@()
foreach($taskExpected in $taskOriginal.identities){
 $taskLive=Get-CimInstance Win32_Process -Filter ('ProcessId='+[int]$taskExpected.pid)
 if(!$taskLive -or $taskLive.CommandLine -cne $taskExpected.commandLine -or [DateTimeOffset]$taskLive.CreationDate -ne [DateTimeOffset]$taskExpected.createdAt -or !($taskListeners|Where-Object {$_.OwningProcess -eq $taskExpected.pid -and $_.LocalPort -eq $taskExpected.port})){throw 'Exact current PID/full command/UTC/listener differs.'}
 $taskRows += [ordered]@{scope=$taskExpected.scope;audience=$taskExpected.audience;role=$taskExpected.role;pid=$taskExpected.pid;port=$taskExpected.port;createdAt=$taskLive.CreationDate.ToUniversalTime().ToString('o');commandLine=$taskLive.CommandLine;sameProcessStillLive=$true;listenerStillOwned=$true}
}
if($taskRows.Count -ne 4){throw 'Expected exactly four current identities.'}
$taskOut=Join-Path $taskRepo ($taskScope+'/current-identities06.json');if(Test-Path -LiteralPath $taskOut){throw 'Preserve previous identity capture.'}
[IO.File]::WriteAllText($taskOut,([ordered]@{checkedAt=[DateTime]::UtcNow.ToString('o');sourceCommit=$taskOriginal.sourceCommit;identities=$taskRows;currentExactLiveCount=4;cleanupPerformed=$false;priorIdentityReceipt=$taskScope+'/process-identities.json';originalLaunchAndHistoricalRecordsUnchanged=$true}|ConvertTo-Json -Depth 7)+"`n",[Text.UTF8Encoding]::new($false));Write-Output 'Revalidated four exact current PID/fullcommand/UTC/listeners.'
