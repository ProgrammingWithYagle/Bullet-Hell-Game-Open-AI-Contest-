import {source as currentSource} from './publication180.mjs';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {root,stage,read,write,sha,fingerprints} from './common100.mjs';
process.chdir(root);const before=fingerprints();
const {Game}=await import(pathToFileURL(root+'/src/shared/game.ts').href);
const {idleInput,HZ}=await import(pathToFileURL(root+'/src/shared/protocol.ts').href);
const {distance,segmentRect}=await import(pathToFileURL(root+'/src/shared/geometry.ts').href);
const build={definition:{id:'tank-bulwark-carry-1'},portDefinition:{id:'tank-bulwark-port-1'}};
const survey=read(stage+'/../tank-mobile-bulwark-stage/survey17.json');
const point=({x,y})=>({x,y});
const wrap=angle=>Math.atan2(Math.sin(angle),Math.cos(angle));

function trial(row,shape,route,open){
  const g=new Game({mode:'endless',difficulty:row.difficulty,seed:41,openingArenaId:row.arena,arenaSelection:'fixed'});g.encounter=9;
  const p=g.addPlayer('tank','Controlled physical port comparison','tank');assert.equal(p.totalSp,27);
  for(const id of ['tank-protection-1',build.definition.id,build.portDefinition.id])assert(g.transact(p.id,{kind:'skill',id,item:id}).ok);
  assert(g.start());g.boss.staggerUntil=500;
  const aim=shape.aim,normal={x:Math.cos(aim),y:Math.sin(aim)},side={x:-normal.y*route.sign,y:normal.x*route.sign};
  let sequence=0;
  const wall=()=>g.classKits.cues().find(cue=>cue.kind==='wall'&&cue.owner===p.id);
  function step(input={}){assert(g.submitInput(p.id,{...idleInput(),sequence:++sequence,clientTick:g.combatTick,aim,...input}));g.step();return g.drainEvents();}
  step({q:true});const original=wall(),qAt=p.qAt;assert(original);
  const take={x:original.x-normal.x*32,y:original.y-normal.y*32};
  for(let n=0;n<40&&distance(p,take)>.5;n++){const length=Math.max(distance(p,take),g.movementSpeed(p)/HZ);step({moveX:(take.x-p.x)/length,moveY:(take.y-p.y)/length});}
  assert(distance(p,take)<=.5);step({technique1:true});assert(g.classKits.tankWallCarried(p.id,g.combatTick));
  const start=point(p),stride=4*HZ/g.movementSpeed(p);
  for(let n=0;n<route.clearSteps;n++)step({moveX:side.x*stride,moveY:side.y*stride});assert(distance(start,p)>112);
  const body=point(p);step({technique2:open});for(let n=0;n<6;n++)step();
  assert.equal(g.classKits.tankPortStatus(p.id).phase,open?'open':'closed');
  function hostile(along){
    const from={x:p.x+normal.x*47.2+side.x*along,y:p.y+normal.y*47.2+side.y*along};
    const to={x:p.x+side.x*along,y:p.y+side.y*along};
    assert(!g.obstacles.some(rect=>segmentRect(from,to,rect,3)),'controlled launch needs a clear masonry ray');
    const old=wall(),health=p.health,shield=p.shield;assert(old);
    const shot=g.emitShot('hostile',from.x,from.y,wrap(aim+Math.PI),720,25,3);assert(shot);
    for(let n=0;n<5&&g.shots.has(shot.id);n++)step();assert(!g.shots.has(shot.id));
    return {wallLoss:old.health-wall().health,actorLoss:health-p.health,shieldLoss:shield-p.shield};
  }
  const center=hostile(0),rim=hostile(45);
  assert.equal(center.wallLoss,open?0:25);if(open)assert(center.actorLoss+center.shieldLoss>0);else assert.equal(center.actorLoss+center.shieldLoss,0);
  assert.equal(rim.wallLoss,25);assert.equal(rim.actorLoss+rim.shieldLoss,0);
  const primaryTrace=[];
  const ordinaryFriendly=g.friendlyCollision.bind(g);
  g.friendlyCollision=(shot,from,to,cutoff,...rest)=>{
    const result=ordinaryFriendly(shot,from,to,cutoff,...rest);
    if(shot.owner===p.id){
      let masonry=1;let rectangle;
      for(const rect of g.arena.obstacles){const hit=segmentRect(from,to,rect,shot.radius);if(hit&&hit.t<masonry){masonry=hit.t;rectangle=rect;}}
      primaryTrace.push({shot:shot.id,tick:g.combatTick,from:point(from),to:point(to),actualCutoff:cutoff,masonryCutoff:masonry,rectangle,hitEnemy:result});
    }
    return result;
  };
  const ammo=p.ammo;const events=step({fire:true});
  const emitted=events.flatMap(event=>event.type==='shots'?event.shots.filter(shot=>shot.owner===p.id):[]);
  assert.equal(ammo-p.ammo,open?1:0);assert.equal(emitted.length>0,open);
  for(let n=0;n<4;n++)step();const through=emitted.filter(shot=>g.shots.has(shot.id)).length;
  const central=emitted.find(shot=>Math.abs(wrap(Math.atan2(shot.vy,shot.vx)-aim))<1e-8);
  const centralTrace=central?primaryTrace.filter(trace=>trace.shot===central.id):[];
  const masonryStoppedCentral=!!central&&!g.shots.has(central.id)&&centralTrace.some(trace=>trace.masonryCutoff<1&&Math.abs(trace.actualCutoff-trace.masonryCutoff)<1e-9);
  if(open)assert(through>0||masonryStoppedCentral,'No continuing round or verified central masonry contact');
  const health=wall().health;step({technique1:true});assert(!g.classKits.tankWallCarried(p.id,g.combatTick));const set=wall();assert(set);
  assert.equal(set.halfSpan,original.halfSpan);assert.equal(set.id,original.id);assert.equal(set.until,original.until);
  assert.equal(set.health,health);assert.equal(set.health,original.health-center.wallLoss-rim.wallLoss);
  assert.equal(set.bulwarkPortHalfSpan,undefined);assert.equal(p.qAt,qAt);assert.deepEqual(point(p),body);
  return {open,body,moved:distance(start,body),center,rim,paidRounds:ammo-p.ammo,emitted:emitted.length,stillFlyingAfterFourFurtherTicks:through,
    masonryStoppedCentral,centralPrimaryTrace:centralTrace,
    originalId:original.id,originalUntil:original.until,originalRecovery:qAt,setAt:g.combatTick,remainingWallHealth:set.health,spentSp:5};
}

const rows=[];
for(const row of survey.rows){
  const options=row.surveyed.flatMap(shape=>shape.routes.filter(route=>route.halfSpan===55&&route.canSetFullWidth&&route.traveled>116&&route.remainingAtEnd>30).map(route=>({shape,route})));
  const attempts=[];
  for(const {shape,route} of options){try{
    const open=trial(row,shape,route,true),closed=trial(row,shape,route,false);assert.deepEqual(open.body,closed.body);
    assert.equal(open.originalUntil,closed.originalUntil);assert.equal(open.originalRecovery,closed.originalRecovery);
    attempts.push({passed:true,aim:shape.aim,side:route.sign,open,closed});break;
  }catch(error){attempts.push({passed:false,aim:shape.aim,side:route.sign,error:error.message});}}
  const result={arena:row.arena,difficulty:row.difficulty,passed:attempts.some(attempt=>attempt.passed),attempts};rows.push(result);
  console.log(JSON.stringify({arena:row.arena,difficulty:row.difficulty,passed:result.passed,attempts:attempts.length}));
}
assert.deepEqual(fingerprints(),before);const passed=rows.filter(row=>row.passed).length;
write(stage+'/canonical-geometry192.json',{sourceCommit:currentSource(),at:new Date().toISOString(),passed,total:rows.length,rows,runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),scope:'Actual canonical source. Same controlled36 paired original-arena/difficulty physical gap, rim, paid primary and original-expiry geometry trials as research91. Actual collision observer delegates unmodified results, preserving masonry stops. No online, rendered, human or final balance claim.'});
console.log(JSON.stringify({passed,total:rows.length,failures:rows.filter(row=>!row.passed)}));if(passed!==rows.length)process.exitCode=1;
