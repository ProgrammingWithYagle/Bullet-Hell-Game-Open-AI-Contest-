import fs from 'node:fs';
import assert from 'node:assert/strict';
import {root,stage,read,write,sha,git} from './common100.mjs';
import {scope,source,checkedGate} from './publication180.mjs';
process.chdir(root);const commit=source();assert.equal(git('rev-parse','HEAD'),commit);const {proof}=checkedGate();
const definitions=[['build-census190.json','build-census.json'],['canonical-natural191.json','natural-short.json'],['canonical-geometry192.json','geometry.json']];
const rows=[];
for(const [file,portable]of definitions){
 const result=read(stage+'/'+file);assert.equal(result.sourceCommit,commit);
 for(const key of ['runtimeSourceSha256','sourceSnapshotSha256'])assert.equal(result[key],proof[key],file+':'+key);
 if(file.startsWith('build')){assert.equal(result.totalSets,2334);assert.equal(result.priorSetCount,2298);assert.deepEqual(result.reports.map(row=>[row.classId,row.distinctSets]),[['engineer',841],['soldier',853],['heavy',604],['tank',36]]);}
 else if(file.includes('natural')){assert(result.passed&&result.allRowsExact&&result.rows.length===72);assert.deepEqual(result.outcomes,{none:{victory:19,defeat:5,paidPortRounds:0},pivot:{victory:18,defeat:6,paidPortRounds:0},port:{victory:18,defeat:6,paidPortRounds:213}});}
 else assert(result.passed===36&&result.total===36);
 rows.push({original:stage+'/'+file,portable:scope+'/'+portable,sha256:sha(fs.readFileSync(stage+'/'+file)),sourceCommit:commit});
}
write(stage+'/final-measurement-binding193.json',{passed:true,at:new Date().toISOString(),sourceCommit:commit,runtimeSourceSha256:proof.runtimeSourceSha256,sourceSnapshotSha256:proof.sourceSnapshotSha256,rows,actualBuildSets:2334,actualNaturalRuns:72,actualGeometryPairs:36,allNaturalRawRowsExact:true,onlineProof:false,humanBalanceAcceptance:false});
console.log(JSON.stringify({passed:true,sourceCommit:commit,buildSets:2334,naturalRuns:72,geometryPairs:36,allNaturalRowsExact:true}));
