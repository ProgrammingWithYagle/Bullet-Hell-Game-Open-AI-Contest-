import assert from 'node:assert/strict';
export function checkBulwarkAcquisition(result,transport,handling){
 assert(result.passed);assert.equal(result.handling,handling);assert.equal(result.transport,transport);
 assert.deepEqual(result.actualEarnedSequence,[3,9]);assert.equal(result.actualClears,1);
 assert.equal(result.spent,handling==='none'?3:5);assert.equal(result.originalLifetimeTicks,150);
 assert(result.earlyCarryAtEarned3&&result.earlyMoved>30&&result.laterMoved>30&&result.pausedCommandsDiscarded);
 if(handling==='pivot'){assert(Math.abs(result.turned)>.5);assert.equal(result.paidPortRounds,0);}
 else if(handling==='port'){assert.equal(result.paidPortRounds,1);assert.equal(result.turned,0);}
 else{assert.equal(result.turned,0);assert.equal(result.paidPortRounds,0);}
 const rows=result.menuObservations;
 for(const [item,cost]of [['tank-protection-1',1],['tank-bulwark-carry-1',2]]){
  const purchase=rows.find(row=>row.item===item);assert(purchase?.earned===3&&purchase.requests===1&&purchase.before-purchase.after===cost);
 }
 for(const fitting of ['pivot','port']){
  const observations=rows.filter(row=>row.item==='tank-bulwark-'+fitting+'-1');
  assert.equal(observations[0].earned,3);assert.equal(observations[0].requests,0);
  assert.equal(observations[0].before,observations[0].after);
  const later=observations.find(row=>row.earned===9);assert(later);
  assert.equal(later.requests,handling===fitting?1:0);assert.equal(later.before-later.after,handling===fitting?2:0);
 }
 if(transport==='worker')assert(result.wholeOptimizedWorker&&result.workerPatched===false);
 else assert(result.realPeers===3&&result.tankIsNonHost&&result.ownerPrivateHandlingAndPublicPanels&&result.sharedPhysicalPanels);
}
