import {pathToFileURL} from 'node:url';
import {root,stage,write} from './common100.mjs';
process.chdir(root);
const {runtimeArena}=await import(pathToFileURL(root+'/src/shared/arena-layouts.ts'));
const {moveBody,distance}=await import(pathToFileURL(root+'/src/shared/geometry.ts'));
const {data}=await import(pathToFileURL(root+'/src/shared/game.ts'));
const {planBulwarkStaging,clearTrialWalk,trialCastClear,stagingBearings}=await import(pathToFileURL(root+'/tests/helpers/tank-bulwark-staging.ts'));
const rows=[];
for(const start of [{x:902,y:298.5},{x:988.25,y:401.5}]){
 const world={...runtimeArena('gatehouse','baby'),tick:0};
 const directions=[[0,1],[1,0],[0,-1],[-1,0],[1,1],[1,-1],[-1,1],[-1,-1]].map(([x,y])=>{
  const to={x:start.x+x*32,y:start.y+y*32};
  return {to,clear:clearTrialWalk(world,start,to),actual:moveBody(start,{x:x*32,y:y*32},data.rules.playerRadius,[...world.obstacles]),conservative:moveBody(start,{x:x*32,y:y*32},data.rules.playerRadius+2,[...world.obstacles])};
 });
 rows.push({start,radius:data.rules.playerRadius,boss:world.bossSpawn,nearby:world.obstacles.filter(r=>distance(start,{x:Math.min(r.x+r.width,Math.max(r.x,start.x)),y:Math.min(r.y+r.height,Math.max(r.y,start.y))})<60),directions,withoutThreats:planBulwarkStaging(world,start),withThreat:planBulwarkStaging(world,start,[world.bossSpawn]),casts:stagingBearings.map(aim=>({aim,clear:trialCastClear(world,start,aim)}))});
}
write(stage+'/inspect-staging173.json',{at:new Date().toISOString(),rows});console.log(JSON.stringify(rows));
