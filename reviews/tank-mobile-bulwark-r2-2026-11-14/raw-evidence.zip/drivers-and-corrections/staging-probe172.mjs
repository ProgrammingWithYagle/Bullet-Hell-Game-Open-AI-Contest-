import assert from 'node:assert/strict';
import fs from 'node:fs';
import {pathToFileURL} from 'node:url';
import {root,stage,read,write,sha,fingerprints} from './common100.mjs';
process.chdir(root);const before=fingerprints();
const {runtimeArena}=await import(pathToFileURL(root+'/src/shared/arena-layouts.ts').href);
const {data}=await import(pathToFileURL(root+'/src/shared/game.ts').href);
const {planBulwarkStaging,clearTrialWalk,trialCastClear}=await import(pathToFileURL(root+'/tests/helpers/tank-bulwark-staging.ts').href);
const rows=[];
for(const arena of data.arenas)for(const difficulty of data.difficulties){
 const actual=runtimeArena(arena.id,difficulty.id),world={...actual,tick:0},body=actual.playerSpawn;
 const route=planBulwarkStaging(world,body);let passed=!!route,why='';
 if(route){let previous=body;for(const point of route.points){if(!clearTrialWalk(world,previous,point))passed=false;previous=point;}if(!trialCastClear(world,route.goal,route.aim))passed=false;}
 else why='No sampled staging path';rows.push({arena:arena.id,difficulty:difficulty.id,passed,route,why});
}
for(const body of [{x:902,y:298.5},{x:988.25,y:401.5}]){
 const world={...runtimeArena('gatehouse','baby'),tick:0},beforeWorld=JSON.stringify(world),route=planBulwarkStaging(world,body,[world.bossSpawn]);
 rows.push({arena:'gatehouse-recorded-body',difficulty:'baby',body,passed:!!route,route,scope:'Recorded body against the current actual static arena and its ordinary boss spawn. Not a replay of missing original dynamic cues.'});assert.equal(JSON.stringify(world),beforeWorld);
}
assert.deepEqual(fingerprints(),before);const passed=rows.filter(row=>row.passed).length;
write(stage+'/staging-probe172.json',{at:new Date().toISOString(),passed,total:rows.length,rows,driverSha256:sha(fs.readFileSync(new URL(import.meta.url))),runtimeSourceSha256:before.runtimeSourceSha256,sourceSnapshotSha256:before.sourceSnapshotSha256,scope:'Read-only actual-arena path/placement probing; no actual player is moved and no online proof is claimed.'});
console.log(JSON.stringify({passed,total:rows.length,failures:rows.filter(row=>!row.passed)}));if(passed!==rows.length)process.exitCode=1;
