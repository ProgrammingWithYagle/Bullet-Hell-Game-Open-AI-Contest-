import assert from 'node:assert/strict';
import { execFile as runFile } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const run = promisify(runFile);
const here = path => new URL('./' + path, import.meta.url);
const digest = path => sha256(readFileSync(here(path)));
const edition = readJson(here('content01.json'));
const bundle = readJson(here('game03.json'));
assert.equal(digest('game03.mjs'),bundle.bundle);
const layers = ['stage/', ...['swordsman-counterstroke','swordsman-measured','bard-misdirection','bard-lament','bard-conductor']
  .map(folder => `../${folder}/stage/`)];
for (const [path, hash] of Object.entries(bundle.inputs)) {
  const exact = layers.map(layer => layer + path).find(input => existsSync(here(input)));
  assert.equal(digest(exact),hash,path);
}

const policies = ['banked','unused','passing','through','cross'];
const actions = ['passing','open-through','open-cross','through','cross'];
const damage = (row, action) => row.effects.filter(event => event.action === action && event.damage > 0).length;
const replays = 'replays01';
mkdirSync(here(replays + '/'));
const cases = [];
const groups = [];
for (const mode of ['short','standard']) for (const cohort of ['solo','party']) {
  const path = `${mode}-${cohort}02.json`, group = readJson(here(path));
  assert(group.stageOnly && group.revision === edition.revision && group.bundle === bundle.bundle);
  assert(group.mode === mode && group.cohort === cohort && group.rows.length === 20);
  assert(group.controls.length === 4 && group.controls.every(row => row.sameTrace));
  for (const row of group.rows) {
    if (['banked','unused'].includes(row.policy)) assert.equal(row.effects.length,0);
    for (const buy of row.purchases) assert(buy.earned === (mode === 'short' ? 9 : 5) && buy.clears === 1);
    for (const event of row.effects) {
      assert(actions.includes(event.action) && event.before.ammo > 0);
      if (!event.refill) assert.equal(event.ammo,event.before.ammo - 1);
      if (event.action.startsWith('open-')) {
        assert(event.damage > 0 && row.effects.some(sibling => sibling.at === event.at && sibling.action === 'passing'));
        if (!event.refill) assert(event.state.followUntil > event.at);
      }
    }
  }
  const counts = policies.map(policy => {
    const rows = group.rows.filter(row => row.policy === policy);
    assert.equal(rows.length,4);
    return { policy, runs:rows.length, wins:rows.filter(row => row.won).length,
      fittings:rows.flatMap(row => row.purchases).length, refilled:rows.flatMap(row => row.effects).filter(event => event.refill).length,
      ...Object.fromEntries(actions.map(action => [action,rows.reduce((total,row) => total + damage(row,action),0)])) };
  });
  groups.push({ path, sha256:digest(path), mode, cohort, counts, matched:group.controls.length });
  cases.push(...await Promise.all(['passing','through','cross'].map(async policy => {
    const row = group.rows.filter(row => row.policy === policy).sort((a,b) => damage(b,policy) - damage(a,policy))[0];
    assert(damage(row,policy));
    const tag = `${replays}/${mode}-${cohort}-${policy}`;
    const outfile = tag + '.json', logfile = tag + '.log';
    const result = await run(process.execPath,[fileURLToPath(here('natural-pursuit.mjs')),fileURLToPath(here(outfile)),cohort,
      mode,'game03',row.arena + '/' + policy],{ cwd:fileURLToPath(here('')), windowsHide:true, timeout:180_000, maxBuffer:1024*1024 });
    writeFileSync(here(logfile),result.stdout,{ flag:'wx' });
    assert.deepEqual(readJson(here(outfile)).rows,[row]);
    return { path:outfile, sha256:digest(outfile), logSha256:digest(logfile), mode, cohort, policy, arena:row.arena,
      effectCount:damage(row,policy), trace:row.trace };
  })));
}
const combined = groups.flatMap(group => group.counts);
const totals = Object.fromEntries(actions.map(action => [action,combined.reduce((total,row) => total + row[action],0)]));
assert(totals.passing === 1008 && totals.through === 238 && totals.cross === 208 && cases.length === 12);
const outcomes = Object.fromEntries(policies.map(policy => {
  const rows = combined.filter(row => row.policy === policy);
  return [policy,{ runs:rows.reduce((n,row) => n + row.runs,0), wins:rows.reduce((n,row) => n + row.wins,0) }];
}));
receipt(here(replays + '/summary.json'),{ passed:true, revision:edition.revision, bundle:bundle.bundle, cases });
receipt(here('study-summary01.json'), { passed:true, revision:edition.revision, bundle:bundle.bundle, totals, outcomes,
  runs:combined.reduce((n,row) => n + row.runs,0), matched:groups.reduce((n,group) => n + group.matched,0),
  exactReplays:cases.length, refilledAfterClear:combined.reduce((n,row) => n + row.refilled,0),
  replaySummarySha256:digest(replays + '/summary.json'), groups });
console.log(JSON.stringify({ passed:true, totals, outcomes, replays:cases.length }));
