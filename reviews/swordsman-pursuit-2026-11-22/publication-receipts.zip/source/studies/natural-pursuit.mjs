import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { pursuitPilot } from './pursuit-pilot.mjs';

const [output, cohort, mode = 'short', bundleName = 'game02', sample] = process.argv.slice(2);
assert(output && ['solo','party'].includes(cohort) && ['short','standard'].includes(mode) && /^game\d\d$/.test(bundleName));
const here = path => new URL('./' + path, import.meta.url);
const verified = readJson(here(bundleName + '.json'));
const api = await verifiedBundle(fileURLToPath(here(bundleName + '.mjs')), verified.bundle);
const { Game, data, viewOf, HZ, idleInput, CONTENT_REVISION, pursuitIds, pursuitRules: rules, measuredRules: component,
  distance, segmentRect, segmentCircle, restRaidInput, swordCircleContact } = api;
const worlds = [['gatehouse','baby',41], ['sunken-chapel','normal',73], ['ossuary-works','normal',109], ['crown-crypt','baby',61]];
const policies = ['banked','unused','passing','through','cross'];
const filter = sample?.split('/');
if (filter) assert(filter.length === 2 && worlds.some(world => world[0] === filter[0]) && policies.includes(filter[1]));

function conduct(arena,difficulty,seed,policy) {
  const game = new Game({ mode, difficulty, seed, openingArenaId: arena, arenaSelection:'route', maxPlayers:cohort === 'solo' ? 1 : 2 });
  const sword = game.addPlayer('solo','Dara','swordsman');
  const ally = cohort === 'party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [sword,ally] : [sword];
  const trace = createHash('sha256'), shots = new Map(), effects = [], purchases = [];
  let serial = 0, passes = 0, lastShop = -1;
  const buy = (player,kind,item) => game.transact(player.id,{kind,item,id:'pursuit-study-' + ++serial});
  assert.equal(sword.totalSp,3);
  assert(buy(sword,'skill','swordsman-footwork-1').ok);
  if (policy !== 'banked') assert(buy(sword,'skill',pursuitIds.entry).ok);
  function equipment(p) {
    for (const item of data.weapons.filter(weapon => weapon.classId === p.classId).sort((a,b) => b.tier-a.tier))
      if (p.weapon === item.id || buy(p,'weapon',item.id).ok) break;
    for (const item of ['damage','health','fire-rate','reload','magazine']) buy(p,'upgrade',item);
    buy(p,'supply','medkit');
  }
  actors.forEach(equipment);
  assert(game.start());
  function danger(view,point,horizon) {
    if (view.minions.some(target => target.health > 0 && distance(target,point) < 26 + horizon * 2)) return true;
    if (view.fields.some(field => field.kind === 'zone' && distance(field,point) < field.radius + 12)) return true;
    for (const shot of shots.values()) {
      const left = Math.min(horizon,shot.expires - view.combatTick);
      if (left <= 0 || distance(point,shot) > 410) continue;
      const flown = (view.combatTick - shot.seenAt) / HZ;
      const a = { x: shot.x + shot.vx * flown, y: shot.y + shot.vy * flown };
      const b = { x: a.x + shot.vx * left / HZ, y: a.y + shot.vy * left / HZ };
      const hit = segmentCircle(a,b,point,shot.radius + data.rules.playerRadius + 2);
      if (hit !== null && !game.obstacles.some(wall => (segmentRect(a,b,wall,shot.radius)?.t ?? Infinity) <= hit)) return true;
    }
    return false;
  }
  const context = { ...api, game, danger, rules, component, observed:shots };
  const navigate = explicitNavigation(context);
  const play = pursuitPilot({ ...context, policy });
  while (!['victory','defeat'].includes(game.phase) && passes++ < 90000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of actors) game.vote(actor.id,0);
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        actors.forEach(equipment);
        if (['through','cross'].includes(policy) && !sword.skills.includes(pursuitIds[policy])) {
          const id = pursuitIds[policy];
          assert(sword.totalSp >= 5 && buy(sword,'skill',id).ok);
          assert.equal(buy(sword,'skill',pursuitIds[policy === 'through' ? 'cross' : 'through']).reason,'incompatibleItem');
          purchases.push({ id, earned:sword.totalSp, clears:sword.progress.clears });
        }
      }
      game.step();
      game.drainEvents();
      continue;
    }
    const seen = viewOf(game,sword.id);
    let ownerInput;
    const before = { e:sword.eAt, q:sword.qAt, damage:sword.damageDealt, x:sword.x, y:sword.y, ammo:sword.ammo,
      clears:sword.progress.clears, reload:sword.reloadAt };
    for (const actor of actors) {
      const player = seen.players.find(row => row.id === actor.id);
      const base = actor.status === 'active' ? restRaidInput(seen,player,[...shots.values()]) :
        actor.status === 'downed' ? {interact:true} : {};
      const choice = actor.status !== 'active' ? base : actor === sword
        ? play(seen,player,base,navigate) : navigate(seen,player,base);
      const frame = { ...idleInput(), ...choice, sequence: actor.ack + 1, clientTick: game.combatTick };
      frame.aim = Math.atan2(Math.sin(frame.aim), Math.cos(frame.aim));
      if (actor === sword) ownerInput = frame;
      trace.update(JSON.stringify(frame));
      assert(game.submitInput(actor.id, frame));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id,{...shot,seenAt:game.combatTick});
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== sword.id || !event.id.startsWith('sword-pursuit-')) continue;
      const action = event.id.slice('sword-pursuit-'.length);
      const state = game.kitStatus(sword.id).pursuit;
      const damage = sword.damageDealt - before.damage;
      const current = { phase:game.phase, ammo:sword.ammo, q:sword.qAt, e:sword.eAt,
        clears:sword.progress.clears, reload:sword.reloadAt };
      const detail = () => JSON.stringify({ arena,difficulty,seed,policy,boss:game.boss.id,tick:game.combatTick,action,before,current,ownerInput,damage,state });
      const refill = game.phase !== 'combat' && current.clears === before.clears + 1 && current.ammo === game.stats(sword).magazine;
      assert(ownerInput.technique3 && before.ammo > 0 && (sword.ammo === before.ammo - 1 || refill) &&
        sword.eAt === before.e && sword.qAt === before.q,detail());
      if (action.startsWith('open-')) assert(damage > 0 && (refill || state?.followUntil > game.combatTick),detail());
      effects.push({ action, at:game.combatTick, boss:game.boss.id, before, ammo:sword.ammo, damage, refill, state,
        cues:game.classCues().filter(cue => cue.owner === sword.id && cue.kind === 'sword-passing-cut') });
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(a => [a.x,a.y,a.health,a.qAt,a.eAt,a.ammo,a.damageDealt])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  return { arena,difficulty,seed,policy,won:game.phase === 'victory',clears:sword.progress.clears,trace:trace.digest('hex'),effects,purchases };
}

const rows = [], controls = [];
for (const world of worlds) {
  if (filter && world[0] !== filter[0]) continue;
  const outcomes = (filter ? [filter[1]] : policies).map(policy => conduct(...world,policy));
  if (!filter) {
    assert.equal(outcomes[0].trace,outcomes[1].trace);
    controls.push({ arena:world[0],sameTrace:true });
  }
  for (const row of outcomes) console.log(JSON.stringify({ arena:row.arena,policy:row.policy,won:row.won,clears:row.clears,
    outcomes:Object.fromEntries(['passing','open-through','open-cross','through','cross','meleeHit'].map(action => [action,row.effects.filter(item => action==='meleeHit' ? ['passing','through','cross'].includes(item.action)&&item.damage>0 : item.action===action).length])) }));
  rows.push(...outcomes);
}
receipt(output,{stageOnly:true,bundle:verified.bundle,revision:CONTENT_REVISION,mode,cohort,rows,controls});
