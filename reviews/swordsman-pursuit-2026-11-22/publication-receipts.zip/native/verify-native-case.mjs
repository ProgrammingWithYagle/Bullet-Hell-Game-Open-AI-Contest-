import assert from 'node:assert/strict';

export function verifyNativeCase(report, expected) {
  const { transport,fitting,revision,driver,worker } = expected;
  assert(report.passed && report.protocol===98 && report.contentRevision===revision && report.driverSha256===driver);
  assert(report.transport===transport && report.fitting===fitting && report.pausedCommandsDiscarded && report.noCheckpointImports);
  const entry = fitting==='entry';
  assert.equal(report.firstClear,entry ? 0 : 1);
  assert.equal(report.bought.at(-1).earned,entry ? 3 : 5);
  const { first,release,boss,angle,sounds } = report.result;
  assert(typeof boss==='string' && boss.length>0);
  assert(first.cue.state==='passing' && first.stride>=54 && sounds.includes('sword-pursuit-passing'));
  assert.equal(release.cue.state,entry ? 'passing' : fitting);
  for (const cut of [first,release]) {
    assert(cut.hits.length && cut.hits.every(hit => hit.after < hit.before));
    assert.equal(cut.ammo[1],cut.ammo[0]-1);
  }
  if (entry) assert.deepEqual(first,release);
  else {
    assert(release.stride>=32 && release.cue.id!==first.cue.id && first.opening.state==='open-'+fitting);
    assert(first.opening.until-first.opening.at===42 && first.opening.at===first.cue.at && release.cue.at<first.opening.until);
    assert(sounds.includes('sword-pursuit-open-'+fitting) && sounds.includes('sword-pursuit-'+fitting));
    const degrees = angle * 180 / Math.PI;
    if (fitting==='through') assert(degrees<=38.12);
    else assert(degrees>=56.88 && degrees<=123.12);
  }
  if (transport==='worker') assert(report.wholeOptimizedWorker && !report.workerPatched && report.workerSha256===worker);
  else {
    assert(report.witnessed.nonHost && report.witnessed.ownedStatePrivate);
    for (const cue of [first.cue,first.opening,release.cue].filter(Boolean)) assert(report.witnessed.shared.includes(cue.id));
  }
  return { transport,fitting,boss,firstClear:report.firstClear,stage:first.cue.id,opening:first.opening?.id,
    release:release.cue.id,angle,hits:release.hits };
}
