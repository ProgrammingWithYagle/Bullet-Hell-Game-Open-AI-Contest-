import { measuredPilot } from '../swordsman-measured/measured-pilot.mjs';

const angle = (a, b) => Math.abs(Math.atan2(Math.sin(a - b), Math.cos(a - b)));
const bearing = (from, to) => Math.atan2(to.y - from.y, to.x - from.x);
const point = (origin, heading, distance) => ({ x:origin.x + distance * Math.cos(heading), y:origin.y + distance * Math.sin(heading) });

export function pursuitPilot({ game, data, component, rules, distance, swordCircleContact, clearTrialWalk, danger, policy, ...rest }) {
  const ordinary = measuredPilot({ game, data, rules:component, distance, clearTrialWalk, danger, policy:'unused', ...rest });
  let approach = 0, combat = -1;
  function opponents(seen, body) {
    const definition = data.bosses.find(row => row.id === seen.boss.id);
    const parts = seen.bossCues.filter(row => ['raid-prop','early-prop','service-prop','stitch-pin'].includes(row.kind));
    return [...seen.minions, ...parts, { ...seen.boss, radius:definition?.radius ?? 42 }]
      .filter(row => row.health > 0 && row.radius > 0 && distance(row,body) < 480)
      .sort((a, b) => distance(a,body) - distance(b,body));
  }
  function release(origin, heading, targets, shape) {
    for (const target of targets) {
      const direct = bearing(origin,target);
      const relative = Math.atan2(Math.sin(direct-heading),Math.cos(direct-heading));
      const limit = rules.aimAngle - 0.045;
      const aim = heading + Math.min(limit,Math.max(-limit,relative));
      if (swordCircleContact(origin,aim,shape.reach,shape.arc,target,target.radius,game.obstacles)) return aim;
    }
  }
  return (seen, body, routine, navigate) => {
    const baseline = ordinary(seen,body,routine,navigate);
    if (policy === 'banked' || policy === 'unused') return baseline;
    const status = body.kit.pursuit, now = seen.combatTick;
    const fitting = status?.followUntil > now ? status.fitting : undefined;
    if (combat !== seen.encounter) { combat = seen.encounter; approach = 0; }
    if (!status || !body.ammo || body.reloadAt > now || (baseline.supply ?? -1) >= 0 ||
      (!fitting && status.recoveryAt > now)) return baseline;
    const targets = opponents(seen,body);
    if (!targets.length || distance(targets[0],body) > (fitting ? 252 : 330)) return baseline;
    const shape = rules[fitting || 'passing'];
    const heading = status.heading;
    const stride = fitting ? status.followStride : status.stride;
    const threshold = fitting ? rules.followStride : rules.stride;
    const quiet = { ...baseline, q:false, e:false, ultimate:false, dodge:false, sprint:false, reload:false, fire:false, supply:-1 };
    if (stride >= threshold && heading !== undefined && !danger(seen,body,3)) {
      const aim = release(body,heading,targets,shape);
      if (aim !== undefined) {
        if (!fitting) approach = heading;
        return { ...quiet, moveX:0, moveY:0, aim, technique3:true };
      }
    }

    const opening = seen.classCues.find(cue => cue.kind === 'sword-passing-cut' && cue.owner === body.id && cue.state === 'open-' + fitting);
    const axis = opening?.aim ?? approach;
    const near = bearing(body,targets[0]);
    const preferred = fitting === 'through' ? [axis,axis-0.36,axis+0.36] : fitting === 'cross' ?
      [axis+Math.PI/2,axis-Math.PI/2,axis+1.14,axis-1.14,axis+1.94,axis-1.94] :
      [near,near-0.28,near+0.28,near-0.59,near+0.59,near-0.86,near+0.86];
    const candidates = heading === undefined ? preferred : [heading, ...preferred];
    const terrain = { ...game.arena, obstacles:game.obstacles, tick:now, playerRadius:data.rules.playerRadius };
    const toward = candidates.flatMap(direction => {
      const ahead = point(body,direction,Math.max(14,threshold-stride));
      const first = point(body,direction,23);
      if (!clearTrialWalk(terrain,body,first) || danger(seen,first,5)) return [];
      const value = release(ahead,direction,targets,shape) === undefined ? 0 : 1;
      return [{ direction, score:value * 2 + Number(heading !== undefined && angle(direction,heading)<0.1) }];
    }).sort((a,b) => b.score-a.score)[0];
    if (!toward || !toward.score) return baseline;
    return { ...quiet, aim:toward.direction, moveX:Math.cos(toward.direction), moveY:Math.sin(toward.direction) };
  };
}
