import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { measuredPilot } from '../swordsman-measured/measured-pilot.mjs';
import { pursuitPilot } from './pursuit-pilot.mjs';

export function recordPursuitCues(history, view) {
  for (const cue of view.classCues) {
    if (cue.kind !== 'sword-passing-cut') continue;
    const previous = history.get(cue.id);
    if (previous) previous.last = cue;
    else history.set(cue.id,{ first:cue, last:cue });
  }
}

export function createPursuitPolicy({ adapter, view, data, HZ,rules,component,runtimeArena,bulwarkTrialWorld,clearTrialWalk,
  segmentRect,segmentCircle,distance,restRaidInput,fitting,swordCircleContact }) {
  let frameTick = -1, world;
  const game = {
    get arena() { return runtimeArena(view().arenaId,view().run.difficulty); },
    get obstacles() {
      const seen = view();
      if (frameTick !== seen.combatTick || world?.arenaId !== seen.arenaId) {
        frameTick = seen.combatTick;
        world = { ...bulwarkTrialWorld(seen), arenaId:seen.arenaId };
      }
      return world.obstacles;
    },
    get combatTick() { return view().combatTick; },
    get encounter() { return view().encounter; },
    movementSpeed(body) { return body.speed; },
  };
  function danger(seen,point,horizon) {
    if (seen.minions.some(actor => actor.health > 0 && distance(actor,point) < 22 + horizon)) return true;
    if (seen.fields.some(field => field.kind === 'zone' && distance(field,point) < field.radius + 8)) return true;
    for (const shot of adapter.observed.values()) {
      const time = Math.min(horizon,shot.expires - seen.combatTick);
      if (shot.owner !== 'hostile' || time <= 0 || distance(shot,point) > 435) continue;
      const age = Math.max(0,seen.combatTick - shot.seenAt) / HZ;
      const from = { x:shot.x + shot.vx * age, y:shot.y + shot.vy * age };
      const to = { x:from.x + shot.vx * time / HZ, y:from.y + shot.vy * time / HZ };
      const contact = segmentCircle(from,to,point,shot.radius + data.rules.playerRadius + 2);
      if (contact !== null && !game.obstacles.some(wall => (segmentRect(from,to,wall,shot.radius)?.t ?? Infinity) <= contact)) return true;
    }
    return false;
  }
  const context = { game,data,HZ,rules,component,distance,segmentRect,segmentCircle,clearTrialWalk,danger,swordCircleContact };
  const navigate = explicitNavigation(context);
  const ordinary = measuredPilot({ ...context, rules:component, policy:'unused' });
  const use = pursuitPilot({ ...context, policy:fitting === 'entry' ? 'passing' : fitting });
  const baseline = (seen,body) => restRaidInput(seen,body,[...adapter.observed.values()]);
  return { ordinary:(seen,body) => ordinary(seen,body,baseline(seen,body),navigate),
    invoke:(seen,body) => use(seen,body,baseline(seen,body),navigate) };
}

function readHealth(view) {
  const values = [['boss/' + view.boss.id,view.boss.health], ...view.minions.map(row => ['minion/' + row.id,row.health]),
    ...view.bossCues.filter(row => ['raid-prop','service-prop','early-prop','stitch-pin'].includes(row.kind))
      .map(row => ['part/' + row.id,row.health])];
  return new Map(values);
}
function changedHealth(before,after) {
  const updated = readHealth(after);
  return [...before].flatMap(([id,health]) => {
    const value = updated.get(id);
    return typeof value === 'number' && value < health ? [{ id, before:health, after:value }] : [];
  });
}
const angle = (a,b) => Math.abs(Math.atan2(Math.sin(a-b),Math.cos(a-b)));

export async function exercisePursuit({ adapter, view, owner, submit, fitting, rules, equip, policy }) {
  const deadline = Date.now() + 195_000, startTick = view().combatTick, eventStart = adapter.events.length;
  let lastTick = -1, lastShop = view().encounter, first;
  const trace = [];
  const samples = () => [...adapter.cues.values()].map(row => row.first)
    .filter(cue => cue.owner === adapter.id && cue.at >= startTick);
  const sounds = () => adapter.events.slice(eventStart).filter(event => event.type === 'sound' &&
    event.owner === adapter.id && event.id.startsWith('sword-pursuit-')).map(event => event.id);
  for (;;) {
    const seen = view(), body = owner();
    if (Date.now() >= deadline || ['victory','defeat'].includes(seen.phase)) {
      assert.fail(JSON.stringify({ fitting, phase:seen.phase, boss:seen.boss.id, tick:seen.combatTick, health:body.health,
        trace:trace.slice(-8), sounds:sounds().slice(-20), cues:samples().slice(-7) }));
    }
    if (seen.phase !== 'combat') {
      if (['mutationVote','contractVote','secretOffer'].includes(seen.phase)) adapter.vote(0);
      if (seen.phase === 'shop' && seen.encounter !== lastShop) { lastShop = seen.encounter; await equip(); }
      await sleep(20);
      continue;
    }
    if (seen.combatTick === lastTick) { await sleep(9); continue; }
    lastTick = seen.combatTick;
    const intent = body.status === 'active' ? policy.invoke(seen,body) : { interact:true };
    const status = body.kit.pursuit, opening = status?.followUntil > seen.combatTick;
    const input = intent.technique3 && status ? { status, health:readHealth(seen), x:body.x, y:body.y, ammo:body.ammo,
      q:body.qAt, e:body.eAt, encounter:seen.encounter } : undefined;
    await submit(intent);
    adapter.allyCover?.();
    if (!input) continue;
    const after = view(), current = owner();
    const found = samples().find(cue => cue.state === (opening ? fitting : 'passing') && cue.at > seen.combatTick && cue.at <= after.combatTick);
    if (!found) continue;
    const hits = changedHealth(input.health,after);
    const claim = { cue:found, hits, stride:opening ? status.followStride : status.stride, heading:status.heading,
      ammo:[input.ammo,current.ammo], q:input.q, e:input.e, boss:after.boss.id, encounter:input.encounter,
      footing:{ x:input.x, y:input.y } };
    trace.push(claim);
    if (after.phase !== 'combat' || !hits.length) continue;
    assert.equal(current.ammo,input.ammo - 1);
    assert.equal(current.qAt,input.q);
    assert.equal(current.eAt,input.e);
    assert(sounds().includes('sword-pursuit-' + found.state));
    assert(typeof claim.heading === 'number' && claim.stride >= (opening ? rules.followStride : rules.stride));
    assert(angle(found.aim,claim.heading) <= rules.aimAngle + 0.002);
    if (!opening) {
      if (fitting === 'entry') return { first:claim, release:claim, boss:claim.boss, sounds:sounds(), trace:trace.slice(-12) };
      const cue = samples().find(item => item.state === 'open-' + fitting && item.at === found.at && item.id !== found.id);
      if (cue) {
        assert(sounds().includes('sword-pursuit-open-' + fitting) && cue.until - cue.at === rules.followTicks);
        first = { ...claim, opening:cue };
      }
      continue;
    }
    if (!first || first.encounter !== claim.encounter || first.opening.until !== status.followUntil) continue;
    const change = angle(claim.heading,first.heading);
    if (fitting === 'through') assert(change <= rules.throughAngle + 0.002);
    else assert(change >= rules.crossMin - 0.002 && change <= rules.crossMax + 0.002);
    assert(found.at > first.cue.at && found.at < first.opening.until);
    assert.equal(current.kit.pursuit.followUntil,0);
    return { first, release:claim, boss:claim.boss, angle:change, sounds:sounds(), trace:trace.slice(-12) };
  }
}
