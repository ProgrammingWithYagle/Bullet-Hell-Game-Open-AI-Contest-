import assert from 'node:assert/strict';
import { mkdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, sha256 } from '../bonded/study-paths.mjs';
import { digest, runChild } from './run-native.mjs';

const folder = process.argv[2];
assert(folder);
mkdirSync(folder);
const jobs = ['short', 'standard'].flatMap(mode => ['solo', 'pair'].map(party => [mode, party]));
const driver = fileURLToPath(new URL('./seeded-study.mts', import.meta.url));
async function lane(mode, party) {
  const key = mode + '-' + party;
  const raw = join(folder, key + '.json'), rawReplay = join(folder, key + '-replay.json');
  const log = join(folder, key + '.log'), replayLog = join(folder, key + '-replay.log');
  assert.equal(await runChild([driver, mode, party, raw], log, 260000), 0, log);
  assert.equal(await runChild([driver, mode, party, rawReplay, 'replay'], replayLog, 180000), 0, replayLog);
  const full = readJson(raw), replay = readJson(rawReplay);
  assert(full.protocol === 101 && full.rows.length === 18 && replay.rows.length === 3);
  for (const field of ['revision', 'runtimeSourceSha256', 'driverSha256', 'policySha256']) assert.equal(full[field], replay[field]);
  for (const active of full.rows.filter(row => row.active)) {
    const unused = full.rows.find(row => !row.active && row.arena === active.arena && row.fitting === active.fitting);
    assert(unused && unused.orders.length === 0 && unused.catches.length === 0 && unused.sets.length === 0 && unused.shifts.length === 0);
    assert.deepEqual(unused.purchases, active.purchases);
  }
  for (const row of replay.rows) assert.deepEqual(full.rows.find(r => r.active && r.arena === row.arena && r.fitting === row.fitting), row);
  const results = ['entry', 'walking', 'turn'].map(fitting => {
    const rules = full.rows.filter(row => row.fitting === fitting);
    const sum = label => rules.reduce((total, row) => total + row[label].length, 0);
    return { fitting, unusedWins: rules.filter(row => !row.active && row.won).length, activeWins: rules.filter(row => row.active && row.won).length,
      activeWithFitting: rules.filter(row => row.active && row.acquired).length, orders: sum('orders'), sets: sum('sets'), catches: sum('catches'), shifts: sum('shifts') };
  });
  const result = { mode, party, runs: full.rows.length, exactReplays: replay.rows.length,
    revision: full.revision, runtimeSourceSha256: full.runtimeSourceSha256, cases: results,
    files: [raw, rawReplay, log, replayLog].map(path => ({ path: path.split(/[\\/]/).at(-1), sha256: digest(path) })) };
  console.log(JSON.stringify(result));
  return result;
}
const results = [];
for (const [mode, party] of jobs) results.push(await lane(mode, party));
const summaries = results.flatMap(row => row.cases);
const summary = { passed: true, matches: 72, pairedComparisons: 36, exactReplays: 12,
  orders: summaries.reduce((sum, row) => sum + row.orders, 0), sets: summaries.reduce((sum, row) => sum + row.sets, 0),
  catches: summaries.reduce((sum, row) => sum + row.catches, 0), shifts: summaries.reduce((sum, row) => sum + row.shifts, 0),
  driverSha256: digest(driver), policySha256: sha256(readFileSync(new URL('./formation-policy.mjs', import.meta.url))), results };
receipt(join(folder, 'study-summary.json'), summary);
