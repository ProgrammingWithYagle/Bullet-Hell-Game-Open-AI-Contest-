import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { formationCue, formationInput } from './formation-policy.mjs';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { viewOf } = await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput } = await repoImport('src/shared/protocol.ts');
const { formationIds } = await repoImport('src/shared/summoner-formation.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [mode, party, output, replay] = process.argv.slice(2);
assert(PROTOCOL === 101 && ['short', 'standard'].includes(mode) && ['solo', 'pair'].includes(party) && output);
const seeds = [['gatehouse', 41], ['sunken-chapel', 67], ['ossuary-works', 103]] as const;
const styles = ['entry', 'walking', 'turn'] as const;
const sourceFiles = (dir: string): string[] => readdirSync(join(checkout, dir), { withFileTypes: true }).flatMap(row => {
  const path = dir + '/' + row.name;
  return row.isDirectory() ? sourceFiles(path) : [path];
});
const runtime = createHash('sha256');
for (const path of sourceFiles('src').sort()) runtime.update(path + '\0').update(readFileSync(join(checkout, path)));

function run(arena, seed, fitting, active) {
  const game = new Game({ mode, difficulty: 'normal', seed, openingArenaId: arena, arenaSelection: 'fixed', maxPlayers: party === 'solo' ? 1 : 2 });
  const owner = game.addPlayer('joss', 'Joss', 'summoner');
  const players = party === 'solo' ? [owner] : [owner, game.addPlayer('mara', 'Mara', 'soldier')];
  const observed = new Map();
  const purchases = [], orders = [], sets = [], catches = [], shifts = [];
  const holding = new Map();
  let serial = 0, frames = 0, shop = -1;
  const trace = createHash('sha256');

  function buy(player, kind, item) {
    const result = game.transact(player.id, { id: 'formation-study-' + ++serial, kind, item });
    if (result.ok) purchases.push({ who: player.id, kind, item, earned: player.totalSp, clears: player.progress.clears });
    return result.ok;
  }
  function equip(player) {
    const weapons = data.weapons.filter(w => w.classId === player.classId).sort((a, b) => b.tier - a.tier);
    for (const weapon of weapons) if (player.weapon === weapon.id || buy(player, 'weapon', weapon.id)) break;
    for (const item of ['damage', 'health', 'fire-rate', 'reload', 'magazine']) buy(player, 'upgrade', item);
    buy(player, 'supply', 'medkit');
  }
  assert.equal(owner.totalSp, 3);
  assert(buy(owner, 'skill', 'summoner-bonds-1') && buy(owner, 'skill', formationIds.entry));
  if (fitting !== 'entry') assert(!buy(owner, 'skill', formationIds[fitting]));
  players.forEach(equip);
  assert(game.start());

  while (game.phase !== 'victory' && game.phase !== 'defeat' && frames++ < 90000) {
    if (game.phase !== 'combat') {
      observed.clear();
      if (['mutationVote', 'contractVote', 'secretOffer'].includes(game.phase)) for (const player of players) game.vote(player.id, 0);
      if (game.phase === 'shop' && game.encounter !== shop) {
        shop = game.encounter;
        if (fitting !== 'entry' && owner.totalSp >= 5 && !owner.skills.includes(formationIds[fitting])) {
          assert(buy(owner, 'skill', formationIds[fitting]));
          assert(owner.progress.clears >= 1);
        }
      }
      game.step();
      game.drainEvents();
      continue;
    }
    const view = viewOf(game, owner.id);
    const marker = formationCue(view, owner);
    if (marker?.state === 'holding') {
      const initial = holding.get(marker.id);
      if (!initial) holding.set(marker.id, marker);
      else if (!shifts.some(row => row.id === marker.id) &&
          (Math.hypot(initial.x - marker.x, initial.y - marker.y) >= 3 || Math.abs(initial.aim - marker.aim) >= 0.5)) {
        shifts.push({ id: marker.id, tick: game.combatTick, from: initial, to: marker });
      }
    }
    const hostile = [...observed.values()];
    const enabled = active && (fitting === 'entry' || owner.skills.includes(formationIds[fitting]));
    for (const player of players) {
      const seen = view.players.find(candidate => candidate.id === player.id);
      assert(seen);
      const control = player.status !== 'active' ? { interact: true } : player === owner ?
        formationInput(view, seen, hostile, restRaidInput, enabled) : restRaidInput(view, seen, hostile);
      const input = { ...idleInput(), ...control, sequence: player.ack + 1, clientTick: game.combatTick };
      input.aim = Math.atan2(Math.sin(input.aim), Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      assert(game.submitInput(player.id, input));
    }
    game.step();
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') observed.set(shot.id, { ...shot, seenAt: game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) observed.delete(id);
      if (event.type === 'sound' && event.owner === owner.id && event.id.startsWith('summoner-formation-')) {
        assert(enabled);
        const row = { tick: game.combatTick, boss: view.boss.id, clears: owner.progress.clears };
        if (event.id === 'summoner-formation-order') orders.push(row);
        if (event.id === 'summoner-formation-set') sets.push(row);
        if (event.id === 'summoner-formation-catch') catches.push({ ...row, x: event.x, y: event.y });
      }
    }
    trace.update(JSON.stringify([game.combatTick, game.boss.health, owner.x, owner.y, owner.health, owner.ammo,
      owner.damageDealt, game.kitStatus(owner.id).formation, ...game.retinue.owned(owner.id).map(u=>[u.id, u.x, u.y, u.health, u.attackAt])]));
  }
  assert(['defeat', 'victory'].includes(game.phase));
  return { arena, seed, fitting, active, won: game.phase === 'victory', clears: owner.progress.clears,
    acquired: owner.skills.includes(formationIds[fitting]), purchases, orders, sets, catches, shifts, trace: trace.digest('hex') };
}

const rows = [];
for (const [arena, seed] of seeds) for (const fitting of styles) for (const active of [false, true]) {
  if (replay && (!active || fitting === 'entry' && arena !== 'gatehouse' || fitting === 'walking' && arena !== 'sunken-chapel' || fitting === 'turn' && arena !== 'ossuary-works')) continue;
  const result = run(arena, seed, fitting, active);
  rows.push(result);
  console.log(JSON.stringify({ ...result, purchases: result.purchases.length, orders: result.orders.length, sets: result.sets.length, catches: result.catches.length, shifts: result.shifts.length }));
}
assert.equal(rows.length, replay ? 3 : 18);
receipt(output, { protocol: PROTOCOL, revision: CONTENT_REVISION, runtimeSourceSha256: runtime.digest('hex'), mode, party, replay: !!replay,
  driverSha256: sha256(readFileSync(new URL(import.meta.url))), policySha256: sha256(readFileSync(new URL('./formation-policy.mjs', import.meta.url))), rows });
