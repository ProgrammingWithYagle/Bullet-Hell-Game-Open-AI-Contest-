import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { bondInput } from '../bonded/bond-policy.mjs';
import { repoImport } from '../bonded/study-paths.mjs';
import { formationCue, normalizedAim, standing } from './formation-policy.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { formationIds, formationRules } = await repoImport('src/shared/summoner-formation.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');

export async function waitFor(check, detail, limit = 6500) {
  const end = Date.now() + limit;
  while (!check()) {
    assert(Date.now() < end, typeof detail === 'function' ? detail() : detail);
    await sleep(12);
  }
}

export async function formationFlow(adapter, fitting) {
  const view = () => { const frame = adapter.view(); assert(frame); return frame; };
  const owner = () => { const player = view().players.find(p => p.id === adapter.id); assert(player); return player; };
  const status = () => owner().kit.formation;
  const cue = () => formationCue(view(), owner());
  const bodies = () => (view().retinue ?? []).filter(unit => unit.owner === adapter.id && unit.health > 0 && !unit.temporary);
  const ordinary = () => bondInput(view(), owner(), [...adapter.observed.values()], restRaidInput, false);
  const spent = () => owner().skills.reduce((sum, id) => sum + [...data.skills, ...data.specializationSkills].find(node => node.id === id).cost, 0);
  const bought = [], probes = [];
  const details = () => JSON.stringify({ fitting, phase: view().phase, tick: view().combatTick, boss: view().boss.id,
    owner: { hp: owner().health, focus: owner().ammo, status: status() }, unitHealth: bodies().map(unit => unit.health), recent: probes.slice(-5) });
  async function buy(item) {
    assert((await adapter.purchase({ kind: 'skill', item })).ok, item);
    bought.push({ item, earned: spent() + owner().sp, clears: owner().progress.clears });
  }
  async function outfit() {
    for (const weapon of data.weapons.filter(row => row.classId === 'summoner').sort((a, b) => b.tier - a.tier)) {
      if (owner().weapon === weapon.id || (await adapter.purchase({ kind: 'weapon', item: weapon.id })).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({ kind: 'upgrade', item });
    await adapter.purchase({ kind: 'supply', item: 'medkit' });
  }

  assert.equal(owner().sp, 3);
  await buy('summoner-bonds-1');
  await buy(formationIds.entry);
  await waitFor(() => !!status(), 'authoritative Action 3 state');
  if (fitting !== 'entry') assert(!(await adapter.purchase({ kind: 'skill', item: formationIds[fitting] })).ok);
  await outfit();
  adapter.start();
  await waitFor(() => view().phase === 'combat', 'opening encounter');
  if (fitting !== 'entry') {
    const end = Date.now() + 140000;
    while (view().phase !== 'shop') {
      assert(Date.now() < end && !['defeat','victory'].includes(view().phase), details());
      if (view().phase === 'combat') { adapter.input(ordinary()); adapter.ally?.(true); }
      if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(view().phase === 'contractVote' ? 1 : 0);
      await sleep(24);
    }
    assert.equal(owner().progress.clears, 1);
    assert.equal(spent() + owner().sp, 5);
    await buy(formationIds[fitting]);
    assert.equal((await adapter.purchase({ kind: 'skill', item: formationIds[fitting === 'walking' ? 'turn' : 'walking'] })).reason, 'incompatibleItem');
    await outfit();
    await waitFor(() => view().phase === 'combat', 'next fight with earned fitting', 95000);
  }
  const firstClear = owner().progress.clears;
  console.log(JSON.stringify({ type: 'earned purchase', fitting, firstClear, boss: view().boss.id, bought }));

  adapter.pause(true);
  await waitFor(() => adapter.paused(), 'pause acknowledged');
  const pausedAt = view().combatTick, stoppedFocus = owner().ammo;
  adapter.input({ technique3:true });
  await sleep(120);
  assert.equal(view().combatTick, pausedAt);
  assert.equal(owner().ammo, stoppedFocus);
  assert(!cue());
  adapter.input({});
  adapter.pause(false);
  await waitFor(() => !adapter.paused() && view().combatTick > pausedAt, 'resumed');

  const end = Date.now() + 110000;
  let passes = 0;
  while (Date.now() < end && !['defeat','victory'].includes(view().phase)) {
    if (view().phase !== 'combat') {
      if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(view().phase === 'contractVote' ? 1 : 0);
      await sleep(50);
      continue;
    }
    const control = ordinary();
    if (bodies().length < 2 || owner().ammo < 2 || ['busy','recovering','gathering'].includes(status()?.stage)) {
      adapter.input(control);
      adapter.ally?.(true);
      await sleep(24);
      continue;
    }
    const player = owner(), arena = runtimeArena(view().arenaId, view().run.difficulty);
    const bossAim = Math.atan2(view().boss.y - player.y, view().boss.x - player.x);
    const half = fitting === 'walking' ? formationRules.walkingHalfWidth : formationRules.halfWidth;
    const clearRank = (aim, center) => {
      const side = { x: -Math.sin(aim) * half, y: Math.cos(aim) * half };
      const a = { x:center.x - side.x, y:center.y - side.y }, b = { x:center.x + side.x, y:center.y + side.y };
      const bounds = arena.bounds;
      return [a,b].every(p => p.x > bounds.x+14 && p.x < bounds.x+bounds.width-14 && p.y > bounds.y+14 && p.y < bounds.y+bounds.height-14) &&
        !arena.obstacles.some(wall => segmentRect(a,b,wall,14) !== null || segmentRect(player,center,wall,0) !== null) &&
        !arena.lavaPits.some(pit => segmentCircle(a,b,pit,pit.radius+14) !== null);
    };
    const offset = passes % 3 === 0 ? 0 : passes % 3 === 1 ? Math.PI / 12 : -Math.PI / 12;
    const threatAim = normalizedAim(bossAim + offset);
    const aim = threatAim;
    const center = { x:player.x + Math.cos(aim) * formationRules.lead, y:player.y + Math.sin(aim) * formationRules.lead };
    const blocked = arena.obstacles.some(wall => segmentRect(center, view().boss, wall, 8) !== null);
    const pivot = [aim + Math.PI / 2, aim - Math.PI / 2].map(normalizedAim).find(angle => clearRank(angle, center));
    if (blocked || !clearRank(aim, center) || fitting === 'turn' && pivot === undefined) {
      adapter.input(control);
      adapter.ally?.(true);
      await sleep(25);
      continue;
    }
    const rested = adapter.input({ ...standing(control), aim });
    await waitFor(() => owner().ack >= rested || view().phase !== 'combat', details);
    if (status()?.stage !== 'ready') { adapter.input(control); await sleep(25); continue; }
    const paid = { focus:owner().ammo, tick:view().combatTick, health:Object.fromEntries(bodies().map(unit => [unit.id,unit.health])) };
    const startEvents = adapter.events.length;
    const start = adapter.input({ ...standing(control), aim, technique3:true });
    await waitFor(() => owner().ack >= start || view().phase !== 'combat', details);
    adapter.input({ ...standing(control), aim });
    if (!(status()?.recoveryAt > paid.tick)) continue;
    assert.equal(owner().ammo, paid.focus - 2);
    passes++;
    let held, shifted, latest, witness, movedAt = 0, pivotSent = false;
    const tryEnd = Date.now() + 6300;
    while (Date.now() < tryEnd && view().phase === 'combat') {
      const marker = cue();
      if (marker) latest = marker;
      if (marker?.state === 'holding' && !held) {
        held = marker;
        assert.equal(held.until - held.at, formationRules.duration);
      }
      if (held && fitting === 'walking' && !movedAt) movedAt = view().combatTick;
      const displaced = marker && held && fitting !== 'entry' && (fitting === 'walking' ?
        Math.hypot(marker.x - held.x, marker.y - held.y) >= 14 : Math.abs(normalizedAim(marker.aim - held.aim)) > 1.5);
      if (displaced) {
        if (marker.state === 'holding' && !shifted) {
          assert.equal(marker.id, held.id);
          assert.equal(marker.until, held.until);
          shifted = marker;
          console.log(JSON.stringify({ type: 'replanted', fitting, marker }));
        }
      }
      const caught = adapter.events.slice(startEvents).some(event => event.type === 'sound' &&
        event.owner === adapter.id && event.id === 'summoner-formation-catch');
      if (held && (fitting === 'entry' || shifted) && caught && (fitting !== 'turn' || status()?.catches === 1)) {
        const active = shifted ?? held;
        const poses = [{ x:active.ax, y:active.ay }, { x:active.bx, y:active.by }];
        const seats = bodies().filter(unit => poses.some(point => Math.hypot(unit.x - point.x, unit.y - point.y) <= 24));
        const affectedByCatch = () => Object.entries(paid.health).some(([id, hp]) => {
          const body = bodies().find(unit => unit.id === +id);
          return (!body || seats.some(unit => unit.id === +id)) && (!body || hp - body.health > 0.5);
        });
        // A peer can receive the combat event ahead of the updated retinue view.
        await waitFor(affectedByCatch, 'Caught shot damage must reach the projected retinue', 2300);
        witness = await adapter.witness?.(held);
        return { passed:true, boss:view().boss.id, firstClear, bought, fitting, pauseRejected:true, attempts:probes,
          result:{ focusCost:2, held, shifted, caught:true, affected:true, retainedCatch:fitting === 'turn' ? 1 : undefined, witness, initialFocus:paid.focus } };
      }
      if (!marker && view().combatTick > paid.tick + 6) break;
      const quiet = { ...standing(ordinary()), aim };
      if (held && fitting === 'turn' && !pivotSent && caught && marker?.state === 'holding' && status()?.catches === 1) {
        const seq = adapter.input({ ...quiet, aim:pivot, technique3:true });
        await waitFor(() => owner().ack >= seq || view().phase !== 'combat', details);
        pivotSent = Math.abs(normalizedAim((cue()?.aim ?? aim) - aim)) > 1.5;
      } else if (held && fitting === 'walking' && view().combatTick - movedAt < 4) {
        adapter.input({ ...quiet, moveX: Math.cos(aim), moveY: Math.sin(aim) });
      } else adapter.input(quiet);
      adapter.ally?.(false);
      await sleep(24);
    }
    probes.push({ paid, held, shifted, latest, pivotSent, boss: view().boss.id });
    console.log(JSON.stringify({ type:'paid attempt', ...probes.at(-1) }));
  }
  throw Error('No complete natural formation catch: ' + details());
}
