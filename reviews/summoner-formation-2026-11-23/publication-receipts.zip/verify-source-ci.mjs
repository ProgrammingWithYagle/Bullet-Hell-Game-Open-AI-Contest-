import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, readJson, receipt, sha256 } from '../bonded/study-paths.mjs';

const [commit, directory, phase = 'source'] = process.argv.slice(2);
assert(/^[0-9a-f]{40}$/.test(commit) && directory && ['source','metadata'].includes(phase), 'Pass the pushed commit and a new receipt directory');
assert(!existsSync(directory));
const local = readJson(join(checkout, 'reviews/summoner-formation-2026-11-23/source-verification.json'));
const repository = 'ProgrammingWithYagle/Bullet-Hell-Game-Open-AI-Contest-';
const api = 'https://api.github.com/repos/' + repository;
const auth = spawnSync('git', ['-c', 'core.bare=false', 'credential', 'fill'], {
  cwd: checkout,
  input: 'protocol=https\nhost=github.com\npath=' + repository + '.git\n\n',
  encoding: 'utf8',
  env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GCM_INTERACTIVE: 'Never' },
  timeout: 12_000,
  stdio: ['pipe', 'pipe', 'ignore'],
  windowsHide: true,
});
assert.equal(auth.status, 0, 'GitHub credential lookup failed');
const token = auth.stdout.split(/\r?\n/).find(line => line.startsWith('password='))?.slice(9);
assert(token, 'GitHub credential unavailable');
const headers = { Authorization: 'Bearer ' + token, Accept: 'application/vnd.github+json', 'X-GitHub-Api-Version': '2022-11-28' };
const decoder = new URL("file:///C:/Users/yigal/Documents/Codex/2026-11-10/continue-grave-accord-in-the-same/work/menu21-stage/unzip-runtime-artifact01.mjs");
const { decodeRuntimeEvidenceArchive } = await import(decoder.href);

async function github(path) {
  const response = await fetch(api + path, { headers, redirect: 'manual', signal: AbortSignal.timeout(18_000) });
  assert(response.ok || response.status === 302, 'GitHub API HTTP ' + response.status + ' for ' + path);
  return response;
}
async function json(path) {
  return (await github(path)).json();
}
async function download(path) {
  let response = await github(path);
  if (response.status === 302) {
    const redirect = new URL(response.headers.get('location'));
    assert(redirect.protocol === 'https:' && /(?:^|\.)(?:blob\.core\.windows\.net|githubusercontent\.com)$/.test(redirect.hostname));
    response = await fetch(redirect, { signal: AbortSignal.timeout(23_000) });
  }
  assert(response.ok, 'GitHub download HTTP ' + response.status + ' for ' + path);
  return Buffer.from(await response.arrayBuffer());
}

const [listing, pr] = await Promise.all([json('/actions/runs?head_sha=' + commit + '&per_page=30'), json('/pulls/14')]);
assert(pr.draft && pr.state === 'open' && pr.head.sha === commit && pr.head.ref === 'feat/first-playable-loop');
const runs = ['push', 'pull_request'].map(event => listing.workflow_runs
  .filter(run => run.head_sha === commit && run.path === '.github/workflows/verify.yml' && run.event === event)
  .sort((a, b) => b.id - a.id)[0]);
if (runs.some(run => run?.status !== 'completed')) {
  console.log(JSON.stringify({ pending: true, runs: runs.map(run => run && { id: run.id, event: run.event, status: run.status }) }));
  process.exit(2);
}

mkdirSync(directory);
const exact = readJson(new URL('./source-commit01.json', import.meta.url));
assert(exact.passed && exact.protocol === 101 && Number.isInteger(exact.tests));
const counts = { tests: exact.tests, pass: exact.tests, fail: 0, cancelled: 0, skipped: 0, todo: 0 };
async function verify(run) {
  const path = '/actions/runs/' + run.id;
  const [jobsResult, artifactResult] = await Promise.all([
    json(path + '/attempts/' + run.run_attempt + '/jobs?per_page=100'),
    json(path + '/artifacts?name=verification-evidence&per_page=100'),
  ]);
  assert.equal(jobsResult.total_count, 1);
  const [job] = jobsResult.jobs;
  const log = await download('/actions/jobs/' + job.id + '/logs');
  writeFileSync(join(directory, run.event + '-' + job.id + '.log'), log, { flag: 'wx' });
  const pattern = key => new RegExp('(?:ℹ|#) ' + key + '\\s+(\\d+)', 'g');
  const observed = Object.fromEntries(Object.keys(counts).map(key => {
    const matches = [...log.toString('utf8').matchAll(pattern(key))];
    return [key, Number(matches.at(-1)?.[1] ?? -1)];
  }));
  assert.equal(run.conclusion, 'success', run.event);
  assert.equal(job.conclusion, 'success', run.event);
  assert(job.steps.length > 0 && job.steps.every(step => step.status === 'completed' && step.conclusion === 'success'));
  assert.deepEqual(observed, counts);
  assert(log.includes('Verification passed; evidence'));
  const current = artifactResult.artifacts.filter(artifact =>
    !artifact.expired && artifact.name === 'verification-evidence' &&
    artifact.workflow_run.head_sha === commit && Date.parse(artifact.created_at) >= Date.parse(job.started_at));
  assert.equal(current.length, 1);
  const [artifact] = current;
  const zip = await download('/actions/artifacts/' + artifact.id + '/zip');
  assert.equal(artifact.digest, 'sha256:' + sha256(zip));
  writeFileSync(join(directory, run.event + '-' + artifact.id + '.zip'), zip, { flag: 'wx' });
  const report = decodeRuntimeEvidenceArchive(zip);
  const runtime = JSON.parse(report.text);
  assert(runtime.passed && runtime.checks.length === 7 && runtime.checks.every(check => check.passed));
  for (const key of ['runtimeSourceSha256', 'sourceSnapshotSha256', 'contentRevision', 'verificationDriverSha256', 'testFiles']) {
    assert.equal(runtime[key], local[key], key);
  }
  return { id: run.id, event: run.event, url: run.html_url, attempt: run.run_attempt, job: job.id, steps: job.steps.length,
    counts: observed, downloadedLogSha256: sha256(log), artifact: artifact.id, artifactSha256: sha256(zip),
    report: report.name, reportSha256: sha256(report.text) };
}

const outcomes = await Promise.allSettled(runs.map(verify));
const result = { commit, head: commit, phase, draft: pr.draft, checkedAt: new Date().toISOString(), passed: outcomes.every(row => row.status === 'fulfilled'),
  outcomes: outcomes.map((row, i) => row.status === 'fulfilled' ? row.value : { id: runs[i].id, error: String(row.reason) }) };
receipt(join(directory, 'feature-ci.json'), result);
console.log(JSON.stringify(result));
if (!result.passed) process.exitCode = 1;
