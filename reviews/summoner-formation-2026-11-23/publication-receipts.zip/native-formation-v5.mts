import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import { Worker } from 'node:worker_threads';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { formationFlow, waitFor as until } from './native-flow-v5.mts';

const { data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION } = await repoImport('src/shared/protocol.ts');
const { Session } = await repoImport('src/client/session.ts');
const { confirmedPurchase, inputFrame, remember } = await repoImport('tests/helpers/tank-interceptor-transport.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [transport, fitting, outcome, supplied, audience = 'public', difficulty = 'normal'] = process.argv.slice(2);
assert(PROTOCOL === 101 && ['worker','peer'].includes(transport) && ['entry','walking','turn'].includes(fitting) && outcome);
assert(['testing','public'].includes(audience) && ['normal','baby'].includes(difficulty));
const setup = { mode: fitting === 'entry' ? 'short' : 'standard', difficulty, arenaSelection: 'fixed', openingArenaId: 'gatehouse',
  freePlay: { openingBossId: 'constable', variant: 'normal', seed: 73 } };
const playerIn = (view, id) => view?.players.find(player => player.id === id);
const state = () => ({ events:[], observed:new Map(), cues:new Map() });
const play = adapter => formationFlow(adapter, fitting);
function observeCues(receiver, view) {
  for (const cue of view.classCues) if (cue.kind === 'summoner-formation' && cue.state === 'holding' && !receiver.has(cue.id)) receiver.set(cue.id, cue);
}

async function runWorker() {
  let code = supplied && supplied !== '-' ? readFileSync(supplied, 'utf8') : undefined;
  if (code === undefined) {
    const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
    const output = await build({ absWorkingDir: checkout, entryPoints: ['src/client/offline.worker.ts'],
      bundle: true, minify: true, write: false, platform: 'browser', format: 'esm', logLevel: 'silent',
      define: { __GA_TESTING_BUILD__: String(audience === 'testing'), 'import.meta.env.DEV': 'false' } });
    code = output.outputFiles[0].text;
  }
  const wrapper = "import{parentPort}from'node:worker_threads';globalThis.self={};globalThis.postMessage=m=>parentPort.postMessage(m);" + code +
    "\nparentPort.on('message',data=>self.onmessage({data}));parentPort.postMessage({type:'ready'});";
  const worker = new Worker(new URL('data:text/javascript;base64,' + Buffer.from(wrapper).toString('base64')), { execArgv: [] });
  const captured = state(), purchases = new Map();
  let view, error, ready = false, sequence = 0, serial = 0, paused = false;
  worker.on('error', failure => { error = failure; });
  worker.on('message', message => {
    if (message.type === 'ready') ready = true;
    if (message.type === 'error') error = Error(JSON.stringify(message));
    if (message.type === 'view') { view = message.view; observeCues(captured.cues, view); }
    if (message.type === 'events') remember(captured.events, captured.observed, message.events, view?.combatTick ?? 0);
    if (message.type === 'purchaseResult') purchases.set(message.id, message);
    if (message.type === 'pauseState') paused = message.value;
  });
  const send = message => worker.postMessage(message);
  try {
    await until(() => ready || error, 'whole worker ready');
    if (error) throw error;
    send({ type: 'init', settings: { ...setup, seed: setup.freePlay.seed, maxPlayers: 1 }, name: 'Joss', classId: 'summoner' });
    await until(() => !!view || error, 'worker lobby');
    if (error) throw error;
    const result = await play({ ...captured, id: 'solo', view: () => { if (error) throw error; return view; },
      input: props => { send({ type: 'input', input: inputFrame(view, ++sequence, props) }); return sequence; },
      purchase: async request => {
        const id = 'formation-' + ++serial;
        send({ type: 'purchase', request: { ...request, id } });
        await until(() => confirmedPurchase(view, 'solo', request, purchases.get(id)), 'worker purchase response');
        return purchases.get(id);
      }, start: () => send({ type: 'start' }), vote: index => send({ type: 'vote', index }),
      pause: value => send({ type: 'pause', value }), paused: () => paused });
    return { ...result, wholeOptimizedWorker: true, workerPatched: false, workerSha256: sha256(code) };
  } finally { await worker.terminate(); }
}

async function runPeer() {
  const { createGameServer } = await repoImport('src/server/index.ts');
  const transient = supplied && supplied !== '-' ? undefined : createGameServer({ audience });
  if (transient) await transient.server.listen(0, '127.0.0.1');
  const endpoint = transient ? 'http://127.0.0.1:' + transient.httpServer.address().port : supplied;
  assert(/^http:\/\/127\.0\.0\.1:\d+$/.test(endpoint));
  const host = new Session(endpoint), joss = new Session(endpoint);
  const ownerState = state(), hostState = state(), ownerReplies = [], hostReplies = [];
  let seq = 0, hostSeq = 0, leaks = 0;
  host.onView = view => {
    observeCues(hostState.cues, view);
    const raw = host.room?.state.players.get(joss.id)?.lineworkOwner;
    if (playerIn(view, joss.id)?.kit.formation !== undefined || raw && JSON.parse(raw).formation !== undefined) leaks++;
  };
  joss.onView = view => observeCues(ownerState.cues, view);
  joss.onEvents = batch => remember(ownerState.events, ownerState.observed, batch, joss.view?.combatTick ?? 0);
  host.onEvents = batch => remember(hostState.events, hostState.observed, batch, host.view?.combatTick ?? 0);
  host.onPurchase = response => hostReplies.push(response);
  joss.onPurchase = response => ownerReplies.push(response);
  async function purchase(client, replies, request) {
    const i = replies.length;
    client.purchase(request);
    await until(() => confirmedPurchase(client.view, client.id, request, replies[i]), 'room purchase response');
    return replies[i];
  }
  try {
    await host.connect({ ...setup, name: 'Natural host', classId: 'soldier', maxPlayers: 2 });
    await joss.connect({ ...setup, name: 'Formation Joss', classId: 'summoner', maxPlayers: 2 }, { roomId: host.room.roomId });
    await until(() => joss.view?.players.length === 2 && host.view?.players.length === 2, 'two real peers');
    assert.equal(joss.view.owner, host.id);
    assert.notEqual(joss.id, host.id);
    const hostPlayer = () => playerIn(host.view, host.id);
    for (const weapon of data.weapons.filter(row => row.classId === 'soldier').sort((a, b) => b.tier - a.tier)) {
      if (hostPlayer().weapon === weapon.id || (await purchase(host, hostReplies, { kind: 'weapon', item: weapon.id })).ok) break;
    }
    const result = await play({ ...ownerState, id: joss.id, view: () => joss.view,
      input: props => { joss.input(inputFrame(joss.view, ++seq, props)); return seq; },
      purchase: request => purchase(joss, ownerReplies, request), start: () => host.start(),
      vote: index => { host.vote(index); joss.vote(index); }, pause: value => host.setMatchPaused(value), paused: () => joss.view?.matchPaused === true,
      ally: pressure => {
        const control = restRaidInput(host.view, hostPlayer(), [...hostState.observed.values()]);
        host.input(inputFrame(host.view, ++hostSeq, pressure ? control : { ...control, q: false, e: false, ultimate: false, fire: false }));
      },
      witness: async cue => {
        await until(() => hostState.cues.has(cue.id), 'peer sees the planted formation');
        const seen = hostState.cues.get(cue.id);
        for (const key of ['id', 'owner', 'radius', 'at', 'until', 'state']) assert.equal(seen[key], cue[key]);
        const raw = joss.room.state.players.get(joss.id)?.lineworkOwner;
        assert(raw && JSON.parse(raw).formation);
        assert.equal(leaks, 0);
        return { joinedNonHost: true, sharedCue: seen, ownerStateStayedPrivate: true };
      },
    });
    host.endMatch();
    await until(() => [host, joss].every(s => s.view?.phase === 'defeat' && s.view.endedByHost), 'close joined proof room');
    return { ...result, endpoint, peers: 2 };
  } finally {
    await joss.close();
    await host.close();
    if (transient) await transient.server.gracefullyShutdown(false);
  }
}

const result = await (transport === 'worker' ? runWorker() : runPeer());
receipt(outcome, { ...result, protocol: PROTOCOL, contentRevision: CONTENT_REVISION, transport, audience, difficulty,
  flowSha256: sha256(readFileSync(new URL('./native-flow-v5.mts', import.meta.url))), driverSha256: sha256(readFileSync(new URL(import.meta.url))), policySha256: sha256(readFileSync(new URL('./formation-policy.mjs', import.meta.url))) });
console.log(JSON.stringify({ passed: true, transport, fitting, firstClear: result.firstClear, boss: result.boss, caught: result.result.caught }));
