import assert from 'node:assert/strict';
import { existsSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

export const currentDriver = fileURLToPath(new URL('./native-formation-v2.mts', import.meta.url));
export { digest, runChild };
export function verifyNative(row, { transport, fitting, revision, driver, worker, difficulty }) {
  assert(row.passed && row.protocol === 101 && row.contentRevision === revision);
  assert.equal(row.transport, transport);
  assert.equal(row.fitting, fitting);
  assert.equal(row.difficulty, difficulty);
  assert.equal(row.driverSha256, digest(driver));
  assert.equal(row.flowSha256, digest(new URL('./native-flow-v2.mts', import.meta.url)));
  assert.equal(row.policySha256, digest(new URL('./formation-policy.mjs', import.meta.url)));
  assert(row.pauseRejected && row.bought[1].earned === 3);
  if (fitting !== 'entry') assert(row.firstClear === 1 && row.bought[2].earned === 5);
  assert.equal(row.result.focusCost, 2);
  assert(row.result.caught && row.result.affected && row.result.held.state === 'holding' && row.result.held.radius > 0);
  if (fitting !== 'entry') {
    assert.equal(row.result.held.id, row.result.shifted.id);
    assert.equal(row.result.held.until, row.result.shifted.until);
  }
  if (transport === 'worker') {
    assert(row.wholeOptimizedWorker && row.workerPatched === false);
    if (worker) assert.equal(row.workerSha256, worker);
  } else assert(row.peers === 2 && row.result.witness.joinedNonHost && row.result.witness.ownerStateStayedPrivate);
}

async function local(folder, difficulty, filter) {
  assert(folder && !existsSync(folder));
  mkdirSync(folder);
  const { sha256:revision } = readJson(join(checkout,'content/revision.json'));
  const cases = ['worker','peer'].flatMap(transport => ['entry','walking','turn'].map(fitting => [transport,fitting]));
  const chosen = filter ? cases.filter(row => filter.split(',').includes(row.join('-'))) : cases;
  assert(chosen.length);
  const rows = await Promise.all(chosen.map(async ([transport,fitting]) => {
    const stem=transport+'-'+fitting, raw=join(folder,stem+'.json'), log=join(folder,stem+'.log');
    const code = await runChild([currentDriver,transport,fitting,raw,'-','testing',difficulty],log,320000);
    const result = existsSync(raw) ? readJson(raw) : undefined;
    let error;
    if (code === 0) {
      try { verifyNative(result, { transport, fitting, revision, driver: currentDriver, difficulty }); }
      catch (failure) { error = String(failure); }
    }
    const item = { transport,fitting,code,error,passed:code===0 && !error && result?.passed===true,logSha256:digest(log),rawSha256:result && digest(raw),caught:result?.result.caught };
    console.log(JSON.stringify(item));
    return item;
  }));
  const passed = rows.every(row=>row.passed);
  receipt(join(folder,'checks.json'),{passed,difficulty,driver:digest(currentDriver),cases:rows});
  if (!passed) process.exitCode=1;
}

if (process.argv[1] === fileURLToPath(import.meta.url)) await local(...process.argv.slice(2));
