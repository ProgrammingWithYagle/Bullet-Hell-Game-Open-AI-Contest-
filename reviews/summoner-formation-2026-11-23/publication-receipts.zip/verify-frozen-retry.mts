import assert from 'node:assert/strict';
import { existsSync, mkdirSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { basename, join } from 'node:path';
import { setTimeout as sleep } from 'node:timers/promises';
import { checkout, readJson, receipt, sha256 } from '../bonded/study-paths.mjs';
import { currentDriver, digest, runChild, verifyNative } from './native-current.mjs';

const [commit, folder, previous, difficulty = 'normal'] = process.argv.slice(2);
assert(['normal', 'baby'].includes(difficulty));
assert(/^[0-9a-f]{40}$/.test(commit) && folder && !existsSync(folder));
const proof = readJson(new URL('./source-commit01.json', import.meta.url));
assert(proof.passed && proof.sourceCommit === commit && proof.protocol === 101);
mkdirSync(folder);
const revision = proof.contentRevision;
const scope = 'reviews/summoner-formation-2026-11-23';
const prefixes = ['assassin-duelist-2026-11-20', 'assassin-infiltrator-2026-11-21', 'assassin-mark-hunter-2026-11-21',
  'bard-conductor-2026-11-21', 'bard-lament-2026-11-21', 'bard-misdirection-2026-11-21', 'swordsman-measured-2026-11-22',
  'swordsman-counterstroke-2026-11-22', 'swordsman-pursuit-2026-11-22', 'summoner-cohort-2026-11-23', 'summoner-bond-2026-11-23', 'summoner-formation-2026-11-23'];
const iconSources = prefixes.flatMap(name => {
  const root = join(checkout, 'assets/production/ui', name);
  return readdirSync(root).filter(file => file.endsWith('.png')).map(file => join(root, file));
});
const audioSources = ['set','arm','take','arrive','turn','second'].map(name => join(checkout, 'assets/audio/sfx/bard-entrance-' + name + '.wav'));

async function reply(url) {
  const result = await fetch(url, { signal: AbortSignal.timeout(10000) });
  assert.equal(result.status, 200, url);
  return result;
}
async function health(preview) {
  const result = await (await reply(preview.endpoint + '/api/health')).json();
  assert(result.status === 'ok' && result.audience === preview.audience && result.sourceCommit === commit);
  assert.equal(result.protocolVersion, proof.protocol);
  assert.equal(result.contentRevision, revision);
  return result;
}
async function served(preview, member) {
  const bytes = Buffer.from(await (await reply(new URL(member.path, preview.url).href)).arrayBuffer());
  assert.equal(bytes.length, member.bytes, member.path);
  assert.equal(sha256(bytes), member.sha256, member.path);
}

async function review(audience) {
  const preview = readJson(join(checkout, scope, 'preview-' + audience + '.json'));
  assert(preview.passed && preview.sourceCommit === commit && preview.protocol === proof.protocol && preview.contentRevision === revision);
  assert.equal(preview.runtimeSourceSha256, proof.runtimeSourceSha256);
  assert.equal(preview.sourceSnapshotSha256, proof.sourceSnapshotSha256);
  const manifest = readJson(preview.manifestPath);
  assert(manifest.passed && manifest.members.length === preview.files && manifest.audience === audience);
  const startup = await health(preview);
  const worker = manifest.members.find(member => /^assets\/offline\.worker-.*\.js$/.test(member.path));
  assert(worker);
  const workerPath = join(preview.root, worker.path);
  const arts = [...iconSources, ...audioSources];
  const sampled = [worker, ...manifest.members.filter(member => /^(?:index\.html|preview-build\.json|assets\/index-[\w-]+\.(?:css|js))$/.test(member.path))];
  for (const path of arts) {
    const file = basename(path), dot = file.lastIndexOf('.');
    const member = manifest.members.find(row => row.path.startsWith('assets/' + file.slice(0, dot) + '-') && row.path.endsWith(file.slice(dot)));
    assert(member, file);
    assert.equal(digest(path), member.sha256, file);
    sampled.push(member);
  }
  async function exactBytes() {
    assert.equal(digest(preview.manifestPath), preview.manifestSha256);
    assert.equal(digest(preview.backend.path), preview.backend.sha256);
    for (const member of manifest.members) {
      const path = join(preview.root, member.path);
      assert.equal(statSync(path).size, member.bytes, member.path);
      assert.equal(digest(path), member.sha256, member.path);
    }
    await Promise.all(sampled.map(member => served(preview, member)));
  }
  await exactBytes();

  const smokePath = join(checkout, scope, 'smoke-' + audience + '.json');
  const smokeFolder = previous ? join(folder, '..', readJson(join(previous, 'result-' + audience + '.json')).httpFolder) : folder;
  const smokeLog = join(smokeFolder, audience + '-http.log');
  if (!previous) {
    assert(!existsSync(smokePath));
    assert.equal(await runChild(['tools/smoke-client-review.mts', audience, scope], smokeLog, 95000), 0, smokeLog);
  }
  const smoke = readJson(smokePath);
  assert(smoke.passed && smoke.probeRoomsClosed && smoke.health.startedAt === startup.startedAt && smoke.sourceCommit === commit);
  let earlier;
  if (previous) {
    earlier = readJson(join(previous, 'result-' + audience + '.json'));
    assert(earlier.sourceCommit === commit && earlier.backendStartedAt === startup.startedAt && earlier.worker.sha256 === worker.sha256);
    assert.equal(digest(smokeLog), earlier.httpLogSha256);
    assert.equal(digest(smokePath), earlier.httpSha256);
  }

  async function native(transport, fitting) {
    const stem = [audience, transport, fitting].join('-');
    const latest = earlier?.cases.find(caseResult => caseResult.transport === transport && caseResult.fitting === fitting && caseResult.passed);
    const expected = { transport, fitting, revision, worker: worker.sha256, driver: currentDriver, difficulty };
    if (latest) {
      const earlierPath = join(folder, '..', latest.folder, latest.raw);
      assert.equal(digest(earlierPath), latest.resultSha256);
      assert.equal(digest(join(folder, '..', latest.folder, latest.log)), latest.logSha256);
      const raw = readJson(earlierPath);
      assert(['normal', 'baby'].includes(raw.difficulty));
      verifyNative(raw, { ...expected, difficulty:raw.difficulty });
      return latest;
    }
    const raw = join(folder, stem + '.json'), log = join(folder, stem + '.log');
    const before = await health(preview);
    assert.equal(before.startedAt, startup.startedAt);
    const target = transport === 'worker' ? workerPath : preview.endpoint;
    const status = await runChild([currentDriver, transport, fitting, raw, target, audience, difficulty], log, 300000);
    const after = await health(preview);
    assert.equal(after.startedAt, before.startedAt);
    const response = existsSync(raw) ? readJson(raw) : undefined;
    let error;
    if (status === 0) {
      try {
        assert.equal(response.audience, audience);
        verifyNative(response, expected);
      } catch (failure) { error = String(failure); }
    }
    const result = { fitting, transport, status, difficulty, passed: status === 0 && !error && response?.passed === true, error,
      folder: basename(folder), log: basename(log), logSha256: digest(log), raw: response && basename(raw),
      resultSha256: response && digest(raw), caught: response?.result.caught, backendStartedAt: after.startedAt };
    console.log(JSON.stringify({ audience, ...result }));
    return result;
  }
  const lanes = await Promise.all(['worker','peer'].map(async transport => {
    const results = [];
    for (const fitting of ['entry','walking','turn']) results.push(await native(transport, fitting));
    return results;
  }));
  const cases = lanes.flat();
  const deadline = Date.now() + 15000;
  let metrics;
  do {
    metrics = await (await reply(preview.endpoint + '/api/metrics')).json();
    if (!metrics.rooms && !metrics.connections) break;
    await sleep(100);
  } while (Date.now() < deadline);
  await exactBytes();
  assert.equal((await health(preview)).startedAt, startup.startedAt);
  const passed = cases.length === 6 && cases.every(row => row.passed) && metrics.rooms === 0 && metrics.connections === 0;
  const report = { passed, audience, sourceCommit: commit, contentRevision: revision, protocol: proof.protocol,
    url: preview.url, endpoint: preview.endpoint, files: preview.files, manifestSha256: preview.manifestSha256,
    backendSha256: preview.backend.sha256, backendStartedAt: startup.startedAt, worker, sampledAssets: arts.length,
    sampledHttpMembers: sampled.length, fullManifestFilesVerifiedBeforeAndAfter: manifest.members.length,
    httpSha256: digest(smokePath), httpLogSha256: digest(smokeLog), httpFolder: basename(smokeFolder),
    cases, caseCount: cases.length + 1, remainingProbeRooms: metrics.rooms, remainingProbeConnections: metrics.connections };
  receipt(join(folder, 'result-' + audience + '.json'), report);
  return report;
}

const outcomes = await Promise.allSettled(['testing', 'public'].map(review));
const passed = outcomes.every(outcome => outcome.status === 'fulfilled' && outcome.value.passed);
const result = { passed, sourceCommit: commit, contentRevision: revision, protocol: proof.protocol,
  checkedAt: new Date().toISOString(), nativeDriverSha256: digest(currentDriver),
  audiences: outcomes.map(outcome => outcome.status === 'fulfilled' ? outcome.value : { passed: false, error: String(outcome.reason) }) };
receipt(join(folder, 'frozen-verification.json'), result);
console.log(JSON.stringify({ passed, audiences: result.audiences.map(({ audience, passed, error, cases }) => ({ audience, passed, error, cases: cases?.length })) }));
if (!passed) process.exitCode = 1;
