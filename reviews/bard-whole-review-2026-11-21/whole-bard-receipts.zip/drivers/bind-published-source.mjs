import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readdirSync, readFileSync, writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { dirname, join, relative } from 'node:path';
import { checkout, readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const here = path => new URL('./' + path, import.meta.url);
const [name] = process.argv.slice(2);
assert(/^checkout\d\d$/.test(name));
const expected = readJson(here('game01.json'));
const source = readJson(here('../bard-misdirection/source-commit01.json'));
const summary = readJson(here('whole-summary01.json'));
assert(summary.passed && summary.protocol === 95 && summary.cases === 96 && summary.replays === 12);
assert(source.passed && source.protocol === 95 && source.checks === 7 && source.tests === 2870);
assert.equal(summary.revision, source.contentRevision);
assert.equal(sha256(readFileSync(here('game01.mjs'))), expected.bundle);
assert.equal(summary.bundle, expected.bundle);

const fileBytes = path => readFileSync(join(checkout, path));
const tree = directory => readdirSync(join(checkout, directory), { withFileTypes: true })
  .flatMap(entry => {
    assert(!entry.isSymbolicLink());
    const path = directory + '/' + entry.name;
    return entry.isDirectory() ? tree(path) : [path];
  });
function fingerprint(paths) {
  const digest = createHash('sha256');
  for (const path of paths.sort()) digest.update(path + '\0').update(fileBytes(path));
  return digest.digest('hex');
}
const runtime = tree('src');
assert.equal(fingerprint([...runtime]), source.runtimeSourceSha256);
assert.equal(fingerprint([...runtime, ...tree('tests'), 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml',
  'tsconfig.json', 'vite.config.ts', 'index.html']), source.sourceSnapshotSha256);
for (const [path, expectedHash] of Object.entries(expected.inputs)) assert.equal(sha256(fileBytes(path)), expectedHash, path);

const entries = [
  "export { Game, data } from './src/shared/game.ts';",
  "export { misdirectionIds, misdirectionRules } from './src/shared/bard-misdirection.ts';",
  "export { conductorIds, conductorRules } from './src/shared/bard-kit.ts';",
  "export { lamentIds, lamentRules } from './src/shared/bard-lament.ts';",
  "export { HZ, idleInput, PROTOCOL, CONTENT_REVISION } from './src/shared/protocol.ts';",
  "export { viewOf } from './src/shared/view.ts';",
  "export { distance, segmentRect, segmentCircle } from './src/shared/geometry.ts';",
  "export { restRaidInput } from './tests/helpers/sniper-rest-raid-policy.ts';",
  "export { clearTrialWalk } from './tests/helpers/tank-bulwark-staging.ts';",
];
const inputs = new Map();
const { build } = createRequire(join(checkout, 'package.json'))('esbuild');
const result = await build({
  absWorkingDir: checkout,
  stdin: { contents: entries.join('\n'), loader: 'ts', resolveDir: checkout },
  bundle: true, write: false, format: 'esm', platform: 'node', target: 'node24', logLevel: 'silent',
  plugins: [{ name: 'exact-whole-bard', setup(builder) {
    builder.onLoad({ filter: /\.(?:ts|json)$/ }, ({path}) => {
      const member = relative(checkout, path).replaceAll('\\','/');
      if (!Object.hasOwn(expected.inputs, member)) return;
      const contents = fileBytes(member).toString('utf8');
      inputs.set(member, sha256(contents));
      return { contents, loader: member.endsWith('.json') ? 'json' : 'ts', resolveDir: dirname(path) };
    });
  } }],
});
const bytes = result.outputFiles[0].contents;
const bundle = sha256(bytes);
assert.deepEqual(Object.fromEntries(inputs), expected.inputs);
assert.equal(bundle, expected.bundle);
writeFileSync(here(name+'.mjs'), bytes, {flag:'wx'});
receipt(here(name+'.json'), {passed:true, checkoutExact:true, bundle, inputs:Object.fromEntries(inputs)});
receipt(here('whole-runtime01.json'), {passed:true, sourceCommit:source.sourceCommit, protocol:source.protocol,
  contentRevision:source.contentRevision, runtimeSourceSha256:source.runtimeSourceSha256, sourceSnapshotSha256:source.sourceSnapshotSha256,
  studyBundleSha256:expected.bundle, rebuiltBundleSha256:bundle, inputPaths:Object.keys(expected.inputs),
  previousRuntimeBinding:sha256(readFileSync(here('game01.json'))), rebuiltRuntimeBinding:sha256(readFileSync(here(name+'.json'))),
  rebuilt:name+'.json', comparisonCases:summary.cases, exactReplays:summary.replays});
console.log(JSON.stringify({passed:true, source:source.sourceCommit, bundle, inputs:inputs.size}));
