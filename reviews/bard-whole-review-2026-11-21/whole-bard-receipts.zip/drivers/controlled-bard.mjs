import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';

const [out, bundleName='game01']=process.argv.slice(2);
assert(out&&/^game\d\d$/.test(bundleName));
const here=path=>new URL('./'+path,import.meta.url);
const built=readJson(here(bundleName+'.json'));
const api=await verifiedBundle(fileURLToPath(here(bundleName+'.mjs')),built.bundle);
const {Game,PROTOCOL,CONTENT_REVISION,idleInput,distance,conductorIds,lamentIds,misdirectionIds}=api;
assert.equal(PROTOCOL,95);
const orientation=(from,to)=>Math.atan2(to.y-from.y,to.x-from.x);
const at=body=>({x:body.x,y:body.y});

function prove(fittings,party){
  const game=new Game({mode:'endless',seed:41,difficulty:'normal',arenaSelection:'fixed',openingArenaId:'gatehouse',maxPlayers:party?2:1});
  game.encounter=9;
  const bard=game.addPlayer('solo','Iven','bard'), ally=party&&game.addPlayer('ally','Lane','soldier');
  assert.equal(bard.totalSp,27);
  const purchased=['bard-performance-1',conductorIds.entry,conductorIds[fittings[0]],'bard-notecraft-1',lamentIds.entry,lamentIds[fittings[1]],
    'bard-company-1',misdirectionIds.entry,misdirectionIds[fittings[2]]];
  for(const item of purchased)assert(game.transact(bard.id,{kind:'skill',item,id:item}).ok,item);
  assert.equal(purchased.reduce((n,id)=>n+game.skillCost(id),0),15);
  assert(game.start());
  const flat=structuredClone(game.arena);
  flat.obstacles=[];flat.lavaPits=[];
  Object.defineProperty(game,'arena',{get:()=>flat});
  Object.assign(bard,{x:500,y:500});
  if(ally)Object.assign(ally,{x:1140,y:680});
  Object.assign(game.boss,{x:1320,y:720,staggerUntil:9000,deadline:9000});
  function spawn(id,x,y,speed,damage){
    const target=game.minions.spawn(id,{kind:'ordinary',x,y,health:2800,speed,damage,radius:15},game.combatTick);
    assert(target);return target;
  }
  const noteTarget=spawn(990001,785,500,0,0), events=[];
  function tick(input={}){
    assert(game.submitInput(bard.id,{...idleInput(),aim:0,sequence:bard.ack+1,clientTick:game.combatTick,...input}));
    game.step();
    const cues=game.drainEvents().filter(event=>event.type==='sound'&&event.owner===bard.id).map(event=>event.id);
    events.push(...cues.map(id=>({id,at:game.combatTick})));
    return cues;
  }
  const kit=()=>game.kitStatus(bard.id);
  const active=(kind)=>game.classCues().find(cue=>cue.kind===kind&&cue.owner===bard.id);
  const paid=[];
  for(let i=0;i<85&&kit().cadence<3;i++)tick({fire:true});
  assert.equal(kit().cadence,3);
  for(let i=0;i<16;i++)tick();
  const baseline={q:bard.qAt,e:bard.eAt,u:bard.ultimateAt};
  assert(tick({technique3:true}).includes('bard-entrance-set'));
  const first=active('bard-false-entrance');
  assert(first&&!first.armed&&kit().cadence===1);
  paid.push({technique:'entrance',id:first.id,cadence:kit().cadence,q:bard.qAt,e:bard.eAt,u:bard.ultimateAt});
  const pursuer=spawn(990002,746,558,81,12);
  for(let i=0;i<25&&!(kit().misdirecting?.target===pursuer.id&&kit().cadence>=2);i++){
    tick({moveX:kit().misdirecting?.phase==='walk'?-1:0,fire:true,aim:orientation(bard,noteTarget)});
  }
  assert.equal(kit().misdirecting?.target,pursuer.id);
  assert(kit().cadence>=2);
  const call={...at(bard)};
  const qAt=bard.qAt;
  assert(tick({technique1:true,aim:-.48}).includes('bard-answer-call'));
  const stage=active('bard-response-stage'), occupied=active('bard-false-entrance');
  assert(stage&&occupied&&occupied.target===pursuer.id&&occupied.id===first.id);
  assert(bard.qAt>qAt&&kit().cadence===0);
  paid.push({technique:'call',id:stage.id,cadence:kit().cadence,q:bard.qAt,e:bard.eAt,u:bard.ultimateAt});
  const blocked=tick({technique2:true,aim:orientation(bard,noteTarget)});
  assert(!blocked.includes('bard-lament-start')&&bard.eAt===baseline.e);
  for(let i=0;i<29&&distance(bard,stage)>22;i++){
    const heading=orientation(bard,stage);
    tick({moveX:Math.cos(heading),moveY:Math.sin(heading),aim:heading});
  }
  assert(distance(bard,stage)<=22);
  for(let i=0;i<44&&!(kit().conducting?.phase==='answer'&&kit().cadence>=2);i++)tick({fire:true,aim:orientation(bard,noteTarget)});
  assert(kit().conducting?.phase==='answer'&&kit().cadence>=2);
  const answerEvents=tick({technique1:true,aim:fittings[0]==='reprise'?orientation(bard,call):orientation(call,stage)});
  assert(answerEvents.includes('bard-answer-release'));
  assert.equal(answerEvents.includes('bard-answer-reprise'),fittings[0]==='reprise');
  const final=game.classCues().find(cue=>cue.kind==='bard-phrase'&&cue.owner===bard.id&&cue.beat===1);
  assert(final&&distance(final,fittings[0]==='reprise'?call:stage)<.001);
  assert.equal(bard.qAt,paid[1].q);
  const aim=orientation(bard,noteTarget);
  assert(tick({technique2:true,fire:true,aim}).includes('bard-lament-start'));
  const lane=active('bard-lament-line');
  assert(lane&&bard.eAt>baseline.e&&bard.qAt===paid[1].q&&bard.ultimateAt===baseline.u);
  paid.push({technique:'measure',id:lane.id,cadence:kit().cadence,q:bard.qAt,e:bard.eAt,u:bard.ultimateAt});
  const ammo=bard.ammo;
  const before=noteTarget.health;
  for(let i=0;i<38&&!(kit().lamenting?.contacts>=2);i++)tick({aim,fire:true});
  assert.equal(kit().lamenting?.contacts,2);
  assert(noteTarget.health<before&&bard.ammo===ammo);
  if(fittings[1]==='closing')assert(tick({technique2:true,aim}).includes('bard-lament-chord'));
  else for(let i=0;i<68&&kit().lamenting?.phase==='sustain';i++)tick({aim,fire:true});
  assert.equal(kit().lamenting?.phase,'idle');
  assert.equal(bard.ultimateAt,baseline.u);
  return {passed:true,party,fittings,purchased,spent:15,total:27,baseline,paid,events,overlap:{entrance:occupied,call:stage},
    reply:final,pursuer:pursuer.id,owedMeasure:!blocked.includes('bard-lament-start'),primaryHeldDuringMeasure:true};
}
const fixtures=[prove(['side','cross','wrong'],false),prove(['reprise','closing','second'],true)];
receipt(out,{passed:true,stageOnly:true,protocol:PROTOCOL,revision:CONTENT_REVISION,bundle:built.bundle,fixtures});
console.log(JSON.stringify({passed:true,cases:fixtures.length,overlapped:fixtures.filter(row=>row.overlap).length}));
