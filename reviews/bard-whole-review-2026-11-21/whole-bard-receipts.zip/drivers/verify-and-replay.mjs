import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdirSync, readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const here=path=>new URL('./'+path,import.meta.url);
const compiled=readJson(here('game01.json'));
const revision=readJson(here('../bard-misdirection/content01.json')).revision;
const digest=path=>sha256(readFileSync(here(path)));
const exec=promisify(execFile);
const folder='replays01';
mkdirSync(here(folder+'/'));
assert.equal(digest('game01.mjs'),compiled.bundle);
const actionNames=['bard-answer-release','bard-lament-pulse','bard-entrance-take'];
const outcome = (cases,lateOnly=false) => {
  const events=cases.flatMap(row=>row.operations).filter(e=>!lateOnly||e.full);
  return Object.fromEntries([...new Set(events.map(event=>event.id))].sort().map(id=>[id,events.filter(event=>event.id===id).length]));
};
const studies=[], replays=[];
const load=path=>{
  const data=readJson(here(path));
  assert(data.stageOnly&&data.protocol===95&&data.revision===revision&&data.bundle===compiled.bundle);
  return data;
};
for(const cohort of ['solo','party']){
  const path='whole-'+cohort+'01.json', data=load(path);
  assert(data.cohort===cohort&&data.rows.length===48);
  const active=data.rows.filter(row=>row.policy==='active'), unused=data.rows.filter(row=>row.policy==='unused');
  assert.equal(active.length,24);assert.equal(unused.length,24);
  const arenas=[...new Set(data.rows.map(row=>row.arena))];
  assert.equal(arenas.length,3);
  for(const arena of arenas){
    const from=active.filter(row=>row.arena===arena), to=unused.filter(row=>row.arena===arena);
    assert.equal(from.length,8);assert.equal(to.length,8);
    for(const row of from){
      const control=to.find(other=>other.portfolio===row.portfolio);
      assert(control && !control.operations.length);
      assert.deepEqual(row.fittings,control.fittings);
      assert.deepEqual(row.purchases.map(p=>p.item),control.purchases.slice(0,row.purchases.length).map(p=>p.item));
      assert.equal(row.triple,actionNames.every(id=>row.operations.some(op=>op.id===id)));
      assert.equal(row.fittedTriple,actionNames.every(id=>row.operations.some(op=>op.id===id&&op.full)));
    }
    const best=from.sort((a,b)=>Number(b.triple)-Number(a.triple)||Number(!!b.full)-Number(!!a.full)||b.operations.length-a.operations.length)[0];
    const control=to.find(row=>row.portfolio===best.portfolio);
    await Promise.all([best,control].map(async row=>{
      const caseName=[cohort,arena,row.policy].join('-'), result=folder+'/'+caseName+'.json', log=folder+'/'+caseName+'.log';
      const replay=await exec(process.execPath,[fileURLToPath(here('whole-bard.mjs')),fileURLToPath(here(result)),cohort,'game01',
        [arena,row.fittings.join('+'),row.policy].join('/')],{cwd:fileURLToPath(here('')),windowsHide:true,timeout:185_000,maxBuffer:1024*1024});
      writeFileSync(here(log),replay.stdout,{flag:'wx'});
      const repeated=load(result);
      assert.equal(repeated.rows.length,1);
      assert.deepEqual(repeated.rows[0],row);
      replays.push({case:caseName,path:result,sha256:digest(result),log,logSha256:digest(log),trace:row.trace,policy:row.policy,arena});
    }));
  }
  const shape=rows=>({runs:rows.length,wins:rows.filter(row=>row.won).length,fitted:rows.filter(row=>row.full).length,
    allThree:rows.filter(row=>row.triple).length,allThreeAfterFitting:rows.filter(row=>row.fittedTriple).length,events:outcome(rows),lateEvents:outcome(rows,true)});
  studies.push({cohort,path,sha256:digest(path),active:shape(active),unused:shape(unused)});
}
replays.sort((a,b)=>a.case.localeCompare(b.case));
assert.equal(replays.length,12);
receipt(here(folder+'/summary.json'),{passed:true,replays,revision,bundle:compiled.bundle});

const support = readdirSync(here('')).filter(path=>/^(?:late|raid|cover)-(?:solo|party)-[a-z-]+\d\d\.json$/.test(path)).sort().map(path=>{
  const data=load(path);
  assert(data.rows.length===1&&['raid','endless'].includes(data.mode));
  const row=data.rows[0];
  if(data.mode==='raid'){
    assert.equal(row.purchases[6].spent,11);
    assert(row.purchases.slice(0,7).every(p=>p.earned===12&&p.clears===0));
    assert.equal(row.openingTriple,actionNames.every(id=>row.operations.some(op=>op.id===id&&op.encounter===0&&op.boss==='matron')));
  }
  return {path,sha256:digest(path),type:data.mode,cohort:data.cohort,arena:row.arena,clears:row.clears,full:!!row.full,
    triple:row.triple,fullTriple:row.fittedTriple,openingTriple:!!row.openingTriple,counts:outcome([row])};
});
const controlled=load('controlled02.json');
assert(controlled.passed&&controlled.fixtures.length===2&&controlled.fixtures.every(row=>row.spent===15&&row.total===27&&row.overlap&&row.owedMeasure&&row.primaryHeldDuringMeasure));
assert(support.some(row=>row.type==='raid'&&row.openingTriple));
const combined={
  activeWins:studies.reduce((n,row)=>n+row.active.wins,0),unusedWins:studies.reduce((n,row)=>n+row.unused.wins,0),
  activeFull:studies.reduce((n,row)=>n+row.active.fitted,0),unusedFull:studies.reduce((n,row)=>n+row.unused.fitted,0),
  allThree:studies.reduce((n,row)=>n+row.active.allThree,0),afterFitting:studies.reduce((n,row)=>n+row.active.allThreeAfterFitting,0),
};
receipt(here('whole-summary01.json'),{passed:true,stageOnly:true,protocol:95,revision,bundle:compiled.bundle,cases:96,replays:12,
  combined,studies,support,controls:{path:'controlled02.json',sha256:digest('controlled02.json'),cases:2},replaySha256:digest(folder+'/summary.json')});
console.log(JSON.stringify({passed:true,cases:96,replays:12,combined,support:support.length,raidOpeningTriples:support.filter(row=>row.openingTriple).length}));
