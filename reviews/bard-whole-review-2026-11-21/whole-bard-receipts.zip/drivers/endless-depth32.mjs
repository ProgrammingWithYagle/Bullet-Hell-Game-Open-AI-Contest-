import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { readJson, receipt, verifiedBundle } from '../bastion/study-paths.mjs';
import { explicitNavigation } from '../assassin-mark-hunter/native-writ-navigation.mjs';
import { conductorPilot } from '../bard-conductor/conductor-fittings-pilot.mjs';
import { lamentPilot } from '../bard-lament/lament-pilot.mjs';
import { misdirectionPilot } from '../bard-misdirection/misdirection-pilot.mjs';

const [output,cohort,bundleName='game01',sample] = process.argv.slice(2);
assert(output&&['solo','party'].includes(cohort)&&/^game\d\d$/.test(bundleName));
const here=path=>new URL('./'+path,import.meta.url);
const compiled=readJson(here(bundleName+'.json'));
const api=await verifiedBundle(fileURLToPath(here(bundleName+'.mjs')),compiled.bundle);
const {Game,data,HZ,idleInput,viewOf,CONTENT_REVISION,PROTOCOL,distance,segmentRect,segmentCircle,restRaidInput,
  conductorIds,conductorRules,lamentIds,lamentRules,misdirectionIds,misdirectionRules}=api;
assert.equal(PROTOCOL,95);
const worlds=[['gatehouse','baby',41],['sunken-chapel','baby',73],['ossuary-works','baby',109]];
const profiles=['side','reprise'].flatMap(conduct=>['cross','closing'].flatMap(lament=>['wrong','second'].map(ruse=>[conduct,lament,ruse])));
const routes=[
  {name:'conductor',root:'bard-performance-1',entry:conductorIds.entry,ids:conductorIds},
  {name:'lament',root:'bard-notecraft-1',entry:lamentIds.entry,ids:lamentIds},
  {name:'misdirection',root:'bard-company-1',entry:misdirectionIds.entry,ids:misdirectionIds},
];
const selected=sample?.split('/');
if(selected)assert(selected.length===3&&worlds.some(world=>world[0]===selected[0])&&profiles.some(profile=>profile.join('+')===selected[1])&&['active','unused'].includes(selected[2]));

function play([arena,difficulty,seed],fittings,policy,portfolio) {
  const game = new Game({mode:'endless',difficulty,seed,arenaSelection:'route',openingArenaId:arena,maxPlayers:cohort==='solo'?1:2});
  const bard=game.addPlayer('solo','Iven','bard'), ally=cohort==='party'?game.addPlayer('ally','Lane','soldier'):undefined;
  const actors=ally?[bard,ally]:[bard];
  const sequence=routes.map((_,i)=>(i+portfolio)%routes.length).flatMap(index=>{
    const route=routes[index];
    return [[route.root,route.entry],[route.ids[fittings[index]]]];
  });
  const trace=createHash('sha256'), hostileShots=new Map(), operations=[], purchases=[], planned=[];
  let acquired=0, serial=0, lastShop=-1, spent=0, rounds=0, full;
  const votes=[], recorded=new Set(), encounters=new Map();
  const supportsPursuit=new Set(['matron']);
  const complete=['bard-answer-release','bard-lament-pulse','bard-entrance-take'];
  const tripleAfterFittings=()=>complete.every(id=>operations.some(row=>row.id===id&&row.full));
  const buy=(actor,kind,item)=>game.transact(actor.id,{kind,item,id:'whole-bard-'+ ++serial});
  function choices(){
    let remaining=bard.totalSp-spent;
    while(sequence[acquired]){
      const next=sequence[acquired], price=next.reduce((n,id)=>n+game.skillCost(id),0);
      if(price>remaining)break;
      for(const item of next){
        assert(buy(bard,'skill',item).ok,JSON.stringify({item,arena,earned:bard.totalSp,clears:bard.progress.clears}));
        purchases.push({ item,earned:bard.totalSp,clears:bard.progress.clears,spent:spent+game.skillCost(item) });
        spent+=game.skillCost(item);
      }
      trace.update(JSON.stringify(purchases.slice(-next.length)));
      remaining-=price;acquired++;
      if(acquired===sequence.length)full={earned:bard.totalSp,clears:bard.progress.clears,spent};
    }
  }
  function gear(actor) {
    for(const item of data.weapons.filter(weapon=>weapon.classId===actor.classId).sort((a,b)=>b.tier-a.tier))
      if(actor.weapon===item.id||buy(actor,'weapon',item.id).ok)break;
    for(const item of ['damage','health','fire-rate','reload','magazine'])buy(actor,'upgrade',item);
    buy(actor,'supply','medkit');
  }
  assert.equal(bard.totalSp,3);
  choices();actors.forEach(gear);
  assert(game.start());

  function danger(view,at,horizon){
    if(view.minions.some(row=>row.health>0&&distance(row,at)<23+horizon))return true;
    if(view.fields.some(row=>row.kind==='zone'&&distance(row,at)<row.radius+9))return true;
    for(const shot of hostileShots.values()){
      const time=Math.min(horizon,shot.expires-view.combatTick);
      if(time<=0||distance(shot,at)>425)continue;
      const elapsed=Math.max(0,view.combatTick-shot.seenAt)/HZ;
      const from={x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed};
      const to={x:from.x+shot.vx*time/HZ,y:from.y+shot.vy*time/HZ};
      const hit=segmentCircle(from,to,at,shot.radius+data.rules.playerRadius+2);
      if(hit!==null&&!game.obstacles.some(wall=>(segmentRect(from,to,wall,shot.radius)?.t??Infinity)<=hit))return true;
    }
    return false;
  }
  const context={...api,game,danger};
  const navigate=explicitNavigation(context);
  const conduct=conductorPilot({...context,rules:conductorRules,fitting:fittings[0]});
  const lament=lamentPilot({...context,rules:lamentRules,policy:fittings[1]});
  const ruse=misdirectionPilot({...context,rules:misdirectionRules,policy:fittings[2]});
  const lastUsed={conductor:-999,lament:-999,misdirection:-999};
  function specialized(view,body,ordinary){
    const record=route=>request=>planned.push({route,...request});
    const kit=body.kit;
    if(kit.conducting?.phase==='listening'||kit.conducting?.phase==='answer')return conduct(view,body,ordinary,record('conductor'));
    if(kit.lamenting?.phase==='sustain')return lament(view,body,ordinary,record('lament'));
    if(kit.misdirecting&&kit.misdirecting.phase!=='idle')return ruse(view,body,ordinary,record('misdirection'));
    if(kit.misdirecting){
      const choice=ruse(view,body,ordinary,record('misdirection'));
      if(choice.technique3)return choice;
    }
    const use={conductor:()=>conduct(view,body,ordinary,record('conductor')),lament:()=>lament(view,body,ordinary,record('lament'))};
    for(const kind of ['conductor','lament'].sort((a,b)=>lastUsed[a]-lastUsed[b])){
      if(!(kind==='conductor'?kit.conducting:kit.lamenting))continue;
      const choice=use[kind]();
      if(choice.technique1||choice.technique2)return choice;
      if(kind==='conductor'&&kit.cadence<conductorRules.cadence&&body.qAt<=view.combatTick&&lastUsed.conductor+250<view.combatTick)
        ordinary=choice;
    }
    return ordinary;
  }
  while(!['victory','defeat'].includes(game.phase)&&rounds++<448000&&bard.progress.clears<32&&!tripleAfterFittings()){
    if(game.phase!=='combat'){
      hostileShots.clear();
      if(['mutationVote','contractVote','secretOffer'].includes(game.phase)) {
        const offered=game.phase==='contractVote'?game.contractCards.map(card=>card.bossId):[];
        const wanted=full?offered.findIndex(boss=>supportsPursuit.has(boss)):-1;
        const choice=wanted<0?0:wanted;
        const key=game.encounter+'/'+game.phase;
        if(!recorded.has(key)){
          recorded.add(key);
          const vote={encounter:game.encounter,phase:game.phase,offered,choice,full:!!full};
          votes.push(vote);trace.update(JSON.stringify(vote));
        }
        for(const actor of actors)game.vote(actor.id,choice);
      }
      if(game.phase==='shop'&&game.encounter!==lastShop){lastShop=game.encounter;choices();actors.forEach(gear);}
      game.step();game.drainEvents();continue;
    }
    const view=viewOf(game,bard.id);
    const encounter=encounters.get(game.encounter)??{index:game.encounter,boss:game.boss.id,full:!!full,ordinary:[]};
    for(const actor of view.minions)if(actor.kind==='ordinary'&&!encounter.ordinary.includes(actor.id))encounter.ordinary.push(actor.id);
    encounters.set(game.encounter,encounter);
    for(const actor of actors){
      const body=view.players.find(row=>row.id===actor.id);
      const ordinary=actor.status==='active'?navigate(view,body,restRaidInput(view,body,[...hostileShots.values()])):actor.status==='downed'?{interact:true}:{};
      const choice=policy==='active'&&actor===bard&&actor.status==='active'?specialized(view,body,ordinary):ordinary;
      const input={...idleInput(),...choice,sequence:actor.ack+1,clientTick:game.combatTick};
      input.aim=Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      assert(game.submitInput(actor.id,input));
    }
    game.step();
    for(const event of game.drainEvents()){
      if(event.type==='shots')for(const shot of event.shots)if(shot.owner==='hostile')hostileShots.set(shot.id,{...shot,seenAt:game.combatTick});
      if(event.type==='remove')for(const id of event.ids)hostileShots.delete(id);
      if(event.type!=='sound'||event.owner!==bard.id)continue;
      const route=event.id.startsWith('bard-answer-')?'conductor':event.id.startsWith('bard-lament-')?'lament':
        event.id.startsWith('bard-entrance-')?'misdirection':undefined;
      if(!route)continue;
      if(['bard-answer-call','bard-lament-start','bard-entrance-set'].includes(event.id))lastUsed[route]=game.combatTick;
      const effect={ route,id:event.id,tick:game.combatTick,boss:game.boss.id,full:!!full };
      operations.push(effect);trace.update(JSON.stringify(effect));
    }
    trace.update(JSON.stringify([game.phase,game.combatTick,game.boss.health,...actors.map(a=>[a.x,a.y,a.health,a.qAt,a.eAt,a.ultimateAt,a.ammo,a.damageDealt])]));
  }
  assert(['defeat','victory'].includes(game.phase)||bard.progress.clears>=32||tripleAfterFittings());
  if(full)assert.deepEqual(full,{earned:16,clears:5,spent:15});
  if(policy==='unused')assert.equal(operations.length,0);
  return {arena,difficulty,seed,fittings,policy,portfolio,won:game.phase==='victory',clears:bard.progress.clears,full,
    triple:complete.every(id=>operations.some(row=>row.id===id)),fittedTriple:complete.every(id=>operations.some(row=>row.id===id&&row.full)),
    stop:tripleAfterFittings()?'all three performed after fitting':game.phase,encounters:[...encounters.values()],votes,purchases,operations,planned,trace:trace.digest('hex')};
}

const rows=[];
for(const world of worlds){
  if(selected&&world[0]!==selected[0])continue;
  for(const [index,fittings] of profiles.entries()){
    if(selected&&fittings.join('+')!==selected[1])continue;
    for(const policy of selected?[selected[2]]:['active','unused']){
      const outcome=play(world,fittings,policy,index);
      rows.push(outcome);
      console.log(JSON.stringify({arena:world[0],fittings,policy,clears:outcome.clears,won:outcome.won,full:!!outcome.full,
        triple:outcome.triple,fittedTriple:outcome.fittedTriple,operations:outcome.operations.length}));
    }
  }
}
receipt(output,{stageOnly:true,protocol:PROTOCOL,revision:CONTENT_REVISION,bundle:compiled.bundle,mode:'endless',cohort,rows});
