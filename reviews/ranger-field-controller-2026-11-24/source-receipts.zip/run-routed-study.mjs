import assert from 'node:assert/strict';
import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

const folder=process.argv[2];
assert(folder);
mkdirSync(folder);
const driver=fileURLToPath(new URL('./routed-seeded-study.mts',import.meta.url));
const policy=fileURLToPath(new URL('./field-policy.mjs',import.meta.url));
const navigationSha256=digest(new URL('./study-navigation.mjs',import.meta.url));
const results=[];
for(const mode of ['short','standard'])for(const party of ['solo','pair']) {
  const key=mode+'-'+party;
  const raw=join(folder,key+'.json'), replay=join(folder,key+'-replay.json');
  const log=join(folder,key+'.log'), replayLog=join(folder,key+'-replay.log');
  assert.equal(await runChild([driver,mode,party,raw],log,260000),0,log);
  assert.equal(await runChild([driver,mode,party,replay,'replay'],replayLog,180000),0,replayLog);
  const full=readJson(raw),check=readJson(replay);
  assert.equal(full.protocol,104);
  assert.equal(full.rows.length,18);
  assert.equal(check.rows.length,3);
  for(const edition of [full,check]) {
    assert.equal(edition.runtimeSourceSha256,full.runtimeSourceSha256);
    assert.equal(edition.revision,full.revision);
    assert.equal(edition.driverSha256,digest(driver));
    assert.equal(edition.policySha256,digest(policy));
    assert(edition.routed);
    assert.equal(edition.navigationSha256,navigationSha256);
  }
  for(const row of full.rows.filter(row=>row.active)) {
    const paired=full.rows.find(candidate=>!candidate.active&&candidate.arena===row.arena&&candidate.fitting===row.fitting);
    assert(paired&&paired.events.length===0&&paired.contacts.length===0 && paired.replants===0);
    assert.deepEqual(paired.purchases,row.purchases);
  }
  for(const row of check.rows)assert.deepEqual(row,full.rows.find(candidate=>candidate.active&&candidate.arena===row.arena&&candidate.fitting===row.fitting));
  const cases=['entry','pivot','short'].map(fitting=>{
    const rows=full.rows.filter(row=>row.fitting===fitting);
    return { fitting,unusedWins:rows.filter(row=>!row.active&&row.won).length,activeWins:rows.filter(row=>row.active&&row.won).length,
      ownershipReached:rows.filter(row=>row.active&&row.acquired).length,lifts:rows.reduce((sum,row)=>sum+row.lifts,0),
      replants:rows.reduce((sum,row)=>sum+row.replants,0),
      movedCableContacts:rows.flatMap(row=>row.contacts).reduce((sum,event)=>sum+event.count,0) };
  });
  const summary={mode,party,runs:18,exactReplays:3,revision:full.revision,runtimeSourceSha256:full.runtimeSourceSha256,cases,
    files:[raw,replay,log,replayLog].map(path=>({file:path.split(/[\\/]/).at(-1),sha256:digest(path)}))};
  results.push(summary);
  console.log(JSON.stringify(summary));
}
const rows=results.flatMap(lane=>lane.cases);
const total=field=>rows.reduce((sum,row)=>sum+row[field],0);
const summary={passed:true,routed:true,navigationSha256,matches:72,pairedComparisons:36,exactReplays:12,lifts:total('lifts'),replants:total('replants'),
  movedCableContacts:total('movedCableContacts'),driverSha256:digest(driver),policySha256:digest(policy),results};
assert(summary.lifts>0 && summary.replants>0 && summary.movedCableContacts>0);
receipt(join(folder,'study-summary.json'),summary);
