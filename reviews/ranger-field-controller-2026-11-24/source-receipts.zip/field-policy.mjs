import { standing } from '../formation/formation-policy.mjs';

const range=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
const heading=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
const offset=(p,aim,d)=>({x:p.x+Math.cos(aim)*d,y:p.y+Math.sin(aim)*d});
function walk(a,b) {
  const angle=heading(a,b);
  return {moveX:Math.cos(angle),moveY:Math.sin(angle)};
}
const normalize=angle=>Math.atan2(Math.sin(angle),Math.cos(angle));

export function fieldPolicy({ordinary,arenaFor,segmentRect,segmentCircle}) {
  const clear=(world,from,to,margin)=>!world.obstacles.some(wall=>segmentRect(from,to,wall,margin)!==null);
  function path(world,from,to) {
    const {x,y,width,height}=world.bounds;
    return to.x>=x+18 && to.y>=y+18 && to.x<=x+width-18 && to.y<=y+height-18 && clear(world,from,to,12) &&
      !world.lavaPits.some(pit=>segmentCircle(from,to,pit,pit.radius+12)!==null);
  }
  return (view,p,shots,enabled)=>{
    const base=ordinary(view,p,shots);
    if (!enabled || base.dodge || (base.supply??-1)>=0) return base;
    const field=p.kit.rangerField;
    if (!field) return base;
    const boss=view.boss, aim=heading(p,boss), distance=range(p,boss), now=view.combatTick;
    const world=arenaFor(view.arenaId,view.run.difficulty);
    const quiet={...standing(base),aim};
    if (field.until>now) {
      const guide=field.placement;
      if (guide && (segmentCircle(guide.start,guide.end,boss,26)!==null || field.until-now<=12)) return {...quiet,technique3:true};
      const pin=field.anchor;
      const aimPoint=pin ? offset(pin,heading(pin,boss),Math.min(143,Math.max(47,range(pin,boss)+8))) :
        offset(boss,heading(boss,p),field.fitting==='short'?94:129);
      return path(world,p,aimPoint) && range(p,aimPoint)>6?{...quiet,...walk(p,aimPoint)}:{...quiet,moveX:base.moveX,moveY:base.moveY};
    }
    if (field.stage==='ready' && p.ammo>1 && distance<195 && distance>70 && clear(world,p,boss,4)) {
      return {...quiet,technique3:true};
    }
    const own=view.classCues.some(cue=>cue.kind==='ranger-trap' && cue.owner===p.id);
    if (!own && p.eAt<=now && p.ammo>=2 && distance>=76 && distance<=420 && clear(world,p,boss,4)) {
      if (field.stage==='find' && distance<193) {
        const angles=field.fitting==='pivot'?[aim,aim-.16,aim+.16]:[aim+Math.PI/2,aim-Math.PI/2,aim+.74,aim-.74];
        const valid=angles.find(angle=>path(world,p,offset(p,angle,89)));
        if (valid!==undefined) return {...quiet,aim:normalize(valid),e:true};
      }
      if (['find','busy'].includes(field.stage)) {
        const goal=offset(boss,heading(boss,p),145);
        if (path(world,p,goal)) return range(p,goal)>7?{...quiet,...walk(p,goal)}:quiet;
      }
    }
    return base;
  };
}
