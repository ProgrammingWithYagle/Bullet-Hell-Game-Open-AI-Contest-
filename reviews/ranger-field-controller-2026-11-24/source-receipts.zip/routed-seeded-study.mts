import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { checkout, receipt, repoImport, sha256 } from '../bonded/study-paths.mjs';
import { fieldPolicy } from './field-policy.mjs';
import { navigationPolicy } from './study-navigation.mjs';

const { Game, data }=await repoImport('src/shared/game.ts');
const { viewOf }=await repoImport('src/shared/view.ts');
const { PROTOCOL, CONTENT_REVISION, idleInput }=await repoImport('src/shared/protocol.ts');
const { rangerFieldIds }=await repoImport('src/shared/ranger-field.ts');
const { runtimeArena }=await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle }=await repoImport('src/shared/geometry.ts');
const { restRaidInput }=await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const [mode,party,output,replay]=process.argv.slice(2);
assert(PROTOCOL===104 && ['short','standard'].includes(mode) && ['solo','pair'].includes(party) && output);
const archetypes=['entry','pivot','short'] as const;
const worlds=[['gatehouse',41],['sunken-chapel',67],['ossuary-works',103]] as const;
const choose=fieldPolicy({ordinary:restRaidInput,arenaFor:runtimeArena,segmentRect,segmentCircle});

function simulate(arena,seed,fitting,active) {
  const game=new Game({mode,difficulty:'normal',seed,openingArenaId:arena,arenaSelection:'fixed',maxPlayers:party==='solo'?1:2});
  const owner=game.addPlayer('nela','Nela','ranger');
  const partyMembers=party==='solo'?[owner]:[owner,game.addPlayer('mara','Mara','soldier')];
  const navigationOptions={arenaFor:runtimeArena,segmentRect,segmentCircle,playerRadius:data.rules.playerRadius};
  const routeOwner=navigationPolicy({...navigationOptions,ordinary:choose});
  const routeAlly=navigationPolicy({...navigationOptions,ordinary:restRaidInput});
  const observed=new Map(), replanted=new Set(), contacts=[];
  const purchases=[], events=[];
  const trace=createHash('sha256');
  let serial=0, shop=-1, frames=0;
  function buy(actor,kind,item) {
    const result=game.transact(actor.id,{id:'field-study-'+ ++serial,kind,item});
    if(result.ok)purchases.push({owner:actor.id,kind,item,earned:actor.totalSp,clears:actor.progress.clears});
    return result.ok;
  }
  function outfit(actor) {
    for(const weapon of data.weapons.filter(w=>w.classId===actor.classId).sort((a,b)=>b.tier-a.tier)) {
      if(actor.weapon===weapon.id || buy(actor,'weapon',weapon.id))break;
    }
    for(const item of ['damage','health','fire-rate','reload','magazine'])buy(actor,'upgrade',item);
    buy(actor,'supply','medkit');
  }
  assert.equal(owner.totalSp,3);
  assert(buy(owner,'skill','ranger-fieldcraft-1') && buy(owner,'skill',rangerFieldIds.entry));
  if(fitting!=='entry')assert(!buy(owner,'skill',rangerFieldIds[fitting]));
  partyMembers.forEach(outfit);
  assert(game.start());

  while(!['victory','defeat'].includes(game.phase) && frames++<90000) {
    if(game.phase!=='combat') {
      observed.clear();
      if(['mutationVote','contractVote','secretOffer'].includes(game.phase))for(const p of partyMembers)game.vote(p.id,0);
      if(game.phase==='shop' && game.encounter!==shop) {
        shop=game.encounter;
        if(fitting!=='entry' && owner.totalSp>=5 && !owner.skills.includes(rangerFieldIds[fitting])) {
          assert(buy(owner,'skill',rangerFieldIds[fitting]));
          assert(owner.progress.clears>=1);
        }
      }
      game.step();game.drainEvents();continue;
    }
    const view=viewOf(game,owner.id), hostile=[...observed.values()];
    const fitted=owner.skills.includes(rangerFieldIds[fitting]);
    const enabled=active&&fitted;
    for(const actor of partyMembers) {
      const p=view.players.find(row=>row.id===actor.id);
      assert(p);
      const carrying=(p.kit.rangerField?.until??0)>view.combatTick;
      const control=actor.status!=='active'?{interact:true}:actor!==owner?routeAlly(view,p,hostile):
        carrying?choose(view,p,hostile,enabled):routeOwner(view,p,hostile,enabled);
      const input={...idleInput(),...control,sequence:actor.ack+1,clientTick:game.combatTick};
      input.aim=Math.atan2(Math.sin(input.aim),Math.cos(input.aim));
      trace.update(JSON.stringify(input));
      assert(game.submitInput(actor.id,input));
    }
    const before=[...game.ranger.traps.values()].filter(trap=>trap.owner===owner.id)
      .map(trap=>({trap,wasLifted:game.ranger.field.lifted(trap),touched:trap.touched.size,touchSet:trap.touched,
        placedAt:trap.placedAt,until:trap.until,remaining:trap.remaining}));
    game.step();
    const batch=game.drainEvents();
    if (batch.some(event=>event.type==='sound'&&event.owner===owner.id&&event.id==='ranger-cable-set')) {
      const moved=before.find(row=>row.wasLifted&&!game.ranger.field.lifted(row.trap));
      assert(moved && moved.placedAt===moved.trap.placedAt && moved.until===moved.trap.until &&
        moved.remaining===moved.trap.remaining && moved.touchSet===moved.trap.touched);
      replanted.add(moved.trap.id);
    }
    for (const row of before) if (replanted.has(row.trap.id) && row.trap.touched.size>row.touched) {
      contacts.push({id:row.trap.id,tick:game.combatTick,count:row.trap.touched.size-row.touched});
    }
    for(const event of batch) {
      if(event.type==='shots')for(const shot of event.shots) {
        if(shot.owner==='hostile')observed.set(shot.id,{...shot,seenAt:game.combatTick});
      }
      if(event.type==='remove')for(const id of event.ids)observed.delete(id);
      if(event.type==='sound'&&event.owner===owner.id&&event.id.startsWith('ranger-cable-')) {
        assert(enabled);
        events.push({id:event.id,tick:game.combatTick,boss:view.boss.id,clears:owner.progress.clears});
      }
    }
    trace.update(JSON.stringify([game.combatTick,game.boss.health,owner.x,owner.y,owner.health,owner.ammo,owner.damageDealt,game.kitStatus(owner.id).rangerField]));
  }
  assert(['defeat','victory'].includes(game.phase));
  const lifts=events.filter(event=>event.id==='ranger-cable-lift').length;
  const replants=events.filter(event=>event.id==='ranger-cable-set').length;
  assert(replants<=lifts && replanted.size<=replants);
  return { arena,seed,fitting,active,won:game.phase==='victory',clears:owner.progress.clears,acquired:owner.skills.includes(rangerFieldIds[fitting]),
    purchases,events,lifts,replants,contacts,trace:trace.digest('hex') };
}

const rows=[];
for(const [index,[arena,seed]] of worlds.entries())for(const [kind,fitting] of archetypes.entries())for(const active of [false,true]) {
  if(replay&&(!active||index!==kind))continue;
  const row=simulate(arena,seed,fitting,active);
  rows.push(row);
  console.log(JSON.stringify({arena,fitting,active,won:row.won,clears:row.clears,lifts:row.lifts,replants:row.replants,contacts:row.contacts.length}));
}
assert.equal(rows.length,replay?3:18);
function sourceFiles(dir) {
  return readdirSync(join(checkout,dir),{withFileTypes:true}).flatMap(row=>{
    const path=dir+'/'+row.name;
    return row.isDirectory()?sourceFiles(path):[path];
  });
}
const hash=createHash('sha256');
for(const path of sourceFiles('src').sort())hash.update(path+'\0').update(readFileSync(join(checkout,path)));
receipt(output,{routed:true,protocol:PROTOCOL,revision:CONTENT_REVISION,runtimeSourceSha256:hash.digest('hex'),mode,party,replay:!!replay,
  driverSha256:sha256(readFileSync(new URL(import.meta.url))),policySha256:sha256(readFileSync(new URL('./field-policy.mjs',import.meta.url))),
  navigationSha256:sha256(readFileSync(new URL('./study-navigation.mjs',import.meta.url))),rows});
