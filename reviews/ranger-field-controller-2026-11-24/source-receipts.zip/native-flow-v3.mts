import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { repoImport } from '../bonded/study-paths.mjs';
import { waitFor } from '../formation/native-flow-v4.mts';
import { standing } from '../formation/formation-policy.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { rangerFieldIds } = await repoImport('src/shared/ranger-field.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
export { waitFor };
const distance = (a,b) => Math.hypot(b.x-a.x,b.y-a.y);
const heading = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const offset = (point,angle,length) => ({x:point.x+Math.cos(angle)*length,y:point.y+Math.sin(angle)*length});
function walk(from,to) {
  const aim=heading(from,to);
  return {moveX:Math.cos(aim),moveY:Math.sin(aim)};
}
function clear(world,from,to,pad=4) {
  return !world.obstacles.some(wall=>segmentRect(from,to,wall,pad)!==null);
}
function route(world,from,point) {
  const {x,y,width,height}=world.bounds;
  return point.x>=x+20 && point.y>=y+20 && point.x<=x+width-20 && point.y<=y+height-20 &&
    clear(world,from,point,19) && !world.lavaPits.some(pit=>segmentCircle(from,point,pit,pit.radius+19)!==null);
}

export async function fieldFlow(adapter,fitting) {
  const view = () => { const current=adapter.view(); assert(current); return current; };
  const owner = () => { const actor=view().players.find(row=>row.id===adapter.id); assert(actor); return actor; };
  const status = () => owner().kit.rangerField;
  const effort = () => restRaidInput(view(),owner(),[...adapter.observed.values()]);
  const ownedCost = () => owner().skills.reduce((sum,id)=>sum+[...data.skills,...data.specializationSkills].find(node=>node.id===id).cost,0);
  const purchases=[], attempts=[];
  const diagnose=()=>JSON.stringify({fitting,boss:view().boss.id,phase:view().phase,tick:view().combatTick,
    player:{x:owner().x,y:owner().y,ammo:owner().ammo,health:owner().health},status:status(),attempts:attempts.slice(-4)});
  async function buy(item) {
    assert((await adapter.purchase({kind:'skill',item})).ok,item);
    purchases.push({item,earned:ownedCost()+owner().sp,clears:owner().progress.clears});
  }
  async function outfit() {
    for (const bow of data.weapons.filter(row=>row.classId==='ranger').sort((a,b)=>b.tier-a.tier)) {
      if (owner().weapon===bow.id || (await adapter.purchase({kind:'weapon',item:bow.id})).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({kind:'upgrade',item});
    await adapter.purchase({kind:'supply',item:'medkit'});
  }
  assert.equal(owner().sp,3);
  await buy('ranger-fieldcraft-1');
  await buy(rangerFieldIds.entry);
  await waitFor(()=>!!status(),'owner receives Field Controller action');
  if (fitting!=='entry') assert(!(await adapter.purchase({kind:'skill',item:rangerFieldIds[fitting]})).ok);
  await outfit();
  adapter.start();
  await waitFor(()=>view().phase==='combat','Field Controller opening combat');
  if (fitting!=='entry') {
    const deadline=Date.now()+135000;
    while (view().phase!=='shop') {
      assert(Date.now()<deadline && !['victory','defeat'].includes(view().phase),diagnose());
      if (view().phase==='combat') { adapter.input(effort()); adapter.ally?.(true); }
      if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(ownedCost()+owner().sp,5);
    await buy(rangerFieldIds[fitting]);
    assert.equal((await adapter.purchase({kind:'skill',item:rangerFieldIds[fitting==='pivot'?'short':'pivot']})).reason,'incompatibleItem');
    await outfit();
    await waitFor(()=>view().phase==='combat','fitted Field Controller combat',90000);
  }
  const firstClear=owner().progress.clears;
  console.log(JSON.stringify({type:'earned Field Controller purchase',fitting,firstClear,purchases,boss:view().boss.id}));

  adapter.pause(true);
  await waitFor(()=>adapter.paused(),'pause acknowledged');
  const pausedAt=view().combatTick, pausedAmmo=owner().ammo;
  adapter.input({technique3:true});
  await sleep(120);
  assert.equal(view().combatTick,pausedAt);
  assert.equal(owner().ammo,pausedAmmo);
  assert(!status()?.until);
  adapter.input({});
  adapter.pause(false);
  await waitFor(()=>!adapter.paused() && view().combatTick>pausedAt,'Field Controller resumed');

  const deadline=Date.now()+117000;
  const cable=()=>view().classCues.find(row=>row.kind==='ranger-trap' && row.owner===adapter.id);
  let trial,witness;
  const acknowledged=async input=>{
    const sequence=adapter.input(input);
    await waitFor(()=>owner().ack>=sequence || view().phase!=='combat',diagnose);
  };
  while (Date.now()<deadline && !['victory','defeat'].includes(view().phase)) {
    if (view().phase!=='combat') {
      if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(40);
      continue;
    }
    const p=owner(), now=view().combatTick, state=status(), enemy=view().boss;
    const world=runtimeArena(view().arenaId,view().run.difficulty);
    const aim=heading(p,enemy), base=effort(), quiet={...standing(base),aim};
    const sight=distance(p,enemy);
    if (trial?.moved) {
      if (adapter.events.slice(trial.replantEvents).some(event=>event.type==='sound' && event.owner===adapter.id && event.id==='ranger-trip')) {
        const current=trial.moved, old=trial.original;
        assert.equal(current.id,old.id);
        assert.equal(current.until,old.until);
        assert.equal(current.remaining,old.remaining);
        return {passed:true,fitting,firstClear,bought:purchases,boss:enemy.id,pauseRejected:true,attempts,witness,
          result:{hit:true,arrowCost:1,old,current,damageEvent:'ranger-trip',differentEndpoints:true}};
      }
      if (now<trial.moved.at+45 && cable()) {
        adapter.input(quiet);adapter.ally?.(false);await sleep(24);continue;
      }
      attempts.push({reason:'replanted cable did not hit',at:trial.moved.at,from:trial.moved.x,to:trial.moved.x2});
      trial=undefined;
    }
    if (trial && !state.until) {
      attempts.push({reason:'carry ended before placement',tick:now});
      trial=undefined;
    }
    if (trial) {
      const pin=state.anchor, guide=state.placement;
      const valid=guide && Math.max(distance(guide.start,trial.original),distance(guide.end,{x:trial.original.x2,y:trial.original.y2}))>15;
      const hitsBoss=valid && segmentCircle(guide.start,guide.end,enemy,fitting==='short'?23:29)!==null;
      if (hitsBoss) {
        trial.replantEvents=adapter.events.length;
        await acknowledged({...quiet,technique3:true});
        adapter.input(quiet);
        const moved=cable();
        if (moved?.id===trial.original.id && moved.at>now) {
          if (fitting==='short') assert(distance(moved,{x:moved.x2,y:moved.y2})<distance(trial.original,{x:trial.original.x2,y:trial.original.y2}));
          if (fitting==='pivot') assert(distance(moved,pin)<2);
          trial.moved=moved;
        }
      } else {
        const preferred=fitting==='short'?96:132;
        const target=fitting==='pivot' && pin ? offset(pin,heading(pin,enemy),Math.min(144,Math.max(47,distance(pin,enemy)+7))) :
          offset(enemy,heading(enemy,p),preferred);
        adapter.input({...quiet,...(route(world,p,target)&&distance(p,target)>2?walk(p,target):{})});
      }
      adapter.ally?.(false);
    } else if (state.stage==='ready' && p.ammo>=1 && cable()) {
      adapter.ally?.(false);
      const original=cable(), arrows=p.ammo;
      await acknowledged({...quiet,technique3:true});
      adapter.input(quiet);
      if (status().until) {
        assert.equal(owner().ammo,arrows-1);
        assert(!cable());
        trial={original};
        witness=await adapter.witness?.(status());
      }
    } else if (state.stage==='find' && !cable() && p.eAt<=now && p.ammo>=2 && sight<193 && sight>75 && clear(world,p,enemy)) {
      const angles=fitting==='pivot'?[aim,aim-.16,aim+.16]:[aim+Math.PI/2,aim-Math.PI/2,aim+.74,aim-.74];
      const facing=angles.find(angle=>route(world,p,offset(p,angle,89)));
      if (facing!==undefined) {
        const approach=Math.atan2(Math.sin(facing),Math.cos(facing));
        adapter.ally?.(false);
        await acknowledged({...quiet,aim:approach,e:true});
        adapter.input(quiet);
      } else adapter.input({...quiet,moveX:base.moveX,moveY:base.moveY});
    } else if (['find','busy'].includes(state.stage) && !cable() && p.eAt<=now && p.ammo>=2 && sight>76 && sight<445 &&
      !base.dodge && (base.supply??-1)<0) {
      const goal=offset(enemy,heading(enemy,p),143);
      const movement=distance(p,goal)<7?{}:route(world,p,goal)?walk(p,goal):{moveX:base.moveX,moveY:base.moveY};
      adapter.input({...quiet,...movement});
      adapter.ally?.(false);
    } else {
      adapter.input({...base,e:false});
      adapter.ally?.(true);
    }
    await sleep(24);
  }
  throw Error('No verified Field Controller cable contact ' + diagnose());
}
