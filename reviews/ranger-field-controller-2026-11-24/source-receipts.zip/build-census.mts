import assert from 'node:assert/strict';
import { join } from 'node:path';
import { checkout, readJson, receipt, repoImport } from '../bonded/study-paths.mjs';

const { Game, data } = await repoImport('src/shared/game.ts');
const { PROTOCOL, CONTENT_REVISION } = await repoImport('src/shared/protocol.ts');
const { conflictingSkill } = await repoImport('src/shared/skill-conflicts.ts');
const { rangerSightIds } = await repoImport('src/shared/ranger-sight.ts');
const { rangerTrackerIds } = await repoImport('src/shared/ranger-tracker.ts');
const { rangerFieldIds } = await repoImport('src/shared/ranger-field.ts');
const target = process.argv[2];
const pilot = process.argv[3] === 'pilot';
assert(target && PROTOCOL===(pilot?103:104));
const previous=readJson(pilot?new URL('../ranger-tracker/census01.json',import.meta.url):join(checkout,'reviews/ranger-tracker-2026-11-24/build-census.json'));
assert.equal(previous.totalSets,29016);
const previousRanger=previous.reports.find(report=>report.classId==='ranger');
assert.equal(previousRanger.distinctSets,1036);
const skills=new Map([...data.skills,...data.generalSkills,...data.specializationSkills].map(node=>[node.id,node]));
const transforms=data.skills.filter(node=>node.classId==='ranger'&&node.transform);
const techniques=data.specializationSkills.filter(node=>node.classId==='ranger');
assert.equal(transforms.length,3);
assert.equal(techniques.length,9);
const significant=new Set([...techniques,...transforms,...data.generalSkills].map(node=>node.id));
const prerequisites=new Set<string>();
function add(id: string) {
  const node=skills.get(id);
  assert(node,id);
  if (node.prerequisite && !prerequisites.has(node.prerequisite)) add(node.prerequisite);
  prerequisites.add(id);
}
for (const id of significant) add(id);
const choices=[...prerequisites], acquired: string[]=[], additions=new Map();
function walk(index: number,spent: number,capstones: number) {
  if (index===choices.length) {
    if (!acquired.includes(rangerFieldIds.entry)) return;
    const signature=acquired.filter(id=>significant.has(id)).sort().join('|');
    if (!additions.has(signature) || additions.get(signature).spent>spent) {
      additions.set(signature,{skills:[...acquired],spent,remaining:27-spent,capstones,operationAndSharedSignature:signature});
    }
    return;
  }
  const id=choices[index], node=skills.get(id)!;
  walk(index+1,spent,capstones);
  if (spent+node.cost>27 || Number(node.freePlaySpRequired??0)>27 || node.capstone && capstones ||
    node.prerequisite && !acquired.includes(node.prerequisite) || conflictingSkill(acquired,id)) return;
  acquired.push(id);
  walk(index+1,spent+node.cost,capstones+Number(node.capstone));
  acquired.pop();
}
walk(0,0,0);
assert(additions.size>previousRanger.distinctSets);
assert(previousRanger.builds.every(row=>!additions.has(row.operationAndSharedSignature)));

const newRanger=[...previousRanger.builds,...additions.values()];
const reports=previous.reports.map(report=>{
  const ranger=report.classId==='ranger';
  const builds=ranger?newRanger:report.builds;
  let purchases=0, exclusions=0;
  for (const row of builds) {
    const game=new Game({mode:'endless',seed:41,maxPlayers:1});
    game.encounter=9;
    const actor=game.addPlayer('solo','Field Controller build census',report.classId);
    assert.equal(actor.totalSp,27);
    for (const item of row.skills) assert(game.transact(actor.id,{id:'buy-' + ++purchases,kind:'skill',item}).ok,item);
    assert.deepEqual(actor.skills,row.skills);
    assert.equal(actor.skills.reduce((cost,id)=>cost+game.skillCost(id),0),row.spent);
    if (!ranger) continue;
    const status=game.kitStatus(actor.id);
    assert.equal(!!status.rangerSight,actor.skills.includes(rangerSightIds.entry));
    assert.equal(!!status.rangerTracker,actor.skills.includes(rangerTrackerIds.entry));
    assert.equal(!!status.rangerField,actor.skills.includes(rangerFieldIds.entry));
    const pairs=[[rangerSightIds.roll,rangerSightIds.bearing],[rangerTrackerIds.stakes,rangerTrackerIds.backtrack],[rangerFieldIds.pivot,rangerFieldIds.short]];
    for (const [a,b] of pairs) {
      const rejected=actor.skills.includes(a)?b:actor.skills.includes(b)?a:undefined;
      if (!rejected) continue;
      assert.equal(game.transact(actor.id,{id:'excluded-' + rejected,kind:'skill',item:rejected}).reason,'incompatibleItem');
      assert(!actor.skills.includes(rejected));
      exclusions++;
    }
  }
  const count=(id: string)=>[...additions.values()].filter(row=>row.skills.includes(id)).length;
  const fitting=ranger?{
    pivot:count(rangerFieldIds.pivot),short:count(rangerFieldIds.short),
    allThree:[...additions.values()].filter(row=>[rangerSightIds.entry,rangerTrackerIds.entry].every(id=>row.skills.includes(id))).length,
    transformations:Object.fromEntries(transforms.map(node=>[node.transform,count(node.id)])),
    exclusions,
  }:report.fitting;
  return {...report,techniques:ranger?techniques.length:report.techniques,fitting,builds,purchases,
    distinctSets:builds.length,priorSetsPreserved:report.distinctSets};
});
const priorSetCount=reports.reduce((n,report)=>n+report.priorSetsPreserved,0);
const totalSets=reports.reduce((n,report)=>n+report.distinctSets,0);
const ranger=reports.find(report=>report.classId==='ranger');
assert.equal(priorSetCount,29016);
assert(ranger.fitting.pivot===ranger.fitting.short && ranger.fitting.pivot>0 && ranger.fitting.allThree>0);
assert(Object.values(ranger.fitting.transformations).every(value=>value>0));
receipt(target,{scratchOnly:pilot,protocol:PROTOCOL,contentRevision:CONTENT_REVISION,priorSetCount,totalSets,reports,
  scope:'Canonical 27-SP purchases. The tracked issued sets and Ranger Field Controller combinations with Marksman, Tracker, General, and the three Ranger transformations.'});
console.log(JSON.stringify({passed:true,totalSets,priorSetCount,added:additions.size,ranger:ranger.distinctSets,fittings:ranger.fitting}));
