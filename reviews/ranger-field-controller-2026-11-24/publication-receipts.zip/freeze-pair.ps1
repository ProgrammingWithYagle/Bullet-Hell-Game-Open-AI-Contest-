param([Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{40}$')][string]$Commit)
$ErrorActionPreference = 'Stop'
$taskScope = 'reviews/ranger-field-controller-2026-11-24'
$taskGate = Get-Content -LiteralPath "$taskScope/source-verification.json" -Raw | ConvertFrom-Json
$taskPush = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-push01.json') -Raw | ConvertFrom-Json
$taskSource = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-commit01.json') -Raw | ConvertFrom-Json
if (!$taskGate.passed -or $taskGate.checks.Count -ne 7 -or $taskSource.sourceCommit -cne $Commit -or
    $taskSource.protocol -ne 104 -or $taskGate.runtimeSourceSha256 -cne $taskSource.runtimeSourceSha256 -or
    !$taskPush.passed -or $taskPush.head -cne $Commit -or $taskPush.branch -cne 'feat/first-playable-loop') { throw 'Exact full local gate and pushed source required.' }
$taskRoot = (Resolve-Path -LiteralPath '.').Path
$taskExpected = 'C:\Users\yigal\OneDrive\Documents\ChatGPT\OpenAI Multiplayer Game Contest (Bullet Hell)'
if ($taskRoot -cne $taskExpected) { throw 'Run in the canonical checkout.' }
$taskPointer = Get-Content -LiteralPath 'output/review-retention.json' -Raw | ConvertFrom-Json
if ($taskPointer.currentSourceCommit -cne '863954bee46f8f9d40f50ac58e5ba8bbcc99283f' -or
    $taskPointer.rollbackArchiveSha256 -cne 'b08933461f3e70e35f6ab26096ecd58cd66262c9035e91c0f66f50d30a917ab2') { throw 'Previous verified pair or rollback changed.' }
foreach ($port in 5452,5453,2828,2829) {
  $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$port)
  $probe.ExclusiveAddressUse = $true
  try { $probe.Start() } finally { $probe.Stop() }
}
$taskRootReport = 'reviews/runtime-verification.json'
$taskHistory = Join-Path $PSScriptRoot 'pre-freeze-root-runtime-verification.json'
if ((Test-Path -LiteralPath $taskHistory) -or (Test-Path -LiteralPath "$taskScope/preview-testing.json") -or
    (Test-Path -LiteralPath "$taskScope/preview-public.json")) { throw 'Preserve earlier preview identities.' }
Copy-Item -LiteralPath $taskRootReport -Destination $taskHistory
$taskPreviousReport = (Get-FileHash -LiteralPath $taskHistory).Hash
try {
  Copy-Item -LiteralPath "$taskScope/source-verification.json" -Destination $taskRootReport
  node tools/freeze-client-review.mjs $Commit testing $taskScope 5452 2828
  if ($LASTEXITCODE) { throw 'Inspect the testing freeze.' }
  node tools/freeze-client-review.mjs $Commit public $taskScope 5453 2829
  if ($LASTEXITCODE) { throw 'Inspect the public freeze.' }
}
finally {
  Copy-Item -LiteralPath $taskHistory -Destination $taskRootReport
  if ((Get-FileHash -LiteralPath $taskRootReport).Hash -cne $taskPreviousReport) { throw 'Historical root report differs.' }
}
foreach ($audience in 'testing','public') {
  $taskLog = Join-Path $PSScriptRoot ('launcher-'+$audience+'.log')
  $taskErrors = Join-Path $PSScriptRoot ('launcher-'+$audience+'-errors.log')
  $runner = (Get-Command pwsh).Source
  $taskLaunchArgs = @('-NoProfile','-File','tools/launch-review.ps1','-Audience',$audience,'-Scope',$taskScope)
  Start-Process -FilePath $runner -ArgumentList $taskLaunchArgs -WorkingDirectory $taskRoot -WindowStyle Hidden -RedirectStandardOutput $taskLog -RedirectStandardError $taskErrors | Out-Null
}
