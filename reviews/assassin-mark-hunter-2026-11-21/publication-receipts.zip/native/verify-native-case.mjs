import assert from 'node:assert/strict';

export function verifyNativeCase(row, expected) {
  const { transport, fitting, revision, driver, worker } = expected;
  assert(row.passed && row.protocol === 92 && row.contentRevision === revision);
  assert(row.transport === transport && row.fitting === fitting && row.driverSha256 === driver);
  assert(row.pausedCommandsDiscarded && row.noCheckpointImports);
  assert.equal(row.firstClear, fitting === 'canted' ? 1 : 0);
  assert.deepEqual(row.bought.map(node => node.earned), fitting === 'canted' ? [3,3,9] : fitting === 'transfer' ? [12,12,12] : [3,3]);
  assert.deepEqual(row.bought.map(node => node.clears), fitting === 'canted' ? [0,0,1] : fitting === 'transfer' ? [0,0,0] : [0,0]);
  assert.equal(row.setup.mode, fitting === 'transfer' ? 'raid' : 'short');

  const { line, newest, paid, originalPin, effects, original, transferred } = row.result;
  const has = (...notes) => notes.every(note => effects.includes('assassin-writ-' + note));
  assert(line.id === newest.id && line.id === paid.id && line.at === paid.at && line.until === paid.until);
  assert(line.until - line.at === 86 && paid.recovery > line.until && paid.recovery > original);
  assert.deepEqual([line.from, line.to], [newest.from, newest.to]);
  assert(has('mark', 'proof', 'confirm', 'set'));
  if (fitting === 'entry') assert(['strike','guarded'].includes(newest.outcome) && has(newest.outcome));
  if (fitting === 'canted') {
    assert(originalPin && has('pin') && originalPin.ultimateAt <= originalPin.at);
    assert(originalPin.at <= line.at && line.at < originalPin.expires);
    assert(Math.hypot(originalPin.point.x - line.x, originalPin.point.y - line.y) < .7);
  }
  if (fitting === 'transfer') {
    assert(transferred && has('proposal', 'transfer') && newest.until === line.until);
    assert(newest.quarry && line.quarry && Math.hypot(newest.quarry.x - line.quarry.x, newest.quarry.y - line.quarry.y) > 22);
  }
  if (transport === 'worker') assert(row.wholeOptimizedWorker && !row.workerPatched && row.workerSha256 === worker);
  else {
    const { witnessed } = row;
    assert(witnessed.nonHost && witnessed.ownedStatePrivate && witnessed.ownedSoundsPrivate);
    assert.equal(witnessed.shared.first.id, line.id);
    assert.equal(witnessed.shared.first.until, line.until);
    assert.deepEqual([witnessed.shared.first.from, witnessed.shared.first.to], [line.from, line.to]);
    if (newest.outcome) assert.equal(witnessed.shared.last.outcome, newest.outcome);
  }
  return { transport, fitting, startingBoss: row.next.boss, mode: row.setup.mode, earned: row.bought.at(-1).earned,
    paidUntil: paid.recovery, cutoff: line.id, crossing: newest.outcome, pinned: !!originalPin, transferred };
}
