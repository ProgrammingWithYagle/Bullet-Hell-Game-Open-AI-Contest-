import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { writPilot } from './native-writ-pilot.mjs';
import { explicitNavigation } from './native-writ-navigation.mjs';

export function recordCutoffs(cues, view) {
  for (const cue of view.classCues) {
    if (cue.kind !== 'assassin-writ-cutoff') continue;
    const quarry = view.classCues.find(row => row.kind === 'assassin-writ-quarry' && row.owner === cue.owner && row.id === cue.id && row.paid);
    const sample = { ...cue, quarry: quarry && { x: quarry.x, y: quarry.y, radius: quarry.radius } };
    const existing = cues.get(cue.id);
    if (!existing) cues.set(cue.id, { first: sample, last: sample });
    else existing.last = sample;
  }
}

export function createCombatPolicy({ adapter, view, data, HZ, rules, cutoffReach, runtimeArena,
  bulwarkTrialWorld, clearTrialWalk, segmentRect, segmentCircle, distance, restRaidInput, fitting }) {
  const projection = {
    get arena() { return runtimeArena(view().arenaId, view().run.difficulty); },
    get obstacles() { return bulwarkTrialWorld(view()).obstacles; },
    get combatTick() { return view().combatTick; },
    get encounter() { return view().encounter; },
    movementSpeed(player) { return player.speed; },
  };
  function danger(seen, at, horizon) {
    if (seen.minions.some(row => row.health > 0 && distance(row, at) < 24 + horizon)) return true;
    if (seen.fields.some(row => row.kind === 'zone' && distance(row, at) < row.radius + 8)) return true;
    for (const shot of adapter.observed.values()) {
      const time = Math.min(horizon, shot.expires - seen.combatTick);
      if (time <= 0 || shot.owner !== 'hostile' || distance(shot, at) > 475) continue;
      const elapsed = Math.max(0, seen.combatTick - shot.seenAt) / HZ;
      const from = { x: shot.x + shot.vx * elapsed, y: shot.y + shot.vy * elapsed };
      const to = { x: from.x + shot.vx * time / HZ, y: from.y + shot.vy * time / HZ };
      const contact = segmentCircle(from, to, at, shot.radius + data.rules.playerRadius + 2);
      if (contact !== null && !projection.obstacles.some(wall => (segmentRect(from, to, wall, shot.radius)?.t ?? Infinity) <= contact)) return true;
    }
    return false;
  }
  const navigate = explicitNavigation({ game: projection, data, HZ, distance, segmentRect, clearTrialWalk, danger });
  const writ = writPilot({ game: projection, data, rules, cutoffReach, distance, segmentRect, segmentCircle,
    clearTrialWalk, danger, fitting, transportExercise: true });
  const ordinary = (seen, body) => navigate(seen, body, restRaidInput(seen, body, [...adapter.observed.values()]));
  return { ordinary, invoke: (seen, body, record) => {
    const routine = ordinary(seen, body);
    return writ(seen, body, { ...routine, ultimate: body.health <= body.maxHealth / 2 && routine.ultimate }, body, record);
  } };
}

export async function exerciseWrit({ adapter, view, owner, submit, fitting, rules, distance, equip, policy }) {
  const outcomes = [], plans = [], paid = [], pins = [], places = [];
  let previousPhase, lastShop = view().encounter - 1, lastPlace = -Infinity;
  const start = adapter.events.length, original = owner().ultimateAt, limit = Date.now() + 166_000;
  const ownedSounds = () => adapter.events.slice(start).filter(row => row.type === 'sound' && row.owner === adapter.id && row.id.startsWith('assassin-writ-'));
  const note = id => 'assassin-writ-' + id;

  for (;;) {
    const seen = view(), body = owner(), status = body.kit.crossingWrit;
    if (Date.now() >= limit || seen.phase === 'defeat' || seen.phase === 'victory') {
      assert.fail(JSON.stringify({ fitting, phase: seen.phase, boss: seen.boss.id, tick: seen.combatTick,
        outcomes, plans, paid, pins, places, sounds: ownedSounds().map(row => row.id) }));
    }
    if (seen.phase !== 'combat') {
      if (['mutationVote', 'contractVote', 'secretOffer'].includes(seen.phase)) adapter.vote(0);
      if (seen.phase === 'shop' && seen.encounter !== lastShop) {
        lastShop = seen.encounter;
        await equip();
      }
      await sleep(20);
      continue;
    }
    if (status?.phase !== previousPhase) {
      previousPhase = status?.phase;
      outcomes.push({ phase: status?.phase, boss: seen.boss.id, encounter: seen.encounter, at: seen.combatTick, status, ultimateAt: body.ultimateAt });
      if (status?.phase === 'pinned') pins.push({ point: status.pin, at: seen.combatTick, expires: status.until, ultimateAt: body.ultimateAt });
    }
    if (seen.combatTick > lastPlace + 90) {
      lastPlace = seen.combatTick;
      places.push({ at: lastPlace, boss: seen.boss.id, x: body.x, y: body.y, quarry: [seen.boss.x, seen.boss.y], hp: body.health });
    }
    const sounding = ownedSounds();
    const candidates = [...adapter.cues.values()].filter(row => row.first.owner === adapter.id && row.first.at >= (paid[0]?.at ?? 0));
    for (const row of candidates) {
      const line = row.first;
      const set = sounding.find(event => event.id === note('set') && distance(event, line) < 1);
      if (!set || body.ultimateAt <= line.until) continue;
      let payment = paid.find(due => due.id === line.id);
      if (!payment) {
        payment = { id: line.id, at: line.at, until: line.until, recovery: body.ultimateAt };
        paid.push(payment);
      }
      const newest = row.last;
      const originalPin = pins.find(pin => distance(pin.point, line) < .7 && pin.at <= line.at && line.at < pin.expires);
      const transferable = newest.quarry && line.quarry && distance(newest.quarry, line.quarry) > 22 &&
        sounding.findLast(event => event.id === note('transfer') && distance(event, newest.quarry) < 43);
      if (fitting === 'entry' ? newest.outcome === 'strike' || newest.outcome === 'guarded' :
          fitting === 'canted' ? originalPin && sounding.some(event => event.id === note('pin')) :
          transferable && sounding.some(event => event.id === note('proposal'))) {
        assert(line.until - line.at === rules.cutoffTicks && payment.recovery > line.until && payment.recovery > original);
        assert([note('mark'), note('proof'), note('confirm'), note('set')].every(id => sounding.some(event => event.id === id)));
        if (fitting === 'transfer') {
          assert.equal(line.id, newest.id);
          assert.equal(line.until, newest.until);
          assert.deepEqual([line.from, line.to], [newest.from, newest.to]);
        }
        return { paid: payment, original, line, newest, originalPin, transferred: !!transferable,
          effects: sounding.map(event => event.id), outcomes, plans };
      }
    }
    const input = body.status === 'active' ? policy.invoke(seen, body, row => plans.push(row)) : { interact: true };
    await submit(input);
    if (fitting === 'entry' || fitting === 'transfer') adapter.allyCover?.();
  }
}
