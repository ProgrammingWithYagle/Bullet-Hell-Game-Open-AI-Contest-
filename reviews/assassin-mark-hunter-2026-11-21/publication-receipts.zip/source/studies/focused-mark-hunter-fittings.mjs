import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { writPilot } from './writ-pilot-fittings.mjs';
import { readJson,receipt,verifiedBundle } from '../bastion/study-paths.mjs';

const [destination,cohort,bundle='game01',mode='short',sample] = process.argv.slice(2);
assert(destination && ['solo','party'].includes(cohort) && ['short','standard'].includes(mode)&&/^game[0-9]{2}$/.test(bundle));
const here = file => new URL('./'+file,import.meta.url);
const verified = readJson(here(bundle+'.json'));
const { Game,data,viewOf,HZ,idleInput,CONTENT_REVISION,crossingWritId,markHunterIds,crossingWritRules:rules,cutoffReach,distance,
  segmentRect,segmentCircle,restRaidInput,clearTrialWalk } = await verifiedBundle(fileURLToPath(here(bundle+'.mjs')),verified.bundle);
const scenarios = [['gatehouse','baby',41],['sunken-chapel','normal',73],['ossuary-works','normal',109],['crown-crypt','baby',61]];
const policies = ['banked', 'unused', 'writ', 'canted', 'transfer'];
const point = ({x,y}) => ({x,y});
const bearing = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const forward = (p,a,d) => ({ x:p.x+Math.cos(a)*d,y:p.y+Math.sin(a)*d });
const around = angle => Math.atan2(Math.sin(angle),Math.cos(angle));

function run(arena,difficulty,seed,policy) {
  const game = new Game({ mode,difficulty,seed,arenaSelection:'route',openingArenaId:arena,maxPlayers:cohort==='solo'?1:2 });
  const hunter = game.addPlayer('solo','Nyx','assassin');
  const ally = cohort==='party' ? game.addPlayer('ally','Lane','soldier') : undefined;
  const actors = ally ? [hunter,ally] : [hunter];
  const shots = new Map(), events = [], fights = [];
  const trace = createHash('sha256');
  const plans = [], fitBuys = [], motion = {};
  let previousBoss;
  let serial = 0, steps = 0, lastShop = -1, lastEncounter = -1;
  const buy = (actor,kind,item) => game.transact(actor.id,{ kind,item,id:'writ-study-'+(++serial) });
  assert.equal(hunter.totalSp,3);
  assert(buy(hunter,'skill','assassin-evasion-1').ok);
  if(policy!=='banked') assert(buy(hunter,'skill',crossingWritId).ok);
  function equipment(p) {
    for(const weapon of data.weapons.filter(w=>w.classId===p.classId).sort((a,b)=>b.tier-a.tier))
      if(p.weapon===weapon.id || buy(p,'weapon',weapon.id).ok)break;
    for(const item of ['damage','health','fire-rate','reload','magazine']) buy(p,'upgrade',item);
    buy(p,'supply','medkit');
  }
  for(const p of actors) equipment(p);
  assert(game.start());

  function danger(view,p,horizon) {
    if(view.minions.some(actor=>actor.health>0 && distance(actor,p)<28+Math.min(28,horizon*2.8)))return true;
    if(view.fields.some(field=>field.kind==='zone' && distance(field,p)<field.radius+12))return true;
    for(const shot of shots.values()) {
      const lifetime=Math.min(horizon,shot.expires-view.combatTick);
      if(lifetime<=0 || distance(shot,p)>500)continue;
      const elapsed=(view.combatTick-shot.seenAt)/HZ;
      const origin={ x:shot.x+shot.vx*elapsed,y:shot.y+shot.vy*elapsed };
      const end={ x:origin.x+shot.vx*lifetime/HZ,y:origin.y+shot.vy*lifetime/HZ };
      const entry=segmentCircle(origin,end,p,shot.radius+data.rules.playerRadius+2);
      if(entry!==null && !game.obstacles.some(wall=>(segmentRect(origin,end,wall,shot.radius)?.t??Infinity)<=entry))return true;
    }
    return false;
  }
  const visible=(a,b,r=1)=>!game.obstacles.some(wall=>segmentRect(a,b,wall,r));
  function movement(view,p,aim) {
    const target=forward(p,aim,23), world={ ...game.arena,obstacles:game.obstacles,tick:view.combatTick };
    return clearTrialWalk(world,p,target) && !danger(view,target,5) ? { moveX:Math.cos(aim),moveY:Math.sin(aim) } : undefined;
  }
  const navigation = new Map();
  const navigationPlans = [];
  const radius = data.rules.playerRadius;
  const aimVector = angle => ({ x: Math.cos(angle), y: Math.sin(angle) });
  function firingLane(player, target, input) {
    const boss = point(target);
    const walls = game.obstacles;
    const occluded = (from) => walls.some(wall => segmentRect(from, boss, wall, 4));
    if (!occluded(player)) {
      navigation.delete(player.id);
      return;
    }
    if (player.health < player.maxHealth * .28 || danger(viewOf(game, player.id), player, 10)) return;
    const now = game.combatTick;
    const world = { ...game.arena, obstacles: walls, tick: now, playerRadius: radius };
    const clear = (a, b) => clearTrialWalk(world, a, b);
    let chase = navigation.get(player.id);
    if (!chase || chase.encounter !== game.encounter || now >= chase.at + 55 || chase.target !== target.id) {
      const margin = radius + 14;
      const bends = walls.flatMap(wall => [
        { x: wall.x - margin, y: wall.y - margin }, { x: wall.x + wall.width + margin, y: wall.y - margin },
        { x: wall.x - margin, y: wall.y + wall.height + margin }, { x: wall.x + wall.width + margin, y: wall.y + wall.height + margin },
      ]).filter(p => clear(p, p));
      const goals = [142, 200, 275, 360].flatMap(range => Array.from({ length: 20 }, (_, i) => {
        const aim = aimVector(i * Math.PI / 10);
        return { x: boss.x + aim.x * range, y: boss.y + aim.y * range };
      })).filter(p => clear(p, p) && !occluded(p));
      const points = [point(player), ...bends, ...goals];
      const cheapest = points.map((_, i) => i === 0 ? 0 : Infinity);
      const parent = points.map(() => -1), visited = new Set();
      let path = [];
      for (let pass = 0; pass < points.length; pass++) {
        let index = -1, shortest = Infinity;
        for (let i = 0; i < points.length; i++) if (!visited.has(i) && cheapest[i] < shortest) {
          index = i;
          shortest = cheapest[i];
        }
        if (index < 0) break;
        if (index > bends.length) {
          for (let start = index; start > 0; start = parent[start]) path.unshift(points[start]);
          break;
        }
        visited.add(index);
        for (let next = 1; next < points.length; next++) {
          const step = distance(points[index], points[next]);
          if (visited.has(next) || shortest + step >= cheapest[next] || !clear(points[index], points[next])) continue;
          cheapest[next] = shortest + step;
          parent[next] = index;
        }
      }
      chase = { at: now, encounter: game.encounter, path, target: target.id };
      navigation.set(player.id, chase);
      if (path.length) navigationPlans.push({ player: player.id, encounter: game.encounter, tick: now, from: point(player), route: [...path] });
    }
    while (chase.path.length && distance(player, chase.path[0]) < 2) chase.path.shift();
    const next = chase.path[0];
    if (!next || !clear(player, next)) return;
    const scale = Math.max(distance(player, next), game.movementSpeed(player) / HZ);
    return { ...input, moveX: (next.x - player.x) / scale, moveY: (next.y - player.y) / scale, dodge: false };
  }


  function ordinary(view,p,current) {
    const targets=view.bossCues.filter(c=>c.health>0 && ['service-prop','stitch-pin','raid-prop','early-prop'].includes(c.kind) &&
      distance(p,c)<530 && visible(p,c,2)).sort((a,b)=>distance(p,a)-distance(p,b));
    const immediate=view.minions.filter(c=>c.health>0 && distance(p,c)<82 && visible(p,c,2));
    const target=immediate.sort((a,b)=>distance(p,a)-distance(p,b))[0]??targets[0]??view.boss;
    const aim=bearing(p,target);
    if(immediate.length) {
      const retreat=[aim+Math.PI,aim+1.6,aim-1.6].map(h=>movement(view,p,h)).find(Boolean);
      return { ...current,...retreat,aim,fire:true };
    }
    if(visible(p,target,2))
      return { ...current,aim,fire:current.fire || distance(p,target)<320 };
    if(current.dodge || danger(view,p,6))return current;
    return firingLane(p,target,{ ...current,aim }) ?? current;
  }

  const choose = writPilot({ game, data, rules, cutoffReach, distance, segmentRect, segmentCircle, clearTrialWalk, danger, fitting: policy === 'writ' ? 'entry' : policy, transportExercise: policy === 'transfer' });
  while (!['victory','defeat'].includes(game.phase) && steps++ < 90000) {
    if (game.phase !== 'combat') {
      shots.clear();
      if (['mutationVote','contractVote','secretOffer'].includes(game.phase)) for (const actor of actors) game.vote(actor.id, 0);
      if (game.phase === 'shop' && game.encounter !== lastShop) {
        lastShop = game.encounter;
        for (const actor of actors) equipment(actor);
        if (['canted','transfer'].includes(policy) && !hunter.skills.includes(markHunterIds[policy])) {
          const id = markHunterIds[policy];
          const card = data.specializationSkills.find(row => row.id === id);
          assert(card && hunter.totalSp >= card.freePlaySpRequired);
          assert(buy(hunter,'skill',id).ok);
          fitBuys.push({ id, earned: hunter.totalSp, clears: hunter.progress.clears, encounter: game.encounter });
          assert.equal(buy(hunter,'skill',markHunterIds[policy === 'canted' ? 'transfer' : 'canted']).reason,'incompatibleItem');
        }
      }
      game.step();
      game.drainEvents();
      continue;
    }
    if (game.encounter !== lastEncounter) {
      lastEncounter = game.encounter;
      fights.push({ boss: game.boss.id, arena: game.arena.id, earned: hunter.totalSp, tick: game.combatTick });
    }
    const view = viewOf(game, hunter.id);
    if (previousBoss?.encounter === game.encounter) {
      const cohort = motion[view.boss.id] ??= { samples: 0, near: 0, moving: 0, nearMoving: 0, minions: 0, maxStride: 0 };
      const stride = distance(previousBoss, view.boss), gap = distance(hunter, view.boss);
      cohort.samples++;
      if (gap < 285) cohort.near++;
      if (stride >= .34 && stride < rules.maximumCrossingStride) {
        cohort.moving++;
        if (gap < 285) cohort.nearMoving++;
        cohort.maxStride = Math.max(cohort.maxStride, stride);
      }
      if (view.minions.some(target => target.health >= 58 && distance(target, hunter) < 285)) cohort.minions++;
    }
    previousBoss = { ...point(view.boss), encounter: game.encounter };
    const before = { u: hunter.ultimateAt, pos: point(hunter), hp: hunter.health };
    let ownFrame;
    for (const actor of actors) {
      const p = view.players.find(row => row.id === actor.id);
      const base = actor.status === 'active' ? ordinary(view, p, restRaidInput(view, p, [...shots.values()])) :
        actor.status === 'downed' ? { interact: true } : {};
      if (actor !== hunter && ['laid','transfer'].includes(view.players.find(row => row.id === hunter.id)?.kit.crossingWrit?.phase)) {
        base.fire = false;
        base.q = false;
        base.e = false;
        base.ultimate = false;
      }
      const input = actor === hunter && actor.status === 'active' && ['writ','canted','transfer'].includes(policy) ? choose(view, p, base, actor, row => plans.push(row)) : base;
      const frame = { ...idleInput(), ...input, sequence: actor.ack + 1, clientTick: game.combatTick };
      frame.aim = around(frame.aim);
      if (actor === hunter) ownFrame = frame;
      trace.update(JSON.stringify(frame));
      assert(game.submitInput(actor.id, frame), JSON.stringify(frame));
    }
    game.step();
    const privateView = game.kitStatus(hunter.id);
    const cues = game.classCues().filter(cue => cue.owner === hunter.id && (cue.kind === 'assassin-writ-quarry' || cue.kind === 'assassin-writ-cutoff'));
    for (const event of game.drainEvents()) {
      if (event.type === 'shots') for (const shot of event.shots) if (shot.owner === 'hostile') shots.set(shot.id, { ...shot, seenAt: game.combatTick });
      if (event.type === 'remove') for (const id of event.ids) shots.delete(id);
      if (event.type !== 'sound' || event.owner !== hunter.id || !event.id.startsWith('assassin-writ-')) continue;
      const action = event.id.slice('assassin-writ-'.length);
      if (['mark','pin','proposal'].includes(action)) assert(ownFrame.technique3 && hunter.ultimateAt === before.u);
      if (action === 'set') assert(ownFrame.technique3 && hunter.ultimateAt > before.u);
      if (action === 'strike' || action === 'guarded') assert(hunter.ultimateAt === before.u);
      events.push({ action, boss: game.boss.id, at: game.combatTick, before, uAt: hunter.ultimateAt,
        state: privateView.crossingWrit, point: { x: event.x, y: event.y }, cues });
    }
    trace.update(JSON.stringify([game.phase, game.combatTick, game.boss.health, ...actors.map(a => [a.x,a.y,a.health,a.ammo,a.qAt,a.eAt,a.damageDealt,a.damageTaken])]));
  }
  assert(['victory','defeat'].includes(game.phase));
  return { arena, difficulty, seed, policy, won: game.phase === 'victory', clears: hunter.progress.clears,
    events, plans, fitBuys, fights, navigationPlans, motion, trace: trace.digest('hex') };
}

const chosen = sample?.split('/');
if (chosen) assert(chosen.length === 2 && scenarios.some(row => row[0] === chosen[0]) && policies.includes(chosen[1]));
const rows = [], controls = [];
for (const inputs of scenarios) {
  if (chosen && inputs[0] !== chosen[0]) continue;
  const sampleRows = (chosen ? [chosen[1]] : policies).map(policy => run(...inputs, policy));
  if (!chosen) {
    assert.equal(sampleRows[0].trace, sampleRows[1].trace, inputs[0]);
    controls.push({ arena: inputs[0], sameTrace: true });
  }
  rows.push(...sampleRows);
  for (const row of sampleRows) console.log(JSON.stringify({ arena: row.arena, policy: row.policy, won: row.won, clears: row.clears,
    approaches: row.plans.length, counts: Object.fromEntries(['mark','proof','confirm','pin','set','strike','guarded','lost','proposal','transfer'].map(action => [action, row.events.filter(e => e.action === action).length])) }));
}
receipt(destination, { stageOnly: true, focusedCooperativeFittingTrial: true, visiblePathNavigation: true, contentRevision: CONTENT_REVISION,
  bundleSha256: verified.bundle, mode, cohort, rows, controls });
