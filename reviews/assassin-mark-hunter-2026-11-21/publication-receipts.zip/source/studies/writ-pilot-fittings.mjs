export function writPilot({ game, data, rules, cutoffReach, distance, segmentRect, segmentCircle, clearTrialWalk, danger, fitting = "entry", transportExercise = false }) {
  const tracked = new Map();
  let encounter = -1, draft;

  function projection(view) {
    if (encounter !== view.encounter) {
      encounter = view.encounter;
      tracked.clear();
      draft = undefined;
    }
    const candidates = [
      { ...view.boss, key: 'boss', radius: data.bosses.find(row => row.id === view.boss.id)?.radius ?? 46 },
      ...view.minions.map(row => ({ ...row, key: 'actor:' + row.id })),
      ...view.bossCues.filter(row => row.health > 0 && ['service-prop','raid-prop','stitch-pin','early-prop'].includes(row.kind))
        .map(row => ({ ...row, key: 'prop:' + row.id })),
    ].filter(row => row.health > 0);
    return candidates.map(target => {
      const last = tracked.get(target.key);
      const elapsed = view.combatTick - (last?.at ?? view.combatTick);
      let velocity = last?.velocity ?? { x: 0, y: 0 };
      if (last && elapsed > 0 && elapsed <= 4 && distance(last, target) < 54) {
        velocity = { x: velocity.x * .6 + (target.x - last.x) * .4 / elapsed,
          y: velocity.y * .6 + (target.y - last.y) * .4 / elapsed };
      }
      tracked.set(target.key, { x: target.x, y: target.y, at: view.combatTick, velocity });
      return { ...target, velocity };
    });
  }

  const bearing = (a, b) => Math.atan2(b.y - a.y, b.x - a.x);
  const clear = (a, b, pad = 1) => !game.obstacles.some(rect => segmentRect(a, b, rect, pad));
  function chooseLine(p, target, charge, now, pin, minTurn = 0, allowUnpredicted = false) {
    if (!target) return;
    const ends = charge && { x: charge.x2, y: charge.y2 };
    const windup = charge ? Math.max(0, charge.at - now) : 0;
    let motion = target.velocity;
    if (ends) {
      const time = Math.max(1, charge.until - now - windup);
      motion = { x: (ends.x - target.x) / time, y: (ends.y - target.y) / time };
    }
    if (!allowUnpredicted && Math.hypot(motion.x, motion.y) < .45) return;
    let best;
    const world = game.arena;
    const safe = at => at.x > world.bounds.x + 5 && at.x < world.bounds.x + world.bounds.width - 5 &&
      at.y > world.bounds.y + 5 && at.y < world.bounds.y + world.bounds.height - 5;
    const aimed = bearing(p, target), reach = cutoffReach(distance(p, target), target.radius);
    for (let i = -23; i <= 23; i++) {
      const angle = aimed + i * .061, dx = Math.cos(angle), dy = Math.sin(angle);
      const turn = draft ? Math.abs(Math.atan2(Math.sin(angle - draft.angle), Math.cos(angle - draft.angle))) : 0;
      if (turn < minTurn) continue;
      const center = pin ?? { x: p.x + reach * dx, y: p.y + reach * dy };
      const across = (target.x - center.x) * dx + (target.y - center.y) * dy;
      if (distance(center, target) > rules.cutoffNearQuarry - 3 || Math.abs(across) <= Math.max(rules.minimumQuarryLead, target.radius / 2) + 1) continue;
      const projectedSpeed = motion.x * dx + motion.y * dy;
      const moving = Math.abs(projectedSpeed) >= .42 && projectedSpeed * across < 0;
      if (!moving && !allowUnpredicted) continue;
      const travel = moving ? -across / projectedSpeed : rules.cutoffTicks - 9;
      const ticks = windup + travel;
      if (moving && (ticks < 5 || ticks > rules.cutoffTicks - 8 || charge && now + ticks >= charge.until - 2)) continue;
      const next = moving ? { x: target.x + motion.x * travel, y: target.y + motion.y * travel } : target;
      const span = Math.abs((next.x - center.x) * -dy + (next.y - center.y) * dx);
      if (span > rules.cutoffHalfSpan - 7 || !clear(target, next, 0) || !clear(p, center, rules.cutoffWidth)) continue;
      const from = { x: center.x + dy * rules.cutoffHalfSpan, y: center.y - dx * rules.cutoffHalfSpan };
      const to = { x: center.x - dy * rules.cutoffHalfSpan, y: center.y + dx * rules.cutoffHalfSpan };
      if (!safe(from) || !safe(to) || !clear(from, to, rules.cutoffWidth) ||
          world.lavaPits.some(pit => segmentCircle(from, to, pit, pit.radius + rules.cutoffWidth) !== null)) continue;
      const score = (moving ? ticks : rules.cutoffTicks + Math.abs(i)) + span * .26;
      if (!best || score < best.score) best = { angle, center, from, to, ticks, predicted: next, score };
    }
    return best;
  }

  function spacing(view, owner, target, ordinary) {
    const gap = distance(owner, target);
    const desired = rules.minimumReach + Math.max(rules.minimumQuarryLead, target.radius / 2) + 31;
    if (gap >= desired && gap <= desired + 90) return;
    const away = bearing(target, owner), heading = gap < desired ? away : away + Math.PI;
    const world = { ...game.arena, tick: view.combatTick, obstacles: game.obstacles };
    for (const adjustment of [0,.44,-.44,.82,-.82]) {
      const direction = heading + adjustment;
      const to = { x: owner.x + Math.cos(direction) * 24, y: owner.y + Math.sin(direction) * 24 };
      if (!clearTrialWalk(world, owner, to) || danger(view, to, 5)) continue;
      return { ...ordinary, moveX: Math.cos(direction), moveY: Math.sin(direction), aim: bearing(owner, target),
        fire: clear(owner, target, 2), dodge: false, e: false, ultimate: false };
    }
  }

  return (view, owner, ordinary, player, record) => {
    const candidates = projection(view);
    const now = view.combatTick, status = owner.kit.crossingWrit;
    const charge = view.bossCues.find(cue => cue.kind === 'charge' && !cue.interrupted && cue.at < now + 35 && cue.until > now + 5);
    const mark = view.classCues.find(row => row.kind === 'assassin-writ-quarry' && row.owner === owner.id);
    if (danger(view, owner, 5) || owner.health < owner.maxHealth * .28) return ordinary;
    if (status?.phase === 'marked' && mark) {
      const shot = clear(owner, mark, 2);
      if (shot) return spacing(view, owner, { ...mark, radius: mark.radius - 8 }, ordinary) ??
        { ...ordinary, aim: bearing(owner, mark), fire: true, ultimate: false, e: false, dodge: false };
      return { ...ordinary, ultimate: false };
    }
    if ((status?.phase === 'confirmed' || status?.phase === 'pinned') && mark) {
      const trackedTarget = candidates.reduce((best, row) => !best || distance(mark, row) < distance(mark, best) ? row : best, undefined);
      if (trackedTarget && distance(trackedTarget, mark) < 12) {
        const target = { ...trackedTarget, radius: mark.radius - 8 };
        const actualCharge = target.key === 'boss' ? charge : undefined;
        const pinned = status.phase === 'pinned';
        const spare = fitting === 'transfer' && transportExercise && candidates.some(row => row.key !== target.key &&
          distance(owner, row) >= rules.minimumPick && distance(owner, row) <= rules.maximumPick && clear(owner, row, rules.cutoffWidth));
        const line = chooseLine(owner, target, actualCharge, now, pinned ? status.pin : undefined, pinned ? .18 : 0, spare) ??
          (pinned && status.until - now < 24 ? chooseLine(owner, target, actualCharge, now, status.pin) : undefined);
        if (line && player.dashUntil <= now && owner.kit.passageUntil <= now) {
          const pin = fitting === 'canted' && owner.skills.includes('assassin-mark-hunter-canted-cutoff-1') && !pinned;
          if (pin) draft = line;
          record({ kind: pin ? 'pin' : 'set', tick: now, boss: view.boss.id, target: trackedTarget.key, placement: line });
          return { technique3: true, aim: line.angle };
        }
      }
      return spacing(view, owner, { ...mark, radius: mark.radius - 8 }, ordinary) ?? { ...ordinary, ultimate: false };
    }
    if (status?.phase === 'transfer' && status.proposed) {
      return { ...ordinary, aim: bearing(owner, status.proposed), fire: clear(owner, status.proposed, 2), q: false, e: false, ultimate: false };
    }
    if (status?.phase === 'laid') {
      const active = view.classCues.find(row => row.kind === 'assassin-writ-cutoff' && row.owner === owner.id && !row.outcome);
      if (fitting === 'transfer' && active && mark && status.until - now > rules.transferMinimumTime + 9 &&
          owner.skills.includes('assassin-mark-hunter-transfer-writ-1') && player.dashUntil <= now && owner.kit.passageUntil <= now) {
        const alternate = candidates.filter(row => distance(row, mark) > 15 && distance(owner, row) >= rules.minimumPick + 3 &&
          distance(owner, row) <= rules.maximumPick - 4 && clear(owner, row, rules.cutoffWidth))
          .map(row => ({ row, crossing: segmentCircle(row, { x: row.x + row.velocity.x * 38, y: row.y + row.velocity.y * 38 }, active, 53) !== null }))
          .filter(row => row.crossing || transportExercise)
          .sort((a, b) => Number(b.crossing) - Number(a.crossing) || distance(owner, a.row) - distance(owner, b.row))[0]?.row;
        if (alternate && (!draft || draft.proposedId !== active.id || now - draft.proposedAt > 14)) {
          draft = { proposedId: active.id, proposedAt: now };
          record({ kind: 'proposal', tick: now, boss: view.boss.id, target: alternate.key });
          return { technique3: true, aim: bearing(owner, alternate), fire: true };
        }
      }
      return { ...ordinary, e: false };
    }
    if (player.ultimateAt > now) return ordinary;
    if (player.dashUntil > now || owner.kit.passageUntil > now) return { ...ordinary, ultimate: false };
    const legal = candidates.filter(row => row.health >= 58 && distance(owner, row) <= 475 && clear(owner, row, rules.cutoffWidth))
      .map(row => ({ row, gap: distance(owner, row), speed: Math.hypot(row.velocity.x, row.velocity.y) }))
      .sort((a, b) => b.speed - a.speed || a.gap - b.gap);
    const moving = legal.find(({ gap, speed }) => gap >= rules.minimumPick + 10 && gap <= rules.maximumPick - 7 && speed >= .34);
    const candidate = moving ?? legal.find(({ row, gap }) => !row.key.startsWith('prop:') && gap >= rules.minimumPick + 12 && gap <= 305);
    if (candidate) {
      const { row } = candidate;
      return { moveX: ordinary.moveX ?? 0, moveY: ordinary.moveY ?? 0, fire: true, technique3: true, aim: bearing(owner, row) };
    }
    const approach = legal.find(({ row, gap }) => !row.key.startsWith('prop:') && gap > 305);
    return (approach && spacing(view, owner, approach.row, ordinary)) || { ...ordinary, ultimate: false };
  };
}
