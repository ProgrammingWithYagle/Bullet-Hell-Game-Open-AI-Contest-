import assert from 'node:assert/strict';
import { execFile } from 'node:child_process';
import { mkdirSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { promisify } from 'node:util';
import { readJson, receipt, sha256 } from '../bastion/study-paths.mjs';

const attempt = process.argv[2];
assert(/^replays\d\d$/.test(attempt));
const here = file => new URL('./' + file, import.meta.url);
const launch = promisify(execFile);
const base = 'natural-mark-hunter-fittings-v2.mjs';
const scenarioGroups = [
  ['short', 'solo', ['ossuary-works/writ','gatehouse/canted','crown-crypt/transfer']],
  ['short', 'party', ['ossuary-works/writ','sunken-chapel/canted','gatehouse/transfer']],
  ['standard', 'solo', ['sunken-chapel/canted','ossuary-works/writ','crown-crypt/transfer']],
  ['standard', 'party', ['sunken-chapel/writ','ossuary-works/canted','gatehouse/transfer']],
];
const cohorts = scenarioGroups.map(([mode, group, scenarios]) => ({
  mode, group, scenarios, original: readJson(here(mode + '-' + group + '08.json')),
}));
const bundle = readJson(here('game04.json')).bundle;
assert(cohorts.every(row => row.original.bundleSha256 === bundle && row.original.rows.length === 20));
mkdirSync(here(attempt));
const compared = [];
for (let n = 0; n < 3; n++) {
  const round = await Promise.allSettled(cohorts.map(async ({ mode, group, scenarios, original }) => {
    const sample = scenarios[n];
    const name = mode + '-' + group + '-' + sample.replace('/', '-') + '.json';
    const out = here(attempt + '/' + name);
    await launch(process.execPath, [fileURLToPath(here(base)), fileURLToPath(out), group, 'game04', mode, sample],
      { cwd: fileURLToPath(here('./')), windowsHide: true, timeout: 145_000 });
    const [arena, policy] = sample.split('/');
    const reference = original.rows.find(row => row.arena === arena && row.policy === policy);
    const actual = readJson(out);
    assert.equal(actual.rows.length, 1);
    assert.equal(actual.bundleSha256, bundle);
    assert.deepEqual(actual.rows[0], reference, mode + '/' + group + '/' + sample);
    return { file: name, sha256: sha256(readFileSync(out)), mode, group, sample, trace: reference.trace,
      won: reference.won, eventCount: reference.events.length };
  }));
  for (const result of round) {
    if (result.status === 'rejected') throw result.reason;
    compared.push(result.value);
  }
}
assert.equal(compared.length, 12);
receipt(here(attempt + '/summary.json'), { passed: true, bundleSha256: bundle, driverSha256: sha256(readFileSync(here(base))),
  cases: compared, matchedAllInputsAndOutcomes: true });
console.log(JSON.stringify({ passed: true, cases: compared.length, bundle }));
