import assert from 'node:assert/strict';
import { setTimeout as sleep } from 'node:timers/promises';
import { repoImport } from '../bonded/study-paths.mjs';
import { waitFor } from '../formation/native-flow-v4.mts';
import { standing } from '../formation/formation-policy.mjs';

const { data } = await repoImport('src/shared/game.ts');
const { rangerTrackerIds, trackerRules } = await repoImport('src/shared/ranger-tracker.ts');
const { restRaidInput } = await repoImport('tests/helpers/sniper-rest-raid-policy.ts');
const { runtimeArena } = await repoImport('src/shared/arena-layouts.ts');
const { segmentRect, segmentCircle } = await repoImport('src/shared/geometry.ts');
export { waitFor };
const distance = (a,b) => Math.hypot(b.x-a.x,b.y-a.y);
const heading = (a,b) => Math.atan2(b.y-a.y,b.x-a.x);
const offset = (point,angle,length) => ({x:point.x+Math.cos(angle)*length,y:point.y+Math.sin(angle)*length});
function walk(from,to) {
  const aim=heading(from,to);
  return {moveX:Math.cos(aim),moveY:Math.sin(aim)};
}
function clear(world,from,to,pad=4) {
  return !world.obstacles.some(wall=>segmentRect(from,to,wall,pad)!==null);
}
function route(world,from,point) {
  const {x,y,width,height}=world.bounds;
  return point.x>=x+20 && point.y>=y+20 && point.x<=x+width-20 && point.y<=y+height-20 &&
    clear(world,from,point,19) && !world.lavaPits.some(pit=>segmentCircle(from,point,pit,pit.radius+19)!==null);
}

export async function trackerFlow(adapter,fitting) {
  const view = () => { const current=adapter.view(); assert(current); return current; };
  const owner = () => { const actor=view().players.find(row=>row.id===adapter.id); assert(actor); return actor; };
  const status = () => owner().kit.rangerTracker;
  const effort = () => restRaidInput(view(),owner(),[...adapter.observed.values()]);
  const ownedCost = () => owner().skills.reduce((sum,id)=>sum+[...data.skills,...data.specializationSkills].find(node=>node.id===id).cost,0);
  const purchases=[], attempts=[];
  const diagnose=()=>JSON.stringify({fitting,boss:view().boss.id,phase:view().phase,tick:view().combatTick,
    player:{x:owner().x,y:owner().y,ammo:owner().ammo,health:owner().health},status:status(),attempts:attempts.slice(-4)});
  async function buy(item) {
    assert((await adapter.purchase({kind:'skill',item})).ok,item);
    purchases.push({item,earned:ownedCost()+owner().sp,clears:owner().progress.clears});
  }
  async function outfit() {
    for (const bow of data.weapons.filter(row=>row.classId==='ranger').sort((a,b)=>b.tier-a.tier)) {
      if (owner().weapon===bow.id || (await adapter.purchase({kind:'weapon',item:bow.id})).ok) break;
    }
    for (const item of ['damage','health','fire-rate','reload','magazine']) await adapter.purchase({kind:'upgrade',item});
    await adapter.purchase({kind:'supply',item:'medkit'});
  }
  assert.equal(owner().sp,3);
  await buy('ranger-trailkeeping-1');
  await buy(rangerTrackerIds.entry);
  await waitFor(()=>!!status(),'owner receives Tracker action');
  if (fitting!=='entry') assert(!(await adapter.purchase({kind:'skill',item:rangerTrackerIds[fitting]})).ok);
  await outfit();
  adapter.start();
  await waitFor(()=>view().phase==='combat','Tracker opening combat');
  if (fitting!=='entry') {
    const deadline=Date.now()+135000;
    while (view().phase!=='shop') {
      assert(Date.now()<deadline && !['victory','defeat'].includes(view().phase),diagnose());
      if (view().phase==='combat') { adapter.input(effort()); adapter.ally?.(true); }
      if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(24);
    }
    assert.equal(owner().progress.clears,1);
    assert.equal(ownedCost()+owner().sp,5);
    await buy(rangerTrackerIds[fitting]);
    assert.equal((await adapter.purchase({kind:'skill',item:rangerTrackerIds[fitting==='stakes'?'backtrack':'stakes']})).reason,'incompatibleItem');
    await outfit();
    await waitFor(()=>view().phase==='combat','fitted Tracker combat',90000);
  }
  const firstClear=owner().progress.clears;
  console.log(JSON.stringify({type:'earned Tracker purchase',fitting,firstClear,purchases,boss:view().boss.id}));

  adapter.pause(true);
  await waitFor(()=>adapter.paused(),'pause acknowledged');
  const pausedAt=view().combatTick, pausedAmmo=owner().ammo;
  adapter.input({technique2:true});
  await sleep(120);
  assert.equal(view().combatTick,pausedAt);
  assert.equal(owner().ammo,pausedAmmo);
  assert(!status()?.until);
  adapter.input({});
  adapter.pause(false);
  await waitFor(()=>!adapter.paused() && view().combatTick>pausedAt,'Tracker resumed');

  const limit=Date.now()+110000;
  let trial, witness;
  while (Date.now()<limit && !['victory','defeat'].includes(view().phase)) {
    if (view().phase!=='combat') {
      if (['mutationVote','contractVote','secretOffer'].includes(view().phase)) adapter.vote(1);
      await sleep(40);
      continue;
    }
    const p=owner(), now=view().combatTick, trail=status(), enemy=view().boss;
    const world=runtimeArena(view().arenaId,view().run.difficulty);
    const aim=heading(p,enemy), base=effort(), quiet={...standing(base),aim};
    if (trial) {
      let events=adapter.events.slice(trial.events).filter(event=>event.owner===adapter.id);
      if (events.some(event=>event.type==='sound' && event.id==='ranger-track-recover')) {
        await waitFor(()=>view().boss.health<trial.health && status().stage==='recovering',diagnose,1800);
        events=adapter.events.slice(trial.events).filter(event=>event.owner===adapter.id);
        assert(trial.path.length>0,diagnose());
        if (fitting==='stakes') assert(events.some(event=>event.type==='sound' && event.id==='ranger-trip'),diagnose());
        return { passed:true,firstClear,fitting,boss:enemy.id,bought:purchases,witness,attempts,pauseRejected:true,
          result:{hit:true,recovered:true,damagingContact:trial.health-view().boss.health,from:trial.origin,until:trial.until,
            path:[...new Set(trial.path)],events:events.filter(event=>event.type==='sound').map(event=>event.id),ammo:owner().ammo} };
      }
      if (!trail.until) {
        trial.endedAt ??= now;
        if (now-trial.endedAt>=9) {
          attempts.push({until:trial.until,path:trial.path.slice(-12),reason:trail.stage});
          trial=undefined;
        }
      }
    }
    if (trail.stage==='ready' && (!trial) && p.ammo>=2 && p.reloadAt<=now && p.dashUntil<=now &&
      trail.footprints.some(point=>distance(point,enemy)<=75) && clear(world,p,enemy)) {
      adapter.ally?.(false);
      const start=adapter.input({...quiet,technique2:true});
      await waitFor(()=>owner().ack>=start || view().phase!=='combat',diagnose);
      adapter.input(quiet);
      const active=status();
      if (active?.origin && active.until>view().combatTick) {
        assert(active.until <= view().combatTick+trackerRules.duration);
        trial={ origin:active.origin,until:active.until,events:adapter.events.length,health:view().boss.health,path:[] };
        witness=await adapter.witness?.(active);
      }
    } else if (trial && trail.origin && trail.bearing!==undefined) {
      const {origin,bearing,stage}=trail;
      trial.path.push(stage);
      if (fitting==='stakes') {
        const range=distance(p,enemy);
        if (range>=78 && range<=157 && clear(world,p,enemy)) adapter.input({...quiet,e:true});
        else {
          const goal=offset(enemy,heading(enemy,p),range>157?111:118);
          adapter.input({...quiet,...(route(world,p,goal)?walk(p,goal):{moveX:base.moveX,moveY:base.moveY})});
        }
      } else if (stage==='follow' && clear(world,p,enemy)) {
        adapter.input({...quiet,fire:true});
      } else {
        const side=[bearing+Math.PI/2,bearing-Math.PI/2,bearing+Math.PI,bearing];
        const offsets=stage==='leave'?side:side.slice(0,2);
        const goal=stage==='return' ? origin :
          offsets.map(angle=>offset(origin,angle,stage==='leave'?trackerRules.leaveDistance+14:trackerRules.lateralDistance+14))
            .filter(point=>route(world,p,point)).sort((a,b)=>distance(p,a)-distance(p,b))[0];
        adapter.input({...quiet,...(goal && route(world,p,goal)?walk(p,goal):{moveX:base.moveX,moveY:base.moveY})});
      }
      adapter.ally?.(false);
    } else {
      adapter.input({...base,q:false,e:false,ultimate:false});
      adapter.ally?.(trial===undefined && trail.stage!=='ready');
    }
    await sleep(24);
  }
  throw Error('No verified Tracker recovery ' + diagnose());
}
