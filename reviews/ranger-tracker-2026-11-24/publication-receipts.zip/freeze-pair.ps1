param([Parameter(Mandatory)][ValidatePattern('^[0-9a-f]{40}$')][string]$Commit)
$ErrorActionPreference = 'Stop'
$taskScope = 'reviews/ranger-tracker-2026-11-24'
$taskGate = Get-Content -LiteralPath "$taskScope/source-verification.json" -Raw | ConvertFrom-Json
$taskPush = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-push01.json') -Raw | ConvertFrom-Json
$taskSource = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'source-commit01.json') -Raw | ConvertFrom-Json
if (!$taskGate.passed -or $taskGate.checks.Count -ne 7 -or $taskSource.sourceCommit -cne $Commit -or
    $taskSource.protocol -ne 103 -or $taskGate.runtimeSourceSha256 -cne $taskSource.runtimeSourceSha256 -or
    !$taskPush.passed -or $taskPush.head -cne $Commit -or $taskPush.branch -cne 'feat/first-playable-loop') { throw 'Exact full local gate and pushed source required.' }
$taskRoot = (Resolve-Path -LiteralPath '.').Path
$taskExpected = 'C:\Users\yigal\OneDrive\Documents\ChatGPT\OpenAI Multiplayer Game Contest (Bullet Hell)'
if ($taskRoot -cne $taskExpected) { throw 'Run in the canonical checkout.' }
$taskPointer = Get-Content -LiteralPath 'output/review-retention.json' -Raw | ConvertFrom-Json
if ($taskPointer.currentSourceCommit -cne 'a50e857eeb3df5d8de462540d1ae841e442afcdf' -or
    $taskPointer.rollbackArchiveSha256 -cne 'bf6df48333dc80c13fc40ab2b075eea5afe39ad8ba998cfb10a0a79e2b6905a1') { throw 'Previous verified pair or rollback changed.' }
foreach ($port in 5450,5451,2826,2827) {
  $probe = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$port)
  $probe.ExclusiveAddressUse = $true
  try { $probe.Start() } finally { $probe.Stop() }
}
$taskRootReport = 'reviews/runtime-verification.json'
$taskHistory = Join-Path $PSScriptRoot 'pre-freeze-root-runtime-verification.json'
if ((Test-Path -LiteralPath $taskHistory) -or (Test-Path -LiteralPath "$taskScope/preview-testing.json") -or
    (Test-Path -LiteralPath "$taskScope/preview-public.json")) { throw 'Preserve earlier preview identities.' }
Copy-Item -LiteralPath $taskRootReport -Destination $taskHistory
$taskPreviousReport = (Get-FileHash -LiteralPath $taskHistory).Hash
try {
  Copy-Item -LiteralPath "$taskScope/source-verification.json" -Destination $taskRootReport
  node tools/freeze-client-review.mjs $Commit testing $taskScope 5450 2826
  if ($LASTEXITCODE) { throw 'Inspect the testing freeze.' }
  node tools/freeze-client-review.mjs $Commit public $taskScope 5451 2827
  if ($LASTEXITCODE) { throw 'Inspect the public freeze.' }
}
finally {
  Copy-Item -LiteralPath $taskHistory -Destination $taskRootReport
  if ((Get-FileHash -LiteralPath $taskRootReport).Hash -cne $taskPreviousReport) { throw 'Historical root report differs.' }
}
foreach ($audience in 'testing','public') {
  $taskLog = Join-Path $PSScriptRoot ('launcher-'+$audience+'.log')
  $taskErrors = Join-Path $PSScriptRoot ('launcher-'+$audience+'-errors.log')
  $runner = (Get-Command pwsh).Source
  $taskLaunchArgs = @('-NoProfile','-File','tools/launch-review.ps1','-Audience',$audience,'-Scope',$taskScope)
  Start-Process -FilePath $runner -ArgumentList $taskLaunchArgs -WorkingDirectory $taskRoot -WindowStyle Hidden -RedirectStandardOutput $taskLog -RedirectStandardError $taskErrors | Out-Null
}
