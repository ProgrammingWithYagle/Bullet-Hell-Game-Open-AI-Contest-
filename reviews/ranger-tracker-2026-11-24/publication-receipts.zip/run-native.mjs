import assert from 'node:assert/strict';
import { existsSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { checkout, readJson, receipt } from '../bonded/study-paths.mjs';
import { digest, runChild } from '../bonded/run-native.mjs';

export const currentDriver = fileURLToPath(new URL('./native-ranger.mts',import.meta.url));
export { digest, runChild };
export function verifyNative(row,{transport,fitting,revision,worker,difficulty}) {
  assert(row.passed && row.protocol===103 && row.contentRevision===revision && row.transport===transport && row.fitting===fitting && row.difficulty===difficulty);
  assert.equal(row.driverSha256,digest(currentDriver));
  assert.equal(row.flowSha256,digest(new URL('./native-flow.mts',import.meta.url)));
  assert.equal(row.policySha256,digest(join(checkout,'tests/helpers/sniper-rest-raid-policy.ts')));
  const result=row.result;
  assert(row.pauseRejected && row.bought[1].earned===3 && result.hit && result.recovered && result.damagingContact>0);
  assert(result.events.includes('ranger-track-recover'));
  if (fitting!=='entry') assert(row.firstClear===1 && row.bought[2].earned===5);
  if (fitting==='stakes') assert(result.events.includes('ranger-stakes') && result.events.includes('ranger-trip'));
  if (fitting==='entry') assert(result.path.includes('flank') && result.path.includes('follow') && result.events.includes('ranger-release'));
  if (fitting==='backtrack') assert(['leave','return','follow'].every(stage=>result.path.includes(stage)) && result.events.includes('ranger-release'));
  if (transport==='worker') {
    assert(row.wholeOptimizedWorker && row.workerPatched===false);
    if (worker) assert.equal(row.workerSha256,worker);
  } else assert(row.peers===2 && row.witness.joinedNonHost && row.witness.ownerStateStayedPrivate);
}

async function local(folder,difficulty='normal',filter) {
  assert(folder&&!existsSync(folder));
  mkdirSync(folder);
  const {sha256:revision}=readJson(join(checkout,'content/revision.json'));
  const keys=['worker','peer'].flatMap(transport=>['entry','stakes','backtrack'].map(fitting=>[transport,fitting]));
  const chosen=filter? keys.filter(key=>filter.split(',').includes(key.join('-'))) : keys;
  assert(chosen.length);
  const cases=await Promise.all(chosen.map(async ([transport,fitting])=>{
    const stem=transport+'-'+fitting,raw=join(folder,stem+'.json'),log=join(folder,stem+'.log');
    const code=await runChild([currentDriver,transport,fitting,raw,'-','testing',difficulty],log,320000);
    const result=existsSync(raw)?readJson(raw):undefined;
    let error;
    if(code===0) {
      try {verifyNative(result,{transport,fitting,revision,difficulty});}
      catch(failed) {error=String(failed);}
    }
    const row={transport,fitting,code,error,passed:code===0&&!error&&result?.passed===true,logSha256:digest(log),rawSha256:result&&digest(raw)};
    console.log(JSON.stringify(row));
    return row;
  }));
  const passed=cases.every(row=>row.passed);
  receipt(join(folder,'checks.json'),{passed,difficulty,cases,driver:digest(currentDriver)});
  if(!passed)process.exitCode=1;
}

if(process.argv[1]===fileURLToPath(import.meta.url)) await local(...process.argv.slice(2));
